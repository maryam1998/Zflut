package com.linglearn.app.overlay;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

final class SherpaModelManager {

    private static final String TAG = "SherpaModelMgr";
    // منبع اصلیِ دانلود (Hugging Face). میرور (hf-mirror) عمداً استفاده نمی‌شود.
    private static final String HF_BASE = "https://huggingface.co/";

    private SherpaModelManager() {}

    interface ProgressCallback {
        void onProgress(String lang, long done, long total);
        void onDone(String lang);
        void onError(String lang, Exception e);
    }

    // ============ STT (تشخیص گفتار) ============
    private static final class Spec {
        final String repo;
        final String encoder, decoder, joiner, tokens;
        Spec(String repo, String encoder, String decoder, String joiner, String tokens) {
            this.repo = repo; this.encoder = encoder; this.decoder = decoder;
            this.joiner = joiner; this.tokens = tokens;
        }
        String[] files() { return new String[]{encoder, decoder, joiner, tokens}; }
    }

    private static final Map<String, Spec> SPECS;
    static {
        Map<String, Spec> m = new HashMap<>();
        m.put("en", new Spec(
                "csukuangfj/sherpa-onnx-streaming-zipformer-en-2023-06-26",
                "encoder-epoch-99-avg-1-chunk-16-left-128.int8.onnx",
                "decoder-epoch-99-avg-1-chunk-16-left-128.onnx",
                "joiner-epoch-99-avg-1-chunk-16-left-128.int8.onnx",
                "tokens.txt"));
        m.put("zh", new Spec(
                "csukuangfj/sherpa-onnx-streaming-zipformer-bilingual-zh-en-2023-02-20",
                "encoder-epoch-99-avg-1.int8.onnx",
                "decoder-epoch-99-avg-1.onnx",
                "joiner-epoch-99-avg-1.int8.onnx",
                "tokens.txt"));
        // کره‌ای: Zipformer جریانی رسمی k2-fsa (encoder/joiner به‌صورت int8؛ decoder فول)
        m.put("ko", new Spec(
                "k2-fsa/sherpa-onnx-streaming-zipformer-korean-2024-06-16",
                "encoder-epoch-99-avg-1.int8.onnx",
                "decoder-epoch-99-avg-1.onnx",
                "joiner-epoch-99-avg-1.int8.onnx",
                "tokens.txt"));
        // روسی: Zipformer کوچکِ جریانیِ Vosk (فایل‌ها fp32 هستن، حدود ۹۵ مگ)
        m.put("ru", new Spec(
                "csukuangfj/sherpa-onnx-streaming-zipformer-small-ru-vosk-2025-08-16",
                "encoder.onnx", "decoder.onnx", "joiner.onnx", "tokens.txt"));
        // فرانسوی / آلمانی / اسپانیایی: بسته‌ی اختصاصیِ Sherpa نداریم (Whisper یا Vosk؛ نگاه کنید به WhisperModelManager / VoskModelManager)
        SPECS = Collections.unmodifiableMap(m);
    }

    // ============ TTS (تبدیل متن به گفتار) ============
    // موتورها:
    //   • فارسی: Piper/VITS (مدل Mana) + espeak-ng — بدون تغییر
    //   • Supertonic 3 (بسته‌ی مشترک، بدون espeak): de fr es it ru tr ar hi ko ja
    //   • Kokoro multi-lang v1.0 (بسته‌ی مشترک): en zh  (خودِ sherpa برای کلماتِ خارج از لغت‌نامه به espeak-ng-data نیاز دارد)
    static final String ENG_VITS = "vits";
    static final String ENG_SUPERTONIC = "supertonic";
    static final String ENG_KOKORO = "kokoro";

    /** بسته‌ی مشترکِ چندزبانه: یک بار دانلود می‌شود و برای چند زبان کار می‌کند. */
    static final class Pkg {
        final String id, repo;
        final String[] files;      // فایل‌های ریشه‌ی مخزن
        final String[] dirs;       // پوشه‌هایی که کاملاً از مخزن کپی می‌شوند
        final long approxBytes;    // فقط برای نوار پیشرفت
        final String[] zhFiles;    // فایل‌های مخصوصِ چینی؛ فقط وقتی زبان zh دانلود می‌شود گرفته می‌شوند
        Pkg(String id, String repo, String[] files, String[] dirs, long approxBytes) {
            this(id, repo, files, dirs, approxBytes, new String[0]);
        }
        Pkg(String id, String repo, String[] files, String[] dirs, long approxBytes, String[] zhFiles) {
            this.id = id; this.repo = repo; this.files = files; this.dirs = dirs; this.approxBytes = approxBytes;
            this.zhFiles = zhFiles;
        }
    }

    static final Pkg PKG_SUPERTONIC = new Pkg(
            "supertonic3",
            "csukuangfj2/sherpa-onnx-supertonic-3-tts-int8-2026-05-11",
            new String[]{"duration_predictor.int8.onnx", "text_encoder.int8.onnx",
                    "vector_estimator.int8.onnx", "vocoder.int8.onnx",
                    "tts.json", "unicode_indexer.bin", "voice.bin"},
            new String[0],
            146_000_000L);

    static final Pkg PKG_KOKORO = new Pkg(
            "kokoro-multi-lang-v1_0",
            "csukuangfj/kokoro-multi-lang-v1_0",
            new String[]{"model.onnx", "voices.bin", "tokens.txt", "lexicon-us-en.txt"},
            new String[]{"dict"},
            420_000_000L,
            new String[]{"lexicon-zh.txt", "date-zh.fst", "number-zh.fst"});

    static final class TtsSpec {
        final String repo;         // مخزن HuggingFace
        final String modelFile;    // فایل .onnx داخل مخزن (فقط VITS)
        final String tokensFile;   // فایل tokens.txt (فقط VITS)
        final String dataDirName;  // نام پوشه espeak-ng-data (فقط VITS)
        // true = مخزن فقط فایل خام Piper (.onnx + .onnx.json) دارد (بدون tokens.txt و metadata سازگار با Sherpa)؛
        // tokens.txt از json ساخته و metadata به خود onnx اضافه می‌شود. espeak-ng-data هم از مخزن دیگری می‌آید.
        final boolean rawPiper;
        // true = بدون espeak-ng: متن را PersianG2P به نمادهای مدل تبدیل می‌کند و Sherpa با frontend=characters می‌خواندش
        final boolean charFrontend;
        final String engine;       // ENG_*
        final Pkg pkg;             // != null → بسته‌ی مشترک (Supertonic / Kokoro)
        TtsSpec(String repo, String modelFile, String tokensFile, String dataDirName) {
            this(repo, modelFile, tokensFile, dataDirName, false);
        }
        TtsSpec(String repo, String modelFile, String tokensFile, String dataDirName, boolean rawPiper) {
            this(repo, modelFile, tokensFile, dataDirName, rawPiper, false);
        }
        TtsSpec(String repo, String modelFile, String tokensFile, String dataDirName, boolean rawPiper, boolean charFrontend) {
            this.repo = repo;
            this.modelFile = modelFile;
            this.tokensFile = tokensFile;
            this.dataDirName = dataDirName;
            this.rawPiper = rawPiper;
            this.charFrontend = charFrontend;
            this.engine = ENG_VITS;
            this.pkg = null;
        }
        TtsSpec(Pkg pkg, String engine) {
            this.repo = pkg.repo;
            this.modelFile = null;
            this.tokensFile = null;
            this.dataDirName = null;
            this.rawPiper = false;
            this.charFrontend = false;
            this.engine = engine;
            this.pkg = pkg;
        }
    }

    private static final Map<String, TtsSpec> TTS_SPECS;
    static {
        Map<String, TtsSpec> m = new LinkedHashMap<>();

        // فارسی: Mana (مجوز MIT) — مخزنش فایل خام Piper است، پس rawPiper. (بدون تغییر؛ نیازمند espeak-ng)
        m.put("fa", new TtsSpec(
                "MahtaFetrat/Mana-Persian-Piper",
                "fa_IR-mana-medium.onnx", "tokens.txt", "espeak-ng-data", true, false));   // سارا: دوباره با espeak-ng (تلفظِ دقیق‌تر)

        // انگلیسی و چینی: Kokoro multi-lang v1.0 (Apache-2.0)
        m.put("en", new TtsSpec(PKG_KOKORO, ENG_KOKORO));
        m.put("zh", new TtsSpec(PKG_KOKORO, ENG_KOKORO));

        // ده زبانِ دیگر: Supertonic 3 (مجوز OpenRAIL-M)
        for (String lg : new String[]{"de", "fr", "es", "it", "ru", "tr", "ar", "hi", "ko", "ja"}) {
            m.put(lg, new TtsSpec(PKG_SUPERTONIC, ENG_SUPERTONIC));
        }

        TTS_SPECS = Collections.unmodifiableMap(m);
    }

    // ============ چند صدا برای هر زبان ============
    // فارسی: صدای پیش‌فرض (Mana) + چند صدای اضافه‌ی Piper، مثل قبل (پوشه‌ی tts/fa و tts/fa__<id>).
    // Supertonic: ۱۰ گوینده (sid ۰..۹) داخل همان بسته‌ی مشترک؛ Kokoro: چند گوینده‌ی منتخب.
    // صدای فعال در فایل tts/<lang>.active ثبت می‌شود (TtsService در پردازه‌ی جدا اجرا می‌شود).
    static final class TtsVoice {
        final String id;
        final String label;
        final TtsSpec spec;
        final boolean isDefault;
        final int sid;
        TtsVoice(String id, String label, TtsSpec spec, boolean isDefault) {
            this(id, label, spec, isDefault, 0);
        }
        TtsVoice(String id, String label, TtsSpec spec, boolean isDefault, int sid) {
            this.id = id; this.label = label; this.spec = spec; this.isDefault = isDefault; this.sid = sid;
        }
    }

    // {id, برچسب, sid}  — ترتیبِ sid در Kokoro v1.0 (۵۳ گوینده، الفبایی). پیش‌فرض = اولی.
    private static final String[][] KOKORO_EN = {
            {"af_bella", "Alicia · US · F", "2"}, {"af_nicole", "Amara · US · F", "6"},
            {"af_heart", "Ariana · US · F", "3"}, {"af_sarah", "Daisy · US · F", "9"},
            {"am_michael", "Caleb · US · M", "16"}, {"am_adam", "Daniel · US · M", "11"},
            {"bf_emma", "Josie · UK · F", "21"}, {"bm_george", "Edmund · UK · M", "26"},
    };
    private static final String[][] KOKORO_ZH = {
            {"zf_xiaoxiao", "Jiao · F", "47"}, {"zf_xiaobei", "Yuxan · F", "45"},
            {"zf_xiaoni", "Mei · F", "46"}, {"zf_xiaoyi", "Lian · F", "48"},
            {"zm_yunxi", "Tao · M", "50"}, {"zm_yunjian", "Wei · M", "49"},
            {"zm_yunyang", "Hao · M", "52"},
    };
    private static final int SUPERTONIC_VOICES = 10;
    /** صدای سبکِ انگلیسی (Piper low، حدود ۶۰ مگ؛ بسیار سریع‌تر از Kokoro). */
    static final String EN_LIGHT_VOICE = "en_US-lessac-low";
    // نام‌های نمایشیِ صداهای Supertonic (به ترتیبِ sid ۰..۹). ترتیبِ واقعیِ voice.bin: ۵ زن (F1..F5) و بعد ۵ مرد (M1..M5).
    // ⚠️ برچسب‌ها قبلاً برعکس بود (sid ۰..۴ در واقع زن‌اند). فقط برچسب عوض شده؛ شناسه‌ها (st-0..st-9) و sid ثابت مانده‌اند.
    private static final String[] SUPERTONIC_NAMES = {
            "Aria · F", "Clara · F", "Luna · F", "Mila · F", "Nora · F",
            "Adrian · M", "Felix · M", "Leo · M", "Oscar · M", "Theo · M",
    };
    // نام‌های نمایشیِ صداهای Supertonic برای هر زبان (۵ زن اول، ۵ مرد بعد؛ به ترتیبِ sid ۰..۹). زبانِ ناموجود → SUPERTONIC_NAMES بالا.
    private static final Map<String, String[]> SUPERTONIC_NAMES_BY_LANG = new LinkedHashMap<>();
    static {
        SUPERTONIC_NAMES_BY_LANG.put("fr", new String[]{"Adélie", "Justine", "Diya", "Camille", "Margaux", "Axel", "Guillaume", "Carlos", "Hugo", "Lucas"});
        SUPERTONIC_NAMES_BY_LANG.put("de", new String[]{"Josephine", "Lara", "Diya", "Heidi", "Greta", "Björn", "Matthias", "Ralf", "Carlos", "Jonas"});
        SUPERTONIC_NAMES_BY_LANG.put("es", new String[]{"Carmen", "Luisa", "Valeria", "Lara", "Sofia", "Carlos", "Axel", "Javier", "Joshua", "Mateo"});
        SUPERTONIC_NAMES_BY_LANG.put("it", new String[]{"Greta", "Diya", "Giulia", "Chiara", "Elena", "Angelo", "Vincenzo", "Javier", "Carlos", "Marco"});
        SUPERTONIC_NAMES_BY_LANG.put("ru", new String[]{"Anya", "Natasha", "Olga", "Irina", "Katya", "Dmitri", "Ivan", "Sergei", "Pavel", "Nikolai"});
        SUPERTONIC_NAMES_BY_LANG.put("tr", new String[]{"Diya", "Heidi", "Namrita", "Elif", "Selin", "Abhinav", "Bertie", "Jonathan", "Emre", "Mert"});
        SUPERTONIC_NAMES_BY_LANG.put("ar", new String[]{"Layla", "Noor", "Salma", "Yasmin", "Huda", "Omar", "Karim", "Tariq", "Samir", "Zayd"});
        SUPERTONIC_NAMES_BY_LANG.put("hi", new String[]{"Ayushi", "Khyati", "Shweta", "Sunaina", "Priya", "Aman", "Karan", "Aarav", "Abhinav", "Rohan"});
        SUPERTONIC_NAMES_BY_LANG.put("ko", new String[]{"Jangmi", "Minseo", "Soyeon", "Hyejin", "Yuna", "Gyeong", "Hwan", "Jong-su", "Seok", "Minho"});
        SUPERTONIC_NAMES_BY_LANG.put("ja", new String[]{"Kimi", "Minseo", "Haruka", "Sakura", "Yui", "Denki", "Kenji", "Hiroshi", "Takeshi", "Ren"});
    }
    private static String supertonicName(String lang, int i) {
        String[] n = SUPERTONIC_NAMES_BY_LANG.get(lang);
        if (n == null || i < 0 || i >= n.length) return SUPERTONIC_NAMES[i];
        return n[i] + (i < 5 ? " · F" : " · M");
    }
    // نام‌های نمایشیِ صداهای فارسی (فقط برچسب؛ شناسه‌ی مدل‌ها عوض نمی‌شود) — لاتین + F/M مثلِ بقیه‌ی زبان‌ها، تا در همه‌ی زبان‌های رابط ترجمه‌شده باشد
    private static final Map<String, String> FA_LABELS = new LinkedHashMap<>();
    static {
        FA_LABELS.put("fa_IR-mana-medium", "Sara · F");
        FA_LABELS.put("fa_IR-amir-medium", "Arman · M");
        FA_LABELS.put("fa_IR-ganji-medium", "Kamran · M");
        FA_LABELS.put("fa_IR-ganji_adabi-medium", "Bahram · M");
        FA_LABELS.put("fa_IR-reza_ibrahim-medium", "Pouya · M");
        // انگلیسیِ سبک (Piper low): برچسب مثلِ بقیه‌ی صداهای en؛ رده‌ی «low» را خودِ getTtsVoices بعدش اضافه می‌کند
        FA_LABELS.put(EN_LIGHT_VOICE, "Chloe · US · F");
        // دو صدای مردِ Piper انگلیسی: نام‌های باقی‌مانده‌ی لیست
        FA_LABELS.put("en_US-danny-low", "Gordon · US · M");
        FA_LABELS.put("en_GB-alan-low", "Miles · UK · M");
        FA_LABELS.put("en_GB-southern_english_female-low", "Poppy · UK · F");
    }

    private static final Map<String, List<TtsVoice>> TTS_VOICES;
    static {
        Map<String, List<TtsVoice>> vm = new LinkedHashMap<>();
        for (Map.Entry<String, TtsSpec> e : TTS_SPECS.entrySet()) {
            String lg = e.getKey();
            TtsSpec sp = e.getValue();
            List<TtsVoice> list = new ArrayList<>();
            if (sp.pkg == null) {
                String pid = piperIdOf(sp);
                list.add(new TtsVoice(pid, voiceLabel(pid), sp, true));
            } else if (ENG_KOKORO.equals(sp.engine)) {
                String[][] vs = "zh".equals(lg) ? KOKORO_ZH : KOKORO_EN;
                for (int i = 0; i < vs.length; i++) {
                    list.add(new TtsVoice(vs[i][0], vs[i][1], sp, i == 0, Integer.parseInt(vs[i][2])));
                }
            } else {
                for (int i = 0; i < SUPERTONIC_VOICES; i++) {
                    list.add(new TtsVoice("st-" + i, supertonicName(lg, i), sp, i == 0, i));
                }
            }
            vm.put(lg, list);
        }
        // صداهای اضافه‌ی فارسی (Piper) — بدون تغییر
        String[] faExtra = {"fa_IR-amir-medium", "fa_IR-ganji-medium", "fa_IR-ganji_adabi-medium",
                "fa_IR-reza_ibrahim-medium"};
        List<TtsVoice> fa = vm.get("fa");
        if (fa != null) {
            for (final String pid : faExtra) {
                boolean dup = false;
                for (TtsVoice v : fa) if (v.id.equals(pid)) { dup = true; break; }
                if (dup) continue;
                fa.add(new TtsVoice(pid, voiceLabel(pid), new TtsSpec(
                        "csukuangfj/vits-piper-" + pid, pid + ".onnx", "tokens.txt", "espeak-ng-data"), false));
            }
        }
        // انگلیسی: علاوه بر Kokoro، یک گزینه‌ی سبک و سریع (Piper low). پیش‌فرض همان Kokoro می‌ماند (isDefault=false).
        List<TtsVoice> en = vm.get("en");
        if (en != null) {
            boolean dup = false;
            for (TtsVoice v : en) if (v.id.equals(EN_LIGHT_VOICE)) { dup = true; break; }
            if (!dup) {
                en.add(new TtsVoice(EN_LIGHT_VOICE, voiceLabel(EN_LIGHT_VOICE), new TtsSpec(
                        "csukuangfj/vits-piper-" + EN_LIGHT_VOICE, EN_LIGHT_VOICE + ".onnx",
                        "tokens.txt", "espeak-ng-data"), false));
            }
        }
        // 🪶 صداهای سبک و سریعِ Piper (low / x_low، ~۵ تا ۶۰ مگ) برای بقیه‌ی زبان‌ها — کنارِ مدلِ پیش‌فرض (Kokoro/Supertonic)
        // تا خوانش بدون تأخیر باشد. پیش‌فرض عوض نمی‌شود (isDefault=false). فارسی اضافه‌ای لازم ندارد.
        String[][] lightExtra = {
                {"en", "en_US-amy-low"}, {"en", "en_US-danny-low"}, {"en", "en_US-kathleen-low"},
                {"en", "en_GB-alan-low"}, {"en", "en_GB-southern_english_female-low"},
                {"de", "de_DE-thorsten-low"}, {"de", "de_DE-karlsson-low"}, {"de", "de_DE-kerstin-low"},
                {"de", "de_DE-ramona-low"}, {"de", "de_DE-pavoque-low"},
                {"fr", "fr_FR-siwis-low"}, {"fr", "fr_FR-gilles-low"},
                {"es", "es_ES-carlfm-x_low"},
                {"it", "it_IT-riccardo-x_low"},
                {"ar", "ar_JO-kareem-low"},
                {"zh", "zh_CN-huayan-x_low"},
        };
        for (String[] x : lightExtra) {
            List<TtsVoice> lst = vm.get(x[0]);
            if (lst == null) continue;
            final String pid = x[1];
            boolean dup = false;
            for (TtsVoice v : lst) if (v.id.equals(pid)) { dup = true; break; }
            if (dup) continue;
            lst.add(new TtsVoice(pid, voiceLabel(pid), new TtsSpec(
                    "csukuangfj/vits-piper-" + pid, pid + ".onnx", "tokens.txt", "espeak-ng-data"), false));
        }
        for (Map.Entry<String, List<TtsVoice>> e : vm.entrySet()) {
            e.setValue(Collections.unmodifiableList(e.getValue()));
        }
        TTS_VOICES = Collections.unmodifiableMap(vm);
    }

    /**
     * رده‌ی کیفیت/اندازه‌ی مدل برای نمایش در تنظیمات: low / medium / high.
     * Piper: از پسوند نامِ مدل (x_low و low → low). Kokoro (~۴۲۰MB) → high. Supertonic int8 (~۱۴۶MB) → medium.
     * (رده‌بندی بر اساس اندازه‌ی مدل است؛ مدلِ بزرگ‌تر معمولاً باکیفیت‌تر ولی کندتر است.)
     */
    static String tierOf(TtsVoice v) {
        if (v == null || v.spec == null) return "medium";
        if (ENG_KOKORO.equals(v.spec.engine)) return "high";
        if (ENG_SUPERTONIC.equals(v.spec.engine)) return "medium";
        String f = v.spec.modelFile == null ? "" : v.spec.modelFile.toLowerCase(java.util.Locale.ROOT);
        if (f.endsWith(".onnx")) f = f.substring(0, f.length() - 5);
        if (f.endsWith("x_low") || f.endsWith("-low")) return "low";
        if (f.endsWith("-high")) return "high";
        return "medium";
    }

    private static String piperIdOf(TtsSpec s) {
        String f = s.modelFile;
        if (f == null) return s.pkg != null ? s.pkg.id : "";
        return f.endsWith(".onnx") ? f.substring(0, f.length() - 5) : f;
    }

    /** en_US-amy-medium → «amy · US · medium» */
    private static String voiceLabel(String pid) {
        String custom = FA_LABELS.get(pid);
        if (custom != null) return custom;
        try {
            String[] p = pid.split("-");
            if (p.length < 3) return pid;
            String loc = p[0];
            int u = loc.indexOf('_');
            String region = u >= 0 ? loc.substring(u + 1) : loc;
            StringBuilder name = new StringBuilder();
            for (int i = 1; i < p.length - 1; i++) {
                if (name.length() > 0) name.append('-');
                name.append(p[i]);
            }
            return name.toString().replace('_', ' ') + " · " + region + " · " + p[p.length - 1].replace('_', ' ');
        } catch (Throwable t) {
            return pid;
        }
    }

    /**
     * 🎭 sid گوینده‌ی [vid] برای خوانشِ «همین یک جمله» (مثلاً دو نفرِ یک مکالمه با دو صدای متفاوت).
     * فقط وقتی معتبر است که آن صدا هم‌بسته‌ی (pkg) صدای فعال باشد (مثلاً همه‌ی صداهای Kokoro یک موتور و
     * یک مدل‌اند و فقط sid فرق می‌کند)؛ در غیر این‌صورت -1 = از صدای فعال استفاده کن.
     */
    static int sidForVoice(Context ctx, String lang, String vid) {
        try {
            String l = normalize(lang);
            if (l == null || vid == null || vid.isEmpty()) return -1;
            TtsVoice v = findVoice(l, vid);
            TtsVoice av = getReadyVoice(ctx, l);
            if (v == null || av == null || v.spec == null || av.spec == null) return -1;
            if (v.spec.pkg == null || av.spec.pkg == null) return -1;
            if (!v.spec.pkg.id.equals(av.spec.pkg.id)) return -1;
            return v.sid;
        } catch (Throwable t) {
            return -1;
        }
    }

    static List<TtsVoice> ttsVoices(String lang) {
        String l = normalize(lang);
        List<TtsVoice> v = l == null ? null : TTS_VOICES.get(l);
        return v == null ? Collections.<TtsVoice>emptyList() : v;
    }

    private static TtsVoice findVoice(String l, String vid) {
        List<TtsVoice> list = TTS_VOICES.get(l);
        if (list == null || list.isEmpty()) return null;
        if (vid != null && !vid.isEmpty()) {
            for (TtsVoice v : list) if (v.id.equals(vid)) return v;
        }
        return null;
    }

    private static File ttsRoot(Context ctx) {
        return new File(ctx.getFilesDir(), "tts");
    }

    private static File pkgDir(Context ctx, Pkg p) {
        return new File(new File(ttsRoot(ctx), "_pkg"), p.id);
    }

    // ---- غیرفعال‌سازیِ «یک زبان» از بسته‌ی مشترک (Supertonic / Kokoro) ----
    // پاک‌کردنِ یک زبان نباید فایل‌های مشترکِ بسته را پاک کند (زبان‌های دیگر همان‌ها را می‌خوانند).
    // پس فقط یک marker (tts/<lang>.off) ساخته می‌شود و آن زبان «دانلودنشده» حساب می‌شود.
    private static File langOffMarker(Context ctx, String l) {
        return new File(ttsRoot(ctx), l + ".off");
    }

    private static boolean isLangOff(Context ctx, String l) {
        return l != null && langOffMarker(ctx, l).isFile();
    }

    private static void setLangOff(Context ctx, String l, boolean off) {
        if (l == null) return;
        try {
            File f = langOffMarker(ctx, l);
            if (off) {
                File root = ttsRoot(ctx);
                if (!root.isDirectory()) root.mkdirs();
                if (!f.isFile()) f.createNewFile();
            } else if (f.isFile()) {
                f.delete();
            }
        } catch (Throwable t) {
            Log.w(TAG, "setLangOff failed", t);
        }
    }

    /** بسته‌ی مشترک کامل دانلود شده؟ (marker + همه‌ی فایل‌ها و پوشه‌ها) */
    private static boolean pkgReady(Context ctx, Pkg p) {
        File d = pkgDir(ctx, p);
        if (!new File(d, "ready.ok").isFile()) return false;
        for (String f : p.files) {
            File x = new File(d, f);
            if (!x.isFile() || x.length() == 0) return false;
        }
        for (String sub : p.dirs) {
            String[] ch = new File(d, sub).list();
            if (ch == null || ch.length == 0) return false;
        }
        return true;
    }

    /** فایل‌های اضافه‌ی مخصوصِ یک زبان از بسته‌ی مشترک (فعلاً فقط چینیِ Kokoro). */
    static String[] extraFilesFor(Pkg p, String l) {
        return "zh".equals(l) ? p.zhFiles : new String[0];
    }

    private static boolean extrasReady(Context ctx, Pkg p, String l) {
        File d = pkgDir(ctx, p);
        for (String f : extraFilesFor(p, l)) {
            File x = new File(d, f);
            if (!x.isFile() || x.length() == 0) return false;
        }
        return true;
    }

    /** بسته‌ی مشترک + فایل‌های مخصوصِ همین زبان کامل است؟ */
    private static boolean pkgReady(Context ctx, Pkg p, String l) {
        return pkgReady(ctx, p) && extrasReady(ctx, p, l);
    }

    /** فایلِ چینی دانلود شده؟ (TtsEngine برای ساختنِ تنظیماتِ موتور می‌پرسد) */
    static boolean zhExtrasReady(Context ctx, Pkg p) {
        return p.zhFiles.length > 0 && extrasReady(ctx, p, "zh");
    }

    /** فایلِ خراب پیدا شد: marker پاک می‌شود تا دانلودِ بعدی کم‌وکسرها را دوباره بگیرد. */
    static void invalidatePackage(Context ctx, Pkg p) {
        try { new File(pkgDir(ctx, p), "ready.ok").delete(); } catch (Throwable ignored) {}
    }

    static File voiceDir(Context ctx, String lang, TtsVoice v) {
        return ttsDirFor(ctx, normalize(lang), v);
    }

    private static File ttsDirFor(Context ctx, String l, TtsVoice v) {
        if (v != null && v.spec.pkg != null) return pkgDir(ctx, v.spec.pkg);
        return v == null || v.isDefault
                ? new File(ttsRoot(ctx), l)
                : new File(ttsRoot(ctx), l + "__" + v.id);
    }

    /** صدای فعالِ این زبان (اگر انتخابی ثبت نشده یا نامعتبر باشد = صدای پیش‌فرض). */
    static TtsVoice activeVoice(Context ctx, String lang) {
        String l = normalize(lang);
        List<TtsVoice> list = l == null ? null : TTS_VOICES.get(l);
        if (list == null || list.isEmpty()) return null;
        try {
            File f = new File(ttsRoot(ctx), l + ".active");
            if (f.isFile() && f.length() > 0 && f.length() < 200) {
                byte[] b = new byte[(int) f.length()];
                try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                    int off = 0, n;
                    while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
                }
                TtsVoice v = findVoice(l, new String(b, "UTF-8").trim());
                if (v != null) return v;
            }
        } catch (Throwable ignored) {}
        // وقتی کاربر صدایی انتخاب نکرده: صدای پیش‌فرضِ هر زبان (فارسی: «کامران»؛ بقیه: مدل سبکِ low — جدول PREFERRED_VOICE)
        String prefId = PREFERRED_VOICE.get(l);
        if (prefId != null) {
            TtsVoice pv = findVoice(l, prefId);
            if (pv != null) return pv;
        }
        return list.get(0);
    }

    /** صدای پیش‌فرضِ فارسی (وقتی انتخابی ثبت نشده). */
    static final String FA_PREFERRED_VOICE = "fa_IR-ganji-medium";

    /**
     * ⭐ صدای پیش‌فرضِ هر زبان (وقتی کاربر چیزی انتخاب نکرده). فقط همین‌جا را عوض کنید تا پیش‌فرض عوض شود.
     * مدل‌های low سریع‌ترند. زبان‌هایی که مدل low ندارند (ru, tr, hi, ko, ja) اینجا نیستند و همان صدای اول (Supertonic) می‌مانند.
     * اگر مدلِ پیش‌فرض دانلود نشده باشد ولی Kokoro/Supertonic از قبل آماده باشد، getReadyVoice به همان برمی‌گردد.
     */
    private static final Map<String, String> PREFERRED_VOICE;
    static {
        Map<String, String> pm = new LinkedHashMap<>();
        pm.put("fa", FA_PREFERRED_VOICE);                 // فارسی بدون تغییر
        pm.put("en", EN_LIGHT_VOICE);                     // en_US-lessac-low
        pm.put("de", "de_DE-thorsten-low");
        pm.put("fr", "fr_FR-siwis-low");
        pm.put("es", "es_ES-carlfm-x_low");
        pm.put("it", "it_IT-riccardo-x_low");
        pm.put("ar", "ar_JO-kareem-low");
        pm.put("zh", "zh_CN-huayan-x_low");
        PREFERRED_VOICE = Collections.unmodifiableMap(pm);
    }

    /** برچسبِ «پیش‌فرض» در فهرستِ صداها (صدای PREFERRED_VOICE؛ اگر برای زبان تعریف نشده: صدای اول). */
    static boolean isShownDefault(String lang, TtsVoice v) {
        if (v == null) return false;
        String pid = PREFERRED_VOICE.get(normalize(lang));
        return pid != null ? pid.equals(v.id) : v.isDefault;
    }

    static void setActiveVoice(Context ctx, String lang, String vid) {
        String l = normalize(lang);
        if (l == null || !TTS_VOICES.containsKey(l)) return;
        try {
            File root = ttsRoot(ctx);
            if (!root.isDirectory()) root.mkdirs();
            File f = new File(root, l + ".active");
            TtsVoice v = findVoice(l, vid);
            // پیش‌فرض = بدون فایل. اگر برای زبان PREFERRED_VOICE تعریف شده، پیش‌فرض همان است
            // و انتخابِ صریحِ صدای دیگر (مثلاً Kokoro یا سارا) باید در فایل بماند
            if (v == null) { f.delete(); return; }
            String prefId = PREFERRED_VOICE.get(l);
            if (prefId != null ? prefId.equals(v.id) : v.isDefault) { f.delete(); return; }
            try (FileOutputStream out = new FileOutputStream(f, false)) {
                out.write(v.id.getBytes("UTF-8"));
            }
        } catch (Throwable t) {
            Log.w(TAG, "setActiveVoice failed", t);
        }
    }

    private static boolean voiceFilesReady(Context ctx, String l, TtsVoice v) {
        if (v == null) return false;
        if (v.spec.pkg != null) {
            if (isLangOff(ctx, l)) return false;   // این زبان توسط کاربر پاک شده (بسته‌ی مشترک سر جایش است)
            if (!pkgReady(ctx, v.spec.pkg, l)) return false;
            // Kokoro برای کلماتِ خارج از لغت‌نامه به espeak-ng-data نیاز دارد
            return !ENG_KOKORO.equals(v.spec.engine) || isEspeakReady(ctx);
        }
        File dir = ttsDirFor(ctx, l, v);
        File model = new File(dir, "model.onnx");
        File tokens = new File(dir, "tokens.txt");
        if (!model.isFile() || model.length() == 0) return false;
        if (!tokens.isFile() || tokens.length() == 0) return false;
        // صدای پیش‌فرضِ en/fa عوض شده؛ فایل‌های قدیمیِ همان پوشه (ryan/gyro) نباید به‌جای صدای جدید حساب شوند
        if (v.isDefault && MIGRATED_LANGS.contains(l) && !v.id.equals(readVoiceMarker(dir))) return false;
        if (v.spec.charFrontend) return new File(dir, "meta-char2.ok").isFile();   // بدون espeak-ng
        if (v.spec.rawPiper && !new File(dir, "meta.ok").isFile()) return false;
        return isEspeakReady(ctx);
    }

    private static final Set<String> MIGRATED_LANGS =
            Collections.unmodifiableSet(new java.util.HashSet<>(java.util.Arrays.asList("en", "fa", "fr")));

    /** espeak-ng-data برای مدل‌هایی که مخزنشان آن را ندارد (rawPiper) از این مخزن گرفته می‌شود. */
    private static final String ESPEAK_FALLBACK_REPO = "csukuangfj/vits-piper-en_US-amy-low";

    private static String readVoiceMarker(File dir) {
        try {
            File f = new File(dir, "voice.id");
            if (!f.isFile() || f.length() == 0 || f.length() > 200) return "";
            byte[] b = new byte[(int) f.length()];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int off = 0, n;
                while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            }
            return new String(b, "UTF-8").trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static void writeVoiceMarker(File dir, String id) {
        try (FileOutputStream out = new FileOutputStream(new File(dir, "voice.id"), false)) {
            out.write(id.getBytes("UTF-8"));
        } catch (Throwable t) {
            Log.w(TAG, "writeVoiceMarker failed", t);
        }
    }

    /** این صدا (نه لزوماً فعال) کامل دانلود شده؟ */
    static boolean isTtsVoiceInstalled(Context ctx, String lang, String vid) {
        String l = normalize(lang);
        if (l == null) return false;
        TtsVoice v = vid == null || vid.isEmpty() ? activeVoice(ctx, l) : findVoice(l, vid);
        return voiceFilesReady(ctx, l, v);
    }

    /** صدایی که الان برای این زبان در حال دانلود است (null = هیچ). */
    private static final Map<String, String> TTS_DL_VOICE = new ConcurrentHashMap<>();

    static String downloadingVoiceId(String lang) {
        String l = normalize(lang);
        return l == null ? null : TTS_DL_VOICE.get(l);
    }

    static long getTtsPartialBytes(Context ctx, String lang, String vid) {
        String l = normalize(lang);
        if (l == null) return 0;
        TtsVoice v = vid == null || vid.isEmpty() ? activeVoice(ctx, l) : findVoice(l, vid);
        if (v == null) return 0;
        if (v.spec.pkg != null) {
            if (pkgReady(ctx, v.spec.pkg, l)) return 0;
            long sum = 0;
            File[] fs = pkgDir(ctx, v.spec.pkg).listFiles();
            if (fs != null) for (File f : fs) if (f.isFile() && !f.getName().equals("ready.ok")) sum += f.length();
            return sum;
        }
        File part = new File(ttsDirFor(ctx, l, v), "model.onnx.part");
        return part.isFile() ? part.length() : 0;
    }

    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build();
    private static final AtomicBoolean DOWNLOADING = new AtomicBoolean(false);
    private static volatile boolean DOWNLOADING_STATE = false;
    // دانلودِ TTS برای هر زبان مستقله؛ چند زبان می‌تونن هم‌زمان دانلود بشن
    private static final Set<String> TTS_ACTIVE = ConcurrentHashMap.newKeySet();
    // espeak-ng-data بینِ همه‌ی زبان‌ها مشترکه؛ فقط یک نخ دانلودش می‌کنه، بقیه صبر می‌کنن
    private static final ReentrantLock ESPEAK_LOCK = new ReentrantLock();
    // زبان‌هایی که کاربر «توقف» رو زده؛ فایل .part نگه داشته می‌شه تا دفعه‌ی بعد ادامه پیدا کنه
    private static final Set<String> TTS_CANCEL = ConcurrentHashMap.newKeySet();

    /** پرتاب می‌شه وقتی کاربر دانلود رو متوقف کرده. */
    static final class DownloadCancelled extends java.io.IOException {
        DownloadCancelled() { super("cancelled"); }
    }

    static void cancelTtsDownload(String lang) {
        String l = normalize(lang);
        if (l != null && TTS_ACTIVE.contains(l)) TTS_CANCEL.add(l);
    }

    static void cancelAllTtsDownloads() {
        TTS_CANCEL.addAll(TTS_ACTIVE);
    }

    private static void checkCancel(String l) throws DownloadCancelled {
        if (l != null && TTS_CANCEL.contains(l)) throw new DownloadCancelled();
    }

    /** حجمِ بخشِ دانلودشده‌ی ناتمامِ بسته‌ی یه زبان (برای دکمه‌ی «ادامه»). */
    static long getTtsPartialBytes(Context ctx, String lang) {
        return getTtsPartialBytes(ctx, lang, null);
    }
    // آخرین مقدارِ پیشرفتِ هر زبان (بایت) — برای نوتیفیکیشنِ سرویسِ دانلود
    private static final Map<String, Long> TTS_BYTES = new ConcurrentHashMap<>();

    static long getTtsDownloadedBytes() {
        long sum = 0;
        for (Long v : TTS_BYTES.values()) if (v != null) sum += v;
        return sum;
    }

    // ============ متدهای مشترک ============
    static String normalize(String lang) {
        if (lang == null) return null;
        String l = lang.trim().toLowerCase(Locale.ROOT);
        int i = l.indexOf('-');
        if (i < 0) i = l.indexOf('_');
        if (i > 0) l = l.substring(0, i);
        return l.isEmpty() ? null : l;
    }

    // ============ STT ============
    static boolean isAvailable(String lang) {
        String l = normalize(lang);
        return l != null && SPECS.containsKey(l);
    }

    static boolean isDownloading() { return DOWNLOADING_STATE; }

    private static File sttDirFor(Context ctx, String l) {
        return new File(new File(ctx.getFilesDir(), "sherpa"), l);
    }

    static File getModelDir(Context ctx, String lang) {
        String l = normalize(lang);
        Spec s = l == null ? null : SPECS.get(l);
        if (s == null) return null;
        File dir = sttDirFor(ctx, l);
        for (String f : s.files()) {
            File x = new File(dir, f);
            if (!x.isFile() || x.length() == 0) return null;
        }
        return dir;
    }

    static String encoderFile(String lang) { Spec s = SPECS.get(normalize(lang)); return s == null ? null : s.encoder; }
    static String decoderFile(String lang) { Spec s = SPECS.get(normalize(lang)); return s == null ? null : s.decoder; }
    static String joinerFile(String lang)  { Spec s = SPECS.get(normalize(lang)); return s == null ? null : s.joiner; }
    static String tokensFile(String lang)  { Spec s = SPECS.get(normalize(lang)); return s == null ? null : s.tokens; }

    // ============ TTS ============
    static boolean isTtsAvailable(String lang) {
        String l = normalize(lang);
        return l != null && TTS_SPECS.containsKey(l);
    }

    /** زبان‌هایی که بسته TTS آفلاین دارن (به ترتیب تعریف). */
    static List<String> ttsLanguages() {
        return new ArrayList<>(TTS_SPECS.keySet());
    }

    /** زبان‌هایی که بسته TTS‌شون همین الان در حال دانلوده. */
    static List<String> getTtsDownloadingLangs() {
        return new ArrayList<>(TTS_ACTIVE);
    }

    static boolean isTtsDownloading() { return !TTS_ACTIVE.isEmpty(); }

    static boolean isTtsDownloading(String lang) {
        String l = normalize(lang);
        return l != null && TTS_ACTIVE.contains(l);
    }

    /** espeak-ng-data مشترکِ همه‌ی بسته‌های Piper (یک بار دانلود می‌شه). */
    static File getEspeakDataDir(Context ctx) {
        return new File(new File(ctx.getFilesDir(), "tts"), "espeak-ng-data");
    }

    private static File espeakMarker(Context ctx) {
        return new File(new File(ctx.getFilesDir(), "tts"), "espeak-ng-data.ok");
    }

    private static boolean isEspeakReady(Context ctx) {
        return espeakMarker(ctx).isFile() && getEspeakDataDir(ctx).isDirectory();
    }

    /** espeak-ng-data ناقص/خراب بود: marker رو پاک کن تا دانلودِ بعدی فایل‌های کم‌وکسر رو دوباره بگیره. */
    static void invalidateEspeak(Context ctx) {
        try { espeakMarker(ctx).delete(); } catch (Throwable ignored) {}
    }

    /** صدایی که الان آماده‌ی استفاده است (فعال؛ اگر سالم نبود پیش‌فرض)، یا null. */
    static TtsVoice getReadyVoice(Context ctx, String lang) {
        String l = normalize(lang);
        if (l == null || !TTS_SPECS.containsKey(l)) return null;
        cleanupLegacyTts(ctx);
        TtsVoice v = activeVoice(ctx, l);
        if (voiceFilesReady(ctx, l, v)) return v;
        // صدای انتخاب‌شده سالم نیست (مثلاً ناقص/حذف‌شده) → به صدای پیش‌فرض برگرد تا خوانش قطع نشود
        List<TtsVoice> all = TTS_VOICES.get(l);
        if (all != null && !all.isEmpty() && all.get(0) != v && voiceFilesReady(ctx, l, all.get(0))) {
            return all.get(0);
        }
        return null;
    }

    static File getTtsModelDir(Context ctx, String lang) {
        String l = normalize(lang);
        TtsVoice v = getReadyVoice(ctx, lang);
        return v == null ? null : ttsDirFor(ctx, l, v);
    }

    // ============ پاک‌سازیِ صداهای قدیمیِ Piper (غیرِ فارسی) ============
    // فقط یک بار: پوشه‌های tts/<lang> و tts/<lang>__* و فایل‌های <lang>.active زبان‌هایی که حالا Supertonic/Kokoro دارند.
    // فارسی، espeak-ng-data و بسته‌های جدید (_pkg) دست‌نخورده می‌مانند.
    private static volatile boolean LEGACY_DONE = false;
    private static final String[] LEGACY_PIPER_LANGS =
            {"en", "es", "de", "fr", "it", "hi", "tr", "ar", "zh", "ru", "ko", "ja", "he"};

    /** نامِ پوشه‌ی یکی از صداهای Piper ی «فعلی» (غیرِ بسته‌ی مشترک) است؟ */
    private static boolean isCurrentPiperDir(String name) {
        for (Map.Entry<String, List<TtsVoice>> e : TTS_VOICES.entrySet()) {
            for (TtsVoice v : e.getValue()) {
                if (v.spec.pkg != null) continue;
                String d = v.isDefault ? e.getKey() : e.getKey() + "__" + v.id;
                if (d.equals(name)) return true;
            }
        }
        return false;
    }

    static void cleanupLegacyTts(Context ctx) {
        if (LEGACY_DONE) return;
        LEGACY_DONE = true;
        try {
            File root = ttsRoot(ctx);
            File marker = new File(root, "legacy-piper-removed.v1");
            if (!root.isDirectory()) {
                // نصبِ تازه: چیزی برای پاک‌کردن نیست. marker همین‌جا ساخته می‌شود، وگرنه بعدِ دانلودِ صدای Piper ی انگلیسی
                // در اجرای بعدی این پاک‌سازی آن را (و en.active را) به‌عنوانِ «قدیمی» پاک می‌کرد.
                if (root.mkdirs()) { try { marker.createNewFile(); } catch (Throwable ignored) {} }
                return;
            }
            if (marker.isFile()) return;
            File[] fs = root.listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName();
                    if (isCurrentPiperDir(n)) continue;   // صداهای Piper ی فعلی (مثلاً en__en_US-lessac-low) قدیمی نیستند
                    for (String lg : LEGACY_PIPER_LANGS) {
                        if (n.equals(lg) || n.startsWith(lg + "__") || n.equals(lg + ".active")) {
                            deleteRecursive(f);
                            break;
                        }
                    }
                }
            }
            try { marker.createNewFile(); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            Log.w(TAG, "cleanupLegacyTts failed", t);
        }
    }

    // ============ دانلود STT ============
    // توقف/ادامه مثلِ دانلودِ صدا: فایل‌های .part نگه داشته می‌شن و دانلودِ بعدی با Range ادامه پیدا می‌کنه.
    private static volatile boolean STT_CANCEL = false;
    private static volatile String STT_ACTIVE = null;

    /** توقفِ دانلودِ بسته‌ی تشخیص گفتار (بخشِ دانلودشده می‌مونه). */
    static void cancelDownload() { if (DOWNLOADING.get()) STT_CANCEL = true; }

    /** زبانی که همین الان بسته‌اش دانلود می‌شه (یا null). */
    static String activeDownloadLang() { return STT_ACTIVE; }

    /** حجمِ بخشِ دانلودشده‌ی ناتمامِ بسته‌ی یه زبان (برای دکمه‌ی «ادامه»). */
    static long getSttPartialBytes(Context ctx, String lang) {
        String l = normalize(lang);
        Spec s = l == null ? null : SPECS.get(l);
        if (s == null) return 0;
        long sum = 0;
        File dir = sttDirFor(ctx, l);
        for (String f : s.files()) {
            File p = new File(dir, f + ".part");
            if (p.isFile()) sum += p.length();
        }
        return sum;
    }

    static void downloadModel(final Context ctx, final String lang, final ProgressCallback cb) {
        final Context app = ctx.getApplicationContext();
        final String l = normalize(lang);
        final Spec s = l == null ? null : SPECS.get(l);
        if (s == null) {
            if (cb != null) cb.onError(String.valueOf(lang), new IllegalArgumentException("no model for " + lang));
            return;
        }
        if (!DOWNLOADING.compareAndSet(false, true)) {
            if (cb != null) cb.onError(l, new IllegalStateException("another download is running"));
            return;
        }
        DOWNLOADING_STATE = true;
        STT_CANCEL = false;
        STT_ACTIVE = l;
        Thread t = new Thread(() -> {
            Exception failure = null;
            try {
                File dir = sttDirFor(app, l);
                if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("cannot create " + dir);
                long[] done = {0};
                for (String name : s.files()) {
                    if (STT_CANCEL) throw new DownloadCancelled();
                    File target = new File(dir, name);
                    if (target.isFile() && target.length() > 0) { done[0] += target.length(); continue; }
                    downloadSttFile(HF_BASE + s.repo + "/resolve/main/" + name, target, cb, l, done);
                }
            } catch (Exception e) {
                if (!(e instanceof DownloadCancelled)) Log.w(TAG, "STT download failed for " + l, e);
                failure = e;
            } finally {
                // اول وضعیت رو پاک کن، بعد به JS خبر بده — وگرنه JS موقعِ refresh هنوز «در حال دانلود» می‌بینه
                STT_ACTIVE = null;
                STT_CANCEL = false;
                DOWNLOADING.set(false);
                DOWNLOADING_STATE = false;
            }
            if (cb != null) {
                if (failure == null) cb.onDone(l); else cb.onError(l, failure);
            }
        }, "sherpa-download");
        t.setDaemon(true);
        t.start();
    }

    /** یک فایلِ بسته‌ی STT رو با امکانِ ادامه (Range) و توقفِ کاربر می‌گیره. done[0] = مجموعِ بایت‌های همه‌ی فایل‌ها. */
    private static void downloadSttFile(String url, File target, ProgressCallback cb, String l, long[] done) throws Exception {
        File part = new File(target.getParentFile(), target.getName() + ".part");
        long existing = part.isFile() ? part.length() : 0;
        Request.Builder rb = new Request.Builder().url(url);
        if (existing > 0) rb.header("Range", "bytes=" + existing + "-");
        try (Response r = HTTP.newCall(rb.build()).execute()) {
            if (r.code() == 416) {
                // بخشِ قبلی با فایلِ سرور نمی‌خونه؛ از اول می‌گیریم
                part.delete();
                downloadSttFile(url, target, cb, l, done);
                return;
            }
            if (!r.isSuccessful() || r.body() == null) {
                throw new java.io.IOException("HTTP " + r.code() + " for " + target.getName());
            }
            String ctype = r.header("Content-Type");
            if (ctype != null && ctype.toLowerCase(Locale.ROOT).startsWith("text/html")) {
                part.delete();
                throw new java.io.IOException("server returned HTML instead of " + target.getName());
            }
            boolean resumed = r.code() == 206 && existing > 0;
            long base = resumed ? existing : 0;
            long len = r.body().contentLength();
            long total = len > 0 ? base + len : -1;
            done[0] += base;
            long lastEmit = 0;
            try (InputStream in = r.body().byteStream();
                 OutputStream out = new FileOutputStream(part, resumed)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (STT_CANCEL) throw new DownloadCancelled();
                    out.write(buf, 0, n);
                    done[0] += n;
                    if (cb != null) {
                        long now = System.currentTimeMillis();
                        if (now - lastEmit > 300) { lastEmit = now; cb.onProgress(l, done[0], -1); }
                    }
                }
            }
            if (cb != null) cb.onProgress(l, done[0], -1);
            if (total > 0 && part.length() != total) throw new java.io.IOException("incomplete download: " + target.getName());
        }
        if (target.exists()) target.delete();
        if (!part.renameTo(target)) throw new java.io.IOException("rename failed: " + target.getName());
    }

    // ============ دانلود TTS ============
    // هر زبان توی نخِ خودش دانلود می‌شه، پس می‌شه همه‌ی زبان‌ها رو هم‌زمان زد.
    static void downloadTtsModel(final Context ctx, final String lang, final ProgressCallback cb) {
        downloadTtsModel(ctx, lang, null, cb);
    }

    /** vid = شناسه‌ی صدا (null = صدای فعالِ همین زبان). بعد از دانلودِ کامل، همین صدا فعال می‌شود. */
    static void downloadTtsModel(final Context ctx, final String lang, final String vid, final ProgressCallback cb) {
        final Context app = ctx.getApplicationContext();
        final String l = normalize(lang);
        final TtsVoice voice = l == null ? null
                : (vid == null || vid.isEmpty() ? activeVoice(app, l) : findVoice(l, vid));
        final TtsSpec s = voice == null ? null : voice.spec;
        if (s == null) {
            if (cb != null) cb.onError(String.valueOf(lang), new IllegalArgumentException("no TTS for " + lang));
            return;
        }
        if (!TTS_ACTIVE.add(l)) {
            // همین زبان همین الان در حال دانلوده؛ دوباره شروعش نمی‌کنیم
            return;
        }
        TTS_DL_VOICE.put(l, voice.id);
        TTS_CANCEL.remove(l);
        Thread t = new Thread(() -> {
            try {
                Exception last = null;
                for (int attempt = 1; attempt <= 3; attempt++) {
                    try {
                        downloadTtsOnce(app, l, s, ttsDirFor(app, l, voice), new ProgressCallback() {
                            @Override public void onProgress(String lg, long done, long total) {
                                TTS_BYTES.put(l, done);
                                if (cb != null) cb.onProgress(lg, done, total);
                            }
                            @Override public void onDone(String lg) {}
                            @Override public void onError(String lg, Exception e) {}
                        });
                        last = null;
                        break;
                    } catch (DownloadCancelled dc) {
                        last = dc;
                        break;
                    } catch (Exception e) {
                        last = e;
                        Log.w(TAG, "TTS download attempt " + attempt + " failed for " + l, e);
                        if (TTS_CANCEL.contains(l)) { last = new DownloadCancelled(); break; }
                        try { Thread.sleep(1500L * attempt); } catch (InterruptedException ie) { break; }
                    }
                }
                if (last != null) {
                    if (cb != null) {
                        if (last instanceof DownloadCancelled) cb.onError(l, last);
                        else cb.onError(l, new Exception(last.getClass().getSimpleName() + ": " + last.getMessage(), last));
                    }
                } else {
                    // دانلودِ کامل شد → اگر این زبان قبلاً پاک شده بود دوباره فعال شود، و همین صدا صدای فعالِ زبان می‌شود
                    if (voice.spec.pkg != null) setLangOff(app, l, false);
                    setActiveVoice(app, l, voice.id);
                    if (cb != null) cb.onDone(l);
                }
            } finally {
                TTS_DL_VOICE.remove(l);
                TTS_BYTES.remove(l);
                TTS_CANCEL.remove(l);
                TTS_ACTIVE.remove(l);
            }
        }, "sherpa-tts-download-" + l);
        t.setDaemon(true);
        t.start();
    }

    private static void downloadTtsOnce(Context app, String l, TtsSpec s, File dir, ProgressCallback cb) throws Exception {
        if (s.pkg != null) {
            downloadPackage(app, l, s, cb);
            return;
        }
        if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("cannot create " + dir);

        // فایل‌های صدای قدیمی (مثلاً ryan/gyro که پیش‌فرض بودند) پاک می‌شوند تا با صدای جدید قاطی نشوند
        final String vid = piperIdOf(s);
        if (MIGRATED_LANGS.contains(l) && dir.getName().equals(l) && !vid.equals(readVoiceMarker(dir))) {
            new File(dir, "model.onnx").delete();
            new File(dir, "model.onnx.part").delete();
            new File(dir, "tokens.txt").delete();
            new File(dir, "tokens.txt.part").delete();
            new File(dir, "model.json").delete();
            new File(dir, "meta.ok").delete();
        }

        if (s.rawPiper && !s.charFrontend && new File(dir, "meta-char2.ok").isFile()) {
            // نسخه‌ی قبلیِ بدون espeak (metadata ی coqui/characters) با حالتِ espeak سازگار نیست → دوباره گرفته می‌شود
            new File(dir, "model.onnx").delete();
            new File(dir, "model.onnx.part").delete();
            new File(dir, "meta-char2.ok").delete();
            new File(dir, "meta-char.ok").delete();
            new File(dir, "meta.ok").delete();
        }
        if (s.charFrontend && !new File(dir, "meta-char2.ok").isFile()) {
            // نسخه‌ی قدیمیِ مبتنی بر espeak (metadata ی comment=piper) با نسخه‌ی frontend=characters سازگار نیست → دوباره می‌گیریم
            new File(dir, "model.onnx").delete();
            new File(dir, "model.onnx.part").delete();
            new File(dir, "meta.ok").delete();
            new File(dir, "meta-char.ok").delete();   // نسخه‌ی قدیمیِ metadata (بدون comment=coqui) → مدل دوباره گرفته می‌شود
        }
        if (s.rawPiper) {
            // ۱. فایل پیکربندی Piper → tokens.txt
            checkCancel(l);
            File cfg = new File(dir, "model.json");
            if (!cfg.isFile() || cfg.length() == 0) {
                downloadFile(HF_BASE + s.repo + "/resolve/main/" + s.modelFile + ".json", cfg, cb, l);
            }
            File tokensTarget = new File(dir, "tokens.txt");
            if (!tokensTarget.isFile() || tokensTarget.length() == 0) {
                writeTokensFromPiperJson(cfg, tokensTarget);
            }
        } else {
            // ۱. tokens.txt (کوچیکه)
            checkCancel(l);
            File tokensTarget = new File(dir, "tokens.txt");
            if (!tokensTarget.isFile() || tokensTarget.length() == 0) {
                downloadFile(HF_BASE + s.repo + "/resolve/main/" + s.tokensFile, tokensTarget, cb, l);
            }
        }

        // ۲. model.onnx (بزرگ‌ترین فایل؛ از همین‌جا پیشرفت دیده می‌شه و از نقطه‌ی توقف ادامه پیدا می‌کنه)
        checkCancel(l);
        File modelTarget = new File(dir, "model.onnx");
        if (!modelTarget.isFile() || modelTarget.length() == 0) {
            downloadFile(HF_BASE + s.repo + "/resolve/main/" + s.modelFile, modelTarget, cb, l);
        }

        // ۲.۵ فایل خام Piper: metadata موردنیاز Sherpa را به انتهای onnx اضافه کن (فقط یک بار)
        if (s.rawPiper) {
            File ok = new File(dir, s.charFrontend ? "meta-char2.ok" : "meta.ok");
            if (!ok.isFile()) {
                appendSherpaMetadata(modelTarget, new File(dir, "model.json"), s.charFrontend);
                if (!ok.createNewFile()) throw new java.io.IOException("cannot create " + ok.getName());
            }
        }

        // ۳. espeak-ng-data مشترک (فقط یک بار؛ زبان‌های دیگه همین‌جا صبر می‌کنن، ولی با امکانِ توقف)
        if (!s.charFrontend && !isEspeakReady(app)) {
            while (!ESPEAK_LOCK.tryLock(500, TimeUnit.MILLISECONDS)) {
                checkCancel(l);
                if (isEspeakReady(app)) break;
            }
            if (ESPEAK_LOCK.isHeldByCurrentThread()) {
                try {
                    if (!isEspeakReady(app)) {
                        downloadEspeakData(app, s.rawPiper ? ESPEAK_FALLBACK_REPO : s.repo, cb, l);
                    }
                } finally {
                    ESPEAK_LOCK.unlock();
                }
            }
        }

        // ۴. همه‌چیز کامل شد → این پوشه مالِ همین صداست
        writeVoiceMarker(dir, vid);
    }

    // ============ دانلودِ بسته‌ی مشترک (Supertonic / Kokoro) ============
    // چند زبان یک بسته را مشترک دارند؛ قفلِ هر بسته جلوی دانلودِ هم‌زمانِ دوباره را می‌گیرد.
    private static final Map<String, ReentrantLock> PKG_LOCKS = new ConcurrentHashMap<>();

    private static ProgressCallback offsetCb(final ProgressCallback cb, final long base, final long total) {
        return new ProgressCallback() {
            @Override public void onProgress(String lg, long d, long t) {
                if (cb != null) cb.onProgress(lg, Math.min(base + d, total), total);
            }
            @Override public void onDone(String lg) {}
            @Override public void onError(String lg, Exception e) {}
        };
    }

    private static void downloadPackage(Context app, String l, TtsSpec s, ProgressCallback cb) throws Exception {
        final Pkg p = s.pkg;
        ReentrantLock lock = PKG_LOCKS.get(p.id);
        if (lock == null) {
            PKG_LOCKS.putIfAbsent(p.id, new ReentrantLock());
            lock = PKG_LOCKS.get(p.id);
        }
        while (!lock.tryLock(500, TimeUnit.MILLISECONDS)) {
            checkCancel(l);
            if (pkgReady(app, p)) break;
        }
        try {
            if (!pkgReady(app, p)) {
                File dir = pkgDir(app, p);
                if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("cannot create " + dir);
                new File(dir, "ready.ok").delete();
                long done = 0;
                for (String name : p.files) {
                    checkCancel(l);
                    File target = new File(dir, name);
                    if (!target.isFile() || target.length() == 0) {
                        downloadFile(HF_BASE + p.repo + "/resolve/main/" + name, target,
                                offsetCb(cb, done, p.approxBytes), l);
                    }
                    done += target.length();
                    if (cb != null) cb.onProgress(l, Math.min(done, p.approxBytes), p.approxBytes);
                }
                for (String sub : p.dirs) {
                    checkCancel(l);
                    done += downloadRepoDir(p.repo, sub, new File(dir, sub), offsetCb(cb, done, p.approxBytes), l);
                }
                File ok = new File(dir, "ready.ok");
                if (!ok.exists() && !ok.createNewFile()) throw new java.io.IOException("cannot create ready.ok");
            }
            // فایل‌های مخصوصِ همین زبان (چینیِ Kokoro): فقط وقتی zh دانلود می‌شود؛ ready.ok دست نمی‌خورد
            // تا انگلیسی در حینِ دانلودِ چینی از دسترس خارج نشود.
            File pdir = pkgDir(app, p);
            for (String name : extraFilesFor(p, l)) {
                checkCancel(l);
                File target = new File(pdir, name);
                if (!target.isFile() || target.length() == 0) {
                    downloadFile(HF_BASE + p.repo + "/resolve/main/" + name, target,
                            offsetCb(cb, 0, p.approxBytes), l);
                }
            }
        } finally {
            if (lock.isHeldByCurrentThread()) lock.unlock();
        }
        // Kokoro: espeak-ng-data مشترک (همان که فارسی هم دارد)
        if (ENG_KOKORO.equals(s.engine)) ensureEspeak(app, ESPEAK_FALLBACK_REPO, cb, l);
    }

    private static void ensureEspeak(Context app, String repo, ProgressCallback cb, String l) throws Exception {
        if (isEspeakReady(app)) return;
        while (!ESPEAK_LOCK.tryLock(500, TimeUnit.MILLISECONDS)) {
            checkCancel(l);
            if (isEspeakReady(app)) break;
        }
        if (ESPEAK_LOCK.isHeldByCurrentThread()) {
            try {
                if (!isEspeakReady(app)) downloadEspeakData(app, repo, cb, l);
            } finally {
                ESPEAK_LOCK.unlock();
            }
        }
    }

    /** tokens.txt ی Sherpa را از phoneme_id_map فایل json ی Piper می‌سازد («نماد id» در هر خط). */
    private static void writeTokensFromPiperJson(File cfg, File out) throws Exception {
        String json = readAll(cfg);
        JSONObject map = new JSONObject(json).getJSONObject("phoneme_id_map");
        File tmp = new File(out.getParentFile(), "tokens.txt.part");
        try (java.io.Writer w = new java.io.OutputStreamWriter(new FileOutputStream(tmp, false), "UTF-8")) {
            java.util.Iterator<String> it = map.keys();
            while (it.hasNext()) {
                String sym = it.next();
                JSONArray ids = map.getJSONArray(sym);
                if (ids.length() == 0) continue;
                w.write(sym + " " + ids.getInt(0) + "\n");
            }
        }
        if (out.exists()) out.delete();
        if (!tmp.renameTo(out)) throw new java.io.IOException("rename failed: tokens.txt");
    }

    /**
     * Sherpa-ONNX برای مدل‌های Piper چند کلید metadata داخل خود onnx می‌خواهد (model_type, comment=piper, voice, ...).
     * فایل خام Piper آن‌ها را ندارد. ModelProto.metadata_props فیلدِ شماره‌ی ۱۴ (repeated) است و در protobuf
     * اضافه کردنِ بایت‌های یک فیلدِ تکرارشونده به انتهای فایل معتبر است؛ پس همین‌جا به انتهای فایل می‌چسبانیم.
     */
    private static void appendSherpaMetadata(File onnx, File cfg, boolean charFrontend) throws Exception {
        JSONObject c = new JSONObject(readAll(cfg));
        int sampleRate = c.getJSONObject("audio").optInt("sample_rate", 22050);
        int nSpeakers = c.optInt("num_speakers", 1);
        String voice = c.has("espeak") ? c.getJSONObject("espeak").optString("voice", "fa") : "fa";
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        putMeta(bo, "model_type", "vits");
        putMeta(bo, "language", "Persian");
        if (charFrontend) {
            // بدون espeak: هر کاراکترِ ورودی = یک token.
            // comment=coqui لازم است: ورودی‌های onnx خامِ Piper (input, input_lengths, scales) را فقط مسیرِ
            // «piper/coqui» ی Sherpa درست صدا می‌زند؛ بدونِ آن Sherpa ورودی‌های اشتباه می‌دهد و هیچ صدایی ساخته نمی‌شود.
            // comment=piper هم نمی‌شود چون آن frontend ی espeak را فعال می‌کند.
            putMeta(bo, "comment", "coqui");
            putMeta(bo, "frontend", "characters");
            putMeta(bo, "add_blank", "0");        // پدها را خودِ PersianG2P می‌گذارد
            putMeta(bo, "use_eos_bos", "0");      // ^ و $ را هم خودِ PersianG2P می‌گذارد
        } else {
            putMeta(bo, "comment", "piper");
            putMeta(bo, "voice", voice);
            putMeta(bo, "has_espeak", "1");
        }
        putMeta(bo, "n_speakers", String.valueOf(nSpeakers));
        putMeta(bo, "sample_rate", String.valueOf(sampleRate));
        try (FileOutputStream out = new FileOutputStream(onnx, true)) {
            out.write(bo.toByteArray());
        }
    }

    private static void putMeta(java.io.ByteArrayOutputStream bo, String key, String value) throws Exception {
        byte[] k = key.getBytes("UTF-8");
        byte[] v = value.getBytes("UTF-8");
        java.io.ByteArrayOutputStream entry = new java.io.ByteArrayOutputStream();
        entry.write(0x0A); writeVarint(entry, k.length); entry.write(k);       // StringStringEntryProto.key
        entry.write(0x12); writeVarint(entry, v.length); entry.write(v);       // .value
        bo.write(0x72);                                                         // ModelProto.metadata_props (14, len-delimited)
        writeVarint(bo, entry.size());
        bo.write(entry.toByteArray());
    }

    private static void writeVarint(java.io.ByteArrayOutputStream o, int v) {
        while ((v & ~0x7F) != 0) { o.write((v & 0x7F) | 0x80); v >>>= 7; }
        o.write(v);
    }

    private static String readAll(File f) throws Exception {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        }
    }

    /** پوشه‌ی espeak-ng-data رو از HuggingFace می‌گیره؛ فقط وقتی کامل شد فایلِ marker ساخته می‌شه. */
    private static void downloadEspeakData(Context app, String repo, ProgressCallback cb, String l) throws Exception {
        downloadRepoDir(repo, "espeak-ng-data", getEspeakDataDir(app), cb, l);
        File marker = espeakMarker(app);
        if (!marker.exists() && !marker.createNewFile()) throw new java.io.IOException("cannot create marker");
    }

    /**
     * یک زیرپوشه‌ی مخزنِ HuggingFace (لیستِ فایل‌ها با API) را داخلِ root کپی می‌کند.
     * خروجی: مجموعِ بایت‌های پوشه.
     */
    private static long downloadRepoDir(String repo, String sub, File root, ProgressCallback cb, String l) throws Exception {
        final String prefix = sub + "/";
        if (!root.isDirectory() && !root.mkdirs()) throw new java.io.IOException("cannot create " + root);

        // لیست فایل‌ها (با صفحه‌بندی)
        List<String> paths = new ArrayList<>();
        List<Long> sizes = new ArrayList<>();
        String next = HF_BASE + "api/models/" + repo + "/tree/main/" + sub + "?recursive=true";
        int guard = 0;
        while (next != null && guard++ < 20) {
            checkCancel(l);
            Request req = new Request.Builder().url(next).build();
            try (Response r = HTTP.newCall(req).execute()) {
                if (!r.isSuccessful() || r.body() == null) {
                    throw new java.io.IOException("HTTP " + r.code() + " listing " + sub);
                }
                String body = r.body().string();
                JSONArray arr = new JSONArray(body);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    if (!"file".equals(o.optString("type"))) continue;
                    String p = o.optString("path");
                    if (p.startsWith(prefix)) {
                        paths.add(p);
                        sizes.add(o.optLong("size", 0));
                    }
                }
                next = fixHost(parseNextLink(r.header("Link")));
            }
        }
        if (paths.isEmpty()) throw new java.io.IOException(sub + " list is empty");

        // فایل‌ها رو چندتا چندتا هم‌زمان می‌گیریم (صدها فایل کوچیکه؛ یکی‌یکی خیلی کند بود)
        final AtomicLong done = new AtomicLong(0);
        final long totalBytes = sumSizes(sizes);
        ExecutorService ex = Executors.newFixedThreadPool(6);
        try {
            List<Future<Void>> futures = new ArrayList<>();
            for (int i = 0; i < paths.size(); i++) {
                final String p = paths.get(i);
                final String rel = p.substring(prefix.length());
                final File target = new File(root, rel);
                final long expected = sizes.get(i);
                File parent = target.getParentFile();
                if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
                    throw new java.io.IOException("cannot create " + parent);
                }
                if (target.isFile() && (expected <= 0 || target.length() == expected)) {
                    done.addAndGet(target.length());
                    continue;
                }
                final String url = HF_BASE + repo + "/resolve/main/" + p;
                futures.add(ex.submit(new Callable<Void>() {
                    @Override public Void call() throws Exception {
                        checkCancel(l);
                        downloadFile(url, target, null, l);
                        long now = done.addAndGet(target.length());
                        if (cb != null) cb.onProgress(l, now, totalBytes);
                        return null;
                    }
                }));
            }
            for (Future<Void> f : futures) {
                try {
                    f.get();
                } catch (ExecutionException ee) {
                    Throwable c = ee.getCause();
                    if (c instanceof Exception) throw (Exception) c;
                    throw ee;
                }
            }
        } finally {
            ex.shutdownNow();
        }
        return done.get();
    }

    private static long sumSizes(List<Long> sizes) {
        long t = 0;
        for (Long v : sizes) if (v != null) t += v;
        return t;
    }

    /** لینکِ صفحه‌ی بعدیِ API ممکنه به huggingface.co اشاره کنه؛ همون مسیر رو روی آینه‌ی خودمون می‌خونیم. */
    private static String fixHost(String url) {
        if (url == null) return null;
        int i = url.indexOf("/api/");
        if (i < 0) return url;
        return HF_BASE + url.substring(i + 1);
    }

    /** از هدرِ Link مقدارِ rel="next" رو درمیاره (یا null). */
    private static String parseNextLink(String link) {
        if (link == null) return null;
        for (String part : link.split(",")) {
            if (part.contains("rel=\"next\"")) {
                int a = part.indexOf('<');
                int b = part.indexOf('>');
                if (a >= 0 && b > a) return part.substring(a + 1, b).trim();
            }
        }
        return null;
    }

    /** دانلودِ فایل با امکانِ ادامه از نقطه‌ی توقف (Range) و توقفِ کاربر. */
    private static void downloadFile(String url, File target, ProgressCallback cb, String l) throws Exception {
        File part = new File(target.getParentFile(), target.getName() + ".part");
        long existing = part.isFile() ? part.length() : 0;
        Request.Builder rb = new Request.Builder().url(url);
        if (existing > 0) rb.header("Range", "bytes=" + existing + "-");
        try (Response r = HTTP.newCall(rb.build()).execute()) {
            if (r.code() == 416) {
                // بخشِ قبلی با فایلِ سرور نمی‌خونه؛ از اول می‌گیریم
                part.delete();
                downloadFile(url, target, cb, l);
                return;
            }
            if (!r.isSuccessful() || r.body() == null) {
                throw new java.io.IOException("HTTP " + r.code() + " for " + target.getName());
            }
            // صفحه‌ی خطای آینه (HTML) به‌جای فایل → خرابِ بی‌صدا؛ همین‌جا ردش کن
            String ctype = r.header("Content-Type");
            if (ctype != null && ctype.toLowerCase(Locale.ROOT).startsWith("text/html")) {
                part.delete();
                throw new java.io.IOException("server returned HTML instead of " + target.getName());
            }
            boolean resumed = r.code() == 206 && existing > 0;
            long base = resumed ? existing : 0;
            long len = r.body().contentLength();
            long total = len > 0 ? base + len : -1;
            long done = base;
            long lastEmit = 0;
            try (InputStream in = r.body().byteStream();
                 OutputStream out = new FileOutputStream(part, resumed)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    checkCancel(l);
                    out.write(buf, 0, n);
                    done += n;
                    if (cb != null) {
                        long now = System.currentTimeMillis();
                        if (now - lastEmit > 300) { lastEmit = now; cb.onProgress(l, done, total); }
                    }
                }
            }
            if (cb != null) cb.onProgress(l, done, total);
            if (total > 0 && part.length() != total) throw new java.io.IOException("incomplete download");
            if (target.getName().endsWith(".onnx") && part.length() < 2_000_000L) {
                part.delete();
                throw new java.io.IOException("model file too small: " + part.length());
            }
        }
        if (target.exists()) target.delete();
        if (!part.renameTo(target)) throw new java.io.IOException("rename failed: " + target.getName());
    }

    // ============ حذف ============
    static void deleteModel(Context ctx, String lang) {
        String l = normalize(lang);
        if (l == null) return;
        File dir = sttDirFor(ctx, l);
        deleteRecursive(dir);
    }

    /** بسته‌های قدیمیِ حذف‌شده (فرانسوی/آلمانی/اسپانیایی) اگر روی گوشی مانده باشند پاک می‌شوند تا فضا اشغال نکنند. */
    static void purgeRemovedSttPacks(Context ctx) {
        try {
            for (String l : new String[]{"fr", "de", "es"}) {
                File dir = sttDirFor(ctx, l);
                if (dir.exists()) deleteRecursive(dir);
            }
        } catch (Throwable t) {
            Log.w(TAG, "purgeRemovedSttPacks failed", t);
        }
    }

    static void deleteTtsModel(Context ctx, String lang) {
        deleteTtsModel(ctx, lang, null);
    }

    /** vid = null → صدای فعالِ این زبان. اگر صدای فعال پاک شود، انتخاب به صدای پیش‌فرض برمی‌گردد. */
    static void deleteTtsModel(Context ctx, String lang, String vid) {
        String l = normalize(lang);
        if (l == null) return;
        TtsVoice active = activeVoice(ctx, l);
        TtsVoice v = vid == null || vid.isEmpty() ? active : findVoice(l, vid);
        if (v == null) return;
        if (v.spec.pkg != null) {
            // بسته‌ی مشترک (Supertonic/Kokoro): فقط «همین زبان» غیرفعال می‌شود، نه فایل‌های مشترک
            deletePkgLanguage(ctx, l, v.spec.pkg);
            return;
        }
        deleteRecursive(ttsDirFor(ctx, l, v));
        if (active != null && active.id.equals(v.id) && (!v.isDefault || PREFERRED_VOICE.containsKey(l))) setActiveVoice(ctx, l, null);
    }

    /**
     * پاک‌کردنِ یک زبان از بسته‌ی مشترک: زبان غیرفعال می‌شود و فایل‌های مشترک دست‌نخورده می‌مانند.
     * فقط وقتی «هیچ زبانِ دیگری» از همین بسته باقی نمانده باشد، فایل‌های بسته برای آزادشدنِ فضا پاک می‌شوند.
     */
    private static void deletePkgLanguage(Context ctx, String l, Pkg p) {
        setLangOff(ctx, l, true);
        try { new File(ttsRoot(ctx), l + ".active").delete(); } catch (Throwable ignored) {}
        // فایل‌های مخصوصِ این زبان (چینیِ Kokoro) مالِ زبان‌های دیگر نیست؛ برای آزادشدنِ فضا پاک می‌شوند
        for (String name : extraFilesFor(p, l)) {
            try { new File(pkgDir(ctx, p), name).delete(); } catch (Throwable ignored) {}
        }
        for (Map.Entry<String, TtsSpec> e : TTS_SPECS.entrySet()) {
            if (e.getValue().pkg != p || e.getKey().equals(l)) continue;
            if (!isLangOff(ctx, e.getKey()) || TTS_ACTIVE.contains(e.getKey())) return;   // زبانِ دیگری هنوز از بسته استفاده می‌کند
        }
        deleteRecursive(pkgDir(ctx, p));
    }

    private static void deleteRecursive(File f) {
        if (f == null) return;
        if (f.isDirectory()) {
            File[] fs = f.listFiles();
            if (fs != null) for (File c : fs) deleteRecursive(c);
        }
        f.delete();
    }
}
