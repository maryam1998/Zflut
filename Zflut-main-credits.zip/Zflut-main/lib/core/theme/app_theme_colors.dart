import 'package:flutter/material.dart';

import '../constants/app_themes.dart';

/// ThemeExtension تا هر جای ویجت‌ها بتوانیم به رنگ‌های اختصاصی تم
/// (paper/paperDark/ink/gold/...) دسترسی داشته باشیم — معادل CSS variables.
@immutable
class AppThemeColorsExt extends ThemeExtension<AppThemeColorsExt> {
  final AppThemeColors colors;
  const AppThemeColorsExt(this.colors);

  @override
  AppThemeColorsExt copyWith({AppThemeColors? colors}) =>
      AppThemeColorsExt(colors ?? this.colors);

  @override
  AppThemeColorsExt lerp(ThemeExtension<AppThemeColorsExt>? other, double t) {
    if (other is! AppThemeColorsExt) return this;
    // رنگ‌ها گسسته‌اند؛ در زمان ت بین دو تم، انتخاب نزدیک‌ترین کافی است.
    return t < 0.5 ? this : other;
  }

  Color get paper => colors.paper;
  Color get paperDark => colors.paperDark;
  Color get ink => colors.ink;
  Color get inkSoft => colors.inkSoft;
  Color get gold => colors.gold;
  Color get goldSoft => colors.goldSoft;
  Color get teal => colors.teal;
  Color get rose => colors.rose;
  Color get cardBorder => colors.cardBorder;
  Color get headerFrom => colors.headerFrom;
  Color get headerTo => colors.headerTo;
  Color get headerText => colors.headerText;

  /// تمِ تیره (مثلِ «شب»): کارت‌ها/چیپ‌ها نباید سفیدِ ثابت باشند وگرنه متنِ کرم‌رنگ روی سفید دیده نمی‌شود.
  bool get isDark => colors.paper.computeLuminance() < 0.25;

  /// زمینه‌ی کارت/چیپ/فیلد (در تم‌های روشن همان سفید همیشگی)
  Color get surface => isDark ? const Color(0xFF2A3042) : Colors.white;

  /// زمینه‌ی کارتِ «خوانده‌شده»
  Color get surfaceRead =>
      isDark ? const Color(0xFF232838) : const Color(0xFFF8F2DE);

  /// رنگِ متنِ ترجمه (سبزِ تیره روی زمینه‌ی روشن، سبزِ روشن روی زمینه‌ی تیره)
  Color get translationText =>
      isDark ? const Color(0xFF86DDAA) : AppFixedColors.translation;
}

extension AppThemeX on BuildContext {
  AppThemeColorsExt get appColors =>
      Theme.of(this).extension<AppThemeColorsExt>()!;
}
