import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/ai_settings_provider.dart';
import '../providers/app_prefs_provider.dart';
import '../providers/language_selection_provider.dart';
import '../providers/speech_provider.dart';
import '../providers/translation_provider.dart';

/// زبان‌هایی که ترجمه‌ی یک لغت باید به آن‌ها نشان داده شود:
/// زبان مادری + زبان‌های مقصدِ انتخابی، بدون تکرار، و بدون خودِ زبانِ لغت
/// (چون خودِ لغت همان زبان را نشان می‌دهد؛ مثلاً مادری = مقصد = آلمانی → یک‌بار).
List<String> wordTranslationLangs({
  required String native,
  required List<String> targets,
  required String wordLang,
}) {
  final out = <String>[];
  for (final c in [if (!targets.contains(native)) native, ...targets]) {
    final t = c.trim().toLowerCase();
    if (t.isEmpty || t == wordLang.toLowerCase() || out.contains(t)) continue;
    out.add(t);
  }
  return out;
}

final Map<String, String> _trCache = {};

TextDirection _dirOf(String s) =>
    RegExp(r'[\u0590-\u08FF]').hasMatch(s) ? TextDirection.rtl : TextDirection.ltr;

/// ترجمه‌ی یک لغت به همه‌ی زبان‌های مادری+مقصدِ انتخابی.
/// تا رسیدن ترجمه‌ها، معنیِ ذخیره‌شده ([fallback]) نشان داده می‌شود.
class WordTranslations extends ConsumerStatefulWidget {
  final String word;
  final String langCode;
  final String fallback;
  final TextStyle style;
  final bool centered;

  /// برچسب کوچک کدِ زبان (EN / FA ...) کنار هر ترجمه — فقط وقتی بیش از یک زبان باشد.
  final bool showLabels;

  /// true = کنارِ هر ترجمه یک دکمه‌ی 🔊 برای خواندنِ همان ترجمه (به زبانِ خودش).
  final bool speakable;

  /// true = یک دکمه‌ی رفرش (↻) نشان می‌دهد که ترجمه‌ها را بدون کش دوباره می‌گیرد
  /// (مترجم‌های رایگان + ناظر AI) — برای وقتی که ترجمه غلط است.
  final bool refreshable;

  const WordTranslations({
    super.key,
    required this.word,
    required this.langCode,
    required this.fallback,
    required this.style,
    this.centered = false,
    this.showLabels = true,
    this.speakable = false,
    this.refreshable = false,
  });

  @override
  ConsumerState<WordTranslations> createState() => _WordTranslationsState();
}

class _WordTranslationsState extends ConsumerState<WordTranslations> {
  Map<String, String> _res = {};
  String _sig = '';
  int _gen = 0;
  bool _refreshing = false;

  /// زبان‌هایی که رفرشِ تکی‌شان در جریان است.
  final Set<String> _busyLangs = <String>{};

  /// رفرشِ تکی: فقط ترجمه‌ی همین یک زبان دوباره (بدون کش) گرفته می‌شود.
  Future<void> _refreshOne(String l) async {
    if (_busyLangs.contains(l)) return;
    final sigAtStart = _sig;
    final word = widget.word;
    setState(() => _busyLangs.add(l));
    final svc = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);
    var r = '';
    try {
      r = (await svc.retranslate(
        text: word,
        targetLang: l,
        sourceLang: widget.langCode,
        aiSettings: ai,
        previous: _res[l],
        keepPrevious: true,
      ))
          .trim();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _busyLangs.remove(l);
      if (sigAtStart == _sig &&
          r.isNotEmpty &&
          r.toLowerCase() != word.trim().toLowerCase()) {
        _trCache['${widget.langCode}|$l|$word'] = r;
        _res = {..._res, l: r};
      }
    });
  }

  static const Map<String, String> _altLabel = {
    'fa': 'گزینه‌ی دوم',
    'en': 'Second option',
    'ar': 'خيار ثانٍ',
    'es': 'Segunda opción',
    'de': 'Zweite Option',
    'fr': 'Deuxième option',
  };

  /// 🗂️ ↻ ترجمه‌ی قبلی را نگه داشته و جدید را «گزینه‌ی دوم» کرده؛ کاربر خودش انتخاب می‌کند.
  Widget? _altRow(String l, String current) {
    final svc = ref.read(translationServiceProvider);
    final alt = svc.alternative(widget.word, l);
    if (alt == null || alt.trim() == current.trim()) return null;
    final ui = ref.read(appPrefsProvider).uiLang;
    final label = _altLabel[ui] ?? _altLabel['en']!;
    final small = (widget.style.fontSize ?? 12) * 0.85;
    return Padding(
      padding: const EdgeInsets.only(top: 2, bottom: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Text('$label: $alt',
                textDirection: _dirOf(alt),
                style: widget.style.copyWith(
                    fontSize: small,
                    fontStyle: FontStyle.italic,
                    color: const Color(0xFFC9972B))),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () async {
              final v = await svc.chooseAlternative(widget.word, widget.langCode, l);
              if (!mounted || v == null) return;
              _trCache['${widget.langCode}|$l|${widget.word}'] = v;
              setState(() => _res = {..._res, l: v});
            },
            child: const Padding(
              padding: EdgeInsets.all(4),
              child: Icon(Icons.check_circle_outline, size: 18, color: Color(0xFF2E9E6B)),
            ),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () async {
              await svc.dismissAlternative(widget.word, l);
              if (mounted) setState(() {});
            },
            child: const Padding(
              padding: EdgeInsets.all(4),
              child: Icon(Icons.close, size: 16, color: Color(0xFF9A9A9A)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _rowRefreshButton(String l) {
    final busy = _busyLangs.contains(l);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: busy ? null : () => _refreshOne(l),
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: busy
            ? const SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Color(0xFFC9972B)),
              )
            : const Icon(Icons.refresh, size: 16, color: Color(0xFFC9972B)),
      ),
    );
  }

  /// رفرش: ترجمه‌ی دوباره‌ی همه‌ی زبان‌ها بدون کش.
  Future<void> _refresh(List<String> langs) async {
    if (_refreshing || langs.isEmpty) return;
    final sigAtStart = _sig;
    final gen = ++_gen; // بارگذاریِ در جریان را لغو می‌کند
    setState(() => _refreshing = true);
    final svc = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);
    final out = Map<String, String>.from(_res);
    for (final l in langs) {
      String r = '';
      try {
        r = (await svc.retranslate(
          text: widget.word,
          targetLang: l,
          sourceLang: widget.langCode,
          aiSettings: ai,
          previous: _res[l],
          keepPrevious: true,
        ))
            .trim();
      } catch (_) {}
      if (!mounted) return;
      if (r.isNotEmpty && r.toLowerCase() != widget.word.trim().toLowerCase()) {
        _trCache['${widget.langCode}|$l|${widget.word}'] = r;
        out[l] = r;
      }
    }
    if (!mounted) return;
    if (sigAtStart != _sig || gen != _gen) {
      setState(() => _refreshing = false);
      return;
    }
    setState(() {
      _res = out;
      _refreshing = false;
    });
  }

  Widget _refreshButton(List<String> langs) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _refreshing ? null : () => _refresh(langs),
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: _refreshing
            ? const SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Color(0xFFC9972B)),
              )
            : const Icon(Icons.refresh, size: 16, color: Color(0xFFC9972B)),
      ),
    );
  }

  Future<void> _load(List<String> langs) async {
    final gen = ++_gen;
    final svc = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);
    final out = <String, String>{};
    for (final l in langs) {
      final key = '${widget.langCode}|$l|${widget.word}';
      var t = _trCache[key];
      if (t == null) {
        try {
          t = (await svc.translate(
            text: widget.word,
            targetLang: l,
            sourceLang: widget.langCode,
            aiSettings: ai,
          ))
              .trim();
        } catch (_) {
          t = '';
        }
        if (t.isNotEmpty) _trCache[key] = t;
      }
      if (t.isNotEmpty && t.toLowerCase() != widget.word.trim().toLowerCase()) {
        out[l] = t;
      }
      if (!mounted || gen != _gen) return;
    }
    if (!mounted || gen != _gen) return;
    setState(() => _res = out);
  }

  @override
  Widget build(BuildContext context) {
    final sel = ref.watch(languageSelectionProvider);
    final langs = wordTranslationLangs(
      native: sel.native,
      targets: sel.targets,
      wordLang: widget.langCode,
    );
    final sig = '${widget.word}|${widget.langCode}|${langs.join(',')}';
    if (sig != _sig) {
      _sig = sig;
      _res = {};
      if (langs.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && sig == _sig) _load(langs);
        });
      }
    }

    final fb = widget.fallback.trim();
    final canRefresh = widget.refreshable && langs.isNotEmpty;
    if (_res.isEmpty) {
      if (fb.isEmpty && !canRefresh) return const SizedBox.shrink();
      final fbText = fb.isEmpty
          ? const SizedBox.shrink()
          : Text(fb,
              textAlign: widget.centered ? TextAlign.center : TextAlign.start,
              textDirection: _dirOf(fb),
              style: widget.style);
      if (!canRefresh) return fbText;
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment:
            widget.centered ? CrossAxisAlignment.center : CrossAxisAlignment.start,
        children: [fbText, _refreshButton(langs)],
      );
    }

    final labels = widget.showLabels && _res.length > 1;
    final lines = <Widget>[];
    for (final l in langs) {
      final t = _res[l];
      if (t == null) {
        // ترجمه‌ی این زبان نیامده/شکست خورده → فقط دکمه‌ی رفرشِ همین زبان
        if (widget.refreshable) {
          lines.add(Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(l.toUpperCase(),
                  style: widget.style.copyWith(
                      fontSize: (widget.style.fontSize ?? 12) * 0.6,
                      fontWeight: FontWeight.w700,
                      color: widget.style.color?.withOpacity(0.6))),
              const SizedBox(width: 6),
              _rowRefreshButton(l),
            ],
          ));
        }
        continue;
      }
      final txt = Text(t,
          textAlign: widget.centered ? TextAlign.center : TextAlign.start,
          textDirection: _dirOf(t),
          style: widget.style);
      final Widget line = labels
          ? Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(l.toUpperCase(),
                    style: widget.style.copyWith(
                        fontSize: (widget.style.fontSize ?? 12) * 0.6,
                        fontWeight: FontWeight.w700,
                        color: widget.style.color?.withOpacity(0.6))),
                const SizedBox(width: 6),
                Flexible(child: txt),
              ],
            )
          : txt;
      final altW = widget.refreshable ? _altRow(l, t) : null;
      final Widget mainRow = widget.speakable || widget.refreshable
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(child: line),
                if (widget.speakable) ...[
                  const SizedBox(width: 4),
                  _MiniSpeak(
                    text: t,
                    code: l,
                    size: (widget.style.fontSize ?? 12) + 4,
                  ),
                ],
                // رفرشِ مخصوصِ همین ترجمه
                if (widget.refreshable) _rowRefreshButton(l),
              ],
            )
          : line;
      lines.add(altW == null
          ? mainRow
          : Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: widget.centered
                  ? CrossAxisAlignment.center
                  : CrossAxisAlignment.start,
              children: [mainRow, altW],
            ));
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment:
          widget.centered ? CrossAxisAlignment.center : CrossAxisAlignment.start,
      children: lines,
    );
  }
}

/// دکمه‌ی کوچکِ 🔊 برای خواندنِ یک متن به زبانِ [code].
class _MiniSpeak extends ConsumerWidget {
  final String text;
  final String code;
  final double size;
  const _MiniSpeak({required this.text, required this.code, this.size = 16});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => ref.read(speechControllerProvider.notifier).toggle(text, code),
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: Icon(Icons.volume_up_outlined,
            size: size, color: const Color(0xFFC9972B)),
      ),
    );
  }
}
