import '../translate/known_translations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../neural/neural_store.dart';
import 'ai_settings_provider.dart';
import 'language_selection_provider.dart';
import 'translation_provider.dart';
import '../player_sync/player_sync_provider.dart';
import '../tts/media_notification.dart';
import '../tts/speech_controller.dart';
import '../tts/speech_state.dart';
import '../storage/local_storage.dart';
import 'voice_prefs_provider.dart';

final speechControllerProvider =
    StateNotifierProvider<SpeechController, SpeechState>((ref) {
  final ctl = SpeechController(
    // صدای انتخاب‌شده‌ی کاربر برای هر زبان (در صورت وجود)
    voicePref: (lang) => ref.read(voicePrefsProvider)[lang],
    // ⚡ پیش‌فرض = «خودکار»: اگر مدلِ صدای اپ برای آن زبان دانلود شده باشد (سریع‌تر و بدون تأخیر)
    // همان استفاده می‌شود؛ فقط اگر کاربر خودش «صدای گوشی» را انتخاب کرده باشد صدای گوشی.
    preferPhoneVoice: () =>
        ref.read(sharedPrefsProvider).getString('voiceEnginePref') == 'phone',
    // مدل‌ها بی‌صدا و خودکار دانلود می‌شوند (مگر کاربر صریحاً «صدای گوشی» را خواسته باشد)
    autoDownloadModels: () =>
        ref.read(sharedPrefsProvider).getString('voiceEnginePref') != 'phone',
    // 🧬 هر بار که یک لغت/جمله با پلیر کامل خوانده شد → یک تکرار در «مسیر عصبی»
    onChunkPlayed: (e) => _recordNeuralFromPlayback(ref, e),
  );
  // 🎧 کنترلِ پلیر روی نوتیفیکیشن (قبلی / پخش‌وتوقف / بعدی) وقتی از برنامه بیرون هستی
  // 🌐 ترجمه‌ی جمله‌ی در حال خوانش هم زیرِ جمله در نوتیفیکیشن نشان داده می‌شود
  // فقط ترجمه‌ی «زبان مبدأ» (زبان مادریِ کاربر) نشان داده می‌شود، نه چرخش بینِ چند زبان؛
  // اگر متنِ در حال خوانش خودش به زبان مادری است، ترجمه‌ای لازم نیست.
  List<String> targetsFor(String from) {
    final native = ref.read(languageSelectionProvider).native.trim().toLowerCase();
    if (native.isNotEmpty && native != from) return [native];
    return const <String>[];
  }

  final media = MediaNotificationSync(
    ctl,
    targets: targetsFor,
    // مثلِ کارت‌های برنامه: اول ترجمه‌ی ذخیره‌شده/رفرش‌شده، بعد ترجمه‌ی آماده‌ی داده‌های خودِ اپ
    peek: (text, from, to) =>
        ref.read(translationServiceProvider).peekCached(text, from, to) ??
        KnownTranslations.get(text, from, to),
    translate: (text, from, to) async {
      final known = KnownTranslations.get(text, from, to);
      if (known != null && known.trim().isNotEmpty) return known;
      return ref.read(translationServiceProvider).translate(
            text: text,
            targetLang: to,
            sourceLang: from,
            aiSettings: ref.read(aiSettingsProvider),
          );
    },
  )..attach();
  ref.onDispose(media.dispose);
  return ctl;
});

/// تشخیصِ اینکه این خوانش مالِ کدام «مورد» است و ثبتش:
///  • اگر متنِ در حال پخش همان متنِ کاملِ یکی از ترک‌های پلیرِ همگام
///    (لغات، مکالمات، …) باشد → مورد = آیتمِ همان آفست؛ base همیشه متنِ
///    انگلیسیِ آیتم است، پس خوانشِ ترجمه‌ها هم به همان تقویم می‌رود.
///  • وگرنه (مثلاً 🔊 داخلِ کارتِ انتخاب) → مورد = خودِ متنِ خوانده‌شده.
void _recordNeuralFromPlayback(Ref ref, ChunkPlayedEvent e) {
  try {
    final sync = ref.read(playerSyncProvider);
    String? base;
    if (e.key != null) {
      for (final t in sync.tracks.values) {
        if (t.key != e.key) continue;
        final span = t.spanAt(e.charOffset);
        if (span != null) {
          final en = ref.read(playerSyncProvider.notifier).itemText(span.id);
          if (en != null && en.trim().isNotEmpty) base = neuralBase(en);
        }
        break;
      }
    }
    // پخش از داخلِ یک کارت (🔊 لغت/ترجمه‌اش) → همان لغتِ انتخاب‌شده
    base ??= ref.read(neuralPathProvider.notifier).hintFor(e.key);
    base ??= neuralBase(e.text);
    if (base.isEmpty) return;
    ref.read(neuralPathProvider.notifier).addRepeat(base, e.code);
  } catch (_) {
    // ثبتِ تکرار هرگز نباید پخش را خراب کند
  }
}
