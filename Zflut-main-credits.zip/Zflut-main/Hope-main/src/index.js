// ---------------------------------------------------------------------------
// LingoLearn — Cloudflare Worker backend
// مسیر این فایل باید دقیقاً src/index.js باشه (طبق wrangler.toml).
// ---------------------------------------------------------------------------

import { handleTranscribe } from "./transcribe.js";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (url.pathname === "/" && request.method === "GET") {
      return json({ ok: true, message: "Phrasebook backend is running" });
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return json({
        ok: true,
        providers: getProviderChain(env),
        hfTts: {
          fa: hfTtsConfigStatus(env, "fa"),
          ar: hfTtsConfigStatus(env, "ar"),
        },
      });
    }

    // ⭐ NEW: تبدیل صدا به متن با Whisper (Cloudflare Workers AI)
    if (url.pathname === "/api/transcribe" && request.method === "POST") {
      return handleTranscribe(request, env);
    }

    if (url.pathname === "/api/tts" && request.method === "GET") {
      const text = (url.searchParams.get("text") || "").trim();
      const voice = url.searchParams.get("voice") || "en-US-AriaNeural";
      if (!text) return json({ error: "text is required" }, 400);
      const langPrefix = voice.split("-")[0].toLowerCase();
      if (langPrefix === "fa" || langPrefix === "ar") {
        try {
          const { bytes, contentType } = await fetchHuggingFaceTtsAudio(text, langPrefix, env);
          return new Response(bytes, {
            headers: { "Content-Type": contentType, "Cache-Control": "public, max-age=86400", ...CORS_HEADERS },
          });
        } catch (hfErr) {
          try {
            const audioBytes = await fetchEdgeTtsAudio(text, voice);
            return new Response(audioBytes, {
              headers: { "Content-Type": "audio/mpeg", "Cache-Control": "public, max-age=86400", ...CORS_HEADERS },
            });
          } catch (edgeErr) {
            return json({ error: `hf-tts: ${hfErr.message || hfErr} | edge-tts: ${edgeErr.message || edgeErr}` }, 502);
          }
        }
      }
      try {
        const audioBytes = await fetchEdgeTtsAudio(text, voice);
        return new Response(audioBytes, {
          headers: { "Content-Type": "audio/mpeg", "Cache-Control": "public, max-age=86400", ...CORS_HEADERS },
        });
      } catch (e) {
        return json({ error: e.message || "edge-tts failed" }, 502);
      }
    }

    if (url.pathname === "/api/tts-gemini" && request.method === "GET") {
      const text = (url.searchParams.get("text") || "").trim();
      const voice = url.searchParams.get("voice") || "Kore";
      if (!text) return json({ error: "text is required" }, 400);
      try {
        const wavBytes = await fetchGeminiTtsAudio(text, voice, env);
        return new Response(wavBytes, {
          headers: { "Content-Type": "audio/wav", "Cache-Control": "public, max-age=86400", ...CORS_HEADERS },
        });
      } catch (e) {
        return json({ error: e.message || "gemini-tts failed" }, 502);
      }
    }

    if (url.pathname === "/api/youtube-captions" && request.method === "GET") {
      const videoId = (url.searchParams.get("videoId") || "").trim();
      const lang = (url.searchParams.get("lang") || "en").trim();
      if (!videoId) return json({ error: "videoId is required" }, 400);
      try {
        const result = await fetchYoutubeCaptions(videoId, lang);
        return json(result);
      } catch (e) {
        return json({ ok: false, error: e.message || "Could not fetch captions", noCaptions: !!e.noCaptions }, 502);
      }
    }

    // 📺 ترجمه‌ی زیرنویس یوتیوب به‌صورت chunk (چند خط + جمله‌های همسایه به‌عنوان زمینه)
    if (url.pathname === "/api/translate-subtitles" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Invalid JSON body" }, 400);
      }
      try {
        return json(await translateSubtitleChunk(body, env, ctx));
      } catch (e) {
        return json({ error: e.message || "subtitle translation failed" }, 502);
      }
    }

    // 📺 وقتی MediaSession آی‌دی ویدیو نمی‌ده، از روی عنوان (+مدت و کانال) آی‌دی رو پیدا می‌کنه
    if (url.pathname === "/api/youtube-resolve" && request.method === "GET") {
      const title = (url.searchParams.get("title") || "").trim();
      const channel = (url.searchParams.get("channel") || "").trim();
      const durationSec = Number(url.searchParams.get("durationSec") || 0) || 0;
      if (!title) return json({ error: "title is required" }, 400);
      try {
        return json(await resolveYoutubeVideoId(title, channel, durationSec));
      } catch (e) {
        return json({ error: e.message || "could not resolve video" }, 502);
      }
    }

    if (url.pathname === "/api/generate" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Invalid JSON body" }, 400);
      }
      const { prompt, maxTokens } = body || {};
      if (!prompt || typeof prompt !== "string") {
        return json({ error: "prompt (string) is required" }, 400);
      }
      const capped = Math.min(Math.max(Number(maxTokens) || 1000, 1), 8192);

      // کشِ مشترکِ D1: همان پرامپت (با همان سقفِ توکن) دوباره به هوش مصنوعی نمی‌رود.
      // برای «مثالِ جدید/بازتولید» کلاینت می‌تواند { "noCache": true } بفرستد.
      const useCache = !body.noCache;
      const cacheKey = useCache ? await genCacheKey(prompt, capped) : null;
      if (cacheKey) {
        const hit = await genCacheGet(env, cacheKey);
        if (hit) return json({ text: hit, provider: "cache", cached: true });
      }

      const chain = getProviderChain(env);
      const errors = [];
      // سقفِ زمانِ هر پرووایدر: یکی که کند/بی‌صدا شد، کلِ درخواست را معطل نکند و
      // زنجیره سریع برود سراغِ بعدی. متنِ کوتاه ≈ ۵ ثانیه؛ متنِ بلند (داستان) بیشتر.
      const perProviderMs = Math.min(45000, 4000 + capped * 10);
      for (const provider of chain) {
        try {
          const raw = await withTimeout(callProvider(provider, prompt, capped, env), perProviderMs, provider);
          // خروجیِ «فکرکردن»/«گارد (User Safety: safe)»/پرامپتِ برگشتی جواب نیست؛
          // به‌جای فرستادنش به اپ، همین‌جا رد می‌شود و پرووایدرِ بعدی امتحان می‌شود.
          const text = sanitizeAiText(raw);
          const bad = badAiOutputReason(text, prompt);
          if (bad) throw new Error(`unusable output (${bad})`);
          if (cacheKey) ctx.waitUntil(genCachePut(env, cacheKey, text, provider));
          return json({ text, provider });
        } catch (e) {
          errors.push(`${provider}: ${e.message}`);
        }
      }
      return json({ error: errors.join(" | ") }, 502);
    }

    return json({ error: "Not found" }, 404);
  },
};

// --- کشِ مشترکِ D1 برای /api/generate (مثال‌ساز و ...) ---------------------
// اگر binding با نام TR_DB تنظیم نشده باشد، همه‌ی این توابع بی‌صدا هیچ‌کاری نمی‌کنند.
const GEN_CACHE_TTL_MS = 180 * 24 * 60 * 60 * 1000; // ۱۸۰ روز
let genCacheReady = false;

async function genCacheKey(prompt, capped) {
  const data = new TextEncoder().encode(JSON.stringify([prompt, capped]));
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function genCacheInit(env) {
  if (genCacheReady) return;
  await env.TR_DB.prepare(
    "CREATE TABLE IF NOT EXISTS gen_cache (k TEXT PRIMARY KEY, v TEXT NOT NULL, provider TEXT, created INTEGER NOT NULL)"
  ).run();
  genCacheReady = true;
}

async function genCacheGet(env, key) {
  if (!env.TR_DB) return null;
  try {
    await genCacheInit(env);
    const row = await env.TR_DB.prepare("SELECT v, created FROM gen_cache WHERE k = ?1").bind(key).first();
    if (!row || Date.now() - row.created > GEN_CACHE_TTL_MS) return null;
    return row.v;
  } catch {
    return null;
  }
}

async function genCachePut(env, key, text, provider) {
  if (!env.TR_DB || !text) return;
  try {
    await genCacheInit(env);
    await env.TR_DB.prepare(
      "INSERT OR REPLACE INTO gen_cache (k, v, provider, created) VALUES (?1, ?2, ?3, ?4)"
    ).bind(key, text, provider, Date.now()).run();
  } catch {
    // خطای کش نباید جواب را خراب کند
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS },
  });
}

// --- زیرنویسِ واقعیِ یوتیوب -----------------------------------------------
// چند کلاینتِ innertube (ANDROID / ANDROID_VR / IOS / TV-embed) + صفحه‌ی watch هم‌زمان امتحان می‌شن؛
// اولین کسی که زیرنویسِ واقعی بده برنده‌ست. اگه همه شکست بخورن، دلیلِ واقعیِ هر کدوم تو پیام میاد.
const YT_CLIENTS = {
  ANDROID: {
    id: "3", version: "20.10.38",
    ua: "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
    client: { clientName: "ANDROID", clientVersion: "20.10.38", androidSdkVersion: 30, osName: "Android", osVersion: "11" },
  },
  ANDROID_VR: {
    id: "28", version: "1.62.27",
    ua: "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
    client: { clientName: "ANDROID_VR", clientVersion: "1.62.27", deviceMake: "Oculus", deviceModel: "Quest 3", androidSdkVersion: 32, osName: "Android", osVersion: "12L" },
  },
  IOS: {
    id: "5", version: "20.10.4",
    ua: "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
    client: { clientName: "IOS", clientVersion: "20.10.4", deviceMake: "Apple", deviceModel: "iPhone16,2", osName: "iPhone", osVersion: "18.3.2.22D82" },
  },
  TV: {
    id: "85", version: "2.0",
    ua: "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    client: { clientName: "TVHTML5_SIMPLY_EMBEDDED_PLAYER", clientVersion: "2.0" },
  },
};

function ytErr(msg, noCaptions) {
  const e = new Error(msg);
  e.noCaptions = !!noCaptions;
  return e;
}

async function fetchYoutubeCaptions(videoId, wantLang) {
  const cache = typeof caches !== "undefined" ? caches.default : null;
  const cacheKey = new Request(`https://cache.phrasebook.local/yt-captions/${encodeURIComponent(videoId)}/${encodeURIComponent(wantLang)}`);
  if (cache) {
    const hit = await cache.match(cacheKey).catch(() => null);
    if (hit) return await hit.json();
  }

  const attempts = [
    captionsViaClient("ANDROID", videoId, wantLang, 0),
    captionsViaClient("ANDROID_VR", videoId, wantLang, 0),
    captionsViaClient("IOS", videoId, wantLang, 300),
    captionsViaClient("TV", videoId, wantLang, 600),
    captionsViaWatchPage(videoId, wantLang, 900),
  ];
  let result;
  try {
    result = await Promise.any(attempts);
  } catch (agg) {
    const errs = (agg && agg.errors) || [agg];
    const noCaptions = errs.filter((e) => e && e.noCaptions).length >= 2;
    const msg = errs.map((e) => (e && e.message) || String(e)).join(" · ").slice(0, 400);
    throw ytErr(noCaptions ? "این ویدیو زیرنویس ندارد" : msg, noCaptions);
  }

  if (cache) {
    await cache
      .put(cacheKey, new Response(JSON.stringify(result), { headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=21600" } }))
      .catch(() => {});
  }
  return result;
}

async function captionsViaClient(name, videoId, wantLang, delayMs) {
  if (delayMs) await new Promise((r) => setTimeout(r, delayMs));
  const c = YT_CLIENTS[name];
  const label = name.toLowerCase();
  const body = {
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
    context: { client: { hl: "en", gl: "US", ...c.client } },
  };
  if (name === "TV") body.context.thirdParty = { embedUrl: `https://www.youtube.com/watch?v=${videoId}` };
  const res = await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": c.ua,
      "X-YouTube-Client-Name": c.id,
      "X-YouTube-Client-Version": c.version,
      Origin: "https://www.youtube.com",
      "Accept-Language": "en-US,en;q=0.9",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw ytErr(`${label}: player HTTP ${res.status}`);
  const data = await res.json();
  return await captionsFromPlayerResponse(data, label, c.ua, wantLang, videoId);
}

async function captionsViaWatchPage(videoId, wantLang, delayMs) {
  if (delayMs) await new Promise((r) => setTimeout(r, delayMs));
  const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
  const res = await fetch(`https://www.youtube.com/watch?v=${videoId}&hl=en&has_verified=1&bpctr=9999999999`, {
    headers: { "User-Agent": ua, "Accept-Language": "en-US,en;q=0.9", Cookie: "CONSENT=YES+1; SOCS=CAI" },
  });
  if (!res.ok) throw ytErr(`watch: HTTP ${res.status}`);
  const html = await res.text();
  const jsonStr = extractJsonAfter(html, "ytInitialPlayerResponse");
  if (!jsonStr) throw ytErr("watch: player response not found");
  return await captionsFromPlayerResponse(JSON.parse(jsonStr), "watch", ua, wantLang, videoId);
}

async function captionsFromPlayerResponse(data, label, ua, wantLang, videoId) {
  const status = data?.playabilityStatus?.status || "";
  if (status !== "OK") {
    const reason = String(data?.playabilityStatus?.reason || "").slice(0, 70);
    throw ytErr(`${label}: ${status || "no playability"}${reason ? ` (${reason})` : ""}`);
  }
  const tracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  if (!tracks || !tracks.length) throw ytErr(`${label}: no caption tracks`, true);

  const track = pickCaptionTrack(tracks, wantLang);
  const clean = track.baseUrl.replace(/[&?]fmt=[^&]*/g, "");
  let cues = [];
  let why = "";
  for (const url of [`${clean}&fmt=json3`, clean]) {
    const capRes = await fetch(url, { headers: { "User-Agent": ua, "Accept-Language": "en-US,en;q=0.9" } });
    if (!capRes.ok) { why = `timedtext HTTP ${capRes.status}`; continue; }
    const text = await capRes.text();
    if (!text.trim()) { why = "timedtext empty (needs PO token?)"; continue; }
    cues = parseCaptionBody(text);
    if (cues.length) break;
    why = "timedtext unparsable";
  }
  if (!cues.length) throw ytErr(`${label}: ${why}`);

  return {
    ok: true,
    videoId,
    lang: track.languageCode,
    isAuto: track.kind === "asr",
    availableLangs: tracks.map((t) => ({
      code: t.languageCode,
      name: (t.name && t.name.simpleText) || t.languageCode,
      auto: t.kind === "asr",
    })),
    cues,
  };
}

function decodeXmlEntities(s) {
  let out = s;
  for (let i = 0; i < 2 && out.includes("&"); i++) {
    out = out
      .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
      .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");
  }
  return out;
}

// json3 یا XML (srv1: <text start dur>، srv3: <p t d>)
function parseCaptionBody(text) {
  const t = text.trim();
  if (t.startsWith("{")) {
    try {
      const j = JSON.parse(t);
      return (j.events || [])
        .filter((e) => e.segs && e.segs.length)
        .map((e) => ({
          start: Math.round(e.tStartMs || 0) / 1000,
          end: Math.round((e.tStartMs || 0) + (e.dDurationMs || 0)) / 1000,
          text: e.segs.map((s) => s.utf8 || "").join("").replace(/\n/g, " ").trim(),
        }))
        .filter((c) => c.text);
    } catch {
      /* می‌افتیم رو XML */
    }
  }
  const out = [];
  const clean = (raw) => decodeXmlEntities(raw.replace(/<[^>]+>/g, "")).replace(/\n/g, " ").trim();
  let m;
  const v3 = /<p\s+t="(\d+)"(?:\s+d="(\d+)")?[^>]*>([\s\S]*?)<\/p>/g;
  while ((m = v3.exec(t))) {
    const st = parseInt(m[1], 10), du = m[2] ? parseInt(m[2], 10) : 0, tx = clean(m[3]);
    if (tx) out.push({ start: st / 1000, end: (st + du) / 1000, text: tx });
  }
  if (out.length) return out;
  const v1 = /<text\s+start="([\d.]+)"(?:\s+dur="([\d.]+)")?[^>]*>([\s\S]*?)<\/text>/g;
  while ((m = v1.exec(t))) {
    const st = parseFloat(m[1]), du = m[2] ? parseFloat(m[2]) : 0, tx = clean(m[3]);
    if (tx) out.push({ start: st, end: st + du, text: tx });
  }
  return out;
}

function extractJsonAfter(html, marker) {
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  const start = html.indexOf("{", idx);
  if (start === -1) return null;
  let depth = 0;
  let inStr = false;
  let strCh = "";
  let esc = false;
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === strCh) inStr = false;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inStr = true;
      strCh = ch;
      continue;
    }
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return html.slice(start, i + 1);
    }
  }
  return null;
}

function pickCaptionTrack(tracks, wantLang) {
  const norm = (s) => (s || "").toLowerCase().split("-")[0];
  const want = norm(wantLang);
  // 🌍 "auto": زبانِ اصلیِ ویدیو. ترکِ خودکار (asr) همیشه به زبانِ گفتارِ ویدیو ساخته می‌شه؛
  // اگه ترکِ دستی هم به همون زبان بود اون، وگرنه خودِ asr؛ اگه asr نبود، اولین ترکِ دستی.
  if (want === "auto") {
    const asr = tracks.find((t) => t.kind === "asr");
    if (asr) {
      const spoken = norm(asr.languageCode);
      return tracks.find((t) => t.kind !== "asr" && norm(t.languageCode) === spoken) || asr;
    }
    return tracks.find((t) => t.kind !== "asr") || tracks[0];
  }
  return (
    tracks.find((t) => norm(t.languageCode) === want && t.kind !== "asr") ||
    tracks.find((t) => norm(t.languageCode) === want) ||
    tracks.find((t) => t.kind !== "asr") ||
    tracks[0]
  );
}

// --- ترجمه‌ی chunk به chunk‌ِ زیرنویس (برای حالت یوتیوبِ حباب) --------------
// ورودی: { subtitles: [متنِ هر خط], context_before: [...], context_after: [...],
//          content_title, source_language, target_language, translation_tone }
// خروجی: { ok: true, translations: [...] } — دقیقاً به تعدادِ subtitles.
// جمله‌های همسایه فقط برای فهمیدنِ معنی داده می‌شن و ترجمه نمی‌شن؛ همین باعث
// می‌شه ترجمه‌ی خط‌های نیمه‌کاره (که یوتیوب وسطِ جمله می‌بره) دقیق‌تر بشه.
async function translateSubtitleChunk(body, env, ctx) {
  const subs = Array.isArray(body?.subtitles)
    ? body.subtitles.map((s) => (typeof s === "string" ? s : String(s?.text ?? "")))
    : [];
  if (!subs.length) throw new Error("subtitles (array) is required");
  if (subs.length > 30) throw new Error("too many subtitles in one chunk");

  const cleanList = (a) =>
    (Array.isArray(a) ? a : []).map((s) => String(s ?? "").slice(0, 300)).filter(Boolean).slice(0, 6);
  const before = cleanList(body.context_before);
  const after = cleanList(body.context_after);
  const srcName = String(body.source_language || "the source language").slice(0, 40);
  const tgtName = String(body.target_language || "").slice(0, 40);
  if (!tgtName) throw new Error("target_language is required");
  const title = String(body.content_title || "").slice(0, 160);
  const tone = String(body.translation_tone || "neutral").toLowerCase();

  let toneRule = "Use natural, neutral spoken language.";
  if (tone === "formal") toneRule = "Use a formal, polite register.";
  else if (tone === "casual") toneRule = "Use a casual, everyday spoken register.";

  const prompt =
    `You are a professional subtitle translator. Translate every subtitle line from ${srcName} to ${tgtName}.\n` +
    `Rules:\n` +
    `- Output ONLY a JSON array of exactly ${subs.length} strings, in the same order as the input. No markdown, no commentary.\n` +
    `- Item N of the output is the translation of item N of the input. Never merge or split lines, even if a sentence continues on the next line.\n` +
    `- ${toneRule}\n` +
    `- The context lines are ONLY for understanding the meaning; do NOT translate or output them.\n` +
    (title ? `\nVideo title: ${title}\n` : "\n") +
    (before.length ? `Context before (do not translate): ${JSON.stringify(before)}\n` : "") +
    `Subtitle lines to translate: ${JSON.stringify(subs)}\n` +
    (after.length ? `Context after (do not translate): ${JSON.stringify(after)}\n` : "");

  const maxTokens = Math.min(Math.max(600, subs.join("").length * 4 + 300), 4000);

  // ⚡ کشِ سمتِ سرور: همین جمله‌ها + همین زبان‌ها + همین لحن = همان ترجمه (بین همه‌ی کاربرها مشترک).
  // زمینه (جمله‌های قبل/بعد) عمداً در کلید نیست تا شانسِ hit بیشتر شود.
  const cache = typeof caches !== "undefined" ? caches.default : null;
  let cacheReq = null;
  if (cache) {
    try {
      const keyStr = JSON.stringify([srcName, tgtName, tone, subs]);
      const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyStr));
      const hex = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
      cacheReq = new Request(`https://cache.phrasebook.local/sub-tr/${hex}`);
      const hit = await cache.match(cacheReq).catch(() => null);
      if (hit) {
        const j = await hit.json();
        if (Array.isArray(j.translations) && j.translations.length === subs.length) {
          return { ok: true, provider: "cache", cached: true, translations: j.translations };
        }
      }
    } catch {
      cacheReq = null;
    }
  }

  // ⚡ به‌جای امتحانِ ترتیبیِ ~۲۰ پرووایدر (هر خرابی = چند ثانیه تأخیر)، «hedged»: اولی شروع می‌شود؛
  // اگر خطا داد، فوراً بعدی؛ اگر تا hedgeMs جواب نداد، بعدی هم‌زمان (حداکثر ۳ تا هم‌زمان). اولین جوابِ معتبر برنده است.
  const chain = getProviderChain(env);
  const { provider, value: arr } = await hedgedProviders(chain, prompt, maxTokens, env, (raw) => {
    const a = parseJsonStringArray(raw);
    if (!a || a.length !== subs.length) throw new Error(`bad shape (${a ? a.length : "no array"} vs ${subs.length})`);
    return a;
  });

  if (cache && cacheReq) {
    const put = cache
      .put(
        cacheReq,
        new Response(JSON.stringify({ translations: arr }), {
          headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=2592000" },
        })
      )
      .catch(() => {});
    if (ctx && typeof ctx.waitUntil === "function") ctx.waitUntil(put);
  }
  return { ok: true, provider, translations: arr };
}

// اولین پرووایدرِ موفق برنده است؛ بقیه‌ی درخواست‌های در حالِ اجرا نادیده گرفته می‌شوند.
function hedgedProviders(chain, prompt, maxTokens, env, validate, hedgeMs = 2500, maxInflight = 3) {
  return new Promise((resolve, reject) => {
    const errors = [];
    let next = 0;
    let inflight = 0;
    let settled = false;
    let timer = null;

    const finishFail = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error(errors.join(" | ") || "no provider available"));
    };

    const arm = () => {
      clearTimeout(timer);
      if (settled || next >= chain.length) return;
      timer = setTimeout(() => {
        if (!settled && inflight < maxInflight && next < chain.length) launch();
      }, hedgeMs);
    };

    const launch = () => {
      if (settled) return;
      if (next >= chain.length) {
        if (inflight === 0) finishFail();
        return;
      }
      const provider = chain[next++];
      inflight++;
      Promise.resolve()
        .then(() => callProvider(provider, prompt, maxTokens, env))
        .then((raw) => validate(raw))
        .then((value) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve({ provider, value });
        })
        .catch((e) => {
          errors.push(`${provider}: ${(e && e.message) || e}`);
        })
        .finally(() => {
          inflight--;
          if (settled) return;
          if (next < chain.length) launch();
          else if (inflight === 0) finishFail();
        });
      arm();
    };

    launch();
  });
}

function parseJsonStringArray(raw) {
  if (typeof raw !== "string") return null;
  const a = raw.indexOf("[");
  const b = raw.lastIndexOf("]");
  if (a === -1 || b <= a) return null;
  try {
    const arr = JSON.parse(raw.slice(a, b + 1));
    if (!Array.isArray(arr)) return null;
    return arr.map((x) => (typeof x === "string" ? x.trim() : String(x ?? "").trim()));
  } catch {
    return null;
  }
}

// --- پیدا کردنِ آی‌دیِ ویدیو از روی عنوان (جست‌وجوی innertube) -----------------
async function resolveYoutubeVideoId(title, channel, durationSec) {
  const INNERTUBE_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
  const res = await fetch(`https://www.youtube.com/youtubei/v1/search?key=${INNERTUBE_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: channel ? `${title} ${channel}` : title,
      context: { client: { clientName: "WEB", clientVersion: "2.20240401.01.00", hl: "en", gl: "US" } },
    }),
  });
  if (!res.ok) throw new Error(`search status ${res.status}`);
  const data = await res.json();

  const found = [];
  const walk = (node, depth) => {
    if (!node || depth > 14 || found.length > 40) return;
    if (Array.isArray(node)) {
      for (const n of node) walk(n, depth + 1);
      return;
    }
    if (typeof node !== "object") return;
    if (node.videoRenderer && node.videoRenderer.videoId) found.push(node.videoRenderer);
    for (const k of Object.keys(node)) walk(node[k], depth + 1);
  };
  walk(data, 0);
  if (!found.length) throw new Error("no search results");

  const norm = (s) => String(s || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  const wantTitle = norm(title);
  const wantChannel = norm(channel);
  const toSec = (t) => {
    const parts = String(t || "").split(":").map((x) => parseInt(x, 10));
    if (!parts.length || parts.some((n) => Number.isNaN(n))) return 0;
    return parts.reduce((acc, n) => acc * 60 + n, 0);
  };

  let best = null;
  let bestScore = -1;
  for (const v of found) {
    const vTitle = norm((v.title?.runs || []).map((r) => r.text).join("") || v.title?.simpleText);
    const vChannel = norm((v.ownerText?.runs || []).map((r) => r.text).join(""));
    const vSec = toSec(v.lengthText?.simpleText);
    let score = 0;
    if (vTitle === wantTitle) score += 6;
    else if (vTitle && (vTitle.includes(wantTitle) || wantTitle.includes(vTitle))) score += 3;
    if (wantChannel && vChannel && (vChannel === wantChannel || vChannel.includes(wantChannel) || wantChannel.includes(vChannel))) score += 2;
    if (durationSec > 0 && vSec > 0) {
      const diff = Math.abs(vSec - durationSec);
      if (diff <= 2) score += 5;
      else if (diff <= 6) score += 2;
      else score -= 3;
    }
    if (score > bestScore) {
      bestScore = score;
      best = v;
    }
  }
  // بدونِ هیچ نشانه‌ی قابل‌اعتمادی (عنوان یا مدت) حدس نمی‌زنیم؛ زیرنویسِ ویدیوی اشتباه بدتر از بی‌زیرنویسیه.
  if (!best || bestScore < 3) throw new Error("could not confidently match the video");
  return {
    ok: true,
    videoId: best.videoId,
    title: (best.title?.runs || []).map((r) => r.text).join("") || best.title?.simpleText || "",
    score: bestScore,
  };
}

// --- Hugging Face TTS (فارسی/عربی) -------------------------------------------
function hfTtsModelFor(lang, env) {
  if (lang === "fa") return env.HF_TTS_MODEL_FA || "facebook/mms-tts-fas";
  if (lang === "ar") return env.HF_TTS_MODEL_AR || "facebook/mms-tts-ara";
  return null;
}

function hfTtsSpaceUrlFor(lang, env) {
  if (lang === "fa") return env.HF_TTS_SPACE_FA_URL || "";
  if (lang === "ar") return env.HF_TTS_SPACE_AR_URL || "";
  return "";
}

function hfTtsConfigStatus(env, lang) {
  const spaceUrl = hfTtsSpaceUrlFor(lang, env);
  if (spaceUrl) return { mode: "custom-space", url: spaceUrl };
  if (env.HF_API_KEY) return { mode: "hf-inference", model: hfTtsModelFor(lang, env) };
  return { mode: "none (HF_API_KEY not set)" };
}

async function fetchHuggingFaceTtsAudio(text, lang, env) {
  const sanitized = String(text).slice(0, 600);
  const spaceUrl = hfTtsSpaceUrlFor(lang, env);

  if (spaceUrl) {
    const headers = { "Content-Type": "application/json" };
    if (env.HF_TTS_SPACE_TOKEN) headers.Authorization = `Bearer ${env.HF_TTS_SPACE_TOKEN}`;
    const r = await fetch(spaceUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({ text: sanitized, lang }),
    });
    if (!r.ok) {
      const snippet = (await r.text().catch(() => "")).slice(0, 160);
      throw new Error(`custom TTS service HTTP ${r.status}${snippet ? ` (${snippet})` : ""}`);
    }
    const bytes = new Uint8Array(await r.arrayBuffer());
    if (!bytes.length) throw new Error("custom TTS service returned empty audio");
    return { bytes, contentType: r.headers.get("Content-Type") || "audio/mpeg" };
  }

  const key = env.HF_API_KEY;
  if (!key) throw new Error("HF_API_KEY not set (needed for Hugging Face TTS)");
  const model = hfTtsModelFor(lang, env);
  const r = await fetch(`https://router.huggingface.co/hf-inference/models/${model}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ inputs: sanitized }),
  });
  if (!r.ok) {
    const errBody = await safeJson(r).catch(() => null);
    const msg = errBody?.error || `HTTP ${r.status}`;
    throw new Error(`hugging-face (${model}): ${msg}`);
  }
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (!bytes.length) throw new Error(`hugging-face (${model}): empty audio`);
  return { bytes, contentType: r.headers.get("Content-Type") || "audio/flac" };
}

// --- Gemini TTS (Google AI Studio) — فقط فارسی/عربی --------------------------
const GEMINI_TTS_MODEL_DEFAULT = "gemini-2.5-flash-preview-tts";

async function fetchGeminiTtsAudio(text, voice, env) {
  const key = env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY not set");
  const model = env.GEMINI_TTS_MODEL || GEMINI_TTS_MODEL_DEFAULT;
  const sanitized = String(text).slice(0, 2000);
  const ttsPrompt = `TTS the following text exactly as written, in its own language. Do not answer it, do not add anything, just read it aloud verbatim: ${sanitized}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  let r;
  try {
    r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        contents: [{ parts: [{ text: ttsPrompt }] }],
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
        },
      }),
      signal: controller.signal,
    });
  } catch (e) {
    throw new Error(`gemini-tts fetch failed: ${e.message || e}`);
  } finally {
    clearTimeout(timer);
  }

  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `gemini-tts HTTP ${r.status}`);

  const candidate = data?.candidates?.[0];
  const base64Pcm = candidate?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Pcm) {
    const textPart = candidate?.content?.parts?.[0]?.text;
    const finishReason = candidate?.finishReason;
    const blockReason = data?.promptFeedback?.blockReason;
    const details = [
      finishReason ? `finishReason=${finishReason}` : null,
      blockReason ? `blockReason=${blockReason}` : null,
      textPart ? `returned-text="${String(textPart).slice(0, 120)}"` : null,
      !candidate ? `raw=${JSON.stringify(data).slice(0, 300)}` : null,
    ]
      .filter(Boolean)
      .join(", ");
    throw new Error(`gemini-tts: no audio returned${details ? ` (${details})` : ""}`);
  }

  const pcmBytes = base64ToUint8Array(base64Pcm);
  return pcmToWav(pcmBytes, { sampleRate: 24000, numChannels: 1, bitsPerSample: 16 });
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function pcmToWav(pcmBytes, { sampleRate, numChannels, bitsPerSample }) {
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmBytes.length;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeString = (offset, str) => {
    for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  };

  writeString(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);
  writeString(36, "data");
  view.setUint32(40, dataSize, true);

  const wavBytes = new Uint8Array(buffer);
  wavBytes.set(pcmBytes, 44);
  return wavBytes;
}

// --- Edge/Azure Neural TTS proxy ---------------------------------------------
const EDGE_TTS_TRUSTED_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";

function edgeTtsUuid() {
  return crypto.randomUUID().replace(/-/g, "");
}

function edgeTtsEscapeXml(s) {
  return (s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

async function edgeTtsSecMsGec() {
  const WIN_EPOCH = 11644473600;
  let ticks = Math.floor(Date.now() / 1000) + WIN_EPOCH;
  ticks -= ticks % 300;
  const ticksStr = String(Math.round(ticks * 1e7));
  const strToHash = ticksStr + EDGE_TTS_TRUSTED_TOKEN;
  const enc = new TextEncoder().encode(strToHash);
  const hashBuf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(hashBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

async function fetchEdgeTtsAudio(text, voice) {
  const sanitized = String(text).slice(0, 600);
  const gec = await edgeTtsSecMsGec();
  const connId = edgeTtsUuid();
  const wsUrl =
    "https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
    `?TrustedClientToken=${EDGE_TTS_TRUSTED_TOKEN}` +
    `&Sec-MS-GEC=${gec}` +
    `&Sec-MS-GEC-Version=1-131.0.2903.99` +
    `&ConnectionId=${connId}`;

  const resp = await fetch(wsUrl, {
    headers: {
      Upgrade: "websocket",
      Origin: "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
    },
  });
  const ws = resp.webSocket;
  if (!ws) throw new Error("edge-tts: upstream didn't upgrade to websocket");
  ws.accept();

  return new Promise((resolve, reject) => {
    const audioParts = [];
    let settled = false;

    const finishOk = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      try {
        ws.close();
      } catch (e) {}
      if (!audioParts.length) {
        reject(new Error("edge-tts: no audio returned"));
        return;
      }
      let total = 0;
      for (const p of audioParts) total += p.length;
      const merged = new Uint8Array(total);
      let offset = 0;
      for (const p of audioParts) {
        merged.set(p, offset);
        offset += p.length;
      }
      resolve(merged);
    };
    const finishFail = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      try {
        ws.close();
      } catch (e) {}
      reject(err || new Error("edge-tts: failed"));
    };
    const timeoutId = setTimeout(() => finishFail(new Error("edge-tts: timeout")), 15000);

    ws.addEventListener("message", (evt) => {
      if (typeof evt.data === "string") {
        if (evt.data.indexOf("Path:turn.end") !== -1) finishOk();
        return;
      }
      try {
        const buf = new Uint8Array(evt.data);
        if (buf.length < 2) return;
        const headerLen = (buf[0] << 8) | buf[1];
        const headerStr = new TextDecoder("utf-8").decode(buf.slice(2, 2 + headerLen));
        if (headerStr.indexOf("Path:audio") !== -1) {
          const audioData = buf.slice(2 + headerLen);
          if (audioData.length) audioParts.push(audioData);
        }
      } catch (e) {}
    });
    ws.addEventListener("close", () => finishOk());
    ws.addEventListener("error", () => finishFail(new Error("edge-tts: websocket error")));

    try {
      const now = new Date().toISOString();
      ws.send(
        `X-Timestamp:${now}\r\n` +
          "Content-Type:application/json; charset=utf-8\r\n" +
          "Path:speech.config\r\n\r\n" +
          JSON.stringify({
            context: {
              synthesis: {
                audio: {
                  metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false },
                  outputFormat: "audio-24khz-48kbitrate-mono-mp3",
                },
              },
            },
          })
      );
      const ssml =
        `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>` +
        `<voice name='${voice}'><prosody rate='+0%'>${edgeTtsEscapeXml(sanitized)}</prosody></voice>` +
        `</speak>`;
      ws.send(
        `X-RequestId:${edgeTtsUuid()}\r\n` +
          "Content-Type:application/ssml+xml\r\n" +
          `X-Timestamp:${now}\r\n` +
          "Path:ssml\r\n\r\n" +
          ssml
      );
    } catch (e) {
      finishFail(e);
    }
  });
}

async function safeJson(r) {
  const raw = await r.text();
  try {
    return JSON.parse(raw);
  } catch {
    const snippet = raw.trim().slice(0, 120) || `HTTP ${r.status}`;
    throw new Error(`non-JSON response (${snippet})`);
  }
}

function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`timeout after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

// <think>…</think> و برچسب‌های مشابه را برمی‌دارد.
function sanitizeAiText(text) {
  return String(text || "")
    .replace(/<think(ing)?>[\s\S]*?<\/think(ing)?>/gi, "")
    .replace(/<think(ing)?>[\s\S]*$/gi, "")
    .trim();
}

// دلیلِ «این جواب نیست» — یا null اگر سالم است.
function badAiOutputReason(text, prompt) {
  const t = String(text || "").trim();
  if (!t) return "empty";
  if (/^\s*(user\s+|assistant\s+)?safety\s*:/im.test(t) || /^\s*(safe|unsafe)\s*$/im.test(t)) return "guard";
  if (/(thinking process|here'?s a thinking|analy[sz]e the (request|text|input|user)|\*\*\s*analy[sz]e|the user (wants|asks|is asking) |let me (read|think|analy[sz]e|re-?read)|<\/?think(ing)?>|^\s*(we need to|we should|we must|let'?s (craft|produce|compose|draft)))/im.test(t)) return "reasoning";
  // خودِ پرامپت برگشته؟ (۶۰ کاراکترِ اولِ پرامپت عیناً در جواب)
  const head = String(prompt || "").trim().slice(0, 60);
  if (head.length >= 40 && t.includes(head)) return "prompt-echo";
  return null;
}

const VALID_PROVIDERS = [
  "huggingface", "groq", "gemini", "deepseek", "openai", "avalai", "grok", "openrouter", "mistral", "cerebras",
  "aionlabs", "cohere", "zai", "cloudflareai", "kilocode", "llm7", "modelscope", "nvidianim", "ollamacloud", "ovhcloud", "siliconflow",
];
function getProviderChain(env) {
  const raw = (
    env.AI_PROVIDER ||
    "kilocode,llm7,ovhcloud,groq,nvidianim,ollamacloud,cloudflareai,mistral,cohere,zai,aionlabs,modelscope,siliconflow,openrouter,cerebras,grok,gemini,huggingface"
  ).toLowerCase();
  const chain = raw
    .split(",")
    .map((p) => p.trim())
    .filter((p) => VALID_PROVIDERS.includes(p));
  return chain.length ? chain : ["openrouter"];
}

async function callProvider(provider, prompt, maxTokens, env) {
  if (provider === "huggingface") return callHuggingFace(prompt, maxTokens, env);
  if (provider === "groq") return callGroq(prompt, maxTokens, env);
  if (provider === "gemini") return callGemini(prompt, maxTokens, env);
  if (provider === "deepseek") return callDeepSeek(prompt, maxTokens, env);
  if (provider === "openai") return callOpenAI(prompt, maxTokens, env);
  if (provider === "avalai") return callAvalAI(prompt, maxTokens, env);
  if (provider === "grok") return callGrok(prompt, maxTokens, env);
  if (provider === "openrouter") return callOpenRouter(prompt, maxTokens, env);
  if (provider === "mistral") return callMistral(prompt, maxTokens, env);
  if (provider === "cerebras") return callCerebras(prompt, maxTokens, env);
  if (provider === "aionlabs") return callAionLabs(prompt, maxTokens, env);
  if (provider === "cohere") return callCohere(prompt, maxTokens, env);
  if (provider === "zai") return callZai(prompt, maxTokens, env);
  if (provider === "cloudflareai") return callCloudflareAI(prompt, maxTokens, env);
  if (provider === "kilocode") return callKiloCode(prompt, maxTokens, env);
  if (provider === "llm7") return callLLM7(prompt, maxTokens, env);
  if (provider === "modelscope") return callModelScope(prompt, maxTokens, env);
  if (provider === "nvidianim") return callNvidiaNim(prompt, maxTokens, env);
  if (provider === "ollamacloud") return callOllamaCloud(prompt, maxTokens, env);
  if (provider === "ovhcloud") return callOvhCloud(prompt, maxTokens, env);
  if (provider === "siliconflow") return callSiliconFlow(prompt, maxTokens, env);
  throw new Error(`Unknown provider "${provider}"`);
}

async function callAionLabs(prompt, maxTokens, env) {
  const key = env.AIONLABS_API_KEY;
  if (!key) throw new Error("AIONLABS_API_KEY not set");
  const r = await fetch("https://api.aionlabs.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.AIONLABS_MODEL || "aion-labs/aion-3.0-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Aion Labs HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Aion Labs returned empty response");
  return text;
}

async function callCohere(prompt, maxTokens, env) {
  const key = env.COHERE_API_KEY;
  if (!key) throw new Error("COHERE_API_KEY not set");
  const r = await fetch("https://api.cohere.com/v2/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.COHERE_MODEL || "command-r7b-12-2024",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.message || `Cohere HTTP ${r.status}`);
  const parts = data?.message?.content || [];
  const text = parts.map((p) => p.text || "").join("").trim();
  if (!text) throw new Error("Cohere returned empty response");
  return text;
}

async function callZai(prompt, maxTokens, env) {
  const key = env.ZAI_API_KEY;
  if (!key) throw new Error("ZAI_API_KEY not set");
  const r = await fetch("https://api.z.ai/api/paas/v4/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.ZAI_MODEL || "glm-4.7-flash",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Z AI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Z AI returned empty response");
  return text;
}

async function callCloudflareAI(prompt, maxTokens, env) {
  const token = env.CF_API_TOKEN;
  const accountId = env.CF_ACCOUNT_ID;
  if (!token || !accountId) throw new Error("CF_API_TOKEN/CF_ACCOUNT_ID not set");
  const model = env.CF_AI_MODEL || "@cf/openai/gpt-oss-120b";
  const r = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/${model}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens,
      }),
    }
  );
  const data = await safeJson(r);
  if (!r.ok || data?.success === false) {
    const errMsg = (data?.errors || []).map((e) => e.message).join("; ");
    throw new Error(errMsg || `Cloudflare Workers AI HTTP ${r.status}`);
  }
  const text = data?.result?.response || "";
  if (!text) throw new Error("Cloudflare Workers AI returned empty response");
  return text;
}

async function callKiloCode(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.KILOCODE_API_KEY) headers.Authorization = `Bearer ${env.KILOCODE_API_KEY}`;
  const r = await fetch("https://api.kilo.ai/api/gateway/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.KILOCODE_MODEL || "openrouter/free",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Kilo Code HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Kilo Code returned empty response");
  return text;
}

async function callLLM7(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.LLM7_API_KEY) headers.Authorization = `Bearer ${env.LLM7_API_KEY}`;
  const r = await fetch("https://api.llm7.io/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.LLM7_MODEL || "gpt-oss:20b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `LLM7.io HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("LLM7.io returned empty response");
  return text;
}

async function callModelScope(prompt, maxTokens, env) {
  const key = env.MODELSCOPE_API_KEY;
  if (!key) throw new Error("MODELSCOPE_API_KEY not set");
  const r = await fetch("https://api-inference.modelscope.cn/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.MODELSCOPE_MODEL || "Qwen/Qwen3.5-35B-A3B",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `ModelScope HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("ModelScope returned empty response");
  return text;
}

async function callNvidiaNim(prompt, maxTokens, env) {
  const key = env.NVIDIA_API_KEY;
  if (!key) throw new Error("NVIDIA_API_KEY not set");
  const r = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.NVIDIA_MODEL || "meta/llama-3.3-70b-instruct",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `NVIDIA NIM HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("NVIDIA NIM returned empty response");
  return text;
}

async function callOllamaCloud(prompt, maxTokens, env) {
  const key = env.OLLAMA_API_KEY;
  if (!key) throw new Error("OLLAMA_API_KEY not set");
  const r = await fetch("https://ollama.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.OLLAMA_MODEL || "gpt-oss:120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Ollama Cloud HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Ollama Cloud returned empty response");
  return text;
}

async function callOvhCloud(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.OVHCLOUD_API_KEY) headers.Authorization = `Bearer ${env.OVHCLOUD_API_KEY}`;
  const r = await fetch("https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.OVHCLOUD_MODEL || "gpt-oss-120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `OVHcloud HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OVHcloud returned empty response");
  return text;
}

async function callSiliconFlow(prompt, maxTokens, env) {
  const key = env.SILICONFLOW_API_KEY;
  if (!key) throw new Error("SILICONFLOW_API_KEY not set");
  const r = await fetch("https://api.siliconflow.cn/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.SILICONFLOW_MODEL || "Qwen/Qwen3-8B",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `SiliconFlow HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("SiliconFlow returned empty response");
  return text;
}

async function callHuggingFace(prompt, maxTokens, env) {
  const key = env.HF_API_KEY;
  if (!key) throw new Error("HF_API_KEY not set");
  const model = env.HF_MODEL || "openai/gpt-oss-120b";
  const r = await fetch("https://router.huggingface.co/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Hugging Face HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Hugging Face returned empty response");
  return text.trim();
}

async function callGroq(prompt, maxTokens, env) {
  const key = env.GROQ_API_KEY;
  if (!key) throw new Error("GROQ_API_KEY not set");
  const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.GROQ_MODEL || "openai/gpt-oss-120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
      // gpt-oss «فکر» می‌کند و فکرش از سقفِ توکن و زمان کم می‌کند → حداقل
      ...((env.GROQ_MODEL || "openai/gpt-oss-120b").includes("gpt-oss")
        ? { reasoning_effort: "low", include_reasoning: false }
        : {}),
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Groq HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Groq returned empty response");
  return text;
}

async function callGemini(prompt, maxTokens, env) {
  const key = env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY not set");
  const model = env.GEMINI_MODEL || "gemini-3.6-flash";
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: maxTokens },
      }),
    }
  );
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Gemini HTTP ${r.status}`);
  const text = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
  if (!text) throw new Error("Gemini returned empty response");
  return text;
}

async function callDeepSeek(prompt, maxTokens, env) {
  const key = env.DEEPSEEK_API_KEY;
  if (!key) throw new Error("DEEPSEEK_API_KEY not set");
  const baseUrl = env.DEEPSEEK_BASE_URL || "https://api.deepseek.com";
  const r = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.DEEPSEEK_MODEL || "deepseek-chat",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `DeepSeek HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("DeepSeek returned empty response");
  return text;
}

async function callOpenAI(prompt, maxTokens, env) {
  const key = env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY not set");
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `OpenAI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OpenAI returned empty response");
  return text;
}

async function callGrok(prompt, maxTokens, env) {
  const key = env.GROK_API_KEY || env.XAI_API_KEY;
  if (!key) throw new Error("GROK_API_KEY not set");
  const r = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.GROK_MODEL || "grok-3-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Grok HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Grok returned empty response");
  return text;
}

async function callOpenRouter(prompt, maxTokens, env) {
  const key = env.OPENROUTER_API_KEY;
  if (!key) throw new Error("OPENROUTER_API_KEY not set");
  const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
      "HTTP-Referer": env.OPENROUTER_SITE_URL || "https://maryam1998.github.io/Hope/",
      "X-Title": "LingoLearn",
    },
    body: JSON.stringify({
      model: env.OPENROUTER_MODEL || "deepseek/deepseek-chat",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `OpenRouter HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OpenRouter returned empty response");
  return text;
}

async function callMistral(prompt, maxTokens, env) {
  const key = env.MISTRAL_API_KEY;
  if (!key) throw new Error("MISTRAL_API_KEY not set");
  const r = await fetch("https://api.mistral.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.MISTRAL_MODEL || "mistral-small-latest",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Mistral HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Mistral returned empty response");
  return text;
}

async function callCerebras(prompt, maxTokens, env) {
  const key = env.CEREBRAS_API_KEY;
  if (!key) throw new Error("CEREBRAS_API_KEY not set");
  const r = await fetch("https://api.cerebras.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.CEREBRAS_MODEL || "llama3.1-8b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Cerebras HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Cerebras returned empty response");
  return text;
}

async function callAvalAI(prompt, maxTokens, env) {
  const key = env.AVALAI_API_KEY;
  if (!key) throw new Error("AVALAI_API_KEY not set");
  const r = await fetch("https://api.avalai.ir/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.AVALAI_MODEL || "deepseek-chat",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `AvalAI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("AvalAI returned empty response");
  return text;
}
