// ---------------------------------------------------------------------------
// 🗄️ /api/tr-share — کشِ مشترکِ ترجمه‌های اصلاح‌شده‌ی کاربرها
//   op "get": { items: [{text}], source_lang_code, target_lang_code } → { results: [string|null, ...] }
//   op "put": { text, translation, source_lang_code, target_lang_code } → { ok: true }
// از همان جدول و همان کلیدِ /api/translate-text (gen_cache) استفاده می‌کند؛ پس
// translate-text هم ترجمه‌ی اصلاح‌شده را می‌بیند. هیچ AI صدا زده نمی‌شود (هزینه‌ی صفر).
// ردیف‌های این مسیر provider = "user" دارند (برای پاک‌سازی: DELETE FROM gen_cache WHERE provider='user').
// ---------------------------------------------------------------------------

const LANGS = new Set(["fa", "en", "it", "hi", "tr", "ar", "es", "de", "fr", "zh", "ko", "ru", "ja"]);
const MAX_TEXT = 300;      // مثلِ سقفِ /api/translate-text: متنِ بلندِ کاربر وارد کشِ مشترک نمی‌شود
const MAX_TRANSLATION = 1200;
const MAX_BATCH = 40;

// ⏳ مثلِ GEN_CACHE_TTL_MS در index.js؛ ردیف‌های provider="user" هیچ‌وقت منقضی نمی‌شوند.
const TTL_MS = 180 * 24 * 60 * 60 * 1000;

// یک کوئریِ SQL برای کلِ دسته (به‌جای یک کوئری برای هر مورد — سقفِ D1 رایگان ۵۰ کوئری در هر درخواست است).
// اگر برای زبانِ مبدأِ دقیق چیزی نبود، ترجمه‌ی ذخیره‌شده با مبدأِ "auto" هم قبول است.
async function lookupMany(env, deps, texts, source, target) {
  const { genCacheKey, genCacheGet } = deps;
  const valid = texts.map((t) => !!t && t.length <= MAX_TEXT);
  const exact = await Promise.all(
    texts.map((t, i) => (valid[i] ? genCacheKey(`translate-text|${source}|${target}|${t}`, 0) : null))
  );
  const auto = source === "auto"
    ? exact
    : await Promise.all(texts.map((t, i) => (valid[i] ? genCacheKey(`translate-text|auto|${target}|${t}`, 0) : null)));
  const keys = [...new Set([...exact, ...auto].filter(Boolean))];
  if (!keys.length) return texts.map(() => null);

  const rows = new Map();
  try {
    if (!env.TR_DB) return texts.map(() => null);
    const ph = keys.map((_, i) => `?${i + 1}`).join(",");
    const res = await env.TR_DB.prepare(
      `SELECT k, v, provider, created FROM gen_cache WHERE k IN (${ph})`
    ).bind(...keys).all();
    for (const r of res.results || []) rows.set(r.k, r);
  } catch {
    // جدول هنوز ساخته نشده یا خطای D1 → مسیرِ قدیمیِ تک‌به‌تک (که جدول را هم می‌سازد)
    return Promise.all(
      texts.map(async (t, i) => (valid[i] ? (await genCacheGet(env, exact[i])) || null : null))
    );
  }
  const fresh = (r) => r && r.v && (r.provider === "user" || Date.now() - r.created <= TTL_MS);
  return texts.map((t, i) => {
    if (!valid[i]) return null;
    const a = rows.get(exact[i]);
    if (fresh(a)) return a.v;
    const b = rows.get(auto[i]);
    return fresh(b) ? b.v : null;
  });
}

function resp(data, status, cors) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...cors },
  });
}

function norm(body) {
  const target = String(body?.target_lang_code ?? "").toLowerCase();
  const source = String(body?.source_lang_code ?? "auto").toLowerCase() || "auto";
  if (!LANGS.has(target)) return null;
  if (source !== "auto" && !LANGS.has(source)) return null;
  return { source, target };
}

export async function handleTrShare(request, env, ctx, cors, deps) {
  const { genCacheKey, genCacheGet, genCachePut } = deps;
  let body;
  try {
    body = await request.json();
  } catch {
    return resp({ error: "Invalid JSON body" }, 400, cors);
  }
  const lp = norm(body);
  if (!lp) return resp({ error: "unsupported language" }, 400, cors);
  const { source, target } = lp;
  const keyOf = (text) => genCacheKey(`translate-text|${source}|${target}|${text}`, 0);

  if (body.op === "get") {
    const items = Array.isArray(body.items) ? body.items.slice(0, MAX_BATCH) : [];
    const texts = items.map((it) => String(it?.text ?? "").trim());
    const results = await lookupMany(env, deps, texts, source, target);
    return resp({ results }, 200, cors);
  }

  if (body.op === "put") {
    const text = String(body.text ?? "").trim();
    const tr = String(body.translation ?? "").trim();
    if (!text || text.length > MAX_TEXT) return resp({ error: "bad text" }, 400, cors);
    if (!tr || tr.length > MAX_TRANSLATION) return resp({ error: "bad translation" }, 400, cors);
    if (source === target) return resp({ ok: false, skipped: "same-language" }, 200, cors);
    if (tr.toLowerCase() === text.toLowerCase()) return resp({ ok: false, skipped: "same-as-source" }, 200, cors);
    if (!/\p{L}/u.test(tr)) return resp({ ok: false, skipped: "no-letters" }, 200, cors);
    // نسبتِ طول (برای متن‌های بلندتر از ۲۰ نویسه؛ CJK کوتاه‌تر است)
    if (text.length >= 20) {
      const ratio = tr.length / text.length;
      if (ratio < 0.15 || ratio > 6) return resp({ ok: false, skipped: "bad-ratio" }, 200, cors);
    }
    const key = await keyOf(text);
    // 💾 اگر همین ترجمه از قبل در کش هست، ننویس (سقفِ نوشتنِ D1 رایگان فقط ۱۰۰٬۰۰۰ ردیف در روز است؛ خواندن ۵ میلیون)
    const existing = await genCacheGet(env, key);
    if (existing && existing === tr) return resp({ ok: true, skipped: "same" }, 200, cors);
    await genCachePut(env, key, tr, "user");
    return resp({ ok: true }, 200, cors);
  }

  return resp({ error: "unknown op" }, 400, cors);
}
