import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app.dart';
import '../../core/constants/supported_languages.dart';
import '../../core/mascot/mascot_pin_provider.dart';
import '../../core/models/language_selection.dart';
import '../../core/practice/practice_follow.dart' show PinnedCallSlot;
import '../../core/providers/app_prefs_provider.dart';
import '../../core/providers/language_selection_provider.dart';
import '../../core/providers/player_prefs_provider.dart';
import '../../core/router/app_router.dart' show kLastTabPrefKey, kRestorableTabs;
import '../../core/router/back_handlers.dart';
import '../../core/storage/local_storage.dart' show localStorageProvider, sharedPrefsProvider;
import '../../core/storage/prefs_keys.dart';
import '../../core/translate/mlkit_prefetch.dart';
import '../../core/translate/translation_service.dart' show TranslationService;
import '../../core/sync/cloud_sync.dart';
import '../../core/theme/app_theme_colors.dart';
import '../grammar/widgets/practice_sheet.dart';
import 'widgets/feature_dock.dart';
import 'widgets/lingova_mascot.dart';
import 'widgets/player_bar.dart';
import 'widgets/spotlight_tour.dart';

/// 🔕 پنل «تمرین جمله‌سازی و گرامر» فعلاً مخفی است. کدش (PracticeSheet در
/// features/grammar/widgets/practice_sheet.dart) دست‌نخورده مانده؛ برای
/// برگرداندن فقط این مقدار را `true` کن.
const bool kShowPracticeSheet = false;

/// پوستهٔ اپ. مثل Hope هدر/تب‌ها اینجا ثابت نیستند؛ هر تب آن‌ها را
/// (ShellHeader) به‌عنوان اولین آیتمِ لیستِ خودش نشان می‌دهد تا با اسکرول
/// بالا برود. فقط پنل تمرین و پلیر پایینِ صفحه ثابت می‌مانند.
class AppShell extends ConsumerStatefulWidget {
  final Widget child;
  const AppShell({super.key, required this.child});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  /// تب‌هایی که کاربر قبلاً دیده (آخرین = همان که با «بازگشت» برمی‌گردد).
  final List<String> _history = [];
  String _loc = '';
  bool _goingBack = false;
  DateTime? _lastBack;

  static const String _historyPrefKey = 'tab-history';

  StreamSubscription<String>? _refreshSub;

  static const Map<String, Map<String, String>> _refreshMsgs = {
    'confirmed': {
      'fa': 'همین ترجمه تأیید شده است ✓',
      'en': 'This translation is confirmed ✓',
      'ar': 'تم تأكيد هذه الترجمة ✓',
      'es': 'Esta traducción está confirmada ✓',
      'de': 'Diese Übersetzung ist bestätigt ✓',
      'fr': 'Cette traduction est confirmée ✓',
    },
    'limit': {
      'fa': 'برای این متن امروز دیگر نمی‌شود رفرش کرد (حداکثر ۲ بار در روز)',
      'en': 'No more refreshes for this text today (max 2 per day)',
      'ar': 'لا مزيد من التحديث لهذا النص اليوم (حد أقصى مرتان يوميًا)',
      'es': 'No hay más actualizaciones para este texto hoy (máx. 2 al día)',
      'de': 'Für diesen Text heute keine weitere Aktualisierung (max. 2 pro Tag)',
      'fr': 'Plus d’actualisation pour ce texte aujourd’hui (max. 2 par jour)',
    },
    'restored': {
      'fa': 'به ترجمه‌ی اول برگشت (سقفِ رفرشِ امروز پر شده)',
      'en': 'Back to the original translation (today\'s refresh limit reached)',
      'ar': 'عادت الترجمة الأولى (تم بلوغ حد التحديث اليوم)',
      'es': 'Se restauró la traducción original (límite de hoy alcanzado)',
      'de': 'Zurück zur ursprünglichen Übersetzung (Tageslimit erreicht)',
      'fr': 'Retour à la traduction d’origine (limite du jour atteinte)',
    },
    'altfree': {
      'fa': 'رفرشِ AIِ امروز تمام شد؛ ترجمه‌ی رایگان (ML Kit/آنلاین) به‌عنوان «گزینه‌ی دوم» آمد — با ترجمه‌ی برگشتی بسنج و انتخاب کن',
      'en': 'Today\'s AI refreshes are used up; a free (on-device/online) translation is shown as a second option — check its back-translation and choose',
      'ar': 'انتهت تحديثات الذكاء الاصطناعي اليوم؛ ظهرت ترجمة مجانية كخيار ثانٍ — تحقق من الترجمة العكسية ثم اختر',
      'es': 'Se agotaron las actualizaciones de IA de hoy; aparece una traducción gratuita como segunda opción: compruébala con la traducción inversa y elige',
      'de': 'Die KI-Aktualisierungen für heute sind aufgebraucht; eine kostenlose Übersetzung steht als zweite Option bereit – prüfe sie mit der Rückübersetzung und wähle',
      'fr': 'Les actualisations IA du jour sont épuisées ; une traduction gratuite apparaît comme deuxième option — vérifie-la avec la rétro-traduction et choisis',
    },
    'alt': {
      'fa': 'ترجمه‌ی جدید به‌عنوان «گزینه‌ی دوم» آمد؛ خودت انتخاب کن',
      'en': 'The new translation is shown as a second option — your choice',
      'ar': 'ظهرت الترجمة الجديدة كخيار ثانٍ — اختر ما تفضله',
      'es': 'La nueva traducción aparece como segunda opción: tú eliges',
      'de': 'Die neue Übersetzung steht als zweite Option bereit – du entscheidest',
      'fr': 'La nouvelle traduction apparaît comme deuxième option : à toi de choisir',
    },
  };

  @override
  void initState() {
    super.initState();
    // تاریخچه‌ی تب‌ها بعد از بازسازیِ اکتیویتی/بستنِ برنامه هم می‌ماند (بازگشت به «تبِ قبلی»، نه تبِ ثابت)
    try {
      final saved = ref.read(sharedPrefsProvider).getStringList(_historyPrefKey);
      if (saved != null) {
        _history.addAll(saved.where(kRestorableTabs.contains));
      }
    } catch (_) {}
    // 💬 پیامِ کوتاهِ ↻ (تأییدِ هوشمند / سقفِ روزانه / گزینه‌ی دوم)
    _refreshSub = TranslationService.refreshNotices.stream.listen((kind) {
      if (!mounted) return;
      // 🤫 پیامِ «سقفِ رفرش پر شد» دیگر نشان داده نمی‌شود (کاربر را کلافه می‌کرد)
      if (kind == 'limit') return;
      final m = _refreshMsgs[kind];
      if (m == null) return;
      final ui = ref.read(appPrefsProvider).uiLang;
      final msg = m[ui] ?? m['en']!;
      final sm = ScaffoldMessenger.maybeOf(context);
      sm?.hideCurrentSnackBar();
      sm?.showSnackBar(SnackBar(
        content: Text(msg),
        duration: Duration(seconds: kind == 'altfree' ? 6 : 3),
        behavior: SnackBarBehavior.floating,
      ));
    });
    // 📥 کاربری که قبلاً زبان‌هایش را انتخاب کرده: مدل‌های ML Kitِ جامانده را بی‌صدا (با Wi‑Fi یا داده‌ی موبایل) کامل کن
    try {
      if (ref.read(localStorageProvider).readJson(PrefsKeys.languageSelection).isNotEmpty) {
        final sel = ref.read(languageSelectionProvider);
        MlKitPrefetch.schedule(sel.native, sel.targets);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _refreshSub?.cancel();
    super.dispose();
  }

  void _persistNav() {
    try {
      final p = ref.read(sharedPrefsProvider);
      if (kRestorableTabs.contains(_loc)) p.setString(kLastTabPrefKey, _loc);
      p.setStringList(_historyPrefKey, List<String>.from(_history));
    } catch (_) {}
  }

  /// جابه‌جاییِ تب را ثبت می‌کند (فقط حسابداری؛ هیچ setState ای نیست).
  void _track(String loc) {
    if (loc == _loc) return;
    if (_goingBack) {
      _goingBack = false;
    } else if (_loc.isNotEmpty) {
      _history.remove(_loc);
      _history.add(_loc);
      if (_history.length > 20) _history.removeAt(0);
    }
    _history.remove(loc);
    _loc = loc;
    _lastBack = null; // تبِ جدید = هشدارِ خروجِ قبلی باطل
    _persistNav();
  }

  /// دکمه‌ی «بازگشت» گوشی (دیالوگ/شیت‌ها قبل از این به‌صورت عادی بسته می‌شوند):
  /// ۱) اگر تب حالتِ درونی دارد (موضوعِ بازشده، داستانِ بازشده/خوانده‌شده، کتابخانه…)
  ///    فقط یک قدم به مرحله‌ی قبلِ همان تب برمی‌گردد (مثلاً موضوع ← لیست موضوع‌ها)؛
  /// ۲) اگر تب مرحله‌ی درونی ندارد و تبِ اول (Talk) نیست ← برمی‌گردد به تبِ اول؛
  /// ۳) روی تبِ اول و بدون مرحله‌ی درونی، برنامه بی‌صدا بسته می‌شود.
  void _onBack() {
    if (BackHandlers.handle()) return;
    final loc = _loc.isNotEmpty
        ? _loc
        : GoRouter.of(context).routeInformationProvider.value.uri.path;
    if (loc != '/conversations') {
      context.go('/conversations');
      return;
    }
    SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    _track(GoRouter.of(context).routeInformationProvider.value.uri.path);

    // 📥 کاربر زبان‌ها را انتخاب/عوض کرد → همان موقع مدل‌های ML Kitِ آن زبان‌ها در پس‌زمینه دانلود شود
    ref.listen<LanguageSelection>(languageSelectionProvider, (prev, next) {
      if (prev == null) return;
      MlKitPrefetch.schedule(next.native, next.targets);
    });

    // ☁️ مدل‌هایی که با حساب دانلود شده بودند ولی روی این دستگاه نیستند
    ref.listen<List<String>>(missingPacksProvider, (prev, next) {
      if (next.isEmpty) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) _askRestore(context, ref, next);
      });
    });

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBack();
      },
      child: Scaffold(
      backgroundColor: c.paper,
      // هر لمس/اسکرول = «تعامل» (برای پیام‌های یادآوریِ آدمک)
      body: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: (_) => MascotActivity.mark(),
        onPointerMove: (_) => MascotActivity.mark(),
        onPointerSignal: (_) => MascotActivity.mark(),
        child: NotificationListener<ScrollNotification>(
          onNotification: (_) {
            MascotActivity.mark();
            return false;
          },
          child: Stack(
            children: [
              Column(
                children: [
                  // جای نوارِ آدمک — همان ۴۰px که در Hope داخل هدر بود
                  const SizedBox(height: 40),
                  // 🎥 ویدیو کالِ تمرین (لغات/Talk/داستان) بالای صفحه سنجاق می‌شود
                  Expanded(
                    child: LayoutBuilder(
                      builder: (ctx, cons) => Column(
                        children: [
                          PinnedCallSlot(maxHeight: cons.maxHeight * 0.93),
                          Expanded(child: widget.child),
                        ],
                      ),
                    ),
                  ),

                  // ═══ پنل تمرین گرامر — فعلاً مخفی (kShowPracticeSheet) ═══
                  if (kShowPracticeSheet) const PracticeSheet(),

                  // ═══ پلیر پایین صفحه ═══
                  const PlayerBar(),
                ],
              ),
              // ═══ پلیر با شفافیتِ صفر: فقط دکمه‌ی بازنشانی ═══
              if (ref.watch(playerOpacityProvider) == 0)
                Positioned(
                  left: 10,
                  bottom: 10 + MediaQuery.of(context).padding.bottom,
                  child: Material(
                    color: c.paper,
                    shape: CircleBorder(side: BorderSide(color: c.cardBorder)),
                    elevation: 3,
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () =>
                          ref.read(playerOpacityProvider.notifier).set(100),
                      child: SizedBox(
                        width: 34,
                        height: 34,
                        child:
                            Icon(Icons.restart_alt, size: 18, color: c.gold),
                      ),
                    ),
                  ),
                ),
              // ═══ آدمکِ Lingova (نوار بالا + حباب‌ها) ═══
              const Positioned.fill(child: LingovaMascotLayer()),
              // ═══ داکِ ابزارها (ذره‌بین / ترجمه‌ی زنده / یوتیوب) — اسلاید از راست، فقط اندروید ═══
              const FeatureDock(),
              // ═══ تورِ معرفیِ بار اول (نورافکن + حلقه‌ی چشمک‌زن) — همیشه آخرین لایه ═══
              const SpotlightTour(),
            ],
          ),
        ),
      ),
      ),
    );
  }
}

String _packLabel(String id) {
  final i = id.indexOf(':');
  if (i <= 0) return id;
  final kind = id.substring(0, i);
  final pid = id.substring(i + 1);
  String lang(String code) {
    for (final l in kSupportedLanguages) {
      if (l.code == code) return l.faLabel;
    }
    return code.toUpperCase();
  }

  switch (kind) {
    case 'tts':
      return 'صدای آفلاین — ${lang(pid)}';
    case 'speech':
      return 'تشخیص گفتار — ${lang(pid)}';
    case 'song':
      return 'بسته‌ی آهنگ — $pid';
    default:
      return id;
  }
}

Future<void> _askRestore(
    BuildContext context, WidgetRef ref, List<String> ids) async {
  final L = context.l10n;
  final sync = ref.read(cloudSyncProvider);
  final yes = await showDialog<bool>(
    context: context,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(L.sync_restore_title),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(L.sync_restore_body),
              const SizedBox(height: 10),
              for (final id in ids) Text('• ${_packLabel(id)}'),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(L.sync_restore_later)),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(L.sync_restore_download)),
        ],
      ),
    ),
  );
  if (yes == true) {
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(L.sync_restore_started)));
    }
    unawaited(sync.restorePacks(ids));
  } else {
    sync.dismissMissing(ids);
  }
}
