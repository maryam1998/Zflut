import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/primary_school_provider.dart';
import '../../../core/theme/app_theme_colors.dart';
import '../../../core/widgets/category_grid.dart' show categoryAllOpenProvider;

/// ردیفِ چیپ‌های مرحله (مشترک بین تبِ لغات و تبِ مکالمه):
///   [همه]  [Preschool ▸ A1]  [Primary School ▸ A2]
/// [primary] = یکی از دو مرحله‌ی مدرسه‌ای انتخاب است؛ [level] = 'A1' (Preschool) یا 'A2' (Primary School).
class StageChips extends StatelessWidget {
  final bool primary;
  final String level;
  final VoidCallback onAll;
  final VoidCallback onPreschool;
  final VoidCallback onPrimary;
  const StageChips({
    super.key,
    required this.primary,
    required this.level,
    required this.onAll,
    required this.onPreschool,
    required this.onPrimary,
  });

  @override
  Widget build(BuildContext context) {
    final ui = Localizations.localeOf(context).languageCode;
    final allLabel = (ui == 'fa' || ui == 'ar') ? 'همه' : 'All';
    final preschoolOn = primary && level == 'A1';
    final primaryOn = primary && level == 'A2';
    return SizedBox(
      height: 38,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          Center(
            child: _StageChip(
              label: allLabel,
              active: !primary,
              onTap: onAll,
            ),
          ),
          const SizedBox(width: 7),
          Center(
            child: _StageChip(
              label: kPreschoolChipLabel,
              icon: Icons.child_care_rounded,
              active: preschoolOn,
              onTap: onPreschool,
            ),
          ),
          const SizedBox(width: 7),
          Center(
            child: _StageChip(
              label: kPrimaryChipLabel,
              icon: Icons.school_rounded,
              active: primaryOn,
              onTap: onPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

/// نسخه‌ی تبِ لغات (با providerها)
class StageChipsBar extends ConsumerWidget {
  const StageChipsBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final primary = ref.watch(wordsStageProvider) == kStagePrimary;

    void reset() {
      ref.read(primaryTopicProvider.notifier).state = null;
      ref.read(categoryAllOpenProvider('primary').notifier).state = false;
    }

    return StageChips(
      primary: primary,
      level: ref.watch(primaryLevelProvider),
      onAll: () {
        reset();
        ref.read(wordsStageProvider.notifier).state = null;
      },
      onPreschool: () {
        reset();
        ref.read(primaryLevelProvider.notifier).state = 'A1';
        ref.read(wordsStageProvider.notifier).state = kStagePrimary;
      },
      onPrimary: () {
        reset();
        ref.read(primaryLevelProvider.notifier).state = 'A2';
        ref.read(wordsStageProvider.notifier).state = kStagePrimary;
      },
    );
  }
}

class _StageChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  final IconData? icon;
  final Color? color;
  final bool small;
  const _StageChip({
    required this.label,
    required this.active,
    required this.onTap,
    this.icon,
    this.color,
    this.small = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final tone = color ?? c.gold;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
            horizontal: small ? 14 : 16, vertical: small ? 6 : 8),
        decoration: BoxDecoration(
          color: active ? tone.withOpacity(0.16) : c.surface,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: active ? tone : c.cardBorder,
            width: active ? 1.4 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 16, color: active ? tone : c.inkSoft),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                color: active ? c.ink : c.inkSoft,
                fontSize: small ? 12.5 : 13.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
