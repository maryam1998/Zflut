// ---------------------------------------------------------------------------
// سهمیه‌ی «کل عمر» برای کاربرانِ رایگان + تشخیصِ کاربرِ Pro / VIP
//
// • هر بخش (feature) برای هر کاربر یک شمارنده‌ی دائمی در D1 دارد (جدول feature_usage) —
//   با پاک‌کردنِ اپ یا نصبِ دوباره ریست نمی‌شود، چون به user_id حساب گوگل وصل است.
// • وقتی شمارنده به سقف برسد: HTTP 402 + پیامِ فارسی.
// • Pro = (۱) ایمیل در VIP_EMAILS (wrangler.toml)  یا  (۲) ردیفِ plan='pro' در جدول entitlements.
//   Pro/VIP بدونِ محدودیت است.
//
// Vars اختیاری (wrangler.toml):
//   FREE_LIMIT            = "2"            سقفِ پیش‌فرضِ هر بخش
//   FREE_LIMIT_<FEATURE>  = "5"            سقفِ اختصاصیِ یک بخش (مثلاً FREE_LIMIT_STORY)
//   VIP_EMAILS            = "a@gmail.com, b@gmail.com"
// ---------------------------------------------------------------------------

/**
 * window = دقیقه. 0 → هر درخواست/شروع یک بار حساب می‌شود.
 * window > 0 → «یک نشست»: تا وقتی بینِ درخواست‌ها کمتر از این فاصله باشد، همان یک بار حساب می‌شود
 * (برای چت/تماس/زیرنویس که یک استفاده چندین درخواست دارد).
 */
export const FEATURES = {
  example:   { window: 0 },   // مثال‌ساز (AI)
  grammar:   { window: 0 },   // گرامر (AI)
  story:     { window: 0 },   // داستان‌ساز (AI)
  chat:      { window: 30 },  // چت (AI)
  videocall: { window: 30 },  // ویدیوکال AI
  live:      { window: 0 },   // ترجمه‌ی زنده (هر بار شروع)
  magnifier: { window: 0 },   // ذره‌بین (هر بار شروع)
  ytsub:     { window: 60 },  // ترجمه‌ی یوتیوب (نشست)
};

// مسیرهایی که خودشان مشخص می‌کنند کدام بخش‌اند (بدونِ هدر؛ برای بخشِ بومیِ اندروید)
const PATH_FEATURE = {
  "/api/youtube-captions": "ytsub",
  "/api/translate-subtitles": "ytsub",
  "/api/youtube-resolve": "ytsub",
};

// 🆓 بخش‌هایی که سقفِ «کل عمر» ندارند (رایگانِ همیشگی)؛ فقط سقفِ روزانه‌ی سرور روشان اعمال می‌شود.
const LIFETIME_EXEMPT = new Set(["ytsub"]);

const MSG_FA = "سقف استفاده‌ی رایگان از این بخش تمام شده. برای استفاده‌ی نامحدود، نسخه‌ی Pro را بخرید.";

function jsonResp(data, status, cors) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...cors },
  });
}

export function limitOf(env, feature) {
  for (const k of [`FREE_LIMIT_${feature.toUpperCase()}`, "FREE_LIMIT"]) {
    const v = Number(env[k]);
    if (Number.isFinite(v) && v >= 0 && env[k] !== undefined && env[k] !== "") return Math.floor(v);
  }
  return 2;
}

function limitResponse(feature, limit, cors) {
  return jsonResp({ error: MSG_FA, code: "free_limit", feature, limit }, 402, cors);
}

// ───────────── ایمیل / VIP ─────────────
export function normEmail(e) {
  const s = String(e || "").trim().toLowerCase();
  const at = s.lastIndexOf("@");
  if (at < 1) return s;
  const local = s.slice(0, at), dom = s.slice(at + 1);
  if (dom === "gmail.com" || dom === "googlemail.com") {
    // جیمیل نقطه و بعد از + را نادیده می‌گیرد
    return local.split("+")[0].replace(/\./g, "") + "@gmail.com";
  }
  return s;
}

export function isVipEmail(env, email) {
  if (!email) return false;
  const want = normEmail(email);
  return String(env.VIP_EMAILS || "")
    .split(/[,\s;]+/)
    .map(normEmail)
    .filter(Boolean)
    .includes(want);
}

// ───────────── جدول‌ها ─────────────
let tablesReady = false;
async function ensureTables(env) {
  if (tablesReady) return;
  await env.TR_DB.batch([
    env.TR_DB.prepare(
      "CREATE TABLE IF NOT EXISTS feature_usage (" +
        "user_id TEXT NOT NULL, feature TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, " +
        "last_at INTEGER NOT NULL DEFAULT 0, last_use TEXT NOT NULL DEFAULT '', " +
        "PRIMARY KEY (user_id, feature))"
    ),
    env.TR_DB.prepare(
      "CREATE TABLE IF NOT EXISTS entitlements (" +
        "user_id TEXT PRIMARY KEY, plan TEXT NOT NULL, pro_until INTEGER, " +
        "source TEXT, note TEXT, updated INTEGER NOT NULL DEFAULT 0)"
    ),
  ]);
  await env.TR_DB.batch([
    // 📅 سقفِ روزانه‌ی هر بخش — سمتِ سرور (identity, feature, day, count)
    env.TR_DB.prepare(
      "CREATE TABLE IF NOT EXISTS feature_daily (" +
        "user_id TEXT NOT NULL, feature TEXT NOT NULL, day TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, " +
        "last_at INTEGER NOT NULL DEFAULT 0, last_use TEXT NOT NULL DEFAULT '', " +
        "PRIMARY KEY (user_id, feature, day))"
    ),
    // ⏱️ شروعِ نشستِ رایگانِ تماس (برای محدودیتِ طولِ جلسه)
    env.TR_DB.prepare(
      "CREATE TABLE IF NOT EXISTS feature_session (" +
        "user_id TEXT NOT NULL, feature TEXT NOT NULL, start_at INTEGER NOT NULL, " +
        "PRIMARY KEY (user_id, feature))"
    ),
  ]);
  tablesReady = true;
}

// ───────────── Pro؟ ─────────────
const proCache = new Map(); // userId → {pro, t}
export async function isPro(env, userId, email) {
  if (isVipEmail(env, email)) return true;
  if (!env.TR_DB) return false;
  const hit = proCache.get(userId);
  if (hit && Date.now() - hit.t < 60000) return hit.pro;
  let pro = false;
  try {
    await ensureTables(env);
    const row = await env.TR_DB.prepare(
      "SELECT plan, pro_until FROM entitlements WHERE user_id = ?1"
    ).bind(userId).first();
    pro = !!row && row.plan === "pro" && (!row.pro_until || row.pro_until > Date.now());
  } catch (e) {
    console.log("isPro error", String(e));
  }
  proCache.set(userId, { pro, t: Date.now() });
  return pro;
}

// ───────────── مصرفِ یک بار ─────────────
/** {ok, used, limit}. اگر D1 خراب/نبود → ok (نباید کاربر را الکی قفل کند). */
export async function consume(env, userId, feature, useId) {
  const limit = limitOf(env, feature);
  if (!env.TR_DB) return { ok: true, used: 0, limit };
  try {
    await ensureTables(env);
    const now = Date.now();
    const win = (FEATURES[feature]?.window || 0) * 60000;
    const row = await env.TR_DB.prepare(
      "SELECT n, last_at, last_use FROM feature_usage WHERE user_id = ?1 AND feature = ?2"
    ).bind(userId, feature).first();

    if (row) {
      // تلاشِ دوباره‌ی همان درخواست (retry) دوباره حساب نمی‌شود
      if (useId && row.last_use === useId) return { ok: true, used: row.n, limit, fresh: false };
      // ادامه‌ی همان نشست
      if (win > 0 && row.n > 0 && now - row.last_at < win) {
        await env.TR_DB.prepare(
          "UPDATE feature_usage SET last_at = ?3 WHERE user_id = ?1 AND feature = ?2"
        ).bind(userId, feature, now).run();
        return { ok: true, used: row.n, limit, fresh: false };
      }
    }
    if (limit <= 0) return { ok: false, used: row ? row.n : 0, limit };

    // شمارش اتمیک: فقط اگر هنوز زیر سقف باشد زیاد می‌شود
    const r = await env.TR_DB.prepare(
      "INSERT INTO feature_usage (user_id, feature, n, last_at, last_use) VALUES (?1, ?2, 1, ?3, ?4) " +
        "ON CONFLICT(user_id, feature) DO UPDATE SET n = n + 1, last_at = ?3, last_use = ?4 WHERE n < ?5 " +
        "RETURNING n"
    ).bind(userId, feature, now, useId || "", limit).first();
    if (!r) return { ok: false, used: row ? row.n : limit, limit };
    return { ok: true, used: r.n, limit, fresh: true };
  } catch (e) {
    console.log("consume error", String(e));
    return { ok: true, used: 0, limit };
  }
}

export function featureOf(request, url) {
  const h = (request.headers.get("X-Feature") || "").trim().toLowerCase();
  if (h && FEATURES[h]) return h;
  return PATH_FEATURE[url.pathname] || null;
}

/** سقفِ روزانه‌ی یک بخش برای هر کاربر (Pro/VIP و رایگان). DAILY_<FEATURE> در wrangler.toml؛ نبود/۰ = بدونِ سقف. */
export function dailyLimitOf(env, feature) {
  const v = Number(env[`DAILY_${feature.toUpperCase()}`]);
  return Number.isFinite(v) && v > 0 ? Math.floor(v) : 0;
}

/** {ok, used, limit}. هر «استفاده‌ی جدید» یک بار حساب می‌شود (retry و ادامه‌ی نشست حساب نمی‌شود). سمتِ سرور و اتمیک. */
export async function consumeDaily(env, userId, feature, useId) {
  const limit = dailyLimitOf(env, feature);
  if (!limit || !env.TR_DB) return { ok: true, used: 0, limit };
  try {
    await ensureTables(env);
    const now = Date.now();
    const day = new Date(now).toISOString().slice(0, 10);
    const win = (FEATURES[feature]?.window || 0) * 60000;
    const row = await env.TR_DB.prepare(
      "SELECT n, last_at, last_use FROM feature_daily WHERE user_id = ?1 AND feature = ?2 AND day = ?3"
    ).bind(userId, feature, day).first();
    if (row) {
      if (useId && row.last_use === useId) return { ok: true, used: row.n, limit };
      if (win > 0 && row.n > 0 && now - row.last_at < win) {
        await env.TR_DB.prepare(
          "UPDATE feature_daily SET last_at = ?4 WHERE user_id = ?1 AND feature = ?2 AND day = ?3"
        ).bind(userId, feature, day, now).run();
        return { ok: true, used: row.n, limit };
      }
    }
    const r = await env.TR_DB.prepare(
      "INSERT INTO feature_daily (user_id, feature, day, n, last_at, last_use) VALUES (?1, ?2, ?3, 1, ?4, ?5) " +
        "ON CONFLICT(user_id, feature, day) DO UPDATE SET n = n + 1, last_at = ?4, last_use = ?5 WHERE n < ?6 " +
        "RETURNING n"
    ).bind(userId, feature, day, now, useId || "", limit).first();
    if (!r) return { ok: false, used: row ? row.n : limit, limit };
    if (Math.random() < 0.01) {
      const old = new Date(now - 7 * 86400000).toISOString().slice(0, 10);
      await env.TR_DB.prepare("DELETE FROM feature_daily WHERE day < ?1").bind(old).run();
    }
    return { ok: true, used: r.n, limit };
  } catch (e) {
    console.log("consumeDaily error", String(e));
    return { ok: true, used: 0, limit };
  }
}

function dailyResponse(feature, limit, cors) {
  return jsonResp({ error: "daily limit reached, try again tomorrow", code: "daily_feature_limit", feature, limit }, 429, cors);
}

// ⏱️ طولِ جلسه‌ی رایگانِ تماس (ثانیه). FREE_CALL_SECONDS در wrangler.toml؛ ۰/نبود = بدونِ محدودیتِ طول.
const SESSION_LIMITED = new Set(["videocall"]);
function freeSessionSeconds(env) {
  const v = Number(env.FREE_CALL_SECONDS);
  return Number.isFinite(v) && v > 0 ? Math.floor(v) : 0;
}

/** برای کاربرِ رایگان: true = هنوز در سقفِ زمانیِ جلسه. fresh=true یعنی جلسه‌ی تازه شروع شده. */
async function sessionTimeOk(env, userId, feature, fresh) {
  const secs = freeSessionSeconds(env);
  if (!secs || !SESSION_LIMITED.has(feature) || !env.TR_DB) return true;
  try {
    await ensureTables(env);
    const now = Date.now();
    if (fresh) {
      await env.TR_DB.prepare(
        "INSERT INTO feature_session (user_id, feature, start_at) VALUES (?1, ?2, ?3) " +
          "ON CONFLICT(user_id, feature) DO UPDATE SET start_at = ?3"
      ).bind(userId, feature, now).run();
      return true;
    }
    const row = await env.TR_DB.prepare(
      "SELECT start_at FROM feature_session WHERE user_id = ?1 AND feature = ?2"
    ).bind(userId, feature).first();
    if (!row) return true;
    return now - row.start_at <= secs * 1000;
  } catch (e) {
    console.log("sessionTimeOk error", String(e));
    return true;
  }
}

/** داخلِ authGate صدا زده می‌شود. null = اجازه، وگرنه Response (402 رایگان / 429 سقفِ روزانه). */
export async function featureGate(request, env, url, session, cors) {
  const feature = featureOf(request, url);
  if (!feature) return null;
  const useId = (request.headers.get("X-Use-Id") || "").slice(0, 64);
  const pro = await isPro(env, session.sub, session.em);

  if (!pro && !LIFETIME_EXEMPT.has(feature)) {
    // سقفِ «کل عمر» + سقفِ طولِ جلسه (رایگان)
    const r = await consume(env, session.sub, feature, useId);
    if (!r.ok) return limitResponse(feature, r.limit, cors);
    if (!(await sessionTimeOk(env, session.sub, feature, r.fresh === true))) {
      return jsonResp({ error: MSG_FA, code: "free_session_over", feature }, 402, cors);
    }
  }
  // 📅 سقفِ روزانه‌ی هر بخش — برای همه (Pro/VIP/رایگان)، سمتِ سرور
  const d = await consumeDaily(env, session.sub, feature, useId);
  if (!d.ok) return dailyResponse(feature, d.limit, cors);
  return null;
}

/**
 * GET  /api/usage → {pro, features:{x:{used,limit}}}
 * POST /api/use   → {feature, id?} — شروعِ یک استفاده (برای بخش‌هایی که درخواستِ AI ندارند: ذره‌بین، ترجمه‌ی زنده)
 * session = payload توکنِ نشست (از index.js).
 */
export async function handleUsage(request, env, url, cors, session) {
  const pro = await isPro(env, session.sub, session.em);

  if (url.pathname === "/api/usage" && request.method === "GET") {
    const features = {};
    for (const f of Object.keys(FEATURES)) features[f] = { used: 0, limit: limitOf(env, f) };
    if (env.TR_DB) {
      try {
        await ensureTables(env);
        const { results } = await env.TR_DB.prepare(
          "SELECT feature, n FROM feature_usage WHERE user_id = ?1"
        ).bind(session.sub).all();
        for (const r of results || []) if (features[r.feature]) features[r.feature].used = r.n;
      } catch (e) {
        console.log("usage error", String(e));
      }
    }
    return jsonResp({ pro, features }, 200, cors);
  }

  if (url.pathname === "/api/use" && request.method === "POST") {
    let body = {};
    try { body = await request.json(); } catch { /* خالی */ }
    const feature = String(body.feature || "").toLowerCase();
    if (!FEATURES[feature]) return jsonResp({ error: "unknown feature" }, 400, cors);
    const bid = String(body.id || "").slice(0, 64);
    const dd = await consumeDaily(env, session.sub, feature, bid);
    if (!dd.ok) return dailyResponse(feature, dd.limit, cors);
    if (pro) return jsonResp({ ok: true, pro: true }, 200, cors);
    const r = await consume(env, session.sub, feature, bid);
    if (!r.ok) return limitResponse(feature, r.limit, cors);
    return jsonResp({ ok: true, used: r.used, limit: r.limit }, 200, cors);
  }

  return jsonResp({ error: "not found" }, 404, cors);
}
