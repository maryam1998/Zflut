import '../../core/data/paid_content.dart' show PaidContent;
import '../../core/translate/translate_hints.dart';
import '../../core/usage/free_limit.dart';
import '../../core/usage/conversations_index.dart';
import '../../core/usage/pro_i18n.dart';
import '../../core/widgets/locked_conversation_card.dart';
import '../../core/constants/level_colors.dart';
import '../../core/usage/pro_status.dart';
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app.dart';
import '../../core/constants/topic_icons.dart';
import '../../core/constants/topic_titles.dart';
import '../../core/models/conversation.dart';
import '../../core/native/native_bridge.dart';
import '../../core/player_sync/playback_origin.dart';
import '../../core/player_sync/player_track.dart';
import '../../core/player_sync/sync_widgets.dart';
import '../../core/providers/conversation_provider.dart';
import '../../core/providers/language_selection_provider.dart';
import '../../core/providers/read_ids_provider.dart';
import '../../core/router/back_handlers.dart';
import '../../core/storage/local_storage.dart' show sharedPrefsProvider;
import '../../core/theme/app_theme_colors.dart';
import '../../core/widgets/level_chips.dart';
import '../../core/widgets/range_card.dart';
import '../../core/widgets/sync_item_card.dart';
import '../shell/widgets/shell_header.dart';
import '../words/widgets/stage_chips_bar.dart' show StageChips;
import '../shell/widgets/spotlight_tour.dart' show TourTarget, SpotlightTour;
import '_hope_panel.dart' show uiContentDirection;
import 'scenario_practice.dart' show ScenarioPracticeSection;

class ConversationsTab extends ConsumerStatefulWidget {
  const ConversationsTab({super.key});

  @override
  ConsumerState<ConversationsTab> createState() => _ConversationsTabState();
}

class _ConversationsTabState extends ConsumerState<ConversationsTab> {
  String? _activeTopic;
  int? _openScenario;

  // 🎭 مکالمه‌ی واقعی بین دو نفر: «می‌شنوی» (A) = همیشه صدای مرد، «می‌گی» (B) = همیشه صدای زن.
  // هم متنِ اصلی و هم ترجمه‌ها (هر زبانی که در هدر انتخاب شده) برای هر نفر با همان جنسیت
  // و با مدلِ مخصوصِ همان زبان خوانده می‌شود. هدر عوض شد → صداها خودکار دوباره انتخاب می‌شوند.
  static const String _mainLang = 'en';
  final Map<String, ({String? male, String? female})> _langVoices = {};
  final Map<String, List<String>> _langIds = {}; // شناسه‌ی صداهای نصب‌شده (فعال اول)
  bool _voicesBusy = false;
  bool _voicesDirty = false;

  // 🎭 اگر برای یک زبان فقط صدای یک جنسیت نصب باشد (مثلاً فارسی: فقط «پویا»/«سارا»)، A و B با یک صدا
  // خوانده می‌شدند. صدای جنسیتِ ناموجود یک‌بار خودکار دانلود می‌شود و صدای فعالِ قبلیِ کاربر سرِ جایش می‌ماند.
  final Set<String> _autoVoiceAsked = <String>{}; // 'lang:gender'
  final Map<String, ({String? prevActive, String want})> _autoVoicePending = {};
  StreamSubscription<Map<String, dynamic>>? _dlSub;

  /// برچسبِ صدا نشانِ F/M دارد (مثلاً «Nicole · US · F»)؛ برای صداهای برنامه بعدش رده‌ی
  /// کیفیت هم می‌آید («Chloe · US · F · low»)، پس فقط به آخرِ برچسب تکیه نمی‌کنیم.
  static bool _isFemale(String label) =>
      RegExp(r'·\s*F(\s*·|\s*$)').hasMatch(label);
  static bool _isMale(String label) =>
      RegExp(r'·\s*M(\s*·|\s*$)').hasMatch(label);

  /// زبانِ متنِ اصلی + مبدأ + همه‌ی مقصدهای انتخاب‌شده در هدر
  Set<String> _wantedLangs() {
    final sel = ref.read(languageSelectionProvider);
    return <String>{
      _mainLang,
      for (final c in [sel.native, ...sel.targets]) c.trim().toLowerCase(),
    }..remove('');
  }

  Future<void> _loadVoices() async {
    if (!NativeBridge.instance.isSupported) return;
    if (_voicesBusy) {
      _voicesDirty = true;
      return;
    }
    _voicesBusy = true;
    try {
      do {
        _voicesDirty = false;
        final next = <String, ({String? male, String? female})>{};
        final nextIds = <String, List<String>>{};
        for (final lang in _wantedLangs()) {
          try {
            final r = await NativeBridge.instance.getTtsVoices(lang: lang);
            final raw = r['voices'];
            final ok = <Map<String, dynamic>>[
              if (raw is List)
                for (final e in raw)
                  if (e is Map &&
                      e['downloaded'] == true &&
                      '${e['id']}'.isNotEmpty)
                    Map<String, dynamic>.from(e),
            ];
            // اگر صدای فعالِ تنظیمات همان جنسیت را دارد همان؛ وگرنه اولین صدای آن جنسیت
            String? pick(bool Function(String) isG) {
              Map<String, dynamic>? first;
              for (final v in ok) {
                if (!isG('${v['label']}')) continue;
                if (v['active'] == true) return '${v['id']}';
                first ??= v;
              }
              return first == null ? null : '${first['id']}';
            }

            next[lang] = (male: pick(_isMale), female: pick(_isFemale));
            nextIds[lang] = [
              for (final v in ok)
                if (v['active'] == true) '${v['id']}',
              for (final v in ok)
                if (v['active'] != true) '${v['id']}',
            ];
            _autoFetchMissingGender(lang, raw, next[lang]!, ok);
          } catch (_) {}
        }
        if (!mounted) return;
        _langVoices
          ..clear()
          ..addAll(next);
        _langIds
          ..clear()
          ..addAll(nextIds);
      } while (_voicesDirty);
    } catch (_) {
    } finally {
      _voicesBusy = false;
    }
  }

  /// صدای جنسیتِ ناموجود را (اگر در فهرستِ صداهای اپ هست) یک‌بار بی‌صدا دانلود می‌کند.
  /// فقط وقتی کاربر «صدای گوشی» را انتخاب نکرده؛ مثل بقیه‌ی دانلودهای خودکارِ مدل‌ها.
  void _autoFetchMissingGender(String lang, dynamic raw,
      ({String? male, String? female}) have, List<Map<String, dynamic>> installed) {
    try {
      if (raw is! List || installed.isEmpty) return; // مدلِ اپ برای این زبان اصلاً نیست
      final pref = ref.read(sharedPrefsProvider).getString('voiceEnginePref');
      if (pref == 'phone') return;
      String? prevActive;
      for (final v in installed) {
        if (v['active'] == true) prevActive = '${v['id']}';
      }
      void want(String gender, String? haveId, bool Function(String) isG) {
        final key = '$lang:$gender';
        if (haveId != null || _autoVoiceAsked.contains(key)) return;
        // 🎭 اول صداهای سبک/متوسط (دانلودِ سریع‌تر و مطمئن‌تر)، بعد «high»
        for (final allowHigh in const [false, true]) {
          for (final e in raw) {
            if (e is! Map) continue;
            if (e['downloaded'] == true || e['downloading'] == true) continue;
            if (!isG('${e['label']}')) continue;
            if (!allowHigh &&
                '${e['label']}'.toLowerCase().contains('· high')) {
              continue;
            }
            final id = '${e['id']}';
            if (id.isEmpty) continue;
            _autoVoiceAsked.add(key);
            _autoVoicePending[lang] = (prevActive: prevActive, want: id);
            unawaited(NativeBridge.instance
                .downloadTtsModel(lang: lang, voice: id)
                .catchError((_) => <String, dynamic>{}));
            return;
          }
        }
      }

      want('male', have.male, _isMale);
      want('female', have.female, _isFemale);
    } catch (_) {}
  }

  /// پایانِ دانلودِ خودکار → صدای فعالِ قبلیِ کاربر برگردد (دانلودِ یک صدا آن را «فعال» می‌کند) و صداها دوباره خوانده شوند.
  Future<void> _onVoiceDownloaded(Map<String, dynamic> d) async {
    final lang = '${d['lang'] ?? ''}'.trim().toLowerCase();
    final p = _autoVoicePending[lang];
    if (p == null) return;
    try {
      final r = await NativeBridge.instance.getTtsVoices(lang: lang);
      final list = r['voices'];
      var installed = false;
      if (list is List) {
        for (final e in list) {
          if (e is Map && '${e['id']}' == p.want && e['downloaded'] == true) {
            installed = true;
          }
        }
      }
      if (!installed) return; // رویدادِ دانلودِ دیگری بود
      _autoVoicePending.remove(lang);
      final prev = p.prevActive;
      if (prev != null && prev.isNotEmpty && prev != p.want) {
        await NativeBridge.instance.setTtsVoice(lang: lang, voice: prev);
      }
    } catch (_) {}
    if (mounted) unawaited(_loadVoices());
  }

  /// A («می‌شنوی») = مرد، B («می‌گی») = زن
  String? _voiceFor(String itemId, String lang) {
    if (!RegExp(r'^[ab]\d+$').hasMatch(itemId)) return null;
    final male = itemId.startsWith('a');
    final p = _langVoices[lang.trim().toLowerCase()];
    if (p == null && mounted) {
      unawaited(_loadVoices()); // زبانِ تازه (مثلاً هدر تازه عوض شده) → صدایش را پیدا کن
    }
    final own = p == null ? null : (male ? p.male : p.female);
    final other = p == null ? null : (male ? p.female : p.male);
    final v = own ?? (p == null ? null : _distinctFallback(lang, other, male));
    // صدای اختصاصیِ مرد/زن نصب نیست (یا وب/صدای گوشی است) → فقط جنسیت را اعلام کن
    // تا موتورِ صدا از بینِ صداهای گوشی/مرورگر/Edge صدای هم‌جنس را انتخاب کند.
    return v ?? (male ? 'gender:male' : 'gender:female');
  }


  /// 🎭 صدای هم‌جنس نصب نیست → به‌جای «صدای فعال برای هر دو گوینده»، یک صدای
  /// نصب‌شده‌ی دیگر (متفاوت از صدای گوینده‌ی مقابل) انتخاب می‌شود.
  String? _distinctFallback(String lang, String? other, bool male) {
    final ids = _langIds[lang.trim().toLowerCase()] ?? const <String>[];
    if (ids.isEmpty) return null;
    if (other != null) {
      for (final id in ids) {
        if (id != other) return id;
      }
      return null;
    }
    // جنسیتِ هیچ‌کدام معلوم نیست: زن = صدای فعال، مرد = صدای بعدی
    if (male) return ids.length > 1 ? ids[1] : null;
    return ids.first;
  }

  String? _voiceForTrans(String itemId, String lang) => _voiceFor(itemId, lang);

  String? _voiceForItem(String itemId) => _voiceFor(itemId, _mainLang);
  String _query = '';
  final TextEditingController _searchCtrl = TextEditingController();
  final GlobalKey _searchKey = GlobalKey(); // با رفتن به حالتِ «بدون نتیجه» فوکوسِ کیبورد نپرد
  Set<String> _levels = <String>{};

  /// 🎒 true = «Primary School ▸ A1» (فقط موضوع‌های kind=='primary')
  bool _primary = false;

  /// سطحِ انتخاب‌شده زیرِ Primary School: 'A1' یا 'A2' (شناسه‌ی موضوع‌ها p-a1-… / p-a2-…)
  String _primaryLevel = 'A1';

  void _setPrimary(bool v) => setState(() {
        _primary = v;
        _levels = <String>{}; // سطح در این نما معنا ندارد
        _rangeFrom = 1;
        _rangeTo = 65;
      });

  // ───────────── 🔍 جستجوی سراسریِ تبِ Talk ─────────────
  // متنِ مکالمه‌ها «تنبل» لود می‌شود (در لیستِ موضوع‌ها scenarios خالی است)؛
  // پس برای جستجو، متنِ همه‌ی موضوع‌ها (جمله‌های انگلیسی + فارسی، سناریوها و
  // عنوان‌ها) یک‌بار در پس‌زمینه خوانده و به یک متنِ نرمال‌شده تبدیل می‌شود.
  final Map<String, String> _blob = {}; // شناسه‌ی موضوع → متنِ قابلِ جستجو
  String _blobKey = '';
  bool _indexing = false;

  /// نرمال‌سازی برای جستجو در همه‌ی زبان‌ها: حروف کوچک، ی/ک عربی→فارسی،
  /// حذفِ اعراب/کشیده/نیم‌فاصله، ارقامِ فارسی/عربی→لاتین، یکسان‌سازیِ گیومه.
  static String _nz(String s) {
    final b = StringBuffer();
    for (final r in s.toLowerCase().runes) {
      if (r == 0x064A || r == 0x0649) {
        b.writeCharCode(0x06CC); // ي ى → ی
      } else if (r == 0x0643) {
        b.writeCharCode(0x06A9); // ك → ک
      } else if ((r >= 0x064B && r <= 0x065F) ||
          r == 0x0670 ||
          r == 0x0640 ||
          r == 0x200C ||
          r == 0x200D) {
        continue; // اعراب، کشیده، نیم‌فاصله
      } else if (r >= 0x06F0 && r <= 0x06F9) {
        b.writeCharCode(0x30 + r - 0x06F0); // ۰-۹
      } else if (r >= 0x0660 && r <= 0x0669) {
        b.writeCharCode(0x30 + r - 0x0660); // ٠-٩
      } else if (r == 0x2018 || r == 0x2019) {
        b.write("'");
      } else {
        b.writeCharCode(r);
      }
    }
    return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  String _buildBlob(ConversationTopic t) {
    final b = StringBuffer()
      ..write('${t.topic}\n${topicTitle(t.topic, 'fa')}\n${topicTitle(t.topic, 'en')}\n');
    for (final s in t.scenarios) {
      b.write('${s.scenario}\n${s.context ?? ''}\n');
      for (final l in s.speakerA) {
        b.write('${l.en}\n${l.fa}\n');
      }
      for (final l in s.speakerB) {
        b.write('${l.en}\n${l.fa}\n');
      }
    }
    return _nz(b.toString());
  }

  /// متنِ موضوع‌هایی که هنوز خوانده نشده‌اند را (۴ تا ۴ تا) می‌خواند و بعد از هر
  /// دسته نتیجه‌ها را تازه می‌کند. موضوعِ قفل/بدونِ متن (کاربرِ رایگان) فقط با
  /// نامش جستجو می‌شود.
  Future<void> _ensureIndex() async {
    if (_indexing || !mounted) return;
    final key = '${ProStatus.isPro}-${PaidContent.revision.value}';
    if (key != _blobKey) {
      _blob.clear();
      _blobKey = key;
    }
    final repo = ref.read(conversationRepoProvider);
    final todo = [
      for (final t in repo.all)
        if (t.id.isNotEmpty && !_blob.containsKey(t.id)) t
    ];
    if (todo.isEmpty) return;
    _indexing = true;
    if (mounted) setState(() {});
    try {
      for (var i = 0; i < todo.length; i += 4) {
        await Future.wait(todo.skip(i).take(4).map((t) async {
          ConversationTopic? full;
          try {
            full = await repo.loadTopic(t);
          } catch (_) {}
          _blob[t.id] = full == null ? '' : _buildBlob(full);
        }));
        if (!mounted) return;
        setState(() {}); // نتیجه‌ها همین‌طور که ایندکس می‌شوند پر می‌شوند
      }
    } finally {
      _indexing = false;
      if (mounted) setState(() {});
    }
  }

  bool _topicMatches(ConversationTopic t, String rawQuery, String uiLang) {
    final q = _nz(rawQuery);
    if (q.isEmpty) return true;
    final head = _nz('${t.topic} ${topicTitle(t.topic, uiLang)} '
        '${topicTitle(t.topic, 'fa')} ${topicTitle(t.topic, 'en')}');
    final body = _blob[t.id] ?? '';
    // همه‌ی کلمه‌های جستجو باید جایی در عنوان/متنِ موضوع باشند
    for (final w in q.split(' ')) {
      if (w.isEmpty) continue;
      if (!head.contains(w) && !body.contains(w)) return false;
    }
    return true;
  }

  /// 💎 کاربرِ رایگان داخلِ موضوع‌های باز فقط جمله‌های A1 را می‌بیند
  Set<String> get _effLevels {
    final t = _activeTopic;
    if (t != null && !ProStatus.isPro && kFreeConversationTopics.contains(t)) {
      return const <String>{kFreeConversationLevel};
    }
    return _levels;
  }

  bool _lvOk(String l) {
    final s = _effLevels;
    return s.isEmpty || s.contains(l);
  }

  /// 🔒 آیا این موضوع، با فیلترِ سطحِ فعلی، برای کاربرِ رایگان قفل است؟
  /// موضوعِ پولی همیشه قفل است؛ موضوعِ رایگان هم وقتی فیلتر فقط سطح‌های پولی
  /// (B1, B2, …) را می‌خواهد، چون جمله‌های رایگانش فقط A1 است.
  bool _lockedFor(String topic) {
    if (ProStatus.isPro) return false;
    if (ProStatus.topicLocked(topic)) return true;
    return _levels.isNotEmpty && !_levels.contains(kFreeConversationLevel);
  }

  /// آیا موضوع در سطح‌های انتخاب‌شده جمله دارد؟
  /// کاربرِ رایگان: از «ایندکسِ شمارش» (چون متنِ موضوع‌های پولی داخلِ اپ نیست)؛
  /// کاربرِ Pro (یا اگر ایندکس نبود): از خودِ سناریوها.
  bool _topicHasLevel(ConversationTopic t, ConversationsIndex? index) {
    // 📚 لود تنبل: متنِ موضوع‌ها هنوز لود نشده؛ شمارش از ایندکس می‌آید (برای Pro هم)
    final n = index?.of(t.topic)?.total(_levels);
    if (n != null) return n > 0;
    return t.scenarios.any((s) =>
        s.speakerA.any((l) => _lvOk(l.level)) ||
        s.speakerB.any((l) => _lvOk(l.level)));
  }

  int _countLines(ConversationTopic t) {
    var n = 0;
    for (final s in t.scenarios) {
      n += s.speakerA.where((l) => _lvOk(l.level)).length;
      n += s.speakerB.where((l) => _lvOk(l.level)).length;
    }
    return n;
  }
  int _rangeFrom = 1;
  int _rangeTo = 65;

  /// جای اسکرولِ لیستِ موضوع‌ها — وقتی موضوعی باز می‌شود ذخیره و با «بازگشت»
  /// دقیقاً همان‌جا برگردانده می‌شود (نه بالای لیست).
  ScrollController _gridScroll = ScrollController();
  double _gridOffset = 0;

  /// ⏩ نمایشِ تدریجیِ سناریوها: اول چند کارت (فوری)، بقیه در فریم‌های بعدی
  int _reveal = 4;

  /// 🎓 اولین موضوعِ بازِ (قفل‌نشده) لیست — تور همین را باز می‌کند.
  String? _tourTopic;

  void _onTourOpen() {
    if (!mounted || _activeTopic != null) return;
    final name = _tourTopic;
    if (name == null) return;
    _openTopic(name);
  }

  void _onTourClose() {
    if (!mounted || _activeTopic == null) return;
    _closeTopic();
  }

  @override
  void initState() {
    super.initState();
    SpotlightTour.convOpenTopic.addListener(_onTourOpen);
    SpotlightTour.convCloseTopic.addListener(_onTourClose);
    // دکمه‌ی «بازگشت» گوشی: اول از موضوعِ بازشده به لیستِ موضوع‌ها برمی‌گردد؛
    // اگر لیست باز بود، کار را به AppShell می‌سپارد (خروج از برنامه).
    BackHandlers.add(_onSystemBack);
    unawaited(_loadVoices()); // 🎭 صدای مرد/زن برای متنِ اصلی و زبان‌های هدر
    if (NativeBridge.instance.isSupported) {
      _dlSub = NativeBridge.instance
          .on('ttsModelDownloadDone')
          .listen((d) => unawaited(_onVoiceDownloaded(d)));
    }
    // لمسِ طولانیِ دکمه‌ی پخش از تبِ دیگر: موضوع/سناریوی در حال پخش را باز کن
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _applyRestore(ref.read(tabRestoreProvider));
    });
    // 🎓 بارِ اولِ ورود به تبِ مکالمه (بعد از تورِ اصلی): تورِ مکالمه
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) SpotlightTour.startConv();
    });
  }

  /// بازگرداندنِ موضوع + سناریویی که پخش از آن شروع شده بود.
  void _applyRestore(PlaybackOrigin? r) {
    if (r == null || r.route != '/conversations') return;
    final t = r.extra['topic'];
    if (t is! String || ProStatus.topicLocked(t)) return;
    ref.read(tabRestoreProvider.notifier).state = null;
    final sc = r.extra['scenario'];
    if (_gridScroll.hasClients) _gridOffset = _gridScroll.offset;
    setState(() {
      _reveal = 4;
      _activeTopic = t;
      _openScenario = sc is int ? sc : 0;
    });
  }

  @override
  void dispose() {
    SpotlightTour.convOpenTopic.removeListener(_onTourOpen);
    SpotlightTour.convCloseTopic.removeListener(_onTourClose);
    BackHandlers.remove(_onSystemBack);
    _dlSub?.cancel();
    _gridScroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  bool _onSystemBack() {
    if (!mounted || _activeTopic == null) return false;
    _closeTopic();
    return true;
  }

  void _openTopic(String topic) {
    // 💎 موضوعِ پولی: به‌جای باز شدن، پیامِ «مخصوص Pro»
    if (_lockedFor(topic)) {
      FreeLimit.reportLocked();
      return;
    }
    if (_gridScroll.hasClients) _gridOffset = _gridScroll.offset;
    setState(() {
      _reveal = 4;
      _activeTopic = topic;
      _openScenario = 0;
    });
  }

  void _closeTopic() {
    final old = _gridScroll;
    // کنترلرِ تازه با آفستِ ذخیره‌شده: لیست بدونِ پرش/چشمک در همان جا باز می‌شود
    _gridScroll = ScrollController(initialScrollOffset: _gridOffset);
    setState(() {
      _activeTopic = null;
      _openScenario = null;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(languageSelectionProvider, (_, __) => unawaited(_loadVoices()));
    ref.listen<PlaybackOrigin?>(tabRestoreProvider, (prev, next) {
      if (next != null) _applyRestore(next);
    });
    return Directionality(
      // جهتِ محتوا طبقِ زبانِ رابط؛ ShellHeader خودش RTL می‌ماند
      textDirection: uiContentDirection(context),
      child: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    final c = context.appColors;
    ref.watch(isProProvider); // با عوض شدنِ وضعیتِ Pro قفل‌ها به‌روز شوند
    final topics = [
      for (final t in ref.watch(allTopicsProvider))
        if ((t.kind == 'primary') == _primary &&
            (!_primary || t.id.startsWith('p-${_primaryLevel.toLowerCase()}-')))
          t,
    ];
    // 📚 شمارشِ جمله‌ی هر موضوع به‌تفکیکِ سطح (همه لازم دارند: متنِ موضوع‌ها لود تنبل است)
    final index = ref.watch(conversationsIndexProvider).valueOrNull;

    if (topics.isEmpty) {
      final loading = ref.watch(conversationLoaderProvider).isLoading;
      return ListView(
        children: [
          const ShellHeader(),
          if (_primary) _levelBar(), // چیپِ جدیدِ بدونِ محتوا: چیپ‌ها بمانند تا بشود برگشت
          Padding(
            padding: const EdgeInsets.all(40),
            child: Center(
              child: loading
                  ? SizedBox(
                      width: 26,
                      height: 26,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.4, color: c.gold),
                    )
                  : Text(context.l10n.dialogs_no_results,
                      style: TextStyle(color: c.inkSoft, fontSize: 15)),
            ),
          ),
        ],
      );
    }

    final filtered = topics.where((t) {
      // فیلتر سطح: موضوعی که دست‌کم یک جمله‌ی هم‌سطح دارد
      if (_levels.isNotEmpty && !_topicHasLevel(t, index)) {
        return false;
      }
      return _topicMatches(
          t, _query, Localizations.localeOf(context).languageCode);
    }).toList();

    if (_activeTopic != null) {
      final name = _activeTopic!;
      // 📚 لود تنبل: متنِ همین یک موضوع الان لود می‌شود (فایلِ کوچک)
      final loaded = ref.watch(conversationTopicProvider(name));
      final topic = loaded.valueOrNull;
      if (topic != null) return _buildTopicView(context, topic, index);
      return _buildTopicLoading(context, name, loading: loaded.isLoading);
    }
    return _buildTopicsGrid(context, filtered, index);
  }

  /// ردیف فیلتر سطح (A1–C2) بالای لیست موضوع‌ها.
  Widget _levelBar() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ردیفِ اصلی: [همه] + مقاطعِ تحصیلیِ جدید (Preschool، Primary School، …)
            StageChips(
              levelsPlusPrimary: true,
              selected: _primary ? 'P-$_primaryLevel' : null,
              onSelect: (lv) {
                if (lv != null && lv.startsWith('P-')) {
                  _primaryLevel = lv.substring(2);
                  _setPrimary(true);
                } else if (_primary) {
                  _setPrimary(false); // برگشت به «همه»
                }
              },
            ),
            // زیرمجموعه‌ی «همه»: سطح‌های قدیمی (همه سطح‌ها + A1…C2) — دست‌نخورده
            if (!_primary) ...[
              const SizedBox(height: 8),
              LevelChipsMulti(
                selected: _levels,
                onChanged: (s) => setState(() => _levels = s),
              ),
            ],
            const SizedBox(height: 8),
            _searchField(),
          ],
        ),
      );

  /// 🔍 جستجوی مکالمه‌ها (عنوانِ موضوع، سناریو و جمله‌ها) — مثل جستجوی تبِ لغت‌ها.
  Widget _searchField() {
    final c = context.appColors;
    final dir = Directionality.of(context);
    final leftIsPrefix = dir == TextDirection.ltr;
    final search = Icon(Icons.search, color: c.inkSoft, size: 19);
    Widget? side(bool prefix) {
      if (prefix) {
        if (!leftIsPrefix) return search;
      } else if (leftIsPrefix) {
        return null;
      }
      return ValueListenableBuilder<TextEditingValue>(
        valueListenable: _searchCtrl,
        builder: (_, v, __) => v.text.isEmpty
            ? (prefix ? search : const SizedBox.shrink())
            : IconButton(
                icon: Icon(Icons.close, color: c.inkSoft, size: 18),
                onPressed: () {
                  _searchCtrl.clear();
                  setState(() {
                    _query = '';
                    _rangeFrom = 1;
                    _rangeTo = 65;
                  });
                },
              ),
      );
    }

    return Container(
      key: _searchKey,
      height: 46,
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.cardBorder, width: 1),
      ),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) {
          setState(() {
            _query = v;
            _rangeFrom = 1;
            _rangeTo = 65;
          });
          if (v.trim().isNotEmpty) unawaited(_ensureIndex());
        },
        textAlign: TextAlign.start,
        style: TextStyle(color: c.ink, fontSize: 13.5),
        decoration: InputDecoration(
          hintText: context.l10n.phrasebook_search_conversations,
          hintStyle:
              TextStyle(color: c.inkSoft.withOpacity(0.55), fontSize: 13.5),
          prefixIcon: side(true),
          suffixIcon: side(false),
          border: InputBorder.none,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 13),
        ),
      ),
    );
  }

  Widget _buildTopicsGrid(BuildContext context, List<ConversationTopic> topics,
      ConversationsIndex? index) {
    final c = context.appColors;
    final total = topics.length;

    if (total == 0) {
      return ListView(
        children: [
          const ShellHeader(),
          _levelBar(),
          Padding(
            padding: const EdgeInsets.all(40),
            child: Center(
              child: (_indexing && _query.trim().isNotEmpty)
                  ? SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.2, color: c.gold),
                    )
                  : Text(context.l10n.dialogs_no_results,
                      style: TextStyle(color: c.inkSoft, fontSize: 14)),
            ),
          ),
        ],
      );
    }

    final from = _rangeFrom.clamp(1, total).toInt();
    final to = _rangeTo.clamp(from, total).toInt();
    final visible = topics.sublist(from - 1, to);
    // «خوانده‌شده‌ها» روی دستگاه ذخیره می‌شوند (مثل Hope)
    final topicRead = ref.watch(readIdsProvider('conv-topics'));
    final topicReadN = ref.read(readIdsProvider('conv-topics').notifier);
    final readInRange = visible.where((t) => topicRead.contains(t.topic)).length;
    final readTotal = topics.where((t) => topicRead.contains(t.topic)).length;
    final isPro = ProStatus.isPro;
    // 🎓 هدفِ تور = اولین موضوعِ قفل‌نشده
    final tourIdx = visible.indexWhere((t) => !_lockedFor(t.topic));
    _tourTopic = tourIdx >= 0 ? visible[tourIdx].topic : null;
    // 🔒 خلاصه‌ی قفل‌ها برای بنر (فقط کاربرِ رایگان)
    final lockSum = (isPro || index == null)
        ? null
        : index.summary(visible.map((t) => t.topic), _levels,
            isLocked: _lockedFor);

    return ListView(
      controller: _gridScroll,
      padding: const EdgeInsets.only(bottom: 90),
      children: [
        const ShellHeader(),
        _levelBar(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
        RangeCard(
          label: context.l10n.dialogs_topics_label,
          max: total,
          from: from,
          to: to,
          totalInRange: visible.length,
          readInRange: readInRange,
          readTotal: readTotal,
          onFromChanged: (v) => setState(() {
            _rangeFrom = v;
            if (_rangeTo < v) _rangeTo = v;
          }),
          onToChanged: (v) => setState(() => _rangeTo = v),
          onMarkRead: () =>
              topicReadN.setMany(visible.map((t) => t.topic), true),
          onClear: () =>
              topicReadN.setMany(visible.map((t) => t.topic), false),
        ),
        const SizedBox(height: 14),
        if (lockSum != null && lockSum.locked > 0) ...[
          LockedConversationsBanner(
            lockedTopics: lockSum.lockedTopics,
            locked: lockSum.locked,
            total: lockSum.total,
            byLevel: lockSum.byLevel,
          ),
          const SizedBox(height: 14),
        ],
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.62,
          ),
          itemCount: visible.length,
          itemBuilder: (_, i) {
            final topic = visible[i];
            final visual = visualForTopic(topic.topic);
            final e = index?.of(topic.topic);
            final locked = _lockedFor(topic.topic);
            final card = _TopicCard(
              topic: topic,
              visual: visual,
              badgeColor: kTopicBadgeColors[i % kTopicBadgeColors.length],
              isRead: !locked && topicRead.contains(topic.topic),
              mode: locked
                  ? _CardMode.locked
                  : (isPro ? _CardMode.open : _CardMode.free),
              lineCount: e != null
                  ? e.total(_levels)
                  : (isPro ? _countLines(topic) : null),
              freeCount: e?.free(_levels) ?? 0,
              levels: e != null ? e.levels : conversationLevels(topic),
              onTap: () => _openTopic(topic.topic),
              onToggleRead: () => topicReadN.toggle(topic.topic),
            );
            return i == tourIdx ? TourTarget(id: 'cv_topic', child: card) : card;
          },
        ),
            ],
          ),
        ),
      ],
    );
  }

  /// حالتِ «در حالِ لودِ موضوع» یا «لود نشد» (با تلاشِ دوباره).
  Widget _buildTopicLoading(BuildContext context, String name,
      {required bool loading}) {
    final c = context.appColors;
    return ListView(
      children: [
        const ShellHeader(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: InkWell(
            onTap: _closeTopic,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.arrow_back, size: 18, color: c.teal),
                  const SizedBox(width: 6),
                  Text(context.l10n.dialogs_back_to_topics,
                      style: TextStyle(
                          color: c.teal,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(40),
          child: Center(
            child: loading
                ? Column(
                    children: [
                      for (var i = 0; i < 4; i++)
                        Container(
                          height: 64,
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: c.inkSoft.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      const SizedBox(height: 4),
                      SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.2, color: c.gold),
                      ),
                    ],
                  )
                : Column(
                    children: [
                      Text(context.l10n.dialogs_no_results,
                          style: TextStyle(color: c.inkSoft, fontSize: 15)),
                      const SizedBox(height: 12),
                      IconButton(
                        icon: Icon(Icons.refresh, color: c.teal),
                        onPressed: () =>
                            ref.invalidate(conversationTopicProvider(name)),
                      ),
                    ],
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildTopicView(BuildContext context, ConversationTopic topic,
      ConversationsIndex? index) {
    final c = context.appColors;
    // 🔒 جمله‌های قفل‌شده‌ی این موضوعِ رایگان (غیر از A1) — برای کارتِ انتهای صفحه
    final topicCounts = (ProStatus.isPro || index == null)
        ? null
        : index.of(topic.topic);
    final lockedHere = topicCounts?.locked(_levels) ?? 0;
    final visual = visualForTopic(topic.topic);
    final scenarioRead = ref.watch(readIdsProvider('conv-scenarios'));
    final scenarioReadN = ref.read(readIdsProvider('conv-scenarios').notifier);

    // سناریوی بازشده = «متنِ کاملِ» پلیر (اول «می‌شنوی»، بعد «می‌گی» — همان
    // ترتیبِ Hope). همین یک ویجتِ مشترک هایلایت/اسکرول/پرش را برای همه‌ی
    // تب‌ها یکسان انجام می‌دهد.
    // ⏩ تدریجی: حداقل ۴ کارت (و سناریوی بازشده)، بقیه ۴تا۴تا در فریم‌های بعدی
    final totalScenarios = topic.scenarios.length;
    final shownScenarios = math.min(
        totalScenarios, math.max(_reveal, (_openScenario ?? -1) + 1));
    if (shownScenarios < totalScenarios) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) setState(() => _reveal += 4);
      });
    }
    final openIdx = _openScenario;
    final openSc = (openIdx != null && openIdx < topic.scenarios.length)
        ? topic.scenarios[openIdx]
        : null;

    return SyncPlayScope(
      revision: openSc ?? topic,
      originExtra: {'topic': topic.topic, 'scenario': openIdx},
      mode: TrackMode.lines,
      voiceForItem: _voiceForItem,
      voiceForTrans: _voiceForTrans,
      itemsBuilder: () => openSc == null
          ? const <SyncItem>[]
          : [
              // ترتیبِ خوانش = ترتیبِ نمایش: هر جمله‌ی «می‌شنوی» و بلافاصله جوابش «می‌گی»
              for (var i = 0;
                  i < math.max(openSc.speakerA.length, openSc.speakerB.length);
                  i++) ...[
                if (i < openSc.speakerA.length && _lvOk(openSc.speakerA[i].level))
                  SyncItem('a$i', openSc.speakerA[i].en),
                if (i < openSc.speakerB.length && _lvOk(openSc.speakerB[i].level))
                  SyncItem('b$i', openSc.speakerB[i].en),
              ],
            ],
      child: SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 90),
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const ShellHeader(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
        InkWell(
          onTap: _closeTopic,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Icon(Icons.arrow_back, size: 18, color: c.teal),
                const SizedBox(width: 6),
                Text(context.l10n.dialogs_back_to_topics,
                    style: TextStyle(
                        color: c.teal,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Icon(visual.icon, size: 26, color: visual.color),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                  topicTitle(
                      topic.topic, Localizations.localeOf(context).languageCode),
                  style: TextStyle(
                      color: c.ink,
                      fontSize: 19,
                      fontWeight: FontWeight.w800)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...List.generate(shownScenarios, (i) {
          final sc = topic.scenarios[i];
          if (_effLevels.isNotEmpty &&
              !(sc.speakerA.any((l) => _lvOk(l.level)) ||
                  sc.speakerB.any((l) => _lvOk(l.level)))) {
            return const SizedBox.shrink();
          }
          final isOpen = _openScenario == i;
          final readKey = '${topic.topic}::$i';
          final isRead = scenarioRead.contains(readKey);
          return _ScenarioCard(
            scenario: sc,
            levelFilter: _effLevels,
            isOpen: isOpen,
            isRead: isRead,
            onToggle: () =>
                setState(() => _openScenario = isOpen ? null : i),
            onToggleRead: () => scenarioReadN.toggle(readKey),
            onRetry: () =>
                ref.invalidate(conversationTopicProvider(topic.topic)),
          );
        }),
        if (shownScenarios >= totalScenarios && topicCounts != null && lockedHere > 0) ...[
          const SizedBox(height: 4),
          LockedConversationCard(
            locked: lockedHere,
            total: topicCounts.total(_levels),
            byLevel: {
              for (final lv in topicCounts.levels)
                if ((_levels.isEmpty || _levels.contains(lv)) &&
                    topicCounts.lockedAt(lv) > 0)
                  lv: topicCounts.lockedAt(lv),
            },
            scopeLabel: topicTitle(
                topic.topic, Localizations.localeOf(context).languageCode),
          ),
        ],
            ],
          ),
        ),
      ],
    ),
    ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// کارت موضوع
// ═══════════════════════════════════════════════════════════════════

/// open = Pro (همه‌چیز باز) · free = موضوعِ رایگان (فقط A1 باز) · locked = قفل
enum _CardMode { open, free, locked }

class _TopicCard extends StatelessWidget {
  final ConversationTopic topic;
  final TopicVisual visual;
  final Color badgeColor;
  final bool isRead;
  final _CardMode mode;

  /// تعدادِ جمله‌ها (با فیلترِ سطحِ فعلی)؛ null = نشان داده نشود
  final int? lineCount;

  /// تعدادِ جمله‌های رایگان (فقط برای mode == free)
  final int freeCount;

  /// سطح‌هایی که موضوع دارد (نقطه‌های رنگیِ زیرِ آیکون)
  final List<String> levels;
  final VoidCallback onTap, onToggleRead;

  const _TopicCard({
    required this.topic,
    required this.visual,
    required this.badgeColor,
    required this.isRead,
    required this.mode,
    required this.lineCount,
    required this.freeCount,
    required this.levels,
    required this.onTap,
    required this.onToggleRead,
  });

  static Widget _pill(
      AppThemeColorsExt c, Color color, IconData icon, String text) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Container(
        height: 20,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.16),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: color.withOpacity(0.55)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 10, color: color),
            const SizedBox(width: 4),
            Text(text,
                style: TextStyle(
                    color: c.ink, fontSize: 11, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final locked = mode == _CardMode.locked;

    // فوترِ کارت: تعدادِ جمله‌ها
    Widget? footer;
    final n = lineCount;
    if (n != null && n > 0) {
      final unit = ProI18n.t(context, 'lines_unit');
      if (locked) {
        footer = _pill(c, c.gold, Icons.lock, '$n $unit');
      } else if (mode == _CardMode.free) {
        footer = _pill(c, c.teal, Icons.lock_open,
            ProI18n.t(context, 'free_of', {'free': freeCount, 'n': n}));
      } else {
        footer = Text('$n $unit',
            style: TextStyle(
                color: c.inkSoft, fontSize: 11, fontWeight: FontWeight.w600));
      }
    }

    final BoxDecoration deco = locked
        ? BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [c.goldSoft.withOpacity(0.55), c.surface],
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: c.gold.withOpacity(0.55), width: 1.1),
          )
        : BoxDecoration(
            color: isRead ? c.surfaceRead : c.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isRead ? const Color(0xFFE3D2A2) : c.cardBorder,
              width: 1,
            ),
          );

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              padding: const EdgeInsets.fromLTRB(6, 16, 6, 8),
              decoration: deco,
              child: Column(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: locked
                          ? c.gold.withOpacity(0.14)
                          : (isRead
                              ? c.surface.withOpacity(0.7)
                              : badgeBgColor(visual.color)),
                    ),
                    alignment: Alignment.center,
                    child: Icon(
                      visual.icon,
                      size: 24,
                      color: locked
                          ? visual.color.withOpacity(0.8)
                          : (isRead
                              ? const Color(0xFF2E7D6C)
                              : visual.color),
                    ),
                  ),
                  const SizedBox(height: 5),
                  SizedBox(
                    height: 5,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (final lv in levels)
                          Container(
                            width: 5,
                            height: 5,
                            margin: const EdgeInsets.symmetric(horizontal: 1.5),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: levelColor(lv),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Text(
                        topicTitle(topic.topic,
                            Localizations.localeOf(context).languageCode),
                        textAlign: TextAlign.center,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: c.ink,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          height: 1.22,
                        ),
                      ),
                    ),
                  ),
                  if (footer != null) ...[
                    const SizedBox(height: 4),
                    SizedBox(height: 20, child: Center(child: footer)),
                  ],
                ],
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: locked
                ? Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: c.gold,
                      boxShadow: [
                        BoxShadow(
                          color: c.gold.withOpacity(0.35),
                          blurRadius: 4,
                          offset: const Offset(0, 1),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child:
                        const Icon(Icons.lock, size: 12, color: Colors.white),
                  )
                : GestureDetector(
                    onTap: onToggleRead,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isRead ? const Color(0xFF3F9B72) : Colors.white,
                        border: Border.all(
                          color: isRead
                              ? const Color(0xFF276E4F)
                              : const Color(0xFFC8BE95),
                          width: 1.5,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: isRead
                          ? const Icon(Icons.check,
                              size: 11, color: Colors.white)
                          : null,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// کارت سناریو
// ═══════════════════════════════════════════════════════════════════
class _ScenarioCard extends StatelessWidget {
  final ConversationScenario scenario;
  final Set<String> levelFilter;
  final bool isOpen, isRead;
  final VoidCallback onToggle, onToggleRead;

  /// تلاشِ دوباره برای لودِ متنِ کاملِ موضوع (وقتی سناریو متن ندارد)
  final VoidCallback? onRetry;

  const _ScenarioCard({
    required this.scenario,
    required this.levelFilter,
    required this.isOpen,
    required this.isRead,
    required this.onToggle,
    required this.onToggleRead,
    this.onRetry,
  });

  /// سناریو با فیلترِ فعلی هیچ جمله‌ای برای نمایش ندارد
  bool get _hasNoLines {
    bool ok(ConversationLine l) =>
        levelFilter.isEmpty || levelFilter.contains(l.level);
    return !(scenario.speakerA.any(ok) || scenario.speakerB.any(ok));
  }

  Widget _emptyBody(BuildContext context) {
    final c = context.appColors;
    final fa = Localizations.localeOf(context).languageCode == 'fa';
    final pro = ProStatus.isPro;
    final msg = pro
        ? (fa
            ? 'متنِ این مکالمه هنوز لود نشده است. اینترنت را بررسی کنید و دوباره تلاش کنید.'
            : 'This dialogue has not loaded yet. Check your connection and try again.')
        : (fa
            ? 'این مکالمه مخصوصِ Pro است.'
            : 'This dialogue is available with Pro.');
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(
        children: [
          Icon(pro ? Icons.cloud_off : Icons.lock, color: c.gold, size: 22),
          const SizedBox(height: 8),
          Text(msg,
              textAlign: TextAlign.center,
              style: TextStyle(color: c.inkSoft, fontSize: 13.5)),
          if (pro && onRetry != null) ...[
            const SizedBox(height: 6),
            TextButton.icon(
              onPressed: onRetry,
              icon: Icon(Icons.refresh, color: c.teal, size: 18),
              label: Text(fa ? 'تلاش دوباره' : 'Retry',
                  style: TextStyle(color: c.teal)),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isRead ? c.surfaceRead : c.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isRead ? const Color(0xFFE3D2A2) : c.cardBorder),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsets.all(13),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onToggleRead,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isRead
                            ? const Color(0xFF3F9B72)
                            : Colors.transparent,
                        border: Border.all(
                          color: isRead
                              ? const Color(0xFF276E4F)
                              : const Color(0xFFC8BE95),
                          width: 1.5,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: isRead
                          ? const Icon(Icons.check,
                              size: 12, color: Colors.white)
                          : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(scenario.scenario,
                            style: TextStyle(
                                color: c.ink,
                                fontSize: 15.5,
                                fontWeight: FontWeight.w700)),
                        if (scenario.context != null) ...[
                          const SizedBox(height: 2),
                          Text(scenario.context!,
                              style: TextStyle(
                                  color: c.inkSoft, fontSize: 13),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis),
                        ],
                      ],
                    ),
                  ),
                  Icon(isOpen ? Icons.expand_less : Icons.expand_more,
                      color: c.teal, size: 22),
                ],
              ),
            ),
          ),
          if (isOpen && _hasNoLines) ...[
            const Divider(height: 1),
            _emptyBody(context),
          ] else if (isOpen) ...[
            const Divider(height: 1),
            // 🎯 تمرینِ این مکالمه با AI (ویدیو کال) — همان قابلیتِ تاریخچه‌ی مکالمه
            ScenarioPracticeSection(
                key: ObjectKey(scenario),
                scenario: scenario,
                levelFilter: levelFilter),
            _DialogueBox(
                levelFilter: levelFilter,
                hear: scenario.speakerA,
                say: scenario.speakerB),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
class _DialogueBox extends ConsumerWidget {
  final Set<String> levelFilter;

  /// «می‌شنوی» (شناسه‌ی هر خط = 'a$index') و جوابش «می‌گی' (شناسه‌ی 'b$index')
  final List<ConversationLine> hear;
  final List<ConversationLine> say;

  const _DialogueBox({
    required this.levelFilter,
    required this.hear,
    required this.say,
  });

  bool _ok(ConversationLine l) =>
      levelFilter.isEmpty || levelFilter.contains(l.level);

  Widget _tagged(BuildContext context, String title, Color color, Widget row,
      {double indent = 0}) {
    return Padding(
      padding: EdgeInsetsDirectional.only(start: indent, bottom: 4),
      child: Container(
        padding: const EdgeInsetsDirectional.only(start: 8),
        decoration: BoxDecoration(
          border: BorderDirectional(start: BorderSide(color: color, width: 3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: TextStyle(
                    color: color, fontSize: 11.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            row,
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.appColors;
    final L = context.l10n;
    final n = math.max(hear.length, say.length);
    final kids = <Widget>[];
    for (var i = 0; i < n; i++) {
      final hasHear = i < hear.length && _ok(hear[i]);
      final hasSay = i < say.length && _ok(say[i]);
      if (!hasHear && !hasSay) continue;
      // 🎓 اولین خطِ نمایش‌داده‌شده هدفِ تورِ مکالمه است
      final firstLine = kids.isEmpty;
      Widget lineRow(ConversationLine l, String lid, bool tour, String prev) {
        final row = _LineRow(line: l, id: lid, prevEn: prev);
        return tour ? TourTarget(id: 'cv_line', child: row) : row;
      }

      kids.add(Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (hasHear)
              _tagged(context, L.dialogs_you_hear, c.teal,
                  lineRow(hear[i], 'a$i', firstLine,
                      i > 0 && i - 1 < say.length ? say[i - 1].en : '')),
            // جوابِ همین جمله دقیقاً زیرِ آن (کمی تورفته)
            if (hasSay)
              _tagged(context, L.dialogs_you_say, c.gold,
                  lineRow(say[i], 'b$i', firstLine && !hasHear,
                      i < hear.length ? hear[i].en : (i > 0 ? say[i - 1].en : ''))),
                  indent: 16),
          ],
        ),
      ));
    }
    if (kids.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: kids,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// هر خطِ مکالمه = همان کارتِ مشترکِ برنامه (SyncItemCard) — دقیقاً مثل لغات
// ═══════════════════════════════════════════════════════════════════
class _LineRow extends ConsumerWidget {
  final ConversationLine line;
  final String id;

  /// 🎓 خطِ قبلیِ همان مکالمه (انگلیسی) — زمینه برای ترجمه‌ی درست
  final String prevEn;
  const _LineRow({
    required this.line,
    required this.id,
    this.prevEn = '',
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sel = ref.watch(languageSelectionProvider);

    // 🎓 سطح + خطِ قبلی برای Worker (قبل از ساختنِ کارت؛ ترجمه‌ها بعد از build شروع می‌شوند)
    TranslateHints.put(line.en, level: line.level, context: prevEn);

    // مبدأ و مقصدِ یکسان (مثلاً هر دو عربی) → هر زبان فقط یک‌بار
    final langsToShow = <String>[
      if (sel.native != 'en' && !sel.targets.contains(sel.native)) sel.native,
      ...sel.targets.where((t) => t != 'en'),
    ].toSet().toList();

    return SyncItemCard(
      key: ValueKey('line-$id'),
      id: id,
      en: line.en,
      level: line.level,
      langsToShow: langsToShow,
      knownTranslations: line.fa.isNotEmpty
          ? <String, String>{'fa': line.fa}
          : const <String, String>{},
      compact: true,
      aiFirst: true, // 🤖 ترجمه‌ی «اول AI» + کشِ مشترک (lib/core/translate/ai_first_translator.dart)
    );
  }
}
