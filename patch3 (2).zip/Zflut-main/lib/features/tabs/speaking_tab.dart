import '../../core/usage/free_limit.dart';
import '../../core/usage/pro_status.dart';
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../../app.dart';
import '../../core/ai/ai_gateway.dart'
    show aiOutputProblem, cleanAiText;
import '../../core/constants/supported_languages.dart';
import '../../core/models/grammar_note.dart';
import '../../core/providers/ai_settings_provider.dart';
import '../../core/providers/language_selection_provider.dart';
import '../../core/providers/reader_providers.dart';
import '../../core/providers/speech_provider.dart' show speechControllerProvider;
import '../../core/providers/translation_provider.dart';
import '../../core/storage/local_storage.dart';
import '../../core/theme/app_theme_colors.dart';
import '../../core/utils/html_entities.dart';
import '../../core/widgets/ai_answer_tools.dart';
import '../../core/widgets/selection_card.dart'
    show SelectableSyncText, SelectableRun;
import '../../core/widgets/feature_switch_cards.dart';
import '../../core/constants/app_languages.dart' show CalendarSystem;
import '../../core/neural/neural_dates.dart'
    show faDigits, gregorianToJalali, kPersianMonths, kPersianMonthsLatin;
import '../../core/providers/app_prefs_provider.dart';
import '_hope_panel.dart';
import 'speaking_call.dart';

// ═══════════════════════════════════════════════════════════════════
// تب «تمرین مکالمه» — هم‌شکل SpeakingPractice.jsx در Hope
// عنوان + توضیح، انتخاب زبانِ تمرین، کادرِ چت (با پیامِ خوش‌آمدِ Jimmy)،
// نوارِ ورودیِ سبزآبی. گفتگو فقط روی همین گوشی ذخیره می‌شود.
// ═══════════════════════════════════════════════════════════════════

const String _kChatKey = 'zflut-speaking-chat-v1';
const String _kLangKey = 'zflut-speaking-lang-v1';
const String _kHistKey = 'zflut-speaking-history-v1';
const String _kAutoReadKey = 'zflut-speaking-autoread-v1';
// معرفیِ اولیه فقط یک‌بار در کلِ عمرِ برنامه؛ بعد از آن شروعِ گفتگو تصادفی است
const String _kIntroKey = 'zflut-speaking-intro-v1';

// ───────────── بانکِ سؤالِ شروعِ گفتگو (محلی، بدونِ AI، برای کاربرِ رایگان) ─────────────
const Map<String, List<String>> _kLocalOpeners = {
  'en': [
    'Hey! How are you doing today?',
    "Hi! What's up?",
    "How's your day going so far?",
    'What have you been up to lately?',
    'Hey, what are you doing right now?',
    'Hi there! Did anything fun happen today?',
    'How was your day?',
    'Hey! How have you been?',
  ],
  'fa': [
    'سلام! خوبی؟ چه خبر؟',
    'امروزت چطور گذشت؟',
    'چیکار می‌کنی؟',
    'کجا بودی این روزا؟',
    'چه خبرا؟ همه‌چی خوبه؟',
    'امروز کار خاصی کردی؟',
    'هفته‌ات چطور بود؟',
    'سلام! حالت چطوره؟',
  ],
  'es': [
    '¡Hola! ¿Cómo estás?',
    '¿Qué tal tu día?',
    '¿Qué haces ahora?',
    '¿Qué hay de nuevo?',
    '¿Dónde andabas? ¡Cuánto tiempo!',
    '¿Cómo ha ido tu semana?',
    '¿Hiciste algo divertido hoy?',
    '¿Cómo te fue hoy?',
  ],
  'de': [
    "Hallo! Wie geht's dir?",
    "Was gibt's Neues?",
    'Was machst du gerade?',
    'Wie war dein Tag?',
    'Wo warst du in letzter Zeit?',
    'Wie läuft deine Woche?',
    'Hast du heute etwas Schönes gemacht?',
    "Na, wie geht's?",
  ],
  'fr': [
    'Salut ! Comment ça va ?',
    'Quoi de neuf ?',
    "Qu'est-ce que tu fais en ce moment ?",
    'Comment s’est passée ta journée ?',
    'Tu étais où ces derniers temps ?',
    'Comment se passe ta semaine ?',
    'Tu as fait quelque chose d’amusant aujourd’hui ?',
    'Ça va ? Raconte-moi un peu !',
  ],
  'it': [
    'Ciao! Come stai?',
    'Che novità?',
    'Cosa stai facendo adesso?',
    'Com’è andata la giornata?',
    'Dove sei stato in questi giorni?',
    'Com’è la tua settimana?',
    'Hai fatto qualcosa di bello oggi?',
    'Ehi, come va?',
  ],
  'ar': [
    'مرحبًا! كيف حالك؟',
    'ما الأخبار؟',
    'ماذا تفعل الآن؟',
    'كيف كان يومك؟',
    'أين كنت هذه الأيام؟',
    'كيف أسبوعك حتى الآن؟',
    'هل فعلت شيئًا ممتعًا اليوم؟',
    'أهلًا! كيف الحال؟',
  ],
  'tr': [
    'Merhaba! Nasılsın?',
    'Naber?',
    'Şu an ne yapıyorsun?',
    'Günün nasıl geçti?',
    'Bu aralar neler yapıyorsun?',
    'Haftan nasıl gidiyor?',
    'Bugün eğlenceli bir şey yaptın mı?',
    'Selam! Her şey yolunda mı?',
  ],
  'ru': [
    'Привет! Как дела?',
    'Что нового?',
    'Что делаешь сейчас?',
    'Как прошёл твой день?',
    'Где ты пропадал в последнее время?',
    'Как проходит твоя неделя?',
    'Сегодня было что-нибудь интересное?',
    'Привет! Как настроение?',
  ],
  'hi': [
    'नमस्ते! आप कैसे हैं?',
    'क्या चल रहा है?',
    'अभी आप क्या कर रहे हैं?',
    'आपका दिन कैसा रहा?',
    'आजकल कहाँ व्यस्त थे?',
    'आपका हफ़्ता कैसा चल रहा है?',
    'आज कुछ मज़ेदार हुआ क्या?',
    'हेलो! सब ठीक है?',
  ],
  'zh': [
    '你好！你今天怎么样？',
    '最近有什么新鲜事吗？',
    '你现在在做什么？',
    '今天过得怎么样？',
    '最近都在忙什么呢？',
    '这周过得还好吗？',
    '今天有什么有趣的事吗？',
    '嗨！最近好吗？',
  ],
  'ja': [
    'こんにちは！今日はどうですか？',
    '最近どう？',
    '今、何をしていますか？',
    '今日はどんな一日でしたか？',
    '最近、何をしていましたか？',
    '今週はどうですか？',
    '今日、何か楽しいことはありましたか？',
    '元気ですか？',
  ],
  'ko': [
    '안녕하세요! 오늘 어때요?',
    '요즘 어떻게 지내요?',
    '지금 뭐 하고 있어요?',
    '오늘 하루 어땠어요?',
    '요즘 뭐 하고 지냈어요?',
    '이번 주는 어때요?',
    '오늘 재미있는 일 있었어요?',
    '안녕하세요! 잘 지냈어요?',
  ],
};

String _localOpener(String langCode) {
  final list = _kLocalOpeners[langCode.split('-').first.toLowerCase()] ??
      _kLocalOpeners['en']!;
  return list[math.Random().nextInt(list.length)];
}
const Color _kMistake = Color(0xFFC81E1E);
const Color _kCorrection = Color(0xFF166534);

class _Correction {
  final String original;
  final String corrected;
  final int oStart;
  final int oEnd;
  final int cStart;
  final int cEnd;

  const _Correction({
    required this.original,
    required this.corrected,
    required this.oStart,
    required this.oEnd,
    required this.cStart,
    required this.cEnd,
  });

  Map<String, dynamic> toJson() => {
        'original': original,
        'corrected': corrected,
        'oStart': oStart,
        'oEnd': oEnd,
        'cStart': cStart,
        'cEnd': cEnd,
      };

  factory _Correction.fromJson(Map<String, dynamic> j) => _Correction(
        original: (j['original'] ?? '').toString(),
        corrected: (j['corrected'] ?? '').toString(),
        oStart: (j['oStart'] as num?)?.toInt() ?? 0,
        oEnd: (j['oEnd'] as num?)?.toInt() ?? 0,
        cStart: (j['cStart'] as num?)?.toInt() ?? 0,
        cEnd: (j['cEnd'] as num?)?.toInt() ?? 0,
      );
}

class _Msg {
  final String role; // 'user' | 'ai'
  final String text;
  final List<_Correction> corrections;
  final bool savedToGrammar;
  final bool welcome; // پیامِ ثابتِ معرفیِ Jimmy — وارد تاریخچه نمی‌شود

  const _Msg({
    required this.role,
    required this.text,
    this.corrections = const [],
    this.savedToGrammar = false,
    this.welcome = false,
  });

  bool get isWelcome =>
      welcome ||
          (role == 'ai' &&
              (text.startsWith("Hey there! I'm Sara") ||
                  text.startsWith("Hey there! I'm Jimmy")));

  _Msg copyWith({bool? savedToGrammar}) => _Msg(
        role: role,
        text: text,
        corrections: corrections,
        savedToGrammar: savedToGrammar ?? this.savedToGrammar,
        welcome: welcome,
      );

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'corrections': corrections.map((c) => c.toJson()).toList(),
        'savedToGrammar': savedToGrammar,
        if (welcome) 'welcome': true,
      };

  factory _Msg.fromJson(Map<String, dynamic> j) {
    var text = (j['text'] ?? '').toString();
    var cs = <_Correction>[
      for (final e in (j['corrections'] as List? ?? const []))
        if (e is Map) _Correction.fromJson(Map<String, dynamic>.from(e)),
    ];
    // پیام‌های قدیمی ممکن است `&#39;` داشته باشند → رمزگشایی و جابه‌جاییِ آفست‌ها
    final dec = decodeHtmlEntities(text);
    if (dec != text) {
      text = dec;
      cs = _relocate(text, cs);
    }
    return _Msg(
      role: (j['role'] ?? 'ai').toString(),
      text: text,
      corrections: cs,
      savedToGrammar: j['savedToGrammar'] == true,
      welcome: j['welcome'] == true,
    );
  }
}

List<_Correction> _relocate(String text, List<_Correction> list) {
  final out = <_Correction>[];
  var cursor = 0;
  for (final c in list) {
    final o = decodeHtmlEntities(c.original);
    final k = decodeHtmlEntities(c.corrected);
    final oi = text.indexOf(o, cursor);
    final ki = oi < 0 ? -1 : text.indexOf(k, oi + o.length);
    if (oi < 0 || ki < 0) {
      out.add(_Correction(
          original: o, corrected: k, oStart: 0, oEnd: 0, cStart: 0, cEnd: 0));
      continue;
    }
    out.add(_Correction(
      original: o,
      corrected: k,
      oStart: oi,
      oEnd: oi + o.length,
      cStart: ki,
      cEnd: ki + k.length,
    ));
    cursor = ki + k.length;
  }
  return out;
}

class _Reply {
  final String text;
  final List<_Correction> corrections;
  const _Reply(this.text, this.corrections);
}

String _enName(String code) {
  for (final l in kSupportedLanguages) {
    if (l.code == code) return l.enLabel;
  }
  return code;
}

String _normalizeAiText(String t) => decodeHtmlEntities(t)
    .replaceAll('**', '')
    .replaceAll('*', '')
    .replaceAll(RegExp('[\u2018\u2019]'), "'")
    .replaceAll(RegExp('[\u201C\u201D]'), '"');

String _stripThink(String t) => t
    .replaceAll(RegExp(r'<think>[\s\S]*?</think>', caseSensitive: false), '')
    .replaceAll(RegExp(r'<think>[\s\S]*$', caseSensitive: false), '')
    .trim();

/// خطوطِ «FIX: X => Y» بالای پاسخ را استخراج می‌کند و متنِ نمایشی را با
/// آفستِ دقیقِ اشتباه/پیشنهاد می‌سازد (پورتِ extractCorrections وب).
_Reply _extractCorrections(String reply) {
  final normalized = _normalizeAiText(reply);
  final lines = normalized.split('\n');
  final fixRe = RegExp(r'^FIX:\s*(.+?)\s*=>\s*(.+)$', caseSensitive: false);
  final raw = <List<String>>[];
  var i = 0;
  while (i < lines.length) {
    final m = fixRe.firstMatch(lines[i].trim());
    if (m == null) break;
    raw.add([m.group(1)!.trim(), m.group(2)!.trim()]);
    i++;
  }
  final body = lines.sublist(i).join('\n').replaceFirst(RegExp(r'^\s+'), '');
  if (raw.isEmpty) return _Reply(normalized, const []);

  var built = '';
  final out = <_Correction>[];
  for (var idx = 0; idx < raw.length; idx++) {
    final prefix = '${idx + 1}. Instead of "';
    const mid = '", you should say "';
    final oStart = built.length + prefix.length;
    final oEnd = oStart + raw[idx][0].length;
    final cStart = oEnd + mid.length;
    final cEnd = cStart + raw[idx][1].length;
    built += '$prefix${raw[idx][0]}$mid${raw[idx][1]}".\n';
    out.add(_Correction(
      original: raw[idx][0],
      corrected: raw[idx][1],
      oStart: oStart,
      oEnd: oEnd,
      cStart: cStart,
      cEnd: cEnd,
    ));
  }
  return _Reply('$built\n$body', out);
}

class _Seg {
  final String text;
  final int type; // 0 plain, 1 mistake, 2 correction
  const _Seg(this.text, this.type);
}

List<_Seg> _segments(String text, List<_Correction> corrections) {
  if (text.isEmpty || corrections.isEmpty) return [_Seg(text, 0)];
  final ranges = <List<int>>[]; // start, end, type
  for (final c in corrections) {
    if (c.oEnd > c.oStart) ranges.add([c.oStart, c.oEnd, 1]);
    if (c.cEnd > c.cStart) ranges.add([c.cStart, c.cEnd, 2]);
  }
  if (ranges.isEmpty) return [_Seg(text, 0)];
  ranges.sort((a, b) => a[0].compareTo(b[0]));
  final segs = <_Seg>[];
  var cursor = 0;
  for (final r in ranges) {
    if (r[0] < cursor || r[1] > text.length) continue;
    if (r[0] > cursor) segs.add(_Seg(text.substring(cursor, r[0]), 0));
    segs.add(_Seg(text.substring(r[0], r[1]), r[2]));
    cursor = r[1];
  }
  if (cursor < text.length) segs.add(_Seg(text.substring(cursor), 0));
  return segs;
}

String _compactCoach(String text) {
  final kept = text
      .split('\n')
      .where((l) => !RegExp(r'^\s*\d+\.\s*Instead of\s').hasMatch(l))
      .join(' ')
      .replaceAll(RegExp(r'\s{2,}'), ' ')
      .trim();
  final s = kept.isEmpty ? text : kept;
  return s.length > 400 ? s.substring(0, 400) : s;
}

String _historyText(List<_Msg> history) {
  final from = math.max(0, history.length - 4);
  return history.sublist(from).map((m) {
    if (m.role == 'ai') return 'Coach: ${_compactCoach(m.text)}';
    final t = m.text.length > 300 ? m.text.substring(0, 300) : m.text;
    return 'Learner: $t';
  }).join('\n');
}

/// متنِ ترجمه را بدونِ ایموجیِ ابتدایی برمی‌گرداند (مثلاً «✅ Saved» → «Saved»).
String _plain(String t) =>
    t.replaceFirst(RegExp(r'^[^\p{L}\p{N}]+', unicode: true), '');

// ═══════════════════════════════════════════════════════════════════
// تاریخچه‌ی مکالمات — هر مکالمه‌ی ذخیره‌شده یک «جلسه» است با شناسه، زبان،
// زمانِ آخرین تغییر و پیام‌ها (بدون پیامِ ثابتِ معرفیِ Jimmy).
// ═══════════════════════════════════════════════════════════════════
class _Session {
  final String id;
  final String lang;
  final DateTime updatedAt;
  final List<_Msg> messages;

  const _Session({
    required this.id,
    required this.lang,
    required this.updatedAt,
    required this.messages,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'lang': lang,
        'updatedAt': updatedAt.toIso8601String(),
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  static _Session? fromJson(Map<String, dynamic> j) {
    final id = (j['id'] ?? '').toString();
    final at = DateTime.tryParse((j['updatedAt'] ?? '').toString());
    if (id.isEmpty || at == null) return null;
    final msgs = <_Msg>[];
    for (final e in (j['messages'] as List? ?? const [])) {
      if (e is Map) {
        try {
          msgs.add(_Msg.fromJson(Map<String, dynamic>.from(e)));
        } catch (_) {}
      }
    }
    return _Session(
      id: id,
      lang: (j['lang'] ?? 'en').toString(),
      updatedAt: at,
      messages: msgs,
    );
  }
}

/// هر بار که تاریخچه عوض شود یکی زیاد می‌شود تا لیستِ تاریخچه تازه شود.
final ValueNotifier<int> _histTick = ValueNotifier<int>(0);

class _HistoryStore {
  static List<_Session> load(LocalStorage ls) {
    final raw = ls.readJson(_kHistKey)['sessions'];
    final out = <_Session>[];
    if (raw is List) {
      for (final e in raw) {
        if (e is Map) {
          try {
            final x = _Session.fromJson(Map<String, dynamic>.from(e));
            if (x != null) out.add(x);
          } catch (_) {}
        }
      }
    }
    out.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return out;
  }

  static _Session? find(LocalStorage ls, String id) {
    for (final x in load(ls)) {
      if (x.id == id) return x;
    }
    return null;
  }

  static void _save(LocalStorage ls, List<_Session> list) {
    unawaited(ls
        .writeJson(_kHistKey, {'sessions': list.map((x) => x.toJson()).toList()}));
    _histTick.value++;
  }

  static void upsert(LocalStorage ls, _Session s) {
    final list = load(ls).where((x) => x.id != s.id).toList()..add(s);
    _save(ls, list);
  }

  static void remove(LocalStorage ls, Iterable<String> ids) {
    final drop = ids.toSet();
    _save(ls, load(ls).where((x) => !drop.contains(x.id)).toList());
  }
}

String _newId() => DateTime.now().microsecondsSinceEpoch.toString();

String _sessionTitle(_Session s) {
  for (final m in s.messages) {
    if (m.role == 'user' && m.text.trim().isNotEmpty) {
      return m.text.trim().replaceAll(RegExp(r'\s+'), ' ');
    }
  }
  return '';
}

// ═══════════════════════════════════════════════════════════════════
// تب «تمرین مکالمه»: دو زیرتب — «مکالمه» و «تاریخچه‌ی مکالمات»
// ═══════════════════════════════════════════════════════════════════
class SpeakingTab extends ConsumerStatefulWidget {
  const SpeakingTab({super.key});

  @override
  ConsumerState<SpeakingTab> createState() => _SpeakingTabState();
}

class _SpeakingTabState extends ConsumerState<SpeakingTab> {
  int _sub = 0; // 0 = مکالمه، 1 = تاریخچه
  final GlobalKey<_ChatPaneState> _mainKey = GlobalKey<_ChatPaneState>();

  void _go(int i) {
    if (i == _sub) return;
    if (i != 0) _mainKey.currentState?.endCall();
    setState(() => _sub = i);
    if (i == 0) _mainKey.currentState?.reloadFromHistory();
  }

  @override
  Widget build(BuildContext context) {
    return HopePanel(
      contentDirection: uiContentDirection(context),
      children: [
        FeatureSwitchCards(
          selected: _sub,
          onSelect: _go,
          items: [
            FeatureCardItem(
              icon: Icons.record_voice_over_rounded,
              title: context.l10n.speaking_tab_speaking,
              subtitle: FeatureCardTexts.of(context, 'talk_chat'),
              ai: true,
            ),
            FeatureCardItem(
              icon: Icons.history_rounded,
              title: context.l10n.speaking_tab_history,
              subtitle: FeatureCardTexts.of(context, 'talk_history'),
            ),
          ],
        ),
        // هر دو زنده می‌مانند (مکالمه‌ی در حال ارسال با رفتن به تاریخچه گم نشود)
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Offstage(offstage: _sub != 0, child: _ChatPane(key: _mainKey)),
            if (_sub == 1) const _HistoryList(),
          ],
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// لیستِ تاریخچه — گروه‌بندی بر اساس روز (مثل گرامر)، جدیدترین اول.
// باز کردنِ هر مکالمه = همان چتِ کامل (ادامه، ویرایش، حذفِ پیام).
// ═══════════════════════════════════════════════════════════════════
class _HistoryList extends ConsumerStatefulWidget {
  const _HistoryList();

  @override
  ConsumerState<_HistoryList> createState() => _HistoryListState();
}

class _HistoryListState extends ConsumerState<_HistoryList> {
  String? _expanded;
  bool _selectMode = false;
  final Set<String> _selected = {};

  static String _two(int n) => n.toString().padLeft(2, '0');
  static String _dayKey(DateTime d) =>
      '${d.year}/${_two(d.month)}/${_two(d.day)}';

  // 📅 سرتیترِ روز طبقِ «تقویم» در تنظیمات: شمسی / میلادی / هر دو
  String _dayLabel(DateTime d) {
    final loc = Localizations.localeOf(context).toString();
    final cs = ref.watch(appPrefsProvider.select((p) => p.calendarSystem));
    String greg;
    try {
      greg = DateFormat.yMMMEd(loc).format(d);
    } catch (_) {
      greg = _dayKey(d);
    }
    if (cs == CalendarSystem.gregorian) return greg;
    final fa = Localizations.localeOf(context).languageCode == 'fa';
    final j = gregorianToJalali(d.year, d.month, d.day);
    String wd;
    if (fa) {
      const names = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه', 'یکشنبه'];
      wd = names[d.weekday - 1];
    } else {
      try {
        wd = DateFormat.E(loc).format(d);
      } catch (_) {
        wd = '';
      }
    }
    final jal = fa
        ? '$wd ${faDigits(j[2])} ${kPersianMonths[j[1] - 1]} ${faDigits(j[0])}'
        : '${wd.isEmpty ? '' : '$wd, '}${j[2]} ${kPersianMonthsLatin[j[1] - 1]} ${j[0]}';
    return cs == CalendarSystem.both ? '$jal ($greg)' : jal;
  }

  String _timeLabel(DateTime d) {
    final loc = Localizations.localeOf(context).toString();
    try {
      return DateFormat.jm(loc).format(d);
    } catch (_) {
      return '${_two(d.hour)}:${_two(d.minute)}';
    }
  }

  void _exitSelect() => setState(() {
        _selectMode = false;
        _selected.clear();
      });

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;
    final n = _selected.length;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(context.l10n.speaking_confirm_delete_chats('$n')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(context.l10n.cancel_button),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(context.l10n.grammar_delete),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    _HistoryStore.remove(ref.read(localStorageProvider), _selected.toList());
    if (_expanded != null && _selected.contains(_expanded)) _expanded = null;
    _exitSelect();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return ValueListenableBuilder<int>(
      valueListenable: _histTick,
      builder: (context, _, __) {
        final ls = ref.read(localStorageProvider);
        final sessions = _HistoryStore.load(ls);
        final groups = <String, List<_Session>>{};
        for (final x in sessions) {
          groups.putIfAbsent(_dayKey(x.updatedAt), () => []).add(x);
        }
        final labels = groups.keys.toList()..sort((a, b) => b.compareTo(a));

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (sessions.isEmpty)
              HopeEmptyText(context.l10n.speaking_history_empty),
            if (sessions.isNotEmpty && !_selectMode)
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: HopeTextAction(
                  icon: Icons.checklist_rounded,
                  label: context.l10n.grammar_select_delete,
                  color: c.rose,
                  onTap: () => setState(() => _selectMode = true),
                ),
              ),
            if (sessions.isNotEmpty && _selectMode)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: c.goldSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 12,
                  runSpacing: 4,
                  children: [
                    Text(
                      _selected.isNotEmpty
                          ? context.l10n.grammar_n_selected('${_selected.length}')
                          : context.l10n.grammar_select_items,
                      style: TextStyle(
                        color: c.ink,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        HopeTextAction(
                          icon: Icons.checklist_rounded,
                          label: context.l10n.select_all,
                          color: c.teal,
                          onTap: () => setState(() {
                            _selected
                              ..clear()
                              ..addAll(sessions.map((x) => x.id));
                          }),
                        ),
                        const SizedBox(width: 12),
                        HopeTextAction(
                          icon: Icons.delete_outline,
                          label: context.l10n.grammar_delete,
                          color: _selected.isEmpty
                              ? c.rose.withOpacity(0.5)
                              : c.rose,
                          onTap: _selected.isEmpty ? null : _deleteSelected,
                        ),
                        const SizedBox(width: 12),
                        HopeTextAction(
                          label: context.l10n.cancel_button,
                          color: c.inkSoft,
                          onTap: _exitSelect,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            for (final label in labels)
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 4, bottom: 8),
                    child: Row(
                      children: [
                        if (_selectMode)
                          Padding(
                            padding:
                                const EdgeInsetsDirectional.only(end: 8),
                            child: GestureDetector(
                              onTap: () => setState(() {
                                final ids = groups[label]!.map((x) => x.id);
                                if (ids.every(_selected.contains)) {
                                  _selected.removeAll(ids);
                                } else {
                                  _selected.addAll(ids);
                                }
                              }),
                              child: Icon(
                                groups[label]!
                                        .every((x) => _selected.contains(x.id))
                                    ? Icons.check_box
                                    : Icons.check_box_outline_blank,
                                size: 18,
                                color: groups[label]!
                                        .every((x) => _selected.contains(x.id))
                                    ? c.gold
                                    : c.inkSoft,
                              ),
                            ),
                          ),
                        Text(
                          _dayLabel(groups[label]!.first.updatedAt),
                          style: TextStyle(
                            color: c.inkSoft,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  for (final x in groups[label]!)
                    Padding(
                      key: ValueKey('hist-card-${x.id}'),
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _card(c, x),
                    ),
                ],
              ),
          ],
        );
      },
    );
  }

  Widget _card(AppThemeColorsExt c, _Session x) {
    final open = _expanded == x.id && !_selectMode;
    final selected = _selected.contains(x.id);
    final t = _sessionTitle(x);
    final title = t.isEmpty ? context.l10n.speaking_history_untitled : t;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: selected ? c.gold : c.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: () => setState(() {
              if (_selectMode) {
                if (!_selected.add(x.id)) _selected.remove(x.id);
              } else {
                _expanded = _expanded == x.id ? null : x.id;
              }
            }),
            child: Row(
              children: [
                if (_selectMode)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: Icon(
                      selected ? Icons.check_box : Icons.check_box_outline_blank,
                      size: 18,
                      color: selected ? c.gold : c.inkSoft,
                    ),
                  ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textDirection: autoDir(title),
                        style: TextStyle(
                          color: c.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '${langDisplayName(context, x.lang)} · ${_timeLabel(x.updatedAt)}',
                        style: TextStyle(color: c.inkSoft, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                if (!_selectMode) ...[
                  GestureDetector(
                    onTap: () {
                      if (_expanded == x.id) _expanded = null;
                      _HistoryStore.remove(
                          ref.read(localStorageProvider), [x.id]);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Icon(Icons.close, size: 18, color: c.inkSoft),
                    ),
                  ),
                  Icon(
                    open ? Icons.keyboard_arrow_down : Icons.chevron_left,
                    size: 20,
                    color: c.inkSoft,
                  ),
                ],
              ],
            ),
          ),
          if (open)
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.only(top: 10),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: c.cardBorder)),
              ),
              child: _ChatPane(
                key: ValueKey('hist-pane-${x.id}'),
                historyId: x.id,
                onEmptied: () {
                  if (mounted) setState(() => _expanded = null);
                },
              ),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// خودِ چت. دو حالت دارد:
//  • historyId == null → چتِ جاری (تبِ مکالمه)، روی همین گوشی ذخیره می‌شود؛
//    با «ذخیره در تاریخچه» به یک جلسه‌ی تاریخچه گره می‌خورد و از آن به بعد
//    هر تغییرش (و زمانش) در تاریخچه به‌روز می‌شود.
//  • historyId != null → همان جلسه‌ی تاریخچه، درجا و کامل (مثل پیام‌رسان).
// ═══════════════════════════════════════════════════════════════════
class _ChatPane extends ConsumerStatefulWidget {
  final String? historyId;
  final VoidCallback? onEmptied;
  const _ChatPane({super.key, this.historyId, this.onEmptied});

  @override
  ConsumerState<_ChatPane> createState() => _ChatPaneState();
}

class _ChatPaneState extends ConsumerState<_ChatPane> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _editCtrl = TextEditingController();
  int? _editIdx; // اندیسِ پیامِ کاربری که درجا در حال ویرایش است

  List<_Msg> _messages = [];
  bool _loading = false;
  String _error = '';
  String _chatLang = 'en';
  List<_Correction> _corrections = [];
  bool _correctionsSaved = false;
  String? _failedText;
  List<_Msg>? _failedHistory;

  // شخصیتِ هوش مصنوعی + حالتِ ویدیو کال
  AiPersona _persona = PersonaStore.builtIns.first;
  bool _callMode = false;

  // خوانشِ خودکارِ جوابِ AI در چت (با تیک؛ ذخیره می‌شود)
  bool _autoReadOn = false;

  // تاریخچه
  String _sessionId = '';
  bool _inHistory = false;
  DateTime? _syncedAt;

  // انتخاب/حذفِ پیام‌ها
  bool _selectMode = false;
  final Set<int> _sel = {};

  bool get _embedded => widget.historyId != null;

  @override
  void initState() {
    super.initState();
    final ls = ref.read(localStorageProvider);
    if (_embedded) {
      final s = _HistoryStore.find(ls, widget.historyId!);
      _sessionId = widget.historyId!;
      _chatLang = s?.lang ?? 'en';
      _messages = s?.messages ?? [];
      _inHistory = s != null;
      _syncedAt = s?.updatedAt;
      _persona = PersonaStore.byId(ls, PersonaStore.forSession(ls, _sessionId));
      return;
    }
    _autoReadOn = ls.readJson(_kAutoReadKey)['on'] == true;
    final sel = ref.read(languageSelectionProvider);
    final options = sel.targets.isNotEmpty ? sel.targets : const ['en'];
    // زبانِ تمرینِ انتخاب‌شده‌ی قبلی حفظ می‌شود (با جابجایی بین تب‌ها ریست نشود)
    final saved = (ls.readJson(_kLangKey)['lang'] ?? '').toString();
    _chatLang = options.contains(saved) ? saved : options.first;
    final raw = ls.readJson(_kChatKey);
    _sessionId = (raw['sessionId'] ?? '').toString();
    if (_sessionId.isEmpty) _sessionId = _newId();
    _persona = PersonaStore.byId(
        ls, PersonaStore.forSession(ls, _sessionId) ?? PersonaStore.activeId(ls));
    _messages = _load();
    final hs = _HistoryStore.find(ls, _sessionId);
    _inHistory = hs != null;
    _syncedAt = hs?.updatedAt;
    // اگر فقط پیامِ خوش‌آمد هست، با زبانِ فعلی بازسازی شود
    // کاربرِ قدیمی (که قبلاً گفتگو داشته) دیگر «بارِ اول» حساب نمی‌شود
    if (!_introSeen &&
        (_messages.any((m) => !m.isWelcome) ||
            _HistoryStore.load(ls).isNotEmpty)) {
      _markIntroSeen();
    }
    if (_messages.isEmpty || _messages.every((m) => m.isWelcome)) {
      _messages = _freshMessages(_chatLang);
      _persist(history: false);
      // از بارِ دوم به بعد: گاهی خودِ AI گفتگو را شروع می‌کند، گاهی منتظر می‌ماند
      if (_introSeen) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _chatOpener());
      }
    }
  }

  bool get _introSeen =>
      ref.read(localStorageProvider).readString(_kIntroKey) == '1';

  void _markIntroSeen() {
    final ls = ref.read(localStorageProvider);
    if (ls.readString(_kIntroKey) != '1') {
      unawaited(ls.writeString(_kIntroKey, '1'));
    }
  }

  /// بارِ اول: پیامِ معرفی؛ بعد از آن: لیستِ خالی (بدونِ متنِ تکراری).
  List<_Msg> _freshMessages(String lang) =>
      _introSeen ? <_Msg>[] : [_welcome(lang)];

  bool _openerBusy = false;

  /// یک سؤالِ کوتاهِ معمولیِ آدم‌ها برای شروعِ گفتگو (احوال‌پرسی و...).
  /// کاربرِ رایگان: بانکِ محلی (بدونِ AI و بدونِ مصرفِ سهمیه). Pro: AI، و اگر
  /// خطا داد همان بانکِ محلی.
  Future<String?> _smallTalkOpener() async {
    if (!ProStatus.isPro) return _localOpener(_activeLang());
    final ai = await _aiSmallTalkOpener();
    return ai ?? _localOpener(_activeLang());
  }

  Future<String?> _aiSmallTalkOpener() async {
    final langLabel = _enName(_activeLang());
    final native = _enName(ref.read(languageSelectionProvider).native);
    const topics = <String>[
      'how they are doing',
      "what's up / any news",
      'what they are doing right now',
      'how their day has been so far',
      'where they have been lately',
      'whether they have eaten or what they plan for dinner',
      'how their weekend or week is going',
      'what they did today',
      'how they slept or how they are feeling today',
    ];
    final topic = topics[math.Random().nextInt(topics.length)];
    try {
      final r = await _callAi(
          '${_persona.partnerIntro(langLabel)}\n'
          'You start the conversation yourself with a $langLabel learner '
          '(native language: $native). Ask ONE short, casual small-talk '
          'question in $langLabel, the kind people ask each other to begin a '
          'chat, about: $topic. One sentence only, natural and friendly. Do '
          'not introduce yourself and do not explain. Plain text only, no '
          'markdown, no emojis.',
          80);
      final t = _normalizeAiText(r).trim();
      return t.isEmpty ? null : t;
    } catch (_) {
      return null;
    }
  }

  /// چت: بعد از باز شدن (از بارِ دوم به بعد) گاهی AI خودش شروع می‌کند.
  Future<void> _chatOpener() async {
    if (!mounted || _embedded || _callMode || _loading || _openerBusy) return;
    if (_messages.any((m) => !m.isWelcome)) return;
    if (math.Random().nextInt(100) >= 55) return; // این بار منتظرِ کاربر
    final sid = _sessionId;
    _openerBusy = true;
    String? t;
    try {
      t = await _smallTalkOpener();
    } finally {
      _openerBusy = false;
    }
    if (!mounted || t == null || _sessionId != sid || _callMode) return;
    if (_messages.any((m) => !m.isWelcome)) return;
    setState(() => _messages = [
          ..._messages.where((m) => !m.isWelcome),
          _Msg(role: 'ai', text: t!),
        ]);
    _persist();
    _scrollDown();
  }

  void _setChatLang(String v) {
    if (v == _chatLang || !mounted) return;
    setState(() {
      _chatLang = v;
      if (_messages.every((m) => m.isWelcome)) _messages = _freshMessages(v);
    });
    // نوشتن در حافظه بعد از اتمامِ فریم تا انتخابِ زبان لحظه‌ای بماند
    Future.microtask(() {
      if (!mounted) return;
      unawaited(
          ref.read(localStorageProvider).writeJson(_kLangKey, {'lang': v}));
      _persist(history: false);
    });
  }

  @override
  void dispose() {
    _input.dispose();
    _editCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  // ───────────── ذخیره/بازیابی ─────────────
  List<_Msg> _load() {
    final raw = ref.read(localStorageProvider).readJson(_kChatKey)['items'];
    if (raw is! List) return [];
    final out = <_Msg>[];
    for (final e in raw) {
      if (e is Map) {
        try {
          out.add(_Msg.fromJson(Map<String, dynamic>.from(e)));
        } catch (_) {}
      }
    }
    return out;
  }

  void _persist({bool history = true}) {
    if (!mounted) return;
    final ls = ref.read(localStorageProvider);
    if (!_embedded) {
      unawaited(ls.writeJson(_kChatKey, {
        'sessionId': _sessionId,
        'items': _messages.map((m) => m.toJson()).toList(),
      }));
      // اولین پیامِ واقعی (از کاربر یا AI) = معرفیِ اولیه انجام شده
      if (_messages.any((m) => !m.isWelcome)) _markIntroSeen();
    }
    if (history && _inHistory) _syncHistory();
  }

  /// جلسه را در تاریخچه به‌روز می‌کند (پیامِ معرفیِ Jimmy ذخیره نمی‌شود).
  /// اگر دیگر هیچ پیامی نمانده، جلسه از تاریخچه برداشته می‌شود.
  void _syncHistory() {
    final ls = ref.read(localStorageProvider);
    final real = _messages.where((m) => !m.isWelcome).toList();
    if (real.isEmpty) {
      _HistoryStore.remove(ls, [_sessionId]);
      _inHistory = false;
      _syncedAt = null;
      widget.onEmptied?.call();
      return;
    }
    final now = DateTime.now();
    _HistoryStore.upsert(
      ls,
      _Session(
        id: _sessionId,
        lang: _activeLang(),
        updatedAt: now,
        messages: real,
      ),
    );
    _inHistory = true;
    _syncedAt = now;
    PersonaStore.setForSession(ls, _sessionId, _persona.id);
  }

  bool get _hasUserMsg => _messages.any((m) => m.role == 'user');

  void _saveToHistory() {
    if (!_hasUserMsg || _inHistory) return;
    setState(() {
      _inHistory = true;
      _syncHistory();
    });
  }

  /// وقتی از تبِ تاریخچه برمی‌گردیم: اگر همین مکالمه آن‌جا ادامه یافته/حذف شده،
  /// چتِ جاری با آن هم‌گام می‌شود.
  void reloadFromHistory() {
    if (_embedded || !_inHistory || _loading) return;
    final s = _HistoryStore.find(ref.read(localStorageProvider), _sessionId);
    if (s == null) {
      setState(() => _inHistory = false);
      return;
    }
    if (s.updatedAt == _syncedAt) return;
    setState(() {
      _messages = [..._freshMessages(s.lang), ...s.messages];
      _syncedAt = s.updatedAt;
      _selectMode = false;
      _sel.clear();
      _editIdx = null;
      _corrections = [];
      _correctionsSaved = false;
    });
    _persist(history: false);
  }

  _Msg _welcome(String lang) => !_persona.isDefault
      ? _Msg(
          role: 'ai',
          welcome: true,
          text: _persona.welcomeText(_enName(lang)),
        )
      : _Msg(
        role: 'ai',
        welcome: true,
        text: "Hey there! I'm Sara, your conversation coach. Let's practice "
            '${_enName(lang)} together.\n\n'
            "I'll help you with grammar, vocabulary, and natural expressions. "
            "Feel free to write anything you'd like to talk about!\n\n"
            "By the way, what's your name? Or tell me something about yourself.",
      );

  String _activeLang() {
    if (_embedded) return _chatLang;
    final sel = ref.read(languageSelectionProvider);
    final options = sel.targets.isEmpty ? ['en'] : sel.targets;
    return options.contains(_chatLang) ? _chatLang : options.first;
  }

  /// نشانگرِ ابتدای آخرین پیام — صفحه (نه یک لیستِ تودرتو) تا اینجا اسکرول می‌شود
  final GlobalKey _lastMsgKey = GlobalKey();

  void _scrollDown() {
    // ویدیو کال: صفحه باید ثابت بماند (اسکرولِ خودکار نداریم)
    if (_callMode && !_embedded) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final ctx = _lastMsgKey.currentContext;
      if (ctx == null || !ctx.mounted) return;
      // تبِ پنهان (Offstage) → اسکرول نکن
      if (!TickerMode.of(ctx)) return;
      Scrollable.ensureVisible(
        ctx,
        alignment: 0.08,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  /// خوانشِ خودکارِ جوابِ AI؛ همان متنِ دکمه‌ی 🔊 (در حالتِ تماس، پنلِ تماس خودش می‌خواند).
  void _autoRead(String text) {
    if (_callMode || !mounted || !_autoReadOn) return;
    final t = decodeHtmlEntities(text)
        .replaceAll(RegExp('[\u2066-\u2069]'), '')
        .replaceAll(RegExp(r'\*\*|__|`'), '')
        .replaceAll(RegExp(r'^\s{0,3}#{1,6}\s*', multiLine: true), '')
        .replaceAll(RegExp(r'^\s*[-*•]\s+', multiLine: true), '')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
    if (t.isEmpty) return;
    unawaited(PersonaVoice.speak(
        ref.read(speechControllerProvider.notifier), _persona, t, _activeLang()));
  }

  void _setAutoRead(bool v) {
    setState(() => _autoReadOn = v);
    unawaited(
        ref.read(localStorageProvider).writeJson(_kAutoReadKey, {'on': v}));
    // با خاموش‌کردن، خوانشِ در حال پخش هم قطع شود
    if (!v) unawaited(ref.read(speechControllerProvider.notifier).stop());
  }

  // ───────────── انتخاب/حذفِ پیام‌ها ─────────────
  void _enterSelect([int? first]) {
    if (_loading) return;
    setState(() {
      _selectMode = true;
      _editIdx = null;
      _sel.clear();
      if (first != null) _sel.add(first);
    });
  }

  void _exitSelect() => setState(() {
        _selectMode = false;
        _sel.clear();
      });

  void _toggleSel(int i) => setState(() {
        if (!_sel.add(i)) _sel.remove(i);
      });

  void _deleteSelected() {
    if (_sel.isEmpty) return;
    setState(() {
      _messages = [
        for (var i = 0; i < _messages.length; i++)
          if (!_sel.contains(i)) _messages[i],
      ];
      _selectMode = false;
      _sel.clear();
      _editIdx = null;
      _corrections = [];
      _correctionsSaved = false;
      _error = '';
      _failedText = null;
      _failedHistory = null;
      if (_messages.isEmpty && !_embedded) {
        _messages = _freshMessages(_activeLang());
      }
    });
    _persist();
  }

  // ───────────── AI ─────────────
  Future<String> _callAi(String prompt, int maxTokens) async {
    final svc = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);

    Future<String> once(String p, int tokens, int retries) async {
      final r = await svc.callAI(
        prompt: p,
        maxTokens: tokens,
        retries: retries,
        settings: ai,
        // 💎 سقفِ «کل عمر» نسخه‌ی رایگان: تماس جدا از چت شمرده می‌شود
        feature: _callMode ? Feature.videocall : Feature.chat,
      );
      return cleanAiText(_stripThink(r));
    }

    var text = await once(prompt, maxTokens, 1);
    // بعضی مدل‌ها به‌جای جواب، «فکر کردن/تحلیلِ پرامپت» را می‌نویسند (مثل
    // «The user wants me to roleplay as Jimmy…») و توکن‌ها تمام می‌شود.
    // چنین متنی هرگز نباید در تماس/چت نشان داده یا خوانده شود: یک بار با
    // دستورِ سخت‌گیرانه و سقفِ توکنِ بیشتر دوباره می‌پرسیم.
    if (aiOutputProblem(text) != null) {
      text = await once(
        '$prompt\n\nIMPORTANT: Output ONLY the final reply itself, exactly in '
        'the requested format. No analysis, no thinking aloud, no restating '
        'or quoting these instructions.',
        math.max(maxTokens * 3, 420),
        0,
      );
    }
    if (text.isEmpty || aiOutputProblem(text) != null) {
      throw Exception('bad ai output');
    }
    return text;
  }

  Future<_Reply> _askTeacher({
    required String sentence,
    required String lang,
    required String native,
    required List<_Msg> history,
    required bool writtenInNative,
  }) async {
    final langLabel = _enName(lang);
    final nativeLabel = _enName(native);
    final prompt = '''
${_persona.coachIntro(langLabel)} Learner's native language: $nativeLabel.
They just wrote${writtenInNative ? ' (in $nativeLabel, not $langLabel)' : ''}: "$sentence"

Rules:
- If they wrote in $langLabel with mistakes, list each one on its own line at the very top, using EXACTLY this tag — keep the word FIX and the => symbol in English even though everything else you write is in $langLabel, do NOT translate this tag:
FIX: <what they wrote> => <the correct version>
(one FIX line per mistake, using their exact wording for "what they wrote")
- If they wrote in $nativeLabel instead of $langLabel (not a mistake, just the wrong language), use ONE such line: FIX: <what they wrote in $nativeLabel> => <$langLabel equivalent>
- After the FIX line(s) — or immediately if there were no mistakes — leave a blank line, then continue the chat: reply ENTIRELY in $langLabel, plain text only (no markdown/asterisks), naturally and briefly — react, ask a follow-up, like a real conversation, not a report. Do NOT explain the mistakes yourself in prose; the FIX lines above are enough.

${_callMode ? kCallRules : ''}
Recent conversation:
${_historyText(history)}

Now respond to: "$sentence"
''';
    final result = await _callAi(prompt, 550);
    return _extractCorrections(result);
  }

  Future<String> _askContinuation({
    required String translated,
    required String lang,
    required String native,
    required List<_Msg> history,
  }) async {
    final langLabel = _enName(lang);
    final prompt =
        '${_persona.partnerIntro(langLabel)} The learner '
        '(native language: ${_enName(native)}) just said, in $langLabel: "$translated"\n\n'
        'Reply ENTIRELY in $langLabel, briefly and naturally (1-3 short sentences) — '
        'react to what they said and/or ask a short follow-up question, like a real '
        'chat message. Plain text only, no markdown, no numbered lists.\n'
        '${_callMode ? kCallRules : ''}\n'
        'Recent conversation:\n${_historyText(history)}\n';
    final result = await _callAi(prompt, 180);
    return _normalizeAiText(result);
  }

  Future<_Reply> _coachReply(
      String text, List<_Msg> history, String lang) async {
    final native = ref.read(languageSelectionProvider).native;
    final writtenInNative = (native == 'fa' || native == 'ar') &&
        native != lang &&
        lang != 'fa' &&
        lang != 'ar' &&
        isMostlyArabicScript(text);

    if (writtenInNative) {
      // فارسی نوشته → فقط ترجمه است؛ اول ترجمه‌ی رایگان (بدون توکنِ AI)
      var translated = '';
      try {
        translated = decodeHtmlEntities((await ref
                .read(translationServiceProvider)
                .translate(
                  text: text,
                  targetLang: lang,
                  sourceLang: native,
                  aiSettings: ref.read(aiSettingsProvider),
                ))
            .trim());
      } catch (_) {
        translated = '';
      }
      if (translated.isEmpty || translated == text) {
        return _askTeacher(
          sentence: text,
          lang: lang,
          native: native,
          history: history,
          writtenInNative: true,
        );
      }
      final continuation = await _askContinuation(
        translated: translated,
        lang: lang,
        native: native,
        history: history,
      );
      const prefix = '1. Instead of "';
      const mid = '", you should say "';
      final oStart = prefix.length;
      final oEnd = oStart + text.length;
      final cStart = oEnd + mid.length;
      final cEnd = cStart + translated.length;
      return _Reply(
        '$prefix$text$mid$translated".\n\n$continuation',
        [
          _Correction(
            original: text,
            corrected: translated,
            oStart: oStart,
            oEnd: oEnd,
            cStart: cStart,
            cEnd: cEnd,
          ),
        ],
      );
    }

    return _askTeacher(
      sentence: text,
      lang: lang,
      native: native,
      history: history,
      writtenInNative: false,
    );
  }

  Future<void> _ask(String text, List<_Msg> history) async {
    final lang = _activeLang();
    setState(() {
      _editIdx = null;
      _selectMode = false;
      _sel.clear();
      _error = '';
      _corrections = [];
      _correctionsSaved = false;
      _messages = [...history, _Msg(role: 'user', text: text)];
      _loading = true;
    });
    _persist();
    _scrollDown();
    try {
      final r = await _coachReply(text, history, lang);
      if (!mounted) return;
      setState(() {
        if (r.corrections.isNotEmpty) _corrections = r.corrections;
        _messages = [
          ..._messages,
          _Msg(role: 'ai', text: r.text, corrections: r.corrections),
        ];
        _failedText = null;
        _failedHistory = null;
      });
      _autoRead(r.text);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _failedText = text;
        _failedHistory = history;
        _error = context.l10n.speaking_ai_no_response;
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
    _persist();
    _scrollDown();
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _loading) return;
    _input.clear();
    await _ask(text, _messages);
  }

  /// ویرایشِ درجا (مثل چت‌های AI): پیام در همان حباب به یک کادرِ ویرایش تبدیل
  /// می‌شود؛ چیزی حذف نمی‌شود تا کاربر «ذخیره و ارسالِ مجدد» بزند. آن‌وقت
  /// پیام‌های بعد از آن جایگزینِ جوابِ جدیدِ AI می‌شوند. «انصراف» همه‌چیز را
  /// دست‌نخورده برمی‌گرداند.
  void _editMessage(int idx) {
    if (_loading || idx < 0 || idx >= _messages.length) return;
    final m = _messages[idx];
    if (m.role != 'user') return;
    setState(() {
      _editIdx = idx;
      _editCtrl.text = m.text;
      _editCtrl.selection = TextSelection.collapsed(offset: m.text.length);
    });
  }

  void _cancelEdit() {
    if (_editIdx == null) return;
    setState(() => _editIdx = null);
  }

  Future<void> _saveEdit() async {
    final idx = _editIdx;
    final text = _editCtrl.text.trim();
    if (idx == null || text.isEmpty || _loading) return;
    if (idx < 0 || idx >= _messages.length) {
      setState(() => _editIdx = null);
      return;
    }
    final history = _messages.sublist(0, idx);
    setState(() {
      _editIdx = null;
      _failedText = null;
      _failedHistory = null;
    });
    await _ask(text, history);
  }

  /// رفرشِ آخرین پاسخِ AI: همان پیامِ کاربر دوباره فرستاده می‌شود.
  void _refreshReply(int idx) {
    if (_loading || idx < 1 || idx >= _messages.length) return;
    if (_messages[idx].role != 'ai' || _messages[idx - 1].role != 'user') return;
    final text = _messages[idx - 1].text;
    final history = _messages.sublist(0, idx - 1);
    unawaited(_ask(text, history));
  }

  void _retry() {
    final t = _failedText;
    final h = _failedHistory;
    if (t == null || h == null || _loading) return;
    unawaited(_ask(t, h));
  }

  void _clearChat() {
    setState(() {
      _sessionId = _newId(); // مکالمه‌ی جدید = جلسه‌ی جدید؛ قبلی (اگر ذخیره شده) می‌ماند
      _inHistory = false;
      _syncedAt = null;
      _selectMode = false;
      _sel.clear();
      _messages = _freshMessages(_activeLang());
      _editIdx = null;
      _corrections = [];
      _correctionsSaved = false;
      _error = '';
      _failedText = null;
      _failedHistory = null;
    });
    _persist();
    if (_introSeen && !_callMode) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _chatOpener());
    }
  }

  void _saveToGrammar(List<_Correction> list) {
    if (list.isEmpty) return;
    final md = [
      for (var i = 0; i < list.length; i++)
        '**${i + 1}. ${_plain(context.l10n.speaking_mistake)}** ${list[i].original}\n\n'
            '**${_plain(context.l10n.speaking_suggestion)}** ${list[i].corrected}',
    ].join('\n\n---\n\n');
    ref.read(grammarNotesProvider.notifier).addNote(GrammarNote(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          word: '',
          sentence: '',
          markdown: md,
          langCode: _activeLang(),
          savedAt: DateTime.now(),
        ));
  }

  // ───────────── شخصیت + ویدیو کال ─────────────
  Future<void> _pickPersona() async {
    if (_loading || _embedded) return;
    final ls = ref.read(localStorageProvider);
    final picked = await showPersonaSheet(context, ls, _persona.id);
    if (!mounted) return;
    // همان شخصیت ممکن است داخلِ شیت ویرایش یا حذف شده باشد
    final p = PersonaStore.byId(ls, picked ?? _persona.id);
    PersonaStore.setActive(ls, p.id);
    if (_inHistory) PersonaStore.setForSession(ls, _sessionId, p.id);
    setState(() {
      _persona = p;
      if (_messages.every((m) => m.isWelcome)) {
        _messages = _freshMessages(_activeLang());
      }
    });
    _persist(history: false);
  }

  void _setCallMode(bool v) {
    if (v == _callMode || _embedded) return;
    setState(() {
      _callMode = v;
      _editIdx = null;
      _selectMode = false;
      _sel.clear();
    });
  }

  /// از بیرون (تعویضِ زیرتب) تماس را قطع می‌کند.
  void endCall() {
    if (_callMode && mounted) setState(() => _callMode = false);
  }

  /// سلامِ شخصیت وقتی تماس وصل شد (به چت هم اضافه می‌شود).
  Future<String?> _callGreeting() async {
    // فقط یک‌بار: اگر در همین گفتگو قبلاً سلام/معرفی یا هر پیامِ واقعی‌ای هست،
    // با هر بار وارد شدن دوباره معرفیِ خودش را نگوید و در چت هم ننویسد.
    if (_messages.any((m) => !m.isWelcome)) return null;
    if (_openerBusy) return null;
    // از بارِ دوم به بعد: معرفیِ تکراری نداریم؛ گاهی AI با یک سؤالِ معمولی
    // شروع می‌کند و گاهی ساکت منتظرِ حرفِ کاربر می‌ماند.
    if (_introSeen) {
      if (math.Random().nextInt(100) >= 60) return null;
      _openerBusy = true;
      String? o;
      try {
        o = await _smallTalkOpener();
      } finally {
        _openerBusy = false;
      }
      if (!mounted || o == null) return null;
      if (_messages.any((m) => !m.isWelcome)) return null;
      setState(() => _messages = [
            ..._messages.where((m) => !m.isWelcome),
            _Msg(role: 'ai', text: o!),
          ]);
      _persist();
      _scrollDown();
      return o;
    }
    final lang = _activeLang();
    final langLabel = _enName(lang);
    final native = _enName(ref.read(languageSelectionProvider).native);
    final fallback = _persona.welcomeText(langLabel);
    try {
      final r = await _callAi(
          '${_persona.partnerIntro(langLabel)}\n'
          'A live video call with a $langLabel learner (native language: $native) '
          'has just connected. Greet them warmly in $langLabel in 1-2 short spoken '
          'sentences, say your name, and ask one simple question to start the '
          'conversation. Plain text only, no markdown, no emojis.',
          140);
      final t = _normalizeAiText(r).trim();
      if (!mounted) return null;
      if (t.isEmpty) return fallback;
      setState(() => _messages = [..._messages, _Msg(role: 'ai', text: t)]);
      _persist();
      _scrollDown();
      return t;
    } catch (_) {
      return mounted ? fallback : null;
    }
  }

  /// یک نوبتِ تماس: همان مسیرِ چت (تصحیح‌ها + ذخیره در تاریخچه) و برگرداندنِ
  /// متنی که شخصیت باید با صدا بگوید.
  Future<CallTurn?> _callTurn(String text, bool retry) async {
    if (_loading) return null;
    final ft = _failedText;
    final fh = _failedHistory;
    if (retry && ft != null && fh != null) {
      await _ask(ft, fh);
    } else {
      await _ask(text, _messages);
    }
    if (!mounted || _error.isNotEmpty || _messages.isEmpty) return null;
    final last = _messages.last;
    if (last.role != 'ai') return null;
    final fixes = [
      for (final c in last.corrections) CallFix(c.original, c.corrected),
    ];
    var spoken = callSpokenBody(last.text);
    if (fixes.isNotEmpty &&
        !spoken.toLowerCase().contains(fixes.first.corrected.toLowerCase())) {
      spoken = '${fixes.first.corrected}. $spoken';
    }
    return CallTurn(spoken, fixes);
  }

  // ───────────── UI ─────────────
  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final sel = ref.watch(languageSelectionProvider);
    final options = sel.targets.isEmpty ? ['en'] : sel.targets;
    final lang = options.contains(_chatLang) ? _chatLang : options.first;
    final hasReal = _messages.any((m) => !m.isWelcome);

    final parts = <Widget>[
      // ── زبان تمرین + اکشن‌ها ──
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!_embedded)
            Container(
              padding: const EdgeInsetsDirectional.fromSTEB(14, 4, 8, 4),
              decoration: BoxDecoration(
                color: c.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: c.cardBorder),
              ),
              child: Row(
                children: [
                  Icon(Icons.translate_rounded, size: 18, color: c.gold),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      context.l10n.speaking_practice_language
                          .replaceAll(RegExp(r'[:：]\s*$'), '')
                          .trim(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: c.inkSoft,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  // منوی زبان: PopupMenuButton (همیشه داخل صفحه جا می‌گیرد) به‌جای DropdownButton.
                  // انتخاب بعد از بسته‌شدنِ منو و در فریمِ بعد اعمال می‌شود تا هنگ نکند.
                  PopupMenuButton<String>(
                    tooltip: '',
                    padding: EdgeInsets.zero,
                    position: PopupMenuPosition.under,
                    color: c.surface,
                    surfaceTintColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    initialValue: lang,
                    onSelected: (v) {
                      if (v == lang) return;
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (mounted) _setChatLang(v);
                      });
                    },
                    itemBuilder: (ctx) => [
                      for (final code in options.toSet())
                        PopupMenuItem<String>(
                          value: code,
                          height: 40,
                          child: Text(
                            langDisplayName(ctx, code),
                            style: TextStyle(
                                color: c.ink,
                                fontSize: 14,
                                fontWeight: code == lang
                                    ? FontWeight.w800
                                    : FontWeight.w600),
                          ),
                        ),
                    ],
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            langDisplayName(context, lang),
                            style: TextStyle(
                                color: c.ink,
                                fontSize: 14,
                                fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(width: 4),
                          Icon(Icons.keyboard_arrow_down_rounded,
                              color: c.gold),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          if ((hasReal && !_selectMode && !_loading) ||
              (!_embedded && !_callMode) ||
              (!_embedded && _messages.isNotEmpty))
            Padding(
              padding: EdgeInsets.only(top: _embedded ? 0 : 10),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (hasReal && !_selectMode && !_loading)
                    _ToolChip(
                      icon: Icons.checklist_rounded,
                      label: context.l10n.grammar_select_delete,
                      color: c.rose,
                      onTap: () => _enterSelect(),
                    ),
                  if (!_embedded && !_callMode)
                    _ToolChip(
                      icon: _autoReadOn
                          ? Icons.volume_up_rounded
                          : Icons.volume_off_rounded,
                      label: Localizations.localeOf(context).languageCode ==
                              'fa'
                          ? 'خوانش خودکار'
                          : 'Auto-read',
                      color: _autoReadOn ? c.gold : c.inkSoft,
                      active: _autoReadOn,
                      onTap: () => _setAutoRead(!_autoReadOn),
                    ),
                  if (!_embedded && _messages.isNotEmpty)
                    _ToolChip(
                      icon: Icons.delete_outline_rounded,
                      label: context.l10n.speaking_clear_chat,
                      color: c.rose,
                      onTap: _clearChat,
                    ),
                ],
              ),
            ),
        ],
      ),

      // ── شخصیتِ هوش مصنوعی + حالتِ چت/ویدیو کال ──
      if (!_embedded)
        SpeakingPersonaBar(
          persona: _persona,
          callMode: _callMode,
          busy: _loading,
          onPickPersona: _pickPersona,
          onModeChanged: _setCallMode,
        ),

      // ── ویدیو کال (در همان صفحه‌ی چت) ──
      if (_callMode && !_embedded)
        SpeakingCallPanel(
          key: ValueKey('call-$_sessionId-${_persona.id}'),
          persona: _persona,
          langCode: lang,
          langName: _enName(lang),
          onConnected: _callGreeting,
          onUserSaid: _callTurn,
          onEnd: endCall,
        ),

      // ── نوارِ انتخابِ پیام‌ها ──
      if (_selectMode) _selectBar(c),

      // ── کادر تصحیحات ──
      if (_corrections.isNotEmpty) _correctionsBox(c),

      // ── منطقه‌ی چت ──
      _chatArea(c),

      // ── نوار ورودی (در تماس، ورودیِ خودش را دارد) ──
      if (!_callMode || _embedded) _inputBar(c),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < parts.length; i++) ...[
          if (i > 0) const SizedBox(height: 16),
          parts[i],
        ],
      ],
    );
  }

  Widget _selectBar(AppThemeColorsExt c) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: c.goldSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Wrap(
        alignment: WrapAlignment.spaceBetween,
        crossAxisAlignment: WrapCrossAlignment.center,
        spacing: 12,
        runSpacing: 4,
        children: [
          Text(
            _sel.isNotEmpty
                ? context.l10n.grammar_n_selected('${_sel.length}')
                : context.l10n.grammar_select_items,
            style: TextStyle(
              color: c.ink,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              HopeTextAction(
                icon: Icons.checklist_rounded,
                label: context.l10n.select_all,
                color: c.teal,
                onTap: () => setState(() {
                  _sel
                    ..clear()
                    ..addAll(List<int>.generate(_messages.length, (i) => i));
                }),
              ),
              const SizedBox(width: 12),
              HopeTextAction(
                icon: Icons.delete_outline,
                label: context.l10n.grammar_delete,
                color: _sel.isEmpty ? c.rose.withOpacity(0.5) : c.rose,
                onTap: _sel.isEmpty ? null : _deleteSelected,
              ),
              const SizedBox(width: 12),
              HopeTextAction(
                label: context.l10n.cancel_button,
                color: c.inkSoft,
                onTap: _exitSelect,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _correctionsBox(AppThemeColorsExt c) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: c.goldSoft,
        border: Border.all(color: c.gold),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.edit_outlined, size: 15, color: c.ink),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _plain(context.l10n.speaking_corrections_title),
                  style: TextStyle(
                    color: c.ink,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              HopeTextAction(
                label: _correctionsSaved
                    ? _plain(context.l10n.speaking_saved_to_grammar)
                    : _plain(context.l10n.speaking_save_to_grammar),
                color: _correctionsSaved ? c.inkSoft : c.teal,
                fontSize: 11,
                onTap: _correctionsSaved
                    ? null
                    : () {
                        _saveToGrammar(_corrections);
                        setState(() => _correctionsSaved = true);
                      },
              ),
            ],
          ),
          const SizedBox(height: 6),
          for (var i = 0; i < _corrections.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text.rich(
                TextSpan(
                  style: TextStyle(color: c.ink, fontSize: 13, height: 1.7),
                  children: [
                    TextSpan(
                      text: '${i + 1}. ${_plain(context.l10n.speaking_mistake)} ',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    TextSpan(
                      text: _corrections[i].original,
                      style: const TextStyle(
                        color: _kMistake,
                        fontWeight: FontWeight.w700,
                        decoration: TextDecoration.underline,
                        decorationColor: _kMistake,
                      ),
                    ),
                    const TextSpan(text: '\n'),
                    TextSpan(
                      text: '${_plain(context.l10n.speaking_suggestion)} ',
                      style: const TextStyle(
                        color: _kCorrection,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    TextSpan(
                      text: _corrections[i].corrected,
                      style: const TextStyle(
                        color: _kCorrection,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _chatArea(AppThemeColorsExt c) {
    return Container(
      constraints: const BoxConstraints(minHeight: 200),
      decoration: BoxDecoration(
        color: c.surface,
        border: Border.all(color: c.cardBorder),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, bc) {
          final maxW = bc.maxWidth * 0.88;
          // بدونِ اسکرولِ تودرتو: کلِ صفحه با هر جای لمس اسکرول می‌شود
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (var i = 0; i < _messages.length; i++) ...[
                if (i == _messages.length - 1)
                  SizedBox.shrink(key: _lastMsgKey),
                Padding(
                  key: ValueKey('chat-msg-$i'),
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _messageRow(i, _messages[i], maxW, c),
                ),
              ],
              if (_loading)
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: Color.alphaBlend(
                          c.gold.withOpacity(0.10), c.surface),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: c.gold.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: c.gold,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(context.l10n.speaking_checking,
                            style:
                                TextStyle(color: c.inkSoft, fontSize: 13)),
                      ],
                    ),
                  ),
                ),
              if (_error.isNotEmpty)
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(_error,
                          style: TextStyle(color: c.rose, fontSize: 12)),
                      if (_failedText != null) ...[
                        const SizedBox(height: 6),
                        GestureDetector(
                          onTap: _loading ? null : _retry,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: c.rose,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.refresh,
                                    size: 13, color: Colors.white),
                                const SizedBox(width: 4),
                                Text(
                                  context.l10n.speaking_try_again,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
            ],
            ),
          );
        },
      ),
    );
  }

  Widget _messageRow(int idx, _Msg m, double maxW, AppThemeColorsExt c) {
    final isUser = m.role == 'user';
    final dir = autoDir(m.text);

    Widget content;
    final editing = isUser && _editIdx == idx;
    if (editing) {
      content = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _editCtrl,
            autofocus: true,
            minLines: 1,
            maxLines: 6,
            textDirection: dir,
            onChanged: (_) => setState(() {}),
            style: TextStyle(color: c.ink, fontSize: 13, height: 1.7),
            decoration: InputDecoration(
              isDense: true,
              filled: true,
              fillColor: Colors.white,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: c.teal),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: c.teal),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: c.teal, width: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            alignment: WrapAlignment.end,
            children: [
              OutlinedButton(
                onPressed: _cancelEdit,
                style: OutlinedButton.styleFrom(
                  foregroundColor: c.inkSoft,
                  side: BorderSide(color: c.cardBorder),
                  visualDensity: VisualDensity.compact,
                ),
                child: Text(context.l10n.speaking_cancel,
                    style: const TextStyle(fontSize: 12)),
              ),
              FilledButton(
                onPressed:
                    _editCtrl.text.trim().isEmpty ? null : _saveEdit,
                style: FilledButton.styleFrom(
                  backgroundColor: c.teal,
                  visualDensity: VisualDensity.compact,
                ),
                child: Text(context.l10n.speaking_save_resend,
                    style: const TextStyle(fontSize: 12)),
              ),
            ],
          ),
        ],
      );
    } else if (isUser) {
      // لمسِ لغت یا انتخابِ محدوده → کادرِ پاپ‌آپِ مشترک (متن + ترجمه)
      content = SelectableSyncText(
        code: _activeLang(),
        id: 'speaking-user-$idx',
        text: m.text,
        autoLang: true,
        textDirection: dir,
        style: TextStyle(color: c.ink, fontSize: 13, height: 1.7),
      );
    } else {
      final segs = _segments(m.text, m.corrections);
      content = SelectableSyncText(
        code: _activeLang(),
        id: 'speaking-ai-$idx',
        text: segs.map((s) => s.text).join(),
        autoLang: true,
        textDirection: dir,
        style: TextStyle(color: c.ink, fontSize: 13, height: 1.7),
        runs: [
          for (final s in segs)
            SelectableRun(
              s.text,
              s.type == 1
                  ? const TextStyle(
                      color: _kMistake,
                      fontWeight: FontWeight.w700,
                      decoration: TextDecoration.underline,
                      decorationColor: _kMistake,
                    )
                  : s.type == 2
                      ? const TextStyle(
                          color: _kCorrection,
                          fontWeight: FontWeight.w700,
                        )
                      : null,
            ),
        ],
      );
    }

    // 🧬 🔊 داخلِ کادرِ جوابِ AI، بالا سمتِ راست
    if (!isUser && m.text.trim().isNotEmpty) {
      content = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            textDirection: TextDirection.ltr,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: content),
              AiBubbleActions(text: m.text, sourceLang: _activeLang()),
            ],
          ),
          // خطِ‌چین + چیپ‌های ترجمه داخلِ کادر
          AiAnswerTools(text: m.text, sourceLang: _activeLang()),
        ],
      );
    }

    final row = Align(
      alignment: isUser
          ? AlignmentDirectional.centerStart
          : AlignmentDirectional.centerEnd,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: editing ? maxW / 0.88 : maxW),
        child: Column(
          crossAxisAlignment: editing
              ? CrossAxisAlignment.stretch
              : (isUser ? CrossAxisAlignment.start : CrossAxisAlignment.end),
          children: [
            if (!isUser && !editing && _persona.name.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsetsDirectional.only(
                    start: 6, end: 6, bottom: 3),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                          color: c.gold, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 5),
                    Text(_persona.name,
                        style: TextStyle(
                            color: c.gold,
                            fontSize: 11,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? Color.alphaBlend(c.teal.withOpacity(0.10), c.surface)
                    : Color.alphaBlend(c.gold.withOpacity(0.10), c.surface),
                borderRadius: BorderRadiusDirectional.only(
                  topStart: Radius.circular(isUser ? 5 : 18),
                  topEnd: Radius.circular(isUser ? 18 : 5),
                  bottomStart: const Radius.circular(18),
                  bottomEnd: const Radius.circular(18),
                ),
                border: Border.all(
                  color: _selectMode && _sel.contains(idx)
                      ? c.gold
                      : (isUser ? c.teal : c.gold).withOpacity(0.28),
                  width: _selectMode && _sel.contains(idx) ? 2 : 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: content,
            ),
            if (isUser && !_loading && !editing && !_selectMode)
              HopeTextAction(
                icon: Icons.edit_outlined,
                label: context.l10n.speaking_edit,
                color: c.teal,
                fontSize: 11,
                onTap: () => _editMessage(idx),
              ),
            if (!isUser &&
                !_loading &&
                !_selectMode &&
                idx >= 1 &&
                idx == _messages.length - 1 &&
                _messages[idx - 1].role == 'user')
              HopeTextAction(
                icon: Icons.refresh,
                label: context.l10n.speaking_refresh,
                color: c.teal,
                fontSize: 11,
                onTap: () => _refreshReply(idx),
              ),
            if (!isUser && m.corrections.isNotEmpty && !_selectMode)
              HopeTextAction(
                label: m.savedToGrammar
                    ? _plain(context.l10n.speaking_saved_to_grammar)
                    : _plain(context.l10n.speaking_save_to_grammar),
                color: m.savedToGrammar ? c.inkSoft : c.teal,
                fontSize: 11,
                onTap: m.savedToGrammar
                    ? null
                    : () {
                        _saveToGrammar(m.corrections);
                        setState(() {
                          _messages = [
                            for (var i = 0; i < _messages.length; i++)
                              i == idx
                                  ? _messages[i].copyWith(savedToGrammar: true)
                                  : _messages[i],
                          ];
                        });
                        _persist();
                      },
              ),
            if (!_embedded &&
                !isUser &&
                !_loading &&
                !_selectMode &&
                idx == _messages.length - 1 &&
                _hasUserMsg)
              HopeTextAction(
                label: _inHistory
                    ? _plain(context.l10n.speaking_saved_to_history)
                    : _plain(context.l10n.speaking_save_to_history),
                color: _inHistory ? c.inkSoft : c.teal,
                fontSize: 11,
                onTap: _inHistory ? null : _saveToHistory,
              ),
          ],
        ),
      ),
    );

    if (_selectMode) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _toggleSel(idx),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              _sel.contains(idx)
                  ? Icons.check_box
                  : Icons.check_box_outline_blank,
              size: 18,
              color: _sel.contains(idx) ? c.gold : c.inkSoft,
            ),
            const SizedBox(width: 8),
            Expanded(child: IgnorePointer(child: row)),
          ],
        ),
      );
    }
    return GestureDetector(
      onLongPress: (_loading || editing) ? null : () => _enterSelect(idx),
      child: row,
    );
  }

  Widget _inputBar(AppThemeColorsExt c) {
    final canSend = !_loading && _input.text.trim().isNotEmpty;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 5, 5, 5),
      decoration: BoxDecoration(
        color: c.surface,
        border: Border.all(
            color: canSend ? c.teal : c.cardBorder, width: 1.5),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: c.teal.withOpacity(canSend ? 0.18 : 0.06),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        textDirection: TextDirection.ltr, // دکمه‌ی ارسال سمتِ راست
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 5,
              onChanged: (_) => setState(() {}),
              style: TextStyle(color: c.ink, fontSize: 14, height: 1.6),
              decoration: InputDecoration(
                hintText: context.l10n.speaking_input_placeholder,
                hintStyle: TextStyle(
                  color: c.inkSoft.withOpacity(0.6),
                  fontSize: 14,
                ),
                border: InputBorder.none,
                isDense: true,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 11, horizontal: 2),
              ),
            ),
          ),
          const SizedBox(width: 8),
          AnimatedScale(
            scale: canSend ? 1 : 0.92,
            duration: const Duration(milliseconds: 150),
            child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: canSend
                        ? [c.teal, Color.lerp(c.teal, Colors.black, 0.25)!]
                        : [c.cardBorder, c.cardBorder],
                  ),
                ),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: canSend ? _send : null,
                  child: const SizedBox(
                    width: 42,
                    height: 42,
                    child: Icon(Icons.send_rounded,
                        size: 19, color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// چیپِ اکشنِ گردِ نوارِ بالای چت (انتخاب/حذف، خوانش خودکار، پاک‌کردن).
class _ToolChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool active;
  final VoidCallback? onTap;
  const _ToolChip({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Material(
      color: active ? color.withOpacity(0.16) : c.surface,
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
                color: color.withOpacity(active ? 0.6 : 0.35)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                      color: color,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}
