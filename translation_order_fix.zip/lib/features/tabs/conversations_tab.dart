import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app.dart';
import '../../core/constants/topic_icons.dart';
import '../../core/constants/topic_titles.dart';
import '../../core/models/conversation.dart';
import '../../core/native/native_bridge.dart';
import '../../core/player_sync/playback_origin.dart';
import '../../core/player_sync/player_track.dart';
import '../../core/player_sync/sync_widgets.dart';
import '../../core/providers/conversation_provider.dart';
import '../../core/providers/language_selection_provider.dart';
import '../../core/providers/read_ids_provider.dart';
import '../../core/router/back_handlers.dart';
import '../../core/theme/app_theme_colors.dart';
import '../../core/widgets/level_chips.dart';
import '../../core/widgets/range_card.dart';
import '../../core/widgets/sync_item_card.dart';
import '../shell/widgets/shell_header.dart';
import '_hope_panel.dart' show uiContentDirection;

class ConversationsTab extends ConsumerStatefulWidget {
  const ConversationsTab({super.key});

  @override
  ConsumerState<ConversationsTab> createState() => _ConversationsTabState();
}

class _ConversationsTabState extends ConsumerState<ConversationsTab> {
  String? _activeTopic;
  int? _openScenario;

  // 🎭 دو صدای متفاوت برای دو نفرِ مکالمه (A = «می‌شنوی»، B = «می‌گی») — هر بار که سناریو باز می‌شود تصادفی
  final math.Random _rng = math.Random();
  String? _voiceA, _voiceB;
  String? _voicesFor;
  bool _voicesBusy = false;

  /// برچسبِ صدا به F/M ختم می‌شود (مثلاً «Nicole · US · F»).
  static bool _isFemale(String label) => label.trim().endsWith('F');

  Future<void> _pickVoices(String scenarioKey) async {
    if (_voicesBusy || _voicesFor == scenarioKey) return;
    _voicesBusy = true;
    _voicesFor = scenarioKey;
    String? a, b;
    try {
      if (NativeBridge.instance.isSupported) {
        final r = await NativeBridge.instance.getTtsVoices(lang: 'en');
        final raw = r['voices'];
        final ok = <Map<String, dynamic>>[
          if (raw is List)
            for (final e in raw)
              if (e is Map && e['downloaded'] == true && '${e['id']}'.isNotEmpty)
                Map<String, dynamic>.from(e),
        ];
        if (ok.length >= 2) {
          ok.shuffle(_rng);
          final first = ok.first;
          // ترجیحاً یک زن و یک مرد؛ وگرنه دو صدای متفاوت
          final fFem = _isFemale('${first['label']}');
          final other = ok.skip(1).firstWhere(
                (v) => _isFemale('${v['label']}') != fFem,
                orElse: () => ok[1],
              );
          if (_rng.nextBool()) {
            a = '${first['id']}';
            b = '${other['id']}';
          } else {
            a = '${other['id']}';
            b = '${first['id']}';
          }
        }
      }
    } catch (_) {
      a = b = null;
    }
    _voicesBusy = false;
    if (!mounted) return;
    _voiceA = a;
    _voiceB = b;
  }

  String? _voiceForItem(String itemId) {
    if (itemId.startsWith('a')) return _voiceA;
    if (itemId.startsWith('b')) return _voiceB;
    return null;
  }
  String _query = '';
  Set<String> _levels = <String>{};

  bool _lvOk(String l) => _levels.isEmpty || _levels.contains(l);
  int _rangeFrom = 1;
  int _rangeTo = 60;

  /// جای اسکرولِ لیستِ موضوع‌ها — وقتی موضوعی باز می‌شود ذخیره و با «بازگشت»
  /// دقیقاً همان‌جا برگردانده می‌شود (نه بالای لیست).
  ScrollController _gridScroll = ScrollController();
  double _gridOffset = 0;

  @override
  void initState() {
    super.initState();
    // دکمه‌ی «بازگشت» گوشی: اول از موضوعِ بازشده به لیستِ موضوع‌ها برمی‌گردد؛
    // اگر لیست باز بود، کار را به AppShell می‌سپارد (خروج از برنامه).
    BackHandlers.add(_onSystemBack);
    // لمسِ طولانیِ دکمه‌ی پخش از تبِ دیگر: موضوع/سناریوی در حال پخش را باز کن
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _applyRestore(ref.read(tabRestoreProvider));
    });
  }

  /// بازگرداندنِ موضوع + سناریویی که پخش از آن شروع شده بود.
  void _applyRestore(PlaybackOrigin? r) {
    if (r == null || r.route != '/conversations') return;
    final t = r.extra['topic'];
    if (t is! String) return;
    ref.read(tabRestoreProvider.notifier).state = null;
    final sc = r.extra['scenario'];
    if (_gridScroll.hasClients) _gridOffset = _gridScroll.offset;
    setState(() {
      _activeTopic = t;
      _openScenario = sc is int ? sc : 0;
    });
  }

  @override
  void dispose() {
    BackHandlers.remove(_onSystemBack);
    _gridScroll.dispose();
    super.dispose();
  }

  bool _onSystemBack() {
    if (!mounted || _activeTopic == null) return false;
    _closeTopic();
    return true;
  }

  void _openTopic(String topic) {
    if (_gridScroll.hasClients) _gridOffset = _gridScroll.offset;
    setState(() {
      _activeTopic = topic;
      _openScenario = 0;
    });
  }

  void _closeTopic() {
    final old = _gridScroll;
    // کنترلرِ تازه با آفستِ ذخیره‌شده: لیست بدونِ پرش/چشمک در همان جا باز می‌شود
    _gridScroll = ScrollController(initialScrollOffset: _gridOffset);
    setState(() {
      _activeTopic = null;
      _openScenario = null;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<PlaybackOrigin?>(tabRestoreProvider, (prev, next) {
      if (next != null) _applyRestore(next);
    });
    return Directionality(
      // جهتِ محتوا طبقِ زبانِ رابط؛ ShellHeader خودش RTL می‌ماند
      textDirection: uiContentDirection(context),
      child: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    final c = context.appColors;
    final topics = ref.watch(allTopicsProvider);

    if (topics.isEmpty) {
      final loading = ref.watch(conversationLoaderProvider).isLoading;
      return ListView(
        children: [
          const ShellHeader(),
          Padding(
            padding: const EdgeInsets.all(40),
            child: Center(
              child: loading
                  ? SizedBox(
                      width: 26,
                      height: 26,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.4, color: c.gold),
                    )
                  : Text(context.l10n.dialogs_no_results,
                      style: TextStyle(color: c.inkSoft, fontSize: 15)),
            ),
          ),
        ],
      );
    }

    final filtered = topics.where((t) {
      // فیلتر سطح: موضوعی که دست‌کم یک جمله‌ی هم‌سطح دارد
      if (_levels.isNotEmpty &&
          !t.scenarios.any((s) =>
              s.speakerA.any((l) => _lvOk(l.level)) ||
              s.speakerB.any((l) => _lvOk(l.level)))) {
        return false;
      }
      if (_query.trim().isEmpty) return true;
      final q = _query.trim().toLowerCase();
      if (t.topic.toLowerCase().contains(q)) return true;
      if (topicTitle(t.topic, Localizations.localeOf(context).languageCode)
          .toLowerCase()
          .contains(q)) {
        return true;
      }
      return t.scenarios.any((s) =>
          s.scenario.toLowerCase().contains(q) ||
          s.speakerA.any((l) => l.en.toLowerCase().contains(q)) ||
          s.speakerB.any((l) => l.en.toLowerCase().contains(q)));
    }).toList();

    if (_activeTopic != null) {
      final topic = topics.firstWhere((t) => t.topic == _activeTopic,
          orElse: () => topics.first);
      return _buildTopicView(context, topic);
    }
    return _buildTopicsGrid(context, filtered);
  }

  /// ردیف فیلتر سطح (A1–C2) بالای لیست موضوع‌ها.
  Widget _levelBar() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
        child: LevelChipsMulti(
          selected: _levels,
          onChanged: (v) => setState(() {
            _levels = v;
            _rangeFrom = 1;
            _rangeTo = 60;
          }),
        ),
      );

  Widget _buildTopicsGrid(
      BuildContext context, List<ConversationTopic> topics) {
    final c = context.appColors;
    final total = topics.length;

    if (total == 0) {
      return ListView(
        children: [
          const ShellHeader(),
          _levelBar(),
          Padding(
            padding: const EdgeInsets.all(40),
            child: Center(
              child: Text(context.l10n.dialogs_no_results,
                  style: TextStyle(color: c.inkSoft, fontSize: 14)),
            ),
          ),
        ],
      );
    }

    final from = _rangeFrom.clamp(1, total).toInt();
    final to = _rangeTo.clamp(from, total).toInt();
    final visible = topics.sublist(from - 1, to);
    // «خوانده‌شده‌ها» روی دستگاه ذخیره می‌شوند (مثل Hope)
    final topicRead = ref.watch(readIdsProvider('conv-topics'));
    final topicReadN = ref.read(readIdsProvider('conv-topics').notifier);
    final readInRange = visible.where((t) => topicRead.contains(t.topic)).length;
    final readTotal = topics.where((t) => topicRead.contains(t.topic)).length;

    return ListView(
      controller: _gridScroll,
      padding: const EdgeInsets.only(bottom: 90),
      children: [
        const ShellHeader(),
        _levelBar(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
        RangeCard(
          label: context.l10n.dialogs_topics_label,
          max: total,
          from: from,
          to: to,
          totalInRange: visible.length,
          readInRange: readInRange,
          readTotal: readTotal,
          onFromChanged: (v) => setState(() {
            _rangeFrom = v;
            if (_rangeTo < v) _rangeTo = v;
          }),
          onToChanged: (v) => setState(() => _rangeTo = v),
          onMarkRead: () =>
              topicReadN.setMany(visible.map((t) => t.topic), true),
          onClear: () =>
              topicReadN.setMany(visible.map((t) => t.topic), false),
        ),
        const SizedBox(height: 14),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.74,
          ),
          itemCount: visible.length,
          itemBuilder: (_, i) {
            final topic = visible[i];
            final visual = visualForTopic(topic.topic);
            return _TopicCard(
              topic: topic,
              visual: visual,
              badgeColor: kTopicBadgeColors[i % kTopicBadgeColors.length],
              isRead: topicRead.contains(topic.topic),
              onTap: () => _openTopic(topic.topic),
              onToggleRead: () => topicReadN.toggle(topic.topic),
            );
          },
        ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTopicView(BuildContext context, ConversationTopic topic) {
    final c = context.appColors;
    final visual = visualForTopic(topic.topic);
    final scenarioRead = ref.watch(readIdsProvider('conv-scenarios'));
    final scenarioReadN = ref.read(readIdsProvider('conv-scenarios').notifier);

    // سناریوی بازشده = «متنِ کاملِ» پلیر (اول «می‌شنوی»، بعد «می‌گی» — همان
    // ترتیبِ Hope). همین یک ویجتِ مشترک هایلایت/اسکرول/پرش را برای همه‌ی
    // تب‌ها یکسان انجام می‌دهد.
    final openIdx = _openScenario;
    final openSc = (openIdx != null && openIdx < topic.scenarios.length)
        ? topic.scenarios[openIdx]
        : null;
    if (openSc != null) {
      final k = '${topic.topic}:$openIdx';
      if (_voicesFor != k) unawaited(_pickVoices(k));    // 🎭 صدای تازه برای هر بار بازشدنِ سناریو
    }

    return SyncPlayScope(
      revision: openSc ?? topic,
      originExtra: {'topic': topic.topic, 'scenario': openIdx},
      mode: TrackMode.lines,
      voiceForItem: _voiceForItem,
      itemsBuilder: () => openSc == null
          ? const <SyncItem>[]
          : [
              for (var i = 0; i < openSc.speakerA.length; i++)
                if (_lvOk(openSc.speakerA[i].level))
                  SyncItem('a$i', openSc.speakerA[i].en),
              for (var i = 0; i < openSc.speakerB.length; i++)
                if (_lvOk(openSc.speakerB[i].level))
                  SyncItem('b$i', openSc.speakerB[i].en),
            ],
      child: SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 90),
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const ShellHeader(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
        InkWell(
          onTap: _closeTopic,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Icon(Icons.arrow_back, size: 18, color: c.teal),
                const SizedBox(width: 6),
                Text(context.l10n.dialogs_back_to_topics,
                    style: TextStyle(
                        color: c.teal,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Icon(visual.icon, size: 26, color: visual.color),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                  topicTitle(
                      topic.topic, Localizations.localeOf(context).languageCode),
                  style: TextStyle(
                      color: c.ink,
                      fontSize: 19,
                      fontWeight: FontWeight.w800)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...List.generate(topic.scenarios.length, (i) {
          final sc = topic.scenarios[i];
          if (_levels.isNotEmpty &&
              !(sc.speakerA.any((l) => _lvOk(l.level)) ||
                  sc.speakerB.any((l) => _lvOk(l.level)))) {
            return const SizedBox.shrink();
          }
          final isOpen = _openScenario == i;
          final readKey = '${topic.topic}::$i';
          final isRead = scenarioRead.contains(readKey);
          return _ScenarioCard(
            scenario: sc,
            levelFilter: _levels,
            isOpen: isOpen,
            isRead: isRead,
            onToggle: () =>
                setState(() => _openScenario = isOpen ? null : i),
            onToggleRead: () => scenarioReadN.toggle(readKey),
          );
        }),
            ],
          ),
        ),
      ],
    ),
    ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// کارت موضوع
// ═══════════════════════════════════════════════════════════════════
class _TopicCard extends StatelessWidget {
  final ConversationTopic topic;
  final TopicVisual visual;
  final Color badgeColor;
  final bool isRead;
  final VoidCallback onTap, onToggleRead;

  const _TopicCard({
    required this.topic,
    required this.visual,
    required this.badgeColor,
    required this.isRead,
    required this.onTap,
    required this.onToggleRead,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              padding: const EdgeInsets.fromLTRB(6, 22, 6, 8),
              decoration: BoxDecoration(
                color: isRead ? c.surfaceRead : c.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color:
                      isRead ? const Color(0xFFE3D2A2) : c.cardBorder,
                  width: 1,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isRead
                          ? c.surface.withOpacity(0.7)
                          : badgeBgColor(visual.color),
                    ),
                    alignment: Alignment.center,
                    child: Icon(
                      visual.icon,
                      size: 27,
                      color: isRead
                          ? const Color(0xFF2E7D6C)
                          : visual.color,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Text(
                        topicTitle(topic.topic,
                            Localizations.localeOf(context).languageCode),
                        textAlign: TextAlign.center,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: c.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          height: 1.3,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: GestureDetector(
              onTap: onToggleRead,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isRead
                      ? const Color(0xFF3F9B72)
                      : Colors.white,
                  border: Border.all(
                    color: isRead
                        ? const Color(0xFF276E4F)
                        : const Color(0xFFC8BE95),
                    width: 1.5,
                  ),
                ),
                alignment: Alignment.center,
                child: isRead
                    ? const Icon(Icons.check,
                        size: 11, color: Colors.white)
                    : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// کارت سناریو
// ═══════════════════════════════════════════════════════════════════
class _ScenarioCard extends StatelessWidget {
  final ConversationScenario scenario;
  final Set<String> levelFilter;
  final bool isOpen, isRead;
  final VoidCallback onToggle, onToggleRead;

  const _ScenarioCard({
    required this.scenario,
    required this.levelFilter,
    required this.isOpen,
    required this.isRead,
    required this.onToggle,
    required this.onToggleRead,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isRead ? c.surfaceRead : c.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isRead ? const Color(0xFFE3D2A2) : c.cardBorder),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsets.all(13),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onToggleRead,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isRead
                            ? const Color(0xFF3F9B72)
                            : Colors.transparent,
                        border: Border.all(
                          color: isRead
                              ? const Color(0xFF276E4F)
                              : const Color(0xFFC8BE95),
                          width: 1.5,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: isRead
                          ? const Icon(Icons.check,
                              size: 12, color: Colors.white)
                          : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(scenario.scenario,
                            style: TextStyle(
                                color: c.ink,
                                fontSize: 15.5,
                                fontWeight: FontWeight.w700)),
                        if (scenario.context != null) ...[
                          const SizedBox(height: 2),
                          Text(scenario.context!,
                              style: TextStyle(
                                  color: c.inkSoft, fontSize: 13),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis),
                        ],
                      ],
                    ),
                  ),
                  Icon(isOpen ? Icons.expand_less : Icons.expand_more,
                      color: c.teal, size: 22),
                ],
              ),
            ),
          ),
          if (isOpen) ...[
            const Divider(height: 1),
            if (scenario.speakerA.isNotEmpty)
              _SpeakerBox(
                  title: context.l10n.dialogs_you_hear,
                  idPrefix: 'a',
                  color: c.teal,
                  levelFilter: levelFilter,
                  lines: scenario.speakerA),
            if (scenario.speakerB.isNotEmpty)
              _SpeakerBox(
                  title: context.l10n.dialogs_you_say,
                  idPrefix: 'b',
                  color: c.gold,
                  levelFilter: levelFilter,
                  lines: scenario.speakerB),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
class _SpeakerBox extends ConsumerWidget {
  final String title;

  /// 'a' (می‌شنوی) یا 'b' (می‌گی) — شناسه‌ی هر خط = '$idPrefix$index'
  final String idPrefix;
  final Color color;
  final Set<String> levelFilter;
  final List<ConversationLine> lines;

  const _SpeakerBox({
    required this.title,
    required this.idPrefix,
    required this.color,
    required this.levelFilter,
    required this.lines,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.appColors;

    // فقط جمله‌های سطحِ انتخاب‌شده (شناسه‌ها همان ایندکسِ اصلی می‌مانند)
    final shown = <int>[
      for (var i = 0; i < lines.length; i++)
        if (levelFilter.isEmpty || levelFilter.contains(lines[i].level)) i
    ];
    if (shown.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                    color: color, borderRadius: BorderRadius.circular(4)),
              ),
              const SizedBox(width: 6),
              Text(title,
                  style: TextStyle(
                      color: c.ink,
                      fontSize: 14,
                      fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 8),
          for (final i in shown)
            _LineRow(line: lines[i], id: '$idPrefix$i'),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// هر خطِ مکالمه = همان کارتِ مشترکِ برنامه (SyncItemCard) — دقیقاً مثل لغات
// ═══════════════════════════════════════════════════════════════════
class _LineRow extends ConsumerWidget {
  final ConversationLine line;
  final String id;
  const _LineRow({
    required this.line,
    required this.id,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sel = ref.watch(languageSelectionProvider);

    // مبدأ و مقصدِ یکسان (مثلاً هر دو عربی) → هر زبان فقط یک‌بار
    final langsToShow = <String>[
      if (sel.native != 'en' && !sel.targets.contains(sel.native)) sel.native,
      ...sel.targets.where((t) => t != 'en'),
    ].toSet().toList();

    return SyncItemCard(
      key: ValueKey('line-$id'),
      id: id,
      en: line.en,
      level: line.level,
      langsToShow: langsToShow,
      knownTranslations: line.fa.isNotEmpty
          ? <String, String>{'fa': line.fa}
          : const <String, String>{},
      compact: true,
    );
  }
}
