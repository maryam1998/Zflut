package com.linglearn.app.overlay;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.speech.SpeechRecognizer;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

@SuppressLint("NewApi")
public class BubbleService extends Service {

    private static final String TAG = "BubbleService";

    public static final String ACTION_SHOW = "com.linglearn.app.overlay.SHOW";
    public static final String ACTION_HIDE = "com.linglearn.app.overlay.HIDE";
    public static final String ACTION_PROJECTION_RESULT = "com.linglearn.app.overlay.PROJECTION_RESULT";
    public static final String ACTION_PROJECTION_DENIED = "com.linglearn.app.overlay.PROJECTION_DENIED";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_DATA = "data";
    /** true = از مجوزِ ضبطِ مشترک (ProjectionHolder) استفاده کن؛ پنجره‌ی اندروید لازم نیست. */
    public static final String EXTRA_REUSE = "reuse";

    private static final String WORKER_BASE = "https://phrasebook-api.maryam-s-sharifiyan.workers.dev";
    private static final String TRANSCRIBE_PATH = "/api/transcribe";
    private static final String GENERATE_PATH = "/api/generate";
    private static final String GENERATE_PROMPT_KEY = "prompt";

    private static final int SAMPLE_RATE = 16000;
    private static final int CHUNK_MS = 100;
    private static final int CHUNK_BYTES = SAMPLE_RATE * 2 * CHUNK_MS / 1000;
    private static final int MIN_SEG_MS = 800;
    private static final int MAX_SEG_MS = 8000;           // قبلاً ۳۵۰۰: صدا وسطِ جمله بریده می‌شد؛ حالا فقط در جمله‌های خیلی بلند
    private static final int SRV_PARTIAL_EVERY_MS = 500;     // حالت سرور: هر ۵۰۰ms صدای جمع‌شده برای پیش‌نمایشِ زنده فرستاده می‌شود
    private static final int SRV_PARTIAL_MIN_VOICED_MS = 350;
    private static final long SRV_PAUSE_COMMIT_MS = 1600;
    private static final long TAIL_MIN_MS = 220;            // ترجمه‌ی زنده‌ی انتهای جمله حداکثر هر ~۲۲۰ms
    // ✅ تغییر ۴: از 300 به 1400 (جمله‌های کامل‌تر، متنِ باکیفیت‌تر)
    private static final int SILENCE_CUT_MS = 1000;       // مکثِ کوتاهِ نفس‌گیری قطعه را نبُرد
    private static final int MIN_VOICED_MS = 600;
    private static final double SILENCE_RMS = 250.0;
    private static final int MAX_PENDING = 3;
    // If loud audio plays this long and the recognizer never produced text, switch to the server.
    private static final int ASR_WATCHDOG_VOICED_MS = 15000;
    private static final int MAX_TEXT_PENDING = 24;

    private static final long PANEL_HIDE_MS = 6000;
    private static final long PANEL_HIDE_MS_RECORDING = 60000;

    // ✅ تغییر ۵: از 80 به 400 (بار CPU سبک‌تر)
    private static final long PARTIAL_TRANSLATE_INTERVAL_MS = 400;
    private static final long REMOTE_PARTIAL_INTERVAL_MS = 900;
    private static final int MAX_HISTORY = 400;

    private static final int NET_ATTEMPTS = 3;
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .callTimeout(40, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    private static final OkHttpClient HTTP_FAST = HTTP.newBuilder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build();

    private static final String PREFS = "bubble_prefs";
    private static final String CHANNEL_ID = "bubble_channel";
    private static final int NOTIF_ID = 4711;
    private static final int COLOR_INK = Color.parseColor("#1C2541");
    private static final int COLOR_GOLD = Color.parseColor("#C9A227");
    private static final int COLOR_REC = Color.parseColor("#E53935");

    public static volatile boolean running = false;

    private static final Map<String, String> LANG_NAMES = new HashMap<>();
    private static final Map<String, String> LOCALE_TAGS = new HashMap<>();
    static {
        LANG_NAMES.put("fa", "Persian");
        LANG_NAMES.put("en", "English");
        LANG_NAMES.put("ar", "Arabic");
        LANG_NAMES.put("tr", "Turkish");
        LANG_NAMES.put("de", "German");
        LANG_NAMES.put("fr", "French");
        LANG_NAMES.put("es", "Spanish");
        LANG_NAMES.put("it", "Italian");
        LANG_NAMES.put("ru", "Russian");
        LANG_NAMES.put("zh", "Chinese");
        LANG_NAMES.put("ja", "Japanese");
        LANG_NAMES.put("ko", "Korean");
        LANG_NAMES.put("hi", "Hindi");
        LANG_NAMES.put("pt", "Portuguese");
        LANG_NAMES.put("ur", "Urdu");
        LANG_NAMES.put("nl", "Dutch");

        LOCALE_TAGS.put("fa", "fa-IR");
        LOCALE_TAGS.put("en", "en-US");
        LOCALE_TAGS.put("ar", "ar-SA");
        LOCALE_TAGS.put("tr", "tr-TR");
        LOCALE_TAGS.put("de", "de-DE");
        LOCALE_TAGS.put("fr", "fr-FR");
        LOCALE_TAGS.put("es", "es-ES");
        LOCALE_TAGS.put("it", "it-IT");
        LOCALE_TAGS.put("ru", "ru-RU");
        LOCALE_TAGS.put("zh", "zh-CN");
        LOCALE_TAGS.put("ja", "ja-JP");
        LOCALE_TAGS.put("ko", "ko-KR");
        LOCALE_TAGS.put("hi", "hi-IN");
        LOCALE_TAGS.put("pt", "pt-BR");
        LOCALE_TAGS.put("ur", "ur-PK");
        LOCALE_TAGS.put("nl", "nl-NL");
    }

    public static void saveLangs(Context ctx, String target, String source) {
        final SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        final String oldSource = sp.getString("source", "auto");
        SharedPreferences.Editor e = sp.edit();
        if (target != null && !target.isEmpty()) e.putString("target", target);
        if (source != null && !source.isEmpty()) e.putString("source", source);
        e.apply();
        // زبانِ صدا عوض شد (مثلاً از «خودکار» به یک زبانِ مشخص): تشخیصِ قبلی را کنار بگذار
        final BubbleService live = instance;
        if (live != null && source != null && !source.isEmpty() && !source.equals(oldSource)) live.resetDetected();
    }

    /** Comma-separated list of ALL translation target languages the user picked in the app (e.g. "fa,fr,ar"). */
    public static void saveTargets(Context ctx, String csv) {
        if (csv == null) return;
        final SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        // کاربر همین چند لحظه پیش از داخلِ کادر زبان عوض کرده و اپ هنوز نخوانده → فهرستِ قدیمیِ اپ آن را بازنویسی نکند
        if (sp.getBoolean("targetsDirty", false)
                && System.currentTimeMillis() - sp.getLong("targetsDirtyAt", 0L) < 30_000L) return;
        sp.edit().putString("targets", csv.trim()).apply();
    }

    /**
     * 🌐 زبان‌ها از داخلِ کادر عوض شده‌اند و اپ هنوز خبر ندارد؟ → true و فهرستِ جدید در out؛ پرچم پاک می‌شود.
     * (اپ قبل از هر setLanguages این را می‌خواند تا انتخابِ کادر با زبان‌های قدیمیِ اپ بازنویسی نشود.)
     */
    static boolean takePanelTargets(Context ctx, org.json.JSONArray out) {
        final SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!sp.getBoolean("targetsDirty", false)) return false;
        final String csv = sp.getString("targets", "");
        if (csv != null) for (String t : csv.split(",")) {
            t = t.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty()) out.put(t);
        }
        sp.edit().putBoolean("targetsDirty", false).apply();
        return true;
    }

    /** Called by the plugin when languages / display mode change while the bubble is running. */
    static void settingsChanged() {
        final BubbleService s = instance;
        if (s == null) return;
        s.main.post(() -> {
            if (s.yt != null) s.yt.onSettingsChanged();
            s.prepareLocalTranslator();
            s.applyAppFont();
            s.applyPanelColor();
            s.refreshHeader();
            for (Entry e : new ArrayList<>(s.history)) s.renderEntry(e);
            s.refreshLayout();
        });
    }

    /** 🎨 رنگِ کادرِ حباب (مشترک با ذره‌بین)؛ rgb بدونِ آلفا. پیش‌فرض سورمه‌ای 0x1C2541. */
    public static void savePanelColor(Context ctx, int rgb) {
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("panelColor", rgb & 0xFFFFFF).apply();
    }

    /** Translation tone: "neutral" (default), "formal" or "casual". */
    public static void saveTone(Context ctx, String tone) {
        if (tone == null) return;
        String t = tone.trim().toLowerCase(java.util.Locale.ROOT);
        if (!t.equals("formal") && !t.equals("casual") && !t.equals("neutral")) return;
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("tone", t).apply();
    }

    /** Caption display mode: "both" (default, original + translation), "original" or "translation". */
    public static void saveDisplayMode(Context ctx, String mode) {
        if (mode == null) return;
        String m = mode.trim().toLowerCase(java.util.Locale.ROOT);
        if (!m.equals("both") && !m.equals("original") && !m.equals("translation")) return;
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("displayMode", m).apply();
    }

    private String displayMode() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("displayMode", "both");
    }

    private String tone() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("tone", "neutral");
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  📺 حالت یوتیوب: زیرنویسِ ویدیوی در حالِ پخش (جدا از STT؛ منطقش در YtSubtitles/YtMedia)
    // ════════════════════════════════════════════════════════════════════════════

    /** اگه showBubble هنوز سرویس رو بالا نیاورده، درخواستِ روشن‌شدن همین‌جا نگه داشته می‌شه. */
    private static volatile boolean pendingYt = false;

    /** از BubblePlugin.ytSetEnabled: حالتِ یوتیوب رو روشن/خاموش می‌کنه. offsetMs = جابه‌جایی زمانِ زیرنویس. */
    static void setYoutubeEnabled(Context ctx, boolean on, long offsetMs) {
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("ytOffsetMs", offsetMs).apply();
        final BubbleService s = instance;
        if (s == null) { pendingYt = on; return; }
        s.main.post(() -> { if (on) s.startYoutube(true); else s.stopYoutube(true); });
    }

    static boolean youtubeActive() {
        BubbleService s = instance;
        return s != null && s.yt != null && s.yt.isActive();
    }

    // ───────── 👀 روشن‌شدنِ خودکارِ زیرنویسِ یوتیوب ─────────
    // تا حباب بالاست، sessionِ اپ یوتیوب زیر نظر است؛ به‌محضِ پخشِ یک ویدیو، حالتِ یوتیوب خودش روشن می‌شود
    // (کلِ زیرنویس + ترجمه یک‌جا در کادر، همه کم‌رنگ و جمله‌ی در حالِ پخش پررنگ). اگر ویدیو زیرنویس نداشته باشد
    // بی‌سروصدا خاموش می‌شود و ترجمه‌ی زنده‌ی معمولی دست‌نخورده می‌ماند. اگر کاربر خودش ▶ را خاموش کند،
    // برای همان ویدیو دوباره خودکار روشن نمی‌شود. (نیازمندِ «دسترسی به اعلان‌ها»؛ بدونِ آن فقط دستی کار می‌کند.)
    private YtMedia.Tracker ytWatch;
    private boolean ytWatchOn = false;
    private boolean ytAutoStarted = false;   // این بار خودکار روشن شد (نه با دکمه)
    private boolean ytAutoWasRecording = false;   // خودکار که روشن شد، ترجمه‌ی زنده‌ی صدا (STT) در حالِ ضبط بود؟
    private String ytWatchKey = "";          // کلیدِ ویدیوی فعلیِ یوتیوب
    private String ytAutoOffKey = "";        // ویدیویی که کاربر خاموشش کرده / زیرنویس نداشت

    private boolean ytAutoPref() {
        // ⛔ روشن‌شدنِ خودکارِ حالتِ یوتیوب غیرفعال شد (مثلِ linlearn-App: فقط با دکمه‌ی ▶ روشن می‌شود).
        //    علت: ویدیوی بدونِ ترکِ شناخته‌شده (یا خطای موقتِ شبکه) حالتِ یوتیوب را می‌بست و به ترجمه‌ی زنده برمی‌گشت.
        //    کدِ خودکار سرجایش مانده؛ برای روشن‌کردنِ دوباره فقط پیش‌فرضِ زیر را true کنید.
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("ytAuto", false);
    }

    private static String ytKeyOf(YtMedia.State s) {
        if (s == null || !s.hasSession) return "";
        return s.videoId != null ? s.videoId : "t:" + s.title + "|" + (s.durationMs / 1000);
    }

    private final Runnable ytWatchTick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!ytWatchOn && YtMedia.hasAccess(BubbleService.this)) {
                try {
                    if (ytWatch == null) ytWatch = new YtMedia.Tracker(BubbleService.this, BubbleService.this::onYtWatch);
                    ytWatchOn = ytWatch.start();
                } catch (Throwable t) { Log.w(TAG, "yt watcher start failed", t); }
            }
            main.postDelayed(this, 3000);      // دسترسیِ اعلان بعداً هم که داده شد، خودش وصل می‌شود
        }
    };

    private void onYtWatch(YtMedia.State s) {
        if (!running) return;
        if (s == null || !s.hasSession) {          // یوتیوب بسته شد / sessionی نیست
            ytWatchKey = "";
            ytAutoOffKey = "";
            main.removeCallbacks(ytAutoRunnable);
            return;
        }
        final String key = ytKeyOf(s);
        ytWatchKey = key;
        if (yt != null && yt.isActive()) return;
        if (!s.playing || !ytAutoPref()) { main.removeCallbacks(ytAutoRunnable); return; }
        if (s.videoId == null && s.title.isEmpty()) return;
        if (key.equals(ytAutoOffKey)) return;
        main.removeCallbacks(ytAutoRunnable);
        main.postDelayed(ytAutoRunnable, 900);     // چند لحظه صبر: تبلیغ/وضعیتِ گذرا نباشد
    }

    private final Runnable ytAutoRunnable = new Runnable() {
        @Override public void run() {
            if (!running || wm == null || bubble == null) return;
            if (yt != null && yt.isActive()) return;
            YtMedia.State s = ytWatch == null ? null : ytWatch.snapshot();
            if (s == null || !s.hasSession || !s.playing) return;
            if (ytKeyOf(s).equals(ytAutoOffKey)) return;
            ytAutoWasRecording = recording;
            ytAutoStarted = true;
            startYoutube(false);
            if (yt == null || !yt.isActive()) ytAutoStarted = false;
        }
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private final ExecutorService netTr = Executors.newFixedThreadPool(3);
    private final ExecutorService netPartial = Executors.newFixedThreadPool(4);
    private final ExecutorService sttPartialEx = Executors.newSingleThreadExecutor();
    private final java.util.concurrent.atomic.AtomicBoolean srvPartialBusy = new java.util.concurrent.atomic.AtomicBoolean(false);
    private volatile int srvSegId = 0;
    private final AtomicInteger pending = new AtomicInteger(0);
    private final AtomicInteger textPending = new AtomicInteger(0);

    private WindowManager wm;
    private BubbleView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private int bubbleSize;

    private LinearLayout panel;
    private LinearLayout listBox;
    private HistoryScroll scroll;
    private TextView tvHeader;
    private TextView tvStatus;
    private WindowManager.LayoutParams panelLp;
    private boolean panelShown = false;
    private boolean panelFree = false;    // کاربر کادر را با لمسِ سربرگ جابه‌جا کرده → دیگر به حباب چسبیده نیست
    private int panelFreeX = 0, panelFreeY = 0;
    private boolean userHidden = false;   // user closed the panel with the X: do not pop it up again until tapped
    private final ArrayList<Entry> history = new ArrayList<>();   // every sentence heard in this session (main thread only)
    private Entry live;                   // sentence currently being spoken (partial result)
    private YtSubtitles yt;               // 📺 حالت یوتیوب (null = خاموش)
    private TextView tvYt;                // دکمه‌ی ▶ در هدرِ پنل
    private TextView tvYtLoop;            // دکمه‌ی ∞ (تکرارِ کلِ ویدیو)
    private TextView tvYtRestart;         // دکمه‌ی ⏮ : کلِ ویدیوی یوتیوب از اول
    private TextView tvYtPause;           // دکمه‌ی ⏯ : مکث/ادامه‌ی ویدیوی یوتیوب
    private TextView tvYtAll;             // دکمه‌ی 🔂 : (حالتِ «متنِ کامل») خواندنِ کلِ متن از اول و تکرارِ آن
    private boolean ytFullMode = false;   // 📄 زیرنویسِ کامل بدونِ دسترسیِ اعلان و بدونِ پررنگ‌شدن
    private volatile boolean fullLoop = false;
    private int fullIdx = 0, fullToken = 0;
    private TextView tvSave;              // دکمه‌ی 💾 (هم حالت یوتیوب، هم ترجمه‌ی زنده)
    private String lastSourceKey = "";     // پلیر|عنوانِ آخرین منبعِ صدا؛ برای نگه داشتنِ تاریخچه وقتی همان فایل ادامه پیدا می‌کند
    private String liveKey = null;        // شناسه‌ی جلسه‌ی ترجمه‌ی زنده برای ذخیره (با پاک کردنِ تاریخچه ریست می‌شود)
    private long liveStartMs = 0;
    private boolean ytListMode = false;       // 📺 لیستِ کاملِ زیرنویس در پنل است (سقفِ تاریخچه اعمال نشود)
    private int ytListGen = 0;
    private int ytCur = -1;                   // جمله‌ی پررنگ‌شده
    private int ytWanted = -1;                // جمله‌ی جاری در حینِ ساختنِ لیست
    private boolean ytWantedForce = false;
    private boolean ytRefreshQueued = false;
    private static final float YT_DIM = 0.42f;
    private final HashMap<Integer, Entry> ytEntries = new HashMap<>();   // شماره‌ی خطِ زیرنویس -> ردیفِ روی پنل
    private int reqCounter = 0;           // monotonically increasing translation request id
    private final Runnable hidePanel = this::removePanel;

    // ── نمایش/پنهان‌شدنِ خودکارِ کادر ───────────────────────────────────────
    // وقتی چیزی پخش نمی‌شه (ویدیو pause، صدا قطع، یا ضبط متوقف شد) کادر خودش جمع می‌شه و
    // با شروعِ دوباره‌ی پخش خودش برمی‌گرده. بستنِ دستی با ▾ همچنان تا لمسِ حباب پنهان می‌مونه.
    private static final long IDLE_HIDE_MS = 0;   // ⚡ بلافاصله بعد از قطعِ صدا بسته می‌شود (مگر 📌 روشن باشد).   // بعد از قطعِ صدا/ویدیو چند ثانیه صبر می‌کنه (مکثِ بین جمله‌ها کادر را نپرانه) و بعد نرم محو می‌شه
    private static final long IDLE_TICK_MS = 120;     // دقتِ بررسیِ وضعیتِ پخش
    private static final long REOPEN_CONFIRM_MS = 400; // صدا باید این‌قدر پیوسته باشه تا کادر باز شه (نویزِ کوتاه کادر را باز نکنه)
    private static final long PANEL_FADE_IN_MS = 180;
    private static final long PANEL_FADE_OUT_MS = 160;
    private static final long REOPEN_KEEP_HISTORY_MS = 600000;  // منبعِ ناشناس: اگه کمتر از این مدت بسته بوده، تاریخچه نگه داشته می‌شه
    private volatile long lastVoiceMs = 0;   // آخرین لحظه‌ای که صدایی از سیستم شنیده شد
    private volatile long lastTextMs = 0;    // آخرین لحظه‌ای که متنِ تشخیص‌داده‌شده رسید
    private volatile long lastActiveMs = 0;  // آخرین لحظه‌ای که «چیزی در حالِ پخش» یا کاربر مشغول بود
    private boolean idleHidden = false;      // کادر را خودکار (نه کاربر) بسته‌ایم
    // 📌 «باز بمان»: وقتی روشن است کادر هیچ‌وقت خودکار (بی‌کاری / لمسِ بیرونِ کادر) بسته نمی‌شود؛ خاموش = رفتارِ قبلی
    private boolean keepOpen = false;
    private TextView tvPin;
    private boolean idlePinned = false;      // کاربر در حالِ سکوت کادر را برای خواندن باز کرده؛ تا بستنِ دستی خودکار بسته نشه
    private boolean fadingOut = false;       // کادر در حالِ محو شدنِ خودکار است
    private int fadeGen = 0;
    private long idleHiddenAtMs = 0;
    private long activeSinceMs = 0;          // از کی صدا/پخش پیوسته فعال است (0 = فعال نیست)
    private final Runnable idleRunnable = this::idleTick;

    // ── 🎬 حالتِ مینیمال: سربرگ و دکمه‌های پایین بعد از چند ثانیه جمع می‌شوند و فقط متن + نوارِ هاشورخورده می‌ماند ──
    private static final long CHROME_HIDE_MS = 4000;
    private View headerView, pinRowView;
    private final ArrayList<View> gripExtras = new ArrayList<>();
    private boolean chromeHidden = false;
    private volatile long lastPanelTouchMs = 0;

    private boolean anyRowOpen() {
        return (opacityRow != null && opacityRow.getVisibility() == View.VISIBLE)
                || (speedRow != null && speedRow.getVisibility() == View.VISIBLE)
                || (fontRow != null && fontRow.getVisibility() == View.VISIBLE)
                || (langRow != null && langRow.getVisibility() == View.VISIBLE);
    }

    private void applyChrome() {
        final int vis = chromeHidden ? View.GONE : View.VISIBLE;
        if (headerView != null) headerView.setVisibility(vis);
        if (pinRowView != null) pinRowView.setVisibility(vis);
        for (View v : gripExtras) v.setVisibility(vis);
        if (chromeHidden) {
            closeLangRow();
            if (opacityRow != null) opacityRow.setVisibility(View.GONE);
            if (speedRow != null) speedRow.setVisibility(View.GONE);
            if (fontRow != null) fontRow.setVisibility(View.GONE);
        }
        refreshLayout();
    }

    private void toggleChrome() {
        // کنترل‌ها همیشه دیده می‌شوند؛ زدن روی نوارِ پایین دیگر آن‌ها را پنهان نمی‌کند
        if (chromeHidden) { chromeHidden = false; applyChrome(); }
    }

    private boolean somethingPlaying(long now) {
        YtSubtitles y = yt;
        if (y != null && y.isPlaying()) return true;
        return recording && (now - lastVoiceMs < 900 || now - lastTextMs < 900);
    }

    private void idleTick() {
        main.removeCallbacks(idleRunnable);
        if (!running) return;
        long now = SystemClock.elapsedRealtime();
        boolean active = somethingPlaying(now);
        boolean busy = panelDragging || (wordCard != null && wordCard.getVisibility() == View.VISIBLE)
                || (scroll != null && (scroll.frozen || SystemClock.uptimeMillis() - scroll.lastUserTouch < 1500))
                // تمرینِ shadowing: وسطِ ضبط/پخشِ صدای خودت کادر نباید جمع بشه (ضبط حداکثر ۱۰ دقیقه حساب می‌شود)
                || (shadowRecording && now - shadowStartMs < 600000) || shadowPlayer != null;
        if (active || busy) lastActiveMs = now;
        if (panelShown && !fadingOut) {
            final boolean cardOpen = wordCard != null && wordCard.getVisibility() == View.VISIBLE;
            // کنترل‌ها (سربرگ، انتخابِ زبان، دکمه‌های پایین) همیشه نمایش داده می‌شوند؛ جمع‌شدنِ خودکار حذف شد
            if (chromeHidden) {
                chromeHidden = false; applyChrome();                // 📌 روشن و صدا قطع: کنترل‌ها برگردند
            }
        }
        if (!active) activeSinceMs = 0;
        else if (activeSinceMs == 0) activeSinceMs = now;

        if (fadingOut) {
            // وسطِ محو شدن صدا برگشت یا کاربر لمس کرد → منصرف شو
            if (active || busy) { cancelPanelFade(); idleHidden = false; userHidden = false; }
        } else if (active && idleHidden) {
            boolean ytNow = yt != null && yt.isPlaying();
            if (ytNow || now - activeSinceMs >= REOPEN_CONFIRM_MS) reopenFromIdle();
        } else if (!active && !busy && panelShown && !userHidden && !idlePinned && !keepOpen
                && now - lastActiveMs > IDLE_HIDE_MS) {
            fadeOutPanelForIdle();
        }
        main.postDelayed(idleRunnable, IDLE_TICK_MS);
    }

    /** بسته‌شدنِ خودکار: محوِ نرم و بعد برداشتنِ کادر (جای دستیِ کادر حفظ می‌شه). */
    private void fadeOutPanelForIdle() {
        if (!panelShown || panel == null || fadingOut) return;
        fadingOut = true;
        idleHidden = true;
        userHidden = true;
        idleHiddenAtMs = SystemClock.elapsedRealtime();
        final int gen = ++fadeGen;
        panel.animate().cancel();
        panel.animate().alpha(0f).setDuration(PANEL_FADE_OUT_MS).withEndAction(() -> {
            if (!fadingOut || gen != fadeGen) return;
            fadingOut = false;
            final boolean wasFree = panelFree;
            removePanel();
            panelFree = wasFree;
        }).start();
    }

    private void loadKeepOpen() {
        keepOpen = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("keepPanelOpen", false);
    }

    private void toggleKeepOpen() {
        keepOpen = !keepOpen;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("keepPanelOpen", keepOpen).apply();
        updatePinUi();
        if (keepOpen) {
            cancelPanelFade();
            idleHidden = false;
            lastActiveMs = SystemClock.elapsedRealtime();
        }
        showNotice(keepOpen
                ? msg("کادر باز می‌ماند تا خودت ببندی", "Panel stays open until you close it")
                : msg("بسته‌شدنِ خودکارِ کادر دوباره فعال شد", "Auto-hide is back on"));
    }

    private void updatePinUi() {
        if (tvPin == null) return;
        tvPin.setAlpha(keepOpen ? 1f : 0.5f);
        tvPin.setTextColor(keepOpen ? COLOR_GOLD : Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(10));
        bg.setColor(keepOpen ? Color.parseColor("#55F2C14E") : Color.parseColor("#1AFFFFFF"));
        if (keepOpen) bg.setStroke(dp(1), COLOR_GOLD);
        tvPin.setBackground(bg);
    }

    private void cancelPanelFade() {
        if (!fadingOut) return;
        fadingOut = false;
        fadeGen++;
        if (panel != null) {
            panel.animate().cancel();
            panel.animate().alpha(1f).setDuration(120).start();
        }
    }

    /** کادری که خودکار بسته شده بود دوباره باز می‌شه و (در حالتِ یوتیوب) سرِ جمله‌ی در حالِ پخش می‌ره. */
    private void reopenFromIdle() {
        idleHidden = false;
        userHidden = false;
        lastActiveMs = SystemClock.elapsedRealtime();
        // پلیرِ همان فایل (کتابِ صوتی/پادکست…) ادامه پیدا کرد → تاریخچه می‌مونه؛ منبعِ دیگه یا برنامه‌ی بدونِ MediaSession → پاک می‌شه
        if (yt == null && !history.isEmpty()) {
            String key = "";
            try {
                YtMedia.Now np = YtMedia.nowPlaying(this);
                if (np != null && np.title != null && !np.title.isEmpty()) key = np.pkg + "|" + np.title;
            } catch (Throwable ignored) {}
            boolean sameSource = key.isEmpty()
                    ? (SystemClock.elapsedRealtime() - idleHiddenAtMs < REOPEN_KEEP_HISTORY_MS)
                    : key.equals(lastSourceKey);
            if (!sameSource) clearHistory();
            lastSourceKey = key;
        } else if (yt == null) {
            try {
                YtMedia.Now np = YtMedia.nowPlaying(this);
                lastSourceKey = (np != null && np.title != null && !np.title.isEmpty()) ? np.pkg + "|" + np.title : "";
            } catch (Throwable ignored) { lastSourceKey = ""; }
        }
        showPanel();
        if (yt != null && ytCur >= 0) {
            ytWantedForce = true;
            main.postDelayed(() -> applyYtCurrent(false), 250);
        }
    }

    /** متنِ تازه رسید: اگه کادر را خودکار بسته بودیم، دوباره اجازه‌ی نمایش می‌دیم. */
    private void wakeFromIdle() {
        lastTextMs = SystemClock.elapsedRealtime();
        if (idleHidden) { idleHidden = false; userHidden = false; }
    }

    private ObjectAnimator pulse;
    private boolean dragging = false;

    private MediaProjection mediaProjection;
    private boolean projectionRetained = false;      // این سرویس یک «سهم» از مجوزِ مشترک را نگه داشته
    private final Runnable projectionStopListener = new Runnable() {
        @Override public void run() {
            main.post(() -> { mediaProjection = null; projectionRetained = false; stopRecording(); });
        }
    };
    private AudioRecord record;
    private volatile boolean recording = false;

    private static volatile BubbleService instance;
    private volatile boolean micEngine = false;   // true = Android recognizer fed with SYSTEM audio
    private volatile PcmSink sherpaEngine;   // on-device Sherpa-ONNX recognizer (null = Google/server path)
    private volatile boolean gotAsrText = false;
    private volatile int voicedSinceText = 0;

    private Translator localTr;
    private String localTrKey = "";
    private volatile boolean localReady = false;
    private String lastPartialSrc = "";
    private long lastPartialAt = 0;
    private long lastRemotePartialAt = 0;
    private int partialSeq = 0;
    private int shownPartialSeq = 0;
    private boolean partialBusy = false;
    private int finalSeq = 0;
    private int shownFinalSeq = 0;
    private boolean partialScheduled = false;
    private volatile String prevFinalText = "";   // previous final sentence, sent as translation context
    // ✅ تغییر ۱: آخرین متن نهایی — برای جلوگیری از تکرار
    private volatile String lastFinalText = "";
    // ── ترجمه‌ی زنده‌ی نرم و پایدار ──
    private static final long SRC_RENDER_MS = 30;       // متنِ اصلی حداکثر هر ۲۲۰ms به‌روز می‌شود (نه با هر تکانِ تشخیص)
    private static final long PAUSE_COMMIT_MS = 700;     // با ۷۰۰ms سکوت، باقیِ جمله هم ترجمه می‌شود
    private static final long PAUSE_COMMIT_SONG_MS = 6000;   // حالت آهنگ: پیش‌نمایش‌ها هر چند ثانیه می‌آن، پس زود commit نکن
    private static final int TAIL_GUARD_WORDS = 2;       // ۳ کلمه‌ی آخر هنوز ممکن است توسطِ تشخیص عوض شوند
    private static final int CHUNK_MIN_WORDS = 3;
    private static final int CHUNK_MAX_WORDS = 9;
    private static final String CHUNK_FAIL = "\u0000";
    private static final java.util.Set<String> BREAK_BEFORE = new HashSet<>(Arrays.asList(
            "and", "but", "then", "that", "which", "when", "because", "so", "or", "while",
            "who", "where", "as", "if", "though", "until", "after", "before"));
    private static final long SENT_PAUSE_MS = 800;       // مکثِ این‌قدری = پایانِ جمله → خطِ جدید (قبلاً ۵۰۰ و وسطِ جمله می‌شکست)
    private static final long SENT_PAUSE_INCOMPLETE_MS = 2000;   // جمله ناتمام به‌نظر می‌رسد (آخرش «the/to/and/…» است یا خیلی کوتاه است) → بیشتر صبر کن
    private static final int MAX_LINE_WORDS = 22;        // جمله‌ی بدونِ مکث/نقطه از این بلندتر شد، سرِ یک ویرگول/حرفِ ربط شکسته می‌شود
    private static final java.util.Set<String> ABBREVIATIONS = new HashSet<>(Arrays.asList(
            "mr.", "mrs.", "ms.", "dr.", "st.", "prof.", "jr.", "sr.", "vs.", "mt.", "no.", "gen.", "col.",
            "capt.", "lt.", "sgt.", "rev.", "hon.", "messrs.", "etc.", "e.g.", "i.e.",
            // اسپانیایی/آلمانی/فرانسوی/ایتالیایی: مخففی که نقطه دارد پایانِ جمله نیست
            "sra.", "srta.", "dra.", "hr.", "fr.", "nr.", "bzw.", "usw.", "ca.", "z.b.", "d.h.", "u.a.",
            "bspw.", "ggf.", "evtl.", "mme.", "mlle.", "p.ej.", "sig.", "dott.", "ing.", "avv."));
    private int consumedWords = 0;                       // چند کلمه‌ی اولِ گفتارِ جاری قبلاً به‌صورتِ خطِ جدا بسته شده (تشخیصِ گفتار تجمعی است)
    private String pendingHyp = "";
    private long lastSrcRenderAt = 0;
    private boolean srcRenderScheduled = false;
    private TextView selectingTv = null;                 // متنی که الان انگشتِ کاربر رویش است (بازنویسی نشود)
    private final Runnable srcRenderRunnable = () -> { srcRenderScheduled = false; flushPartial(false); };
    private final Runnable pauseCommitRunnable = () -> {
        if (cumulativeAsr() && words(pendingHyp).length >= 4) endSentenceByPause();
        else flushPartial(true);
    };

    private int speechHostRestarts = 0;
    private static final int MAX_SPEECH_HOST_RESTARTS = 40;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        instance = this;

        if (ACTION_HIDE.equals(action)) {
            shutdown();
            return START_NOT_STICKY;
        }

        enterForeground(ACTION_PROJECTION_RESULT.equals(action));

        if (ACTION_PROJECTION_RESULT.equals(action)) {
            handleProjectionResult(intent);
        } else if (ACTION_PROJECTION_DENIED.equals(action)) {
            showNotice(msg("مجوز ضبط صدا داده نشد", "Audio capture permission denied"));
        } else {
            running = true;
            lastActiveMs = SystemClock.elapsedRealtime();
            main.removeCallbacks(idleRunnable);
            main.postDelayed(idleRunnable, 700);
            addBubbleIfNeeded();
            prepareLocalTranslator();
            if (pendingYt) { pendingYt = false; main.post(() -> startYoutube(true)); }
            main.removeCallbacks(ytWatchTick);
            main.post(ytWatchTick);               // 👀 تشخیصِ خودکارِ ویدیوی یوتیوب
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void enterForeground(boolean withProjection) {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            if (withProjection) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            try { startForeground(NOTIF_ID, n, type); }
            catch (SecurityException se) {
                // مجوزِ ضبط دیگر معتبر نیست (مثلاً قطع شده) → بدونِ نوعِ mediaProjection؛ handleProjectionResult دوباره می‌پرسد
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            }
        } else if (withProjection) {
            try { startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); }
            catch (SecurityException se) { startForeground(NOTIF_ID, n); }
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Live translation bubble", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, BubbleService.class).setAction(ACTION_HIDE);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action close = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Close", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("LingoLearn")
                .setContentText("Live translation bubble is active")
                .setOngoing(true)
                .addAction(close)
                .build();
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    private int screenW() {
        if (Build.VERSION.SDK_INT >= 30) return wm.getMaximumWindowMetrics().getBounds().width();
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm.widthPixels;
    }

    private int screenH() {
        if (Build.VERSION.SDK_INT >= 30) return wm.getMaximumWindowMetrics().getBounds().height();
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm.heightPixels;
    }

    private String targetLang() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("target", "fa");
    }

    private String sourceLang() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("source", "auto");
    }

    /** True when the app explicitly told us the spoken language (not "auto"). */
    private boolean srcExplicit() {
        String s = sourceLang();
        return s != null && !s.isEmpty() && !"auto".equals(s);
    }

    /**
     * Spoken language actually used. "auto" is slow (server transcription + LLM translation),
     * so for a language-learning app we assume English unless the target itself is English.
     * Pass sourceLang from the web app to override.
     */
    private String effectiveSource() {
        if (srcExplicit()) return sourceLang();
        if (!LangDetect.ENABLED) return "en".equals(targetLang()) ? "auto" : "en";   // مثلِ linlearn-App
        // 🌐 «تشخیص خودکار»: زبانی که از روی متنِ گفتار تشخیص داده شده (تا وقتی چیزی نیامده: پیش‌فرضِ قبلی)
        final String d = detectedSrc;
        if (d != null) return d;
        return "auto";           // هنوز تشخیص داده نشده: «انگلیسی» فرض نکن (گفتارِ اسپانیایی/… اشتباه ترجمه می‌شد)
    }

    /** زبانِ مخصوصِ «انتخابِ موتورِ تشخیص گفتار»: در حالتِ خودکار همیشه "auto" (Whisperِ چندزبانه)، نه زبانِ تشخیص‌داده‌شده. */
    private String engineSource() {
        if (!LangDetect.ENABLED) return effectiveSource();   // مثلِ linlearn-App
        return srcExplicit() ? sourceLang() : "auto";
    }

    // ───────── 🌐 تشخیصِ خودکارِ زبانِ گفتار (فقط وقتی زبانِ صدا روی «خودکار» است) ─────────
    private volatile String detectedSrc = null;
    private String detectCand = null;
    private int detectStreak = 0;

    /** از روی متنِ تازه‌ی تشخیصِ گفتار، زبان را حدس می‌زند؛ اولین تشخیص فوری، تغییرِ زبان بعد از دو تشخیصِ پشت‌سرهم. */
    private void noteDetected(String text) {
        if (!LangDetect.ENABLED) return;                        // تشخیصِ خودکار فعلاً خاموش است
        if (srcExplicit()) return;
        if (yt != null && yt.isActive()) return;               // یوتیوب: زبانِ خودِ زیرنویس مشخص است
        // متنِ خیلی کوتاه/تکراری («az az az») هرگز زبان را تعیین نمی‌کند
        final String[] dw = text == null ? new String[0] : text.trim().split("\\s+");
        if (dw.length < 3 || WhisperEngine.looksLikeLoop(text)) return;
        final String d = LangDetect.detect(text);
        if (d == null) return;
        final String cur = detectedSrc;
        if (d.equals(cur)) { detectCand = null; detectStreak = 0; return; }
        if (cur == null && dw.length >= 8) { applyDetected(d); return; }       // جمله‌ی بلند: فوری
        if (cur == null) {                                                      // کوتاه: دو تشخیصِ هم‌نظر
            if (d.equals(detectCand)) detectStreak++; else { detectCand = d; detectStreak = 1; }
            if (detectStreak >= 2) applyDetected(d);
            return;
        }
        if (d.equals(detectCand)) detectStreak++; else { detectCand = d; detectStreak = 1; }
        if (detectStreak >= 2) applyDetected(d);
    }

    private void applyDetected(String d) {
        detectedSrc = d;
        detectCand = null;
        detectStreak = 0;
        syncSentenceLang();
        try { prepareLocalTranslator(); } catch (Throwable ignored) { /* مترجمِ آفلاین فقط پشتیبان است */ }
        final Entry e = live;
        if (e != null) e.srcLang = d;                          // 🔊 و کادرِ لغتِ همین خط با زبانِ درست
    }

    private void resetDetected() {
        detectedSrc = null;
        detectCand = null;
        detectStreak = 0;
    }

    /**
     * Every target language the user picked, minus the language being spoken (translating English
     * to English is pointless). Falls back to the UI language for old callers that send no list.
     */
    private List<String> activeTargets() {
        String csv = getSharedPreferences(PREFS, MODE_PRIVATE).getString("targets", "");
        ArrayList<String> out = new ArrayList<>();
        if (csv != null && !csv.isEmpty()) {
            for (String t : csv.split(",")) {
                t = t.trim().toLowerCase(Locale.ROOT);
                if (!t.isEmpty() && !out.contains(t)) out.add(t);
            }
        }
        if (out.isEmpty()) out.add(targetLang());
        // در حالتِ یوتیوب، «زبانِ مبدأ» = زبانِ زیرنویسِ همان ویدیو (مثلاً es)، نه زبانِ صدای تنظیمات؛
        // وگرنه برای ویدیوی غیرانگلیسی، «انگلیسی» به‌اشتباه از ترجمه‌ها حذف می‌شد.
        String src = panelSrcLang();
        if (src != null && !"auto".equals(src)) out.remove(src);
        return out;
    }

    /** زبانِ چیزی که الان ترجمه می‌شود: زیرنویسِ ویدیو (حالتِ یوتیوب) یا زبانِ گفتار (ترجمه‌ی زنده). */
    private String panelSrcLang() {
        return (yt != null && yt.isActive()) ? yt.trackLang() : effectiveSource();
    }

    /** همه‌ی زبان‌های انتخابی (بدونِ حذفِ زبانِ مبدأ) به همان ترتیبی که انتخاب شده‌اند. */
    private ArrayList<String> pickedTargets() {
        String csv = getSharedPreferences(PREFS, MODE_PRIVATE).getString("targets", "");
        ArrayList<String> out = new ArrayList<>();
        if (csv != null && !csv.isEmpty()) {
            for (String t : csv.split(",")) {
                t = t.trim().toLowerCase(Locale.ROOT);
                if (!t.isEmpty() && !out.contains(t)) out.add(t);
            }
        }
        if (out.isEmpty()) out.add(targetLang());
        return out;
    }

    private String primaryTarget() {
        List<String> a = activeTargets();
        return a.isEmpty() ? null : a.get(0);
    }

    // زبانِ متن‌های کادر (ترجمه‌ی زنده، کادرِ لغت، اعلان‌ها) = «زبان نرم‌افزار» در تنظیماتِ اپ،
    // نه زبانِ مقصدِ ترجمه. اگه اپ هنوز زبانِ رابط رو نفرستاده بود، مثلِ قبل از زبانِ مقصد می‌خونه.
    private boolean isFa() { return uiLangIsFa(this); }

    /** true = رابطِ اپ فارسی است (برای BubbleService و MagnifierService مشترک). */
    static boolean uiLangIsFa(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        String ui = sp.getString("uiLang", null);
        if (ui == null || ui.isEmpty()) ui = sp.getString("target", "fa");
        return "fa".equals(ui);
    }

    /** زبانِ رابطِ اپ (fa / en / es / de / fr / ar) را از وب‌اپ می‌گیرد و ذخیره می‌کند. */
    public static void saveUiLang(Context ctx, String lang) {
        if (lang == null) return;
        String l = lang.trim().toLowerCase(java.util.Locale.ROOT);
        // fa / en / es / de / fr / ar — همه‌ی زبان‌های رابطِ اپ (قبلاً فقط fa و en ذخیره می‌شد)
        if (!l.equals("fa") && !l.equals("en") && !l.equals("es") && !l.equals("de")
                && !l.equals("fr") && !l.equals("ar")) return;
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("uiLang", l).apply();
    }

    private void addBubbleIfNeeded() {
        if (bubble != null) return;
        if (!Settings.canDrawOverlays(this)) { shutdown(); return; }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubbleSize = dp(60);

        bubble = new BubbleView(this);
        bubble.setContentDescription("LingoLearn");

        bubbleLp = new WindowManager.LayoutParams(
                bubbleSize, bubbleSize,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS      // ← لازم برای اینکه نیمی از حباب بیرون از صفحه برود
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenW() - bubbleSize - dp(8);
        bubbleLp.y = dp(200);

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        final long longMs = ViewConfiguration.getLongPressTimeout();

        // لمس = شروع/توقفِ ضبط ، نگه‌داشتن = تاریخچه ، ✕ روی حباب = بستنِ کامل ،
        // کشیدنِ حباب روی دایره‌ی ✕ پایینِ صفحه (مثل مسنجر) = بستنِ کامل ، لمسِ حبابِ نیمه‌پنهان فقط آن را بیرون می‌آورد.
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean longDone = false, onBadge = false;
            final Runnable longRun = new Runnable() {
                @Override public void run() {
                    if (dragging || onBadge || bubble == null) return;
                    longDone = true;
                    bubble.setPressedLook(false);
                    bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    toggleHistoryFromBubble();
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (bubble == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        main.removeCallbacks(idleDockRun);
                        main.removeCallbacks(longRun);
                        if (dockAnim != null) { dockAnim.cancel(); dockAnim = null; }
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = bubbleLp.x; startY = bubbleLp.y;
                        dragging = false; longDone = false;
                        onBadge = bubble.hitBadge(e.getX(), e.getY());
                        bubble.setPressedLook(true);
                        if (!onBadge) main.postDelayed(longRun, longMs);
                        return true;

                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            dragging = true; onBadge = false;
                            main.removeCallbacks(longRun);
                            bubble.setPressedLook(false);
                            bubble.setDragging(true);
                            showCloseTarget();
                        }
                        if (dragging) {
                            int nx = clamp(Math.round(startX + dx), 0, screenW() - bubbleSize);
                            int ny = clamp(Math.round(startY + dy), minBubbleY(), maxBubbleY());
                            boolean hot = closeView != null
                                    && Math.hypot(nx + bubbleSize / 2f - tgtCx, ny + bubbleSize / 2f - tgtCy) < dp(84);
                            if (hot != overTarget) {
                                overTarget = hot;
                                if (closeView != null) closeView.setHot(hot);
                                bubble.setHot(hot);
                                if (hot) bubble.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                            }
                            if (hot) { nx = tgtCx - bubbleSize / 2; ny = tgtCy - bubbleSize / 2; }   // می‌نشیند روی ✕
                            bubbleLp.x = nx; bubbleLp.y = ny;
                            try { wm.updateViewLayout(bubble, bubbleLp); } catch (Exception ignored) {}
                            panelFree = false;                       // کشیدنِ حباب، کادر را دوباره کنارِ حباب می‌آورد
                            movePanel();
                        }
                        return true;
                    }

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        main.removeCallbacks(longRun);
                        bubble.setPressedLook(false);
                        boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                        if (dragging) {
                            dragging = false;
                            bubble.setDragging(false);
                            if (up && overTarget) { closeBubbleAnimated(); return true; }
                            hideCloseTarget();
                            bubble.setHot(false);
                            dockBubble(recording);                   // مغناطیس: بعد از رها کردن به نزدیک‌ترین لبه می‌چسبد
                        } else if (up && !longDone) {
                            if (onBadge) {
                                if (bubble.hitBadge(e.getX(), e.getY())) {
                                    bubble.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                                    shutdown();
                                    return true;
                                }
                            } else {
                                bubble.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                                // حبابِ نیمه‌پنهان در حالِ ضبط هم با «یک» لمس ضبط را قطع می‌کند (قبلاً چند لمس لازم بود و حباب دوباره جمع می‌شد)؛
                                // فقط وقتی ضبط خاموش است لمسِ اول حباب را بیرون می‌آورد تا ضبطِ ناخواسته شروع نشود.
                                if (bubble.collapseAmount() > 0.5f && !recording) dockBubble(false);
                                else toggleRecording();
                            }
                        }
                        scheduleIdleDock();                          // چند ثانیه بی‌کاری → نیمه‌پنهان کنار لبه
                        return true;
                    }
                }
                return true;
            }
        });

        try { wm.addView(bubble, bubbleLp); }
        catch (Exception e) { Log.e(TAG, "addView failed", e); shutdown(); }
        scheduleIdleDock();
    }

    private void toggleHistoryFromBubble() {
        if (panelShown) { idleHidden = false; userHidden = true; removePanel(); return; }
        idleHidden = false;
        userHidden = false;
        lastActiveMs = SystemClock.elapsedRealtime();
        idlePinned = !somethingPlaying(lastActiveMs);   // در سکوت باز شد → تا وقتی خودت نبندی (▾ یا لمسِ حباب) می‌مونه تا بخونی
        if (history.isEmpty()) {
            showNotice(msg("لمس: شروع/توقف ضبط  ·  نگه‌داشتن: تاریخچه  ·  ✕ یا کشیدن به پایین: بستن",
                    "Tap: start/stop  ·  Hold: history  ·  ✕ or drag down: close"));
        } else showPanel();
    }

    /** حباب زیرِ نوارِ وضعیت و بالای نوارِ ناوبری می‌ماند تا هیچ‌وقت در گوشه‌ی بالا گیر نکند و لمس‌ناپذیر نشود. */
    private int minBubbleY() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int h = id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
        return h + dp(6);
    }

    private int maxBubbleY() { return Math.max(minBubbleY(), screenH() - bubbleSize - dp(64)); }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private ValueAnimator dockAnim;
    private final Runnable idleDockRun = () -> { if (!dragging) dockBubble(true); };

    /** چند ثانیه بعد از آخرین لمس، حباب خودش کنار لبه جمع می‌شود (کم‌رنگ‌تر و نیمه‌پنهان) تا مزاحمِ محتوا نباشد. */
    private void scheduleIdleDock() {
        main.removeCallbacks(idleDockRun);
        main.postDelayed(idleDockRun, 3500);
    }

    /** حباب را به نزدیک‌ترین لبه‌ی چپ/راست می‌چسباند؛ collapse=true یعنی نیمی از آن بیرون از صفحه می‌رود (آیکون در نیمه‌ی دیدنی می‌ماند). */
    private void dockBubble(final boolean collapse) {
        if (wm == null || bubble == null || bubbleLp == null) return;
        if (dockAnim != null) { dockAnim.cancel(); dockAnim = null; }
        final int hide = collapse ? Math.round(bubbleSize * 0.5f) : 0;
        final boolean left = bubbleLp.x + bubbleSize / 2 < screenW() / 2;
        final int side = left ? -1 : 1;
        final int target = left ? -hide : screenW() - bubbleSize + hide;
        final int from = bubbleLp.x;
        final int fromY = bubbleLp.y, toY = clamp(bubbleLp.y, minBubbleY(), maxBubbleY());
        final float c0 = bubble.collapseAmount(), c1 = collapse ? 1f : 0f;
        dockAnim = ValueAnimator.ofFloat(0f, 1f);
        dockAnim.setDuration(240);
        dockAnim.setInterpolator(new android.view.animation.DecelerateInterpolator());
        dockAnim.addUpdateListener(a -> {
            if (wm == null || bubble == null) return;
            float t = (Float) a.getAnimatedValue();
            bubbleLp.x = Math.round(from + (target - from) * t);
            bubbleLp.y = Math.round(fromY + (toY - fromY) * t);
            bubble.setDock(side, c0 + (c1 - c0) * t);
            try { wm.updateViewLayout(bubble, bubbleLp); } catch (Exception ignored) {}
            movePanel();
        });
        dockAnim.start();
    }

    // ── دایره‌ی ✕ پایینِ صفحه: فقط هنگامِ کشیدنِ حباب دیده می‌شود (مثل مسنجر) ──
    private CloseTargetView closeView;
    private WindowManager.LayoutParams closeLp;
    private boolean overTarget = false;
    private int tgtCx, tgtCy;

    private void showCloseTarget() {
        if (wm == null || closeView != null) return;
        int sz = dp(84);
        closeView = new CloseTargetView(this);
        closeLp = new WindowManager.LayoutParams(
                sz, sz,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        closeLp.gravity = Gravity.TOP | Gravity.START;
        tgtCx = screenW() / 2;
        tgtCy = screenH() - dp(120);
        closeLp.x = tgtCx - sz / 2;
        closeLp.y = tgtCy - sz / 2;
        closeView.setAlpha(0f); closeView.setScaleX(0.6f); closeView.setScaleY(0.6f);
        try {
            wm.addView(closeView, closeLp);
            closeView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start();
        } catch (Exception ex) { closeView = null; }
    }

    private void hideCloseTarget() {
        overTarget = false;
        final CloseTargetView v = closeView;
        closeView = null;
        if (v == null || wm == null) return;
        v.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(120)
                .withEndAction(() -> { try { wm.removeView(v); } catch (Exception ignored) {} }).start();
    }

    private void removeCloseTargetNow() {
        overTarget = false;
        CloseTargetView v = closeView;
        closeView = null;
        if (v != null && wm != null) { try { wm.removeView(v); } catch (Exception ignored) {} }
    }

    /** رها کردنِ حباب روی ✕: کوچک و محو می‌شود و سرویس کاملاً بسته می‌شود. */
    private void closeBubbleAnimated() {
        final BubbleView b = bubble;
        hideCloseTarget();
        if (b == null) { shutdown(); return; }
        b.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(150)
                .withEndAction(this::shutdown).start();
    }

    /** دایره‌ی تیره‌ی ✕؛ وقتی حباب نزدیک می‌شود بزرگ و قرمز می‌شود. */
    private static final class CloseTargetView extends View {
        private final float d;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.animation.ArgbEvaluator argb = new android.animation.ArgbEvaluator();
        private float hot = 0f;
        private ValueAnimator hotAnim;

        CloseTargetView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(1.5f * d);
            ring.setColor(0xE6FFFFFF);
            cross.setStyle(Paint.Style.STROKE);
            cross.setStrokeCap(Paint.Cap.ROUND);
            cross.setStrokeWidth(2.4f * d);
            cross.setColor(Color.WHITE);
        }

        void setHot(boolean h) {
            if (hotAnim != null) hotAnim.cancel();
            hotAnim = ValueAnimator.ofFloat(hot, h ? 1f : 0f);
            hotAnim.setDuration(140);
            hotAnim.addUpdateListener(a -> { hot = (Float) a.getAnimatedValue(); invalidate(); });
            hotAnim.start();
        }

        @Override protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (hotAnim != null) { hotAnim.cancel(); hotAnim = null; }
        }

        @Override protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float sc = 1f + 0.22f * hot;
            cv.save();
            cv.scale(sc, sc, cx, cy);
            fill.setColor((Integer) argb.evaluate(hot, 0xE61C2541, COLOR_REC));
            fill.setShadowLayer(8f * d, 0f, 2f * d, 0x66000000);
            cv.drawCircle(cx, cy, 26f * d, fill);
            cv.drawCircle(cx, cy, 25f * d, ring);
            float k = 7.5f * d;
            cv.drawLine(cx - k, cy - k, cx + k, cy + k, cross);
            cv.drawLine(cx - k, cy + k, cx + k, cy - k, cross);
            cv.restore();
        }
    }

    /** حبابِ طراحی‌شده: دایره‌ی گرادیانی + حلقه‌ی طلایی + میکروفونِ برداری؛ هنگامِ ضبط حلقه‌ی قرمز + موجِ تپنده.
     *  حالتِ آرام: کم‌رنگ و نیمه‌پنهان کنارِ لبه. نشانِ ✕ (بستنِ کامل) فقط وقتی حباب بیرون است دیده می‌شود. */
    private static final class BubbleView extends View {
        private final float d;
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeX = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private boolean rec = false, dragMode = false;
        private int side = 1;
        private float collapse = 0f, ripple = 0f, press = 0f, hot = 0f;
        private ValueAnimator rippleAnim, pressAnim, hotAnim;

        BubbleView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setLayerType(LAYER_TYPE_SOFTWARE, null);      // سایه‌ی نرم روی API پایین هم کار کند
            ring.setStyle(Paint.Style.STROKE);
            wave.setStyle(Paint.Style.STROKE);
            wave.setStrokeWidth(2f * d);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setColor(Color.WHITE);
            fill.setColor(Color.WHITE);
            shine.setStyle(Paint.Style.STROKE);
            shine.setStrokeCap(Paint.Cap.ROUND);
            shine.setStrokeWidth(1.4f * d);
            shine.setColor(0x38FFFFFF);
            badge.setColor(0xF2FFFFFF);
            badgeX.setStyle(Paint.Style.STROKE);
            badgeX.setStrokeCap(Paint.Cap.ROUND);
            badgeX.setStrokeWidth(1.7f * d);
            badgeX.setColor(0xFF1C2541);
        }

        float collapseAmount() { return collapse; }

        void setDock(int s, float c) { side = s; collapse = c; applyAlpha(); invalidate(); }

        void setDragging(boolean g) { dragMode = g; invalidate(); }

        void setPressedLook(boolean p) {
            if (pressAnim != null) pressAnim.cancel();
            pressAnim = ValueAnimator.ofFloat(press, p ? 1f : 0f);
            pressAnim.setDuration(p ? 90 : 170);
            pressAnim.addUpdateListener(a -> { press = (Float) a.getAnimatedValue(); invalidate(); });
            pressAnim.start();
        }

        void setHot(boolean h) {
            if (hotAnim != null) hotAnim.cancel();
            hotAnim = ValueAnimator.ofFloat(hot, h ? 1f : 0f);
            hotAnim.setDuration(140);
            hotAnim.addUpdateListener(a -> { hot = (Float) a.getAnimatedValue(); invalidate(); });
            hotAnim.start();
        }

        void setRecording(boolean r) {
            if (rec == r) return;
            rec = r;
            if (rippleAnim != null) { rippleAnim.cancel(); rippleAnim = null; }
            ripple = 0f;
            if (r) {
                rippleAnim = ValueAnimator.ofFloat(0f, 1f);
                rippleAnim.setDuration(1600);
                rippleAnim.setRepeatCount(ValueAnimator.INFINITE);
                rippleAnim.addUpdateListener(a -> { ripple = (Float) a.getAnimatedValue(); invalidate(); });
                rippleAnim.start();
            }
            applyAlpha();
            invalidate();
        }

        private void applyAlpha() { setAlpha(rec ? 1f : 1f - 0.38f * collapse); }

        private float discR() { return Math.min(getWidth(), getHeight()) / 2f - 8f * d; }

        private float badgeAlpha() { return 0f; }   // ✕ روی حباب حذف شد؛ بستن: نگه‌داشتنِ کادر و رها کردن روی ✕ پایین، یا کشیدنِ حباب روی ✕، یا اعلان

        private float badgeCx() { return getWidth() / 2f - side * discR() * 0.80f; }

        private float badgeCy() { return getHeight() / 2f - discR() * 0.80f; }

        /** آیا لمس روی نشانِ ✕ است؟ (ناحیه‌ی لمس کمی بزرگ‌تر از ظاهرِ آن) */
        boolean hitBadge(float x, float y) {
            if (badgeAlpha() < 0.5f) return false;
            float dx = x - badgeCx(), dy = y - badgeCy();
            return dx * dx + dy * dy <= (16f * d) * (16f * d);
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float r = discR();
            body.setShader(new LinearGradient(w / 2f, h / 2f - r, w / 2f, h / 2f + r, 0xFF34498A, 0xFF121A33, Shader.TileMode.CLAMP));
        }

        @Override protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (rippleAnim != null) { rippleAnim.cancel(); rippleAnim = null; }
            if (pressAnim != null) { pressAnim.cancel(); pressAnim = null; }
            if (hotAnim != null) { hotAnim.cancel(); hotAnim = null; }
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = discR();                                // ۸dp حاشیه برای سایه، موج و نشانِ ✕
            int accent = rec ? COLOR_REC : COLOR_GOLD;

            if (rec) {                                        // موجِ تپنده‌ی ضبط
                float rr = r + (Math.min(w, h) / 2f - 1f * d - r) * ripple;
                wave.setColor(COLOR_REC);
                wave.setAlpha((int) (140 * (1f - ripple)));
                cv.drawCircle(cx, cy, rr, wave);
            }

            float sc = (1f - 0.07f * press) * (1f - 0.22f * hot);
            cv.save();
            cv.scale(sc, sc, cx, cy);

            body.setShadowLayer(6f * d, 0f, 2f * d, 0x66000000);
            cv.drawCircle(cx, cy, r, body);

            ring.setColor(accent);
            ring.setStrokeWidth((rec ? 2.4f : 1.6f) * d);
            cv.drawCircle(cx, cy, r - 1f * d, ring);

            rf.set(cx - r + 3.5f * d, cy - r + 3.5f * d, cx + r - 3.5f * d, cy + r - 3.5f * d);
            cv.drawArc(rf, 205f, 130f, false, shine);         // درخشِ ظریفِ نیمه‌ی بالا

            // آیکونِ میکروفون؛ هنگامِ جمع‌شدن به سمتِ نیمه‌ی دیدنی می‌رود. در حالِ ضبط به‌جای آن «■ توقف» نشان داده می‌شود.
            float ix = cx - side * collapse * (w * 0.22f);
            float k = 0.85f * d;
            if (rec) {
                rf.set(ix - 7f * k, cy - 7f * k, ix + 7f * k, cy + 7f * k);
                cv.drawRoundRect(rf, 3f * k, 3f * k, fill);
            } else {
                rf.set(ix - 4.2f * k, cy - 11f * k, ix + 4.2f * k, cy + 2f * k);
                cv.drawRoundRect(rf, 4.2f * k, 4.2f * k, fill);
                line.setStrokeWidth(1.9f * k);
                rf.set(ix - 8f * k, cy - 8f * k, ix + 8f * k, cy + 7f * k);
                cv.drawArc(rf, 0f, 180f, false, line);
                cv.drawLine(ix, cy + 7f * k, ix, cy + 11f * k, line);
                cv.drawLine(ix - 4f * k, cy + 11f * k, ix + 4f * k, cy + 11f * k, line);
            }

            if (rec) {                                        // نقطه‌ی قرمزِ «در حال ضبط»؛ سمتِ داخلیِ صفحه تا در حالتِ نیمه‌پنهان دیده شود
                float bx = cx - side * r * 0.72f, by = cy + r * 0.72f;
                fill.setColor(Color.WHITE);
                cv.drawCircle(bx, by, 5.2f * d, fill);
                fill.setColor(COLOR_REC);
                cv.drawCircle(bx, by, 3.6f * d, fill);
                fill.setColor(Color.WHITE);
            }
            cv.restore();

            float ba = badgeAlpha();                          // ✕ بستنِ کامل (سمتِ داخلیِ صفحه)
            if (ba > 0.02f) {
                float bx = badgeCx(), by = badgeCy(), br = 8.5f * d;
                badge.setShadowLayer(3f * d, 0f, 1f * d, ((int) (90 * ba) << 24));
                badge.setAlpha((int) (242 * ba));
                cv.drawCircle(bx, by, br, badge);
                badgeX.setAlpha((int) (255 * ba));
                float q = 3.1f * d;
                cv.drawLine(bx - q, by - q, bx + q, by + q, badgeX);
                cv.drawLine(bx - q, by + q, bx + q, by - q, badgeX);
            }
        }
    }


    // ════════════════════════════════════════════════════════════════════════════
    //  Panel: scrollable history of every sentence + one translation line per target language
    // ════════════════════════════════════════════════════════════════════════════

    /** One recognised sentence and its translations (one per target language). */
    private static final class Entry {
        String src = "";
        int shownChars = Integer.MAX_VALUE;   // تایپِ حرف‌به‌حرف: چند حرفِ اول نمایش داده شده (MAX = بدونِ تایپ)
        final long createdAt = System.currentTimeMillis();
        final HashMap<String, String> tr = new HashMap<>();        // lang -> shown text ("…" = pending)
        final HashMap<String, String> trSrc = new HashMap<>();     // lang -> source text that translation was made from
        final HashMap<String, Integer> applied = new HashMap<>();  // lang -> id of the newest request applied (drops stale answers)
        LinearLayout box;
        LinearLayout rowsBox;
        LinearLayout srcRow;            // [🔊][متنِ اصلی]
        TextView tvSrc;
        String srcLang = "en";          // زبانِ واقعیِ متنِ اصلیِ این جمله (برای 🔊 و کادرِ لغت)
        int ytIdx = -1;                 // شماره‌ی خطِ زیرنویسِ یوتیوب (برای چیدنِ مرتب بعد از seek)
        final HashMap<String, LinearLayout> rowBox = new HashMap<>();
        final HashMap<String, TextView> rowText = new HashMap<>();
        // ترجمه‌ی زنده‌ی تکه‌تکه (پایدار): تکه‌های متنِ اصلیِ «قفل‌شده» و ترجمه‌ی هر تکه به‌ازای هر زبان
        final ArrayList<String> chunkSrc = new ArrayList<>();
        final HashMap<String, ArrayList<String>> chunkTr = new HashMap<>();   // lang -> ترجمه‌ی هر تکه ("" = در انتظار)
        int committedWords = 0;
        // ترجمه‌ی زنده‌ی «دنباله‌ی» جمله (کلمه‌هایی که هنوز در تکه‌ی قفل‌شده نیستند) — فوری و کلمه‌به‌کلمه
        final HashMap<String, String> tailTr = new HashMap<>();
        final HashMap<String, Integer> tailTrFrom = new HashMap<>();
        final HashMap<String, String> tailAsked = new HashMap<>();
        final HashMap<String, Boolean> tailBusy = new HashMap<>();
        long tailLastAt = 0;
        boolean tailScheduled = false;
        long mediaPosMs = -1;                                              // موقعیتِ پلیرِ بیرونی (ms) وقتی این جمله شروع شد؛ -1 = نامشخص
        TextView srcSpeakBtn;                                              // 🔊 کنار متن اصلی
        TextView ytReplayBtn;                                              // ↺ پخش دوباره‌ی جمله با صدای پلیر یوتیوب
        long aStart = -1;                                                  // 🎙 شروعِ صدای این جمله در بافرِ ضبط (sample)
        short[] pcm;                                                       // 🎙 صدای خودِ گوینده برای ↺ (16kHz mono)
        final HashMap<String, TextView> rowSpeakBtn = new HashMap<>();     // 🔊 کنار ترجمه‌ی هر زبان
    }

    /** ScrollView with a max height that follows new text unless the user scrolled up to read older lines. */
    private static final class HistoryScroll extends ScrollView {
        int maxHeightPx = Integer.MAX_VALUE;
        boolean atBottom = true;
        boolean frozen = false;      // وقتی کاربر دارد متن انتخاب می‌کند / کادرِ لغت باز است، خودکار به پایین نپر
        boolean ytMode = false;      // 📺 لیستِ کاملِ زیرنویس: به‌جای پرش به انتها، خودِ برنامه خطِ جاری را اسکرول می‌کند
        long lastUserTouch = 0;      // آخرین لمسِ کاربر (تا وسطِ خواندن اسکرولش را نپرانیم)

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_UP) {
                lastUserTouch = SystemClock.uptimeMillis();
            }
            return super.dispatchTouchEvent(ev);
        }

        HistoryScroll(Context c) { super(c); }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            super.onLayout(changed, l, t, r, b);
            if (atBottom && !frozen && !ytMode) {
                View c = getChildAt(0);
                if (c != null) scrollTo(0, Math.max(0, c.getHeight() - getHeight()));
            }
        }

        @Override
        protected void onScrollChanged(int l, int t, int oldl, int oldt) {
            super.onScrollChanged(l, t, oldl, oldt);
            View c = getChildAt(0);
            if (c != null) atBottom = c.getHeight() - (getHeight() + getScrollY()) < 60;
        }
    }

    // ---------- 🎙 shadowing: ضبطِ صدای کاربر و پخشِ دوباره ----------
    private TextView tvShadowRec, tvShadowPlay;
    private boolean shadowRecording = false;
    private long shadowStartMs = 0;
    private String shadowPath = null;
    private MediaPlayer shadowPlayer;

    private void updateShadowUi() {
        if (tvShadowRec != null) {
            tvShadowRec.setText(shadowRecording ? "\u23F9" : "\uD83C\uDF99");
            tvShadowRec.setTextColor(shadowRecording ? Color.parseColor("#FF5A5F") : Color.WHITE);
        }
        if (tvShadowPlay != null) {
            tvShadowPlay.setVisibility(!shadowRecording && shadowPath != null ? View.VISIBLE : View.GONE);
        }
    }

    private void shadowToggle() {
        if (shadowRecording) {
            shadowRecording = false;
            updateShadowUi();
            ShadowRecordActivity.stopIfRunning();
            return;
        }
        shadowStopPlayback();
        try {
            Intent i = new Intent(this, ShadowRecordActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
            shadowRecording = true;
            shadowStartMs = SystemClock.elapsedRealtime();
            shadowPath = null;
            updateShadowUi();
            lastActiveMs = SystemClock.elapsedRealtime();
        } catch (Exception e) {
            Log.w(TAG, "shadow record start failed", e);
            shadowRecording = false;
            updateShadowUi();
            showNotice(msg("⚠ ضبط شروع نشد", "⚠ Could not start recording"));
        }
    }

    /** ضبطِ shadowing: اگر «اجازه‌ی ضبطِ صدای سیستم» قبلاً داده شده، صدای در حالِ پخشِ گوشی هم با ولومِ کم مخلوط می‌شود. */
    static MediaProjection shadowProjection() {
        return ProjectionHolder.current();
    }

    static void shadowDone(final String path) {
        final BubbleService s = instance;
        if (s == null) return;
        s.uiHandlerPost(() -> {
            s.shadowRecording = false;
            s.shadowPath = path;
            s.lastActiveMs = SystemClock.elapsedRealtime();
            s.updateShadowUi();
            if (path != null) s.shadowPlay();
        });
    }

    static void shadowFailed(final int kind) {
        final BubbleService s = instance;
        if (s == null) return;
        s.uiHandlerPost(() -> {
            s.shadowRecording = false;
            s.updateShadowUi();
            s.showNotice(kind == 2
                    ? s.msg("⚠ مجوز میکروفون لازم است", "⚠ Microphone permission required")
                    : s.msg("⚠ ضبط انجام نشد", "⚠ Recording failed"));
        });
    }

    private void uiHandlerPost(Runnable r) {
        new Handler(Looper.getMainLooper()).post(r);
    }

    private void shadowPlay() {
        if (shadowPath == null) return;
        shadowStopPlayback();
        try {
            final MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(shadowPath);
            mp.setOnCompletionListener(m -> { try { m.release(); } catch (Exception ignored) {} if (shadowPlayer == m) shadowPlayer = null; lastActiveMs = SystemClock.elapsedRealtime(); });
            mp.setOnErrorListener((m, w, e) -> { try { m.release(); } catch (Exception ignored) {} if (shadowPlayer == m) shadowPlayer = null; return true; });
            mp.prepare();
            mp.start();
            shadowPlayer = mp;
            lastActiveMs = SystemClock.elapsedRealtime();
        } catch (Exception e) {
            Log.w(TAG, "shadow play failed", e);
            shadowPlayer = null;
        }
    }

    private void shadowStopPlayback() {
        MediaPlayer mp = shadowPlayer; shadowPlayer = null;
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
        }
    }

    private void ensurePanel() {
        if (panel != null) return;
        loadViewPrefs();
        gripExtras.clear();
        panel = new LinearLayout(this) {
            @Override public boolean dispatchTouchEvent(MotionEvent ev) {
                lastPanelTouchMs = SystemClock.elapsedRealtime();       // هر لمسِ کادر، شمارشِ جمع‌شدنِ کنترل‌ها را از نو می‌کند
                return super.dispatchTouchEvent(ev);
            }
        };
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(12), dp(10));
        panel.setClipToPadding(false);                // نوارِ هاشور تا لبه‌ها (بیرون از padding) کشیده می‌شود
        panel.setClipToOutline(true);                 // و گوشه‌های گردِ کادر آن را می‌برد
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#F01C2541"));
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1), Color.parseColor("#40FFFFFF"));
        panel.setBackground(bg);
        panelBgDrawable = bg;
        applyPanelAlpha();

        gripTop = makeGrip(false);
        LinearLayout.LayoutParams gtLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30));
        gtLp.setMargins(-dp(12), -dp(6), -dp(12), dp(4));
        panel.addView(gripTop, gtLp);

        // header: title + languages, clear-history, close
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        header.addView(buildModeSwitch(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // 🌐 «→ ES / FA ▾» = دکمه‌ی انتخابِ زبانِ ترجمه (بزن → ردیفِ زبان‌ها باز می‌شود). فضای خالیِ کنارش همچنان برای کشیدنِ کادر است.
        tvHeader = new TextView(this);
        tvHeader.setTextColor(COLOR_GOLD);
        style(tvHeader, 11, true);
        tvHeader.setSingleLine(true);
        tvHeader.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        tvHeader.setGravity(Gravity.CENTER);
        tvHeader.setPadding(dp(4), dp(8), dp(10), dp(8));
        tvHeader.setContentDescription(msg("زبان‌های ترجمه — برای تغییر بزنید", "Translation languages — tap to change"));
        tvHeader.setOnClickListener(v -> toggleLangRow());
        paintLangPill(false);
        LinearLayout langWrap = new LinearLayout(this);
        langWrap.setOrientation(LinearLayout.HORIZONTAL);
        langWrap.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        langWrap.setGravity(Gravity.CENTER_VERTICAL);
        langWrap.addView(tvHeader, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        wrapLp.setMarginStart(dp(6));
        header.addView(langWrap, wrapLp);
        tvYtRestart = headerButton("\u23EE", v -> restartYoutubeFromStart());   // ⏮ فقط در حالتِ یوتیوب دیده می‌شود
        tvYtRestart.setPadding(dp(8), dp(6), dp(8), dp(6));
        tvYtRestart.setContentDescription(msg("پخشِ ویدیو از اول", "Restart video from the beginning"));
        tvYtRestart.setVisibility(View.GONE);
        tvYtLoop = headerButton("\uD83C\uDFAC\uD83D\uDD01", v -> toggleYoutubeVideoLoop());   // 🎬🔁 تکرارِ کلِ ویدیو؛ فقط در حالتِ یوتیوب
        tvYtLoop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvYtLoop.setPadding(dp(8), dp(6), dp(8), dp(6));
        tvYtLoop.setContentDescription(msg("تکرارِ بی‌نهایتِ کلِ ویدیو", "Loop the whole video"));
        tvYtLoop.setVisibility(View.GONE);
        tvYtPause = headerButton("\u23F8", v -> toggleYoutubePause());   // ⏸ = در حالِ پخش (بزن: مکث) | ▶ = مکث شده (بزن: پخش)   // ⏯ فقط در حالتِ یوتیوب دیده می‌شود
        tvYtPause.setPadding(dp(8), dp(6), dp(8), dp(6));
        tvYtPause.setVisibility(View.GONE);
        tvYtAll = headerButton("\uD83D\uDD02", v -> toggleFullText());   // 🔂 فقط در حالتِ «متنِ کامل»
        tvYtAll.setPadding(dp(8), dp(6), dp(8), dp(6));
        tvYtAll.setVisibility(View.GONE);
        header.addView(tvYtAll);
        tvSave = headerButton("\uD83D\uDCBE", v -> saveCurrent());
        loadRepeatPref();
        tvRepeat = headerButton("\u21BA", v -> cycleRepeat());
        tvRepeat.setContentDescription(msg("تکرارِ هر جمله (خاموش / ۲ / ۳ / ∞)", "Repeat each sentence (off / 2 / 3 / ∞)"));
        tvRepeat.setPadding(dp(8), dp(6), dp(8), dp(6));
        updateRepeatButton();
        updateYtButton();
        TextView tvSpeed = headerButton("\u23E9", v -> toggleSpeedRow());   // ⏩ سرعتِ پخشِ ویدیو/صدای برنامه‌ی دیگر (MediaSession؛ بدونِ Accessibility)
        tvSpeed.setPadding(dp(8), dp(6), dp(8), dp(6));
        tvSpeed.setVisibility(View.GONE);   // 🙈 دکمه‌ی سرعت فعلاً مخفی است (کدِ سرعت دست‌نخورده مانده؛ برای نمایش، GONE را VISIBLE کنید)
        header.addView(tvSpeed);
        TextView tvOpacity = headerButton("\uD83C\uDF13", v -> toggleOpacityRow());
        tvOpacity.setPadding(dp(8), dp(6), dp(8), dp(6));
        header.addView(tvOpacity);
        ChevronButton minimize = new ChevronButton(this);   // ⌄ = فقط کادرِ تاریخچه را پنهان می‌کند (بستنِ حباب: ✕ روی خودِ حباب)
        minimize.setContentDescription(msg("کوچک‌کردنِ کادر", "Minimize panel"));
        minimize.setOnClickListener(v -> { idleHidden = false; userHidden = true; removePanel(); });
        LinearLayout.LayoutParams minLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        minLp.setMarginStart(dp(4));
        header.addView(minimize, minLp);
        header.setOnTouchListener(new PanelMover());      // کشیدنِ سربرگ = جابه‌جایی؛ نگه‌داشتن = برداشتنِ کادر + ✕ پایینِ صفحه
        headerView = header;
        panel.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(buildLangRow(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        opacityRow = new LinearLayout(this);
        opacityRow.setOrientation(LinearLayout.HORIZONTAL);
        opacityRow.setGravity(Gravity.CENTER_VERTICAL);
        opacityRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        opacityRow.setVisibility(View.GONE);
        opacityBar = new SeekBar(this);
        opacityBar.setMax(100);
        opacityBar.setProgress(Math.round(panelAlpha * 100f));
        opacityBar.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_GOLD));
        opacityBar.setThumbTintList(android.content.res.ColorStateList.valueOf(COLOR_GOLD));
        final TextView opacityPct = new TextView(this);
        opacityPct.setTextColor(Color.WHITE);
        opacityPct.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        opacityPct.setMinWidth(dp(44));
        opacityPct.setGravity(Gravity.CENTER);
        opacityPct.setText(Math.round(panelAlpha * 100f) + "%");
        opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                panelAlpha = progress / 100f;
                opacityPct.setText(progress + "%");
                applyPanelAlpha();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) { saveViewPrefs(); }
        });
        opacityRow.addView(opacityBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        opacityRow.addView(opacityPct, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(opacityRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(buildSpeedRow(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(buildFontRow(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        buildWordCard();
        panel.addView(wordCard);   // LayoutParams (با margin) داخلِ buildWordCard ست شده

        scroll = new HistoryScroll(this);
        scroll.maxHeightPx = panelMaxH();
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setVerticalScrollBarEnabled(false);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tvStatus = new TextView(this);
        tvStatus.setTextColor(Color.parseColor("#C8CCD8"));
        styleC(tvStatus, 13, false);
        tvStatus.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        tvStatus.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        tvStatus.setPadding(0, dp(4), 0, 0);
        tvStatus.setVisibility(View.GONE);
        panel.addView(tvStatus);

        gripBottom = makeGrip(true);       // نوارِ هاشور: پایینِ همه‌چیز (بعد از ردیفِ دکمه‌ها) اضافه می‌شود

        // 📌 دکمه‌ی «باز بمان» — پایین-راستِ کادر
        loadKeepOpen();
        LinearLayout pinRow = new LinearLayout(this);
        pinRow.setOrientation(LinearLayout.HORIZONTAL);
        pinRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pinRow.setGravity(Gravity.CENTER_VERTICAL);
        tvFontBtn = buildFontButton();
        pinRow.addView(tvFontBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // دکمه‌های ⏮ ∞ ⏯ 🔁 💾 از هدر آمدند پایین، بعد از دکمه‌ی فونت (paddingِ کمتر تا همه جا شوند)
        tvYtRestart.setPadding(dp(5), dp(4), dp(5), dp(4));
        tvYtLoop.setPadding(dp(5), dp(4), dp(5), dp(4));
        tvYtPause.setPadding(dp(5), dp(4), dp(5), dp(4));
        tvRepeat.setPadding(dp(5), dp(4), dp(5), dp(4));
        tvSave.setPadding(dp(5), dp(4), dp(5), dp(4));
        pinRow.addView(tvYtRestart);
        pinRow.addView(tvYtLoop);
        pinRow.addView(tvYtPause);
        pinRow.addView(tvRepeat);
        pinRow.addView(tvSave);
        pinRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        tvPin = new IconText(this);
        tvPin.setText("\uD83D\uDCCC");
        tvPin.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvPin.setGravity(Gravity.CENTER);
        tvPin.setPadding(dp(8), dp(3), dp(8), dp(3));
        tvPin.setOnClickListener(v -> toggleKeepOpen());
        updatePinUi();
        LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pinLp.topMargin = dp(2);
        TextView tvClear = new IconText(this);                      // 🗑 پاک‌کردنِ تاریخچه (از هدر آمد پایین تا هدر تنگ نشود)
        tvClear.setText("\uD83D\uDDD1");
        tvClear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvClear.setTextColor(Color.WHITE);
        tvClear.setGravity(Gravity.CENTER);
        tvClear.setPadding(dp(8), dp(3), dp(8), dp(3));
        tvClear.setAlpha(0.8f);
        tvClear.setContentDescription(msg("پاک‌کردنِ تاریخچه", "Clear history"));
        tvClear.setOnClickListener(v -> clearHistory());
        LinearLayout.LayoutParams clrLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clrLp.topMargin = dp(2);
        pinRow.addView(tvClear, clrLp);
        pinRow.addView(tvPin, pinLp);
        pinRowView = pinRow;
        panel.addView(pinRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams gbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30));
        gbLp.setMargins(-dp(12), dp(4), -dp(12), -dp(10));
        panel.addView(gripBottom, gbLp);

        // touchable (history scrolls, buttons work) but touches outside the panel still reach the app below
        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        // وقتی چیزی در حالِ پخش نیست، لمسِ بیرونِ کادر آن را (نرم) می‌بندد؛ متن می‌ماند و با پخشِ بعدی دوباره باز می‌شود.
        // لمس همچنان به برنامه‌ی زیرین می‌رسد (ما آن را نمی‌بلعیم).
        // لمس روی جاهای خالیِ کادر (حاشیه‌ها، فاصله‌ها) هم مثلِ سربرگ کادر را جابه‌جا می‌کند.
        final PanelMover panelMover = new PanelMover();
        panel.setOnTouchListener((v, ev) -> {
            if (ev.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                boolean cardOpen = wordCard != null && wordCard.getVisibility() == View.VISIBLE;
                if (!cardOpen && !keepOpen && !panelDragging && panelShown && !fadingOut && !somethingPlaying(SystemClock.elapsedRealtime())) {
                    main.post(this::fadeOutPanelForIdle);
                }
                return false;
            }
            return panelMover.onTouch(v, ev);
        });
    }

    // ───────── کلیدِ حالت: [ ● LIVE | ▶ YT ] ─────────
    private TextView tvModeLive, tvModeYt, tvFontBtn;

    private TextView modeSegment(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.04f);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(5), dp(10), dp(5));
        return t;
    }

    private View buildModeSwitch() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#26FFFFFF"));
        bg.setCornerRadius(dp(15));
        box.setBackground(bg);
        box.setPadding(dp(2), dp(2), dp(2), dp(2));

        tvModeLive = modeSegment("\u25CF LIVE");
        tvModeLive.setContentDescription(msg("ترجمه‌ی زنده", "Live translation"));
        tvModeLive.setOnClickListener(v -> {
            if (yt != null && yt.isActive()) {
                stopYoutube(true);                  // از یوتیوب به زنده: یوتیوب بسته و ترجمه‌ی زنده شروع می‌شود
                if (!recording) toggleRecording();
            } else {
                toggleRecording();                  // شروع/توقفِ ترجمه‌ی زنده
            }
        });
        box.addView(tvModeLive);

        tvModeYt = modeSegment("\u25B6 YT");
        tvModeYt.setContentDescription(msg("زیرنویس یوتیوب", "YouTube subtitles"));
        tvModeYt.setOnClickListener(v -> toggleYoutube());
        tvModeYt.setOnLongClickListener(v -> { askYoutubeAccessChoice(); return true; });   // نگه‌داشتن = «همگام» یا «فقط متنِ کامل»
        box.addView(tvModeYt);
        tvYt = tvModeYt;
        updateModeSwitch();
        return box;
    }

    private void paintSegment(TextView t, boolean active) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(13));
        g.setColor(active ? COLOR_GOLD : Color.TRANSPARENT);
        t.setBackground(g);
        t.setTextColor(active ? Color.parseColor("#1C2541") : Color.parseColor("#B3FFFFFF"));
    }

    private void updateModeSwitch() {
        if (tvModeLive == null || tvModeYt == null) return;
        boolean ytOn = yt != null && yt.isActive();
        paintSegment(tvModeLive, !ytOn);
        paintSegment(tvModeYt, ytOn);
        // نقطه‌ی LIVE: قرمز وقتی واقعاً در حالِ ضبط/ترجمه است
        SpannableString sp = new SpannableString("\u25CF LIVE");
        int dot = recording ? Color.parseColor("#FF4D4F") : (ytOn ? Color.parseColor("#66FFFFFF") : Color.parseColor("#661C2541"));
        sp.setSpan(new android.text.style.ForegroundColorSpan(dot), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvModeLive.setText(sp);
    }

    // ───────── دکمه‌ی کوچک‌کردن: دایره + شورونِ رسم‌شده (بدونِ emoji؛ در همه‌ی گوشی‌ها یکسان) ─────────
    private final class ChevronButton extends View {
        private final Paint bgP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        ChevronButton(Context c) {
            super(c);
            setClickable(true);
            icP.setStyle(Paint.Style.STROKE);
            icP.setStrokeWidth(dp(2));
            icP.setStrokeCap(Paint.Cap.ROUND);
            icP.setStrokeJoin(Paint.Join.ROUND);
            icP.setColor(Color.WHITE);
        }

        @Override protected void drawableStateChanged() { super.drawableStateChanged(); invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            bgP.setColor(isPressed() ? Color.parseColor("#59FFFFFF") : Color.parseColor("#26FFFFFF"));
            cv.drawCircle(cx, cy, Math.min(cx, cy) - dp(1), bgP);
            float w = dp(5), h = dp(2.5f);
            path.reset();
            path.moveTo(cx - w, cy - h);
            path.lineTo(cx, cy + h);
            path.lineTo(cx + w, cy - h);
            cv.drawPath(path, icP);
        }
    }

    // ───────── آیکون‌های خطیِ برداری (Outline) — جایگزینِ ایموجی‌ها ─────────
    // همه با یک ضخامتِ خط و یک اندازه کشیده می‌شوند؛ رنگ = رنگِ متنِ همان View (سفید / طلایی).
    // کدِ قبلی همچنان setText("<کدِ ایموجی>") صدا می‌زند؛ اینجا همان کد به آیکونِ برداری نگاشت می‌شود.
    private static final float ICON_STROKE_DP = 1.7f;

    private final class IconText extends TextView {
        private static final int I_RESTART = 1, I_VLOOP = 2, I_PAUSE = 3, I_PLAY = 4, I_LOOP1 = 5, I_STOP = 6,
                I_SAVE = 7, I_REPLAY = 8, I_FF = 9, I_DROP = 10, I_PIN = 11, I_TRASH = 12, I_MIC = 13,
                I_SPEAKER = 14, I_DOC = 15, I_CLOSE = 16;
        private int icon;
        private String suffix;
        private float iconDp = 18f;
        private final Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path p = new Path();
        private final RectF r = new RectF();

        IconText(Context c) {
            super(c);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.ROUND);
            sp.setStrokeJoin(Paint.Join.ROUND);
            tp.setStyle(Paint.Style.FILL);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void setIconDp(float v) { iconDp = v; requestLayout(); invalidate(); }

        @Override public void setText(CharSequence t, BufferType type) {
            String k = t == null ? "" : t.toString();
            suffix = null;
            icon = iconFor(k);
            super.setText(icon != 0 ? "" : t, type);
            invalidate();
        }

        private int iconFor(String k) {
            if (k.startsWith("\u21BA")) { suffix = k.length() > 1 ? k.substring(1) : null; return I_REPLAY; }
            switch (k) {
                case "\u23EE": return I_RESTART;
                case "\uD83C\uDFAC\uD83D\uDD01": return I_VLOOP;
                case "\u23F8": return I_PAUSE;
                case "\u25B6": return I_PLAY;
                case "\uD83D\uDD02": return I_LOOP1;
                case "\u23F9": return I_STOP;
                case "\uD83D\uDCBE": return I_SAVE;
                case "\u23E9": return I_FF;
                case "\uD83C\uDF13": return I_DROP;
                case "\uD83D\uDCCC": return I_PIN;
                case "\uD83D\uDDD1": return I_TRASH;
                case "\uD83C\uDF99": return I_MIC;
                case "\uD83D\uDD0A": return I_SPEAKER;
                case "\uD83D\uDCC4": return I_DOC;
                case "\u2715": return I_CLOSE;
                default: return 0;
            }
        }

        @Override protected void onMeasure(int wSpec, int hSpec) {
            if (icon == 0) { super.onMeasure(wSpec, hSpec); return; }
            int box = dp(iconDp);
            int w = Math.max(getMinWidth(), getPaddingLeft() + getPaddingRight() + box);
            int h = Math.max(getMinHeight(), getPaddingTop() + getPaddingBottom() + box);
            setMeasuredDimension(resolveSize(w, wSpec), resolveSize(h, hSpec));
        }

        @Override protected void onDraw(Canvas cv) {
            if (icon == 0) { super.onDraw(cv); return; }
            float box = dp(iconDp);
            float s = box / 24f;
            float cx = (getPaddingLeft() + getWidth() - getPaddingRight()) / 2f;
            float cy = (getPaddingTop() + getHeight() - getPaddingBottom()) / 2f;
            int col = getCurrentTextColor();
            sp.setColor(col);
            sp.setStrokeWidth(dp(ICON_STROKE_DP) / s);
            tp.setColor(col);
            cv.save();
            cv.translate(cx - box / 2f, cy - box / 2f);
            cv.scale(s, s);
            p.reset();
            switch (icon) {
                case I_RESTART:
                    p.moveTo(6f, 6f); p.lineTo(6f, 18f);
                    p.moveTo(18f, 6f); p.lineTo(9.5f, 12f); p.lineTo(18f, 18f); p.close();
                    break;
                case I_PLAY:
                    p.moveTo(8f, 5.5f); p.lineTo(18.5f, 12f); p.lineTo(8f, 18.5f); p.close();
                    break;
                case I_PAUSE:
                    p.moveTo(9f, 6f); p.lineTo(9f, 18f);
                    p.moveTo(15f, 6f); p.lineTo(15f, 18f);
                    break;
                case I_STOP:
                    r.set(6.5f, 6.5f, 17.5f, 17.5f);
                    p.addRoundRect(r, 2f, 2f, Path.Direction.CW);
                    break;
                case I_FF:
                    p.moveTo(4f, 6f); p.lineTo(12f, 12f); p.lineTo(4f, 18f); p.close();
                    p.moveTo(12f, 6f); p.lineTo(20f, 12f); p.lineTo(12f, 18f); p.close();
                    break;
                case I_VLOOP:
                case I_LOOP1:
                    loopPath();
                    if (icon == I_VLOOP) {
                        p.moveTo(10.5f, 9.5f); p.lineTo(14f, 12f); p.lineTo(10.5f, 14.5f); p.close();
                    } else {
                        p.moveTo(10.8f, 10.2f); p.lineTo(12.5f, 9f); p.lineTo(12.5f, 15f);
                    }
                    break;
                case I_SAVE:
                    p.moveTo(5f, 5f); p.lineTo(16.5f, 5f); p.lineTo(19f, 7.5f); p.lineTo(19f, 19f);
                    p.lineTo(5f, 19f); p.close();
                    p.moveTo(8f, 5f); p.lineTo(8f, 9f); p.lineTo(15f, 9f); p.lineTo(15f, 5f);
                    p.moveTo(8f, 19f); p.lineTo(8f, 14f); p.lineTo(16f, 14f); p.lineTo(16f, 19f);
                    break;
                case I_REPLAY:
                    r.set(5f, 6f, 19f, 20f);
                    p.arcTo(r, -100f, 300f, true);
                    p.moveTo(14.66f, 8.48f); p.lineTo(10.79f, 6.11f); p.lineTo(13.62f, 2.56f);
                    break;
                case I_DROP:
                    p.moveTo(12f, 4f);
                    p.cubicTo(9f, 7.5f, 6.5f, 10.5f, 6.5f, 14f);
                    p.cubicTo(6.5f, 17.3f, 9f, 20f, 12f, 20f);
                    p.cubicTo(15f, 20f, 17.5f, 17.3f, 17.5f, 14f);
                    p.cubicTo(17.5f, 10.5f, 15f, 7.5f, 12f, 4f);
                    p.close();
                    p.moveTo(9.6f, 14.6f); p.quadTo(9.6f, 16.6f, 11.6f, 17.2f);
                    break;
                case I_PIN:
                    p.moveTo(9f, 4f); p.lineTo(15f, 4f);
                    p.moveTo(10f, 4f); p.lineTo(10f, 10f); p.lineTo(7.5f, 13f); p.lineTo(16.5f, 13f);
                    p.lineTo(14f, 10f); p.lineTo(14f, 4f);
                    p.moveTo(12f, 13f); p.lineTo(12f, 20f);
                    break;
                case I_TRASH:
                    p.moveTo(5f, 7f); p.lineTo(19f, 7f);
                    p.moveTo(9.5f, 7f); p.lineTo(9.5f, 4.8f); p.lineTo(14.5f, 4.8f); p.lineTo(14.5f, 7f);
                    p.moveTo(6.5f, 7f); p.lineTo(7.5f, 19f); p.lineTo(16.5f, 19f); p.lineTo(17.5f, 7f);
                    p.moveTo(10f, 10.5f); p.lineTo(10f, 16f);
                    p.moveTo(14f, 10.5f); p.lineTo(14f, 16f);
                    break;
                case I_MIC:
                    r.set(9f, 3.5f, 15f, 14f);
                    p.addRoundRect(r, 3f, 3f, Path.Direction.CW);
                    r.set(6.5f, 6f, 17.5f, 17f);
                    p.moveTo(17.5f, 11.5f);
                    p.arcTo(r, 0f, 180f, false);
                    p.moveTo(12f, 17f); p.lineTo(12f, 20.5f);
                    p.moveTo(9f, 20.5f); p.lineTo(15f, 20.5f);
                    break;
                case I_SPEAKER:
                    p.moveTo(4f, 10f); p.lineTo(8f, 10f); p.lineTo(13f, 6f); p.lineTo(13f, 18f);
                    p.lineTo(8f, 14f); p.lineTo(4f, 14f); p.close();
                    r.set(9.5f, 8.5f, 16.5f, 15.5f);
                    p.arcTo(r, -45f, 90f, true);
                    r.set(6f, 5f, 20f, 19f);
                    p.arcTo(r, -45f, 90f, true);
                    break;
                case I_DOC:
                    p.moveTo(7f, 3.5f); p.lineTo(14f, 3.5f); p.lineTo(18.5f, 8f); p.lineTo(18.5f, 20.5f);
                    p.lineTo(7f, 20.5f); p.close();
                    p.moveTo(14f, 3.5f); p.lineTo(14f, 8f); p.lineTo(18.5f, 8f);
                    p.moveTo(9.5f, 12.5f); p.lineTo(16f, 12.5f);
                    p.moveTo(9.5f, 16f); p.lineTo(16f, 16f);
                    break;
                case I_CLOSE:
                    p.moveTo(6.5f, 6.5f); p.lineTo(17.5f, 17.5f);
                    p.moveTo(17.5f, 6.5f); p.lineTo(6.5f, 17.5f);
                    break;
                default:
                    break;
            }
            cv.drawPath(p, sp);
            if (icon == I_REPLAY && suffix != null) {
                tp.setTextSize("\u221E".equals(suffix) ? 10f : 8.5f);
                cv.drawText(suffix, 12f, "\u221E".equals(suffix) ? 16.4f : 16f, tp);
            }
            cv.restore();
        }

        /** حلقه‌ی «تکرار»: دو فلشِ چرخشی (بالا-راست و پایین-چپ). */
        private void loopPath() {
            p.moveTo(17f, 4f); p.lineTo(20f, 7f); p.lineTo(17f, 10f);
            p.moveTo(4f, 11f); p.lineTo(4f, 9f); p.quadTo(4f, 7f, 6f, 7f); p.lineTo(20f, 7f);
            p.moveTo(7f, 20f); p.lineTo(4f, 17f); p.lineTo(7f, 14f);
            p.moveTo(20f, 13f); p.lineTo(20f, 15f); p.quadTo(20f, 17f, 18f, 17f); p.lineTo(4f, 17f);
        }
    }

    // ───────── دکمه‌ی فونت (پایین-چپِ کادر) ─────────
    private TextView buildFontButton() {
        TextView t = new TextView(this);
        SpannableString sp = new SpannableString("Aa");
        sp.setSpan(new android.text.style.RelativeSizeSpan(0.78f), 1, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.setText(sp);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(4), dp(14), dp(4));
        t.setContentDescription(msg("تغییرِ فونت", "Change font"));
        t.setOnClickListener(v -> toggleFontRow());
        t.setOnLongClickListener(v -> { resetView(); return true; });
        paintFontButton(t, false);
        return t;
    }

    private void paintFontButton(TextView t, boolean active) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(active ? COLOR_GOLD : Color.parseColor("#1AFFFFFF"));
        g.setStroke(dp(1), active ? COLOR_GOLD : Color.parseColor("#40FFFFFF"));
        t.setBackground(g);
        t.setTextColor(active ? Color.parseColor("#1C2541") : Color.WHITE);
    }

    private void updateFontButton() {
        if (tvFontBtn == null) return;
        paintFontButton(tvFontBtn, fontRow != null && fontRow.getVisibility() == View.VISIBLE);
    }

    private TextView headerButton(String label, View.OnClickListener l) {
        TextView t = new IconText(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        t.setOnClickListener(l);
        return t;
    }

    private void refreshHeader() {
        if (tvHeader == null) return;
        // علامتِ ریزِ ▾ جلوی زبان‌ها؛ باز شد ▴
        final boolean open = langRow != null && langRow.getVisibility() == View.VISIBLE;
        StringBuilder sb = new StringBuilder(open ? "\u25B4 " : "\u25BE ");
        List<String> ts = activeTargets();
        for (int i = 0; i < ts.size(); i++) {
            sb.append(i == 0 ? "" : " / ").append(ts.get(i).toUpperCase(Locale.ROOT));
        }
        tvHeader.setText(sb.toString());
        paintLangChips();
        updateModeSwitch();
    }

    // ───────── 🌐 انتخابِ زبانِ ترجمه از داخلِ خودِ کادر (بدونِ رفتن به اپ) ─────────
    private static final String[] PICK_LANGS = {"en", "es", "de", "fr", "fa", "it", "ar", "tr", "ru", "hi", "zh", "ja", "ko"};
    private static final String[] PICK_LANGS_FA = {"انگلیسی", "اسپانیایی", "آلمانی", "فرانسوی", "فارسی", "ایتالیایی", "عربی", "ترکی", "روسی", "هندی", "چینی", "ژاپنی", "کره‌ای"};
    private static final String[] PICK_LANGS_EN = {"English", "Spanish", "German", "French", "Persian", "Italian", "Arabic", "Turkish", "Russian", "Hindi", "Chinese", "Japanese", "Korean"};
    private LinearLayout langRow;
    private final ArrayList<TextView> langChips = new ArrayList<>();

    private void paintLangPill(boolean open) {
        if (tvHeader == null) return;
        // بدونِ قاب و پس‌زمینه (شلوغ نشود)؛ فقط متنِ طلایی. باز بودن: کمی پررنگ‌تر.
        tvHeader.setBackground(null);
        tvHeader.setTextColor(COLOR_GOLD);
        tvHeader.setAlpha(open ? 1f : 0.85f);
        refreshHeader();
    }

    private View buildLangRow() {
        langRow = new LinearLayout(this);
        langRow.setOrientation(LinearLayout.VERTICAL);
        langRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        langRow.setVisibility(View.GONE);
        langRow.setPadding(0, dp(4), 0, dp(6));
        langChips.clear();

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        final boolean fa = isFa();
        for (int i = 0; i < PICK_LANGS.length; i++) {
            final String code = PICK_LANGS[i];
            TextView c = new TextView(this);
            c.setTag(code);
            c.setText(code.toUpperCase(Locale.ROOT));
            c.setContentDescription(fa ? PICK_LANGS_FA[i] : PICK_LANGS_EN[i]);
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            c.setTypeface(Typeface.DEFAULT_BOLD);
            c.setGravity(Gravity.CENTER);
            c.setSingleLine(true);
            c.setMinWidth(dp(46));
            c.setPadding(dp(12), dp(6), dp(12), dp(6));
            c.setOnClickListener(v -> onPickLang(code));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(6));
            chips.addView(c, lp);
            langChips.add(c);
        }
        hs.addView(chips, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        langRow.addView(hs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        paintLangChips();
        return langRow;
    }

    /** روشن = طلایی؛ خاموش = شیشه‌ای؛ زبانِ خودِ ویدیو/صدا کم‌رنگ (ترجمه‌ی هم‌زبان بی‌معنی است). */
    private void paintLangChips() {
        if (langChips.isEmpty()) return;
        final List<String> picked = pickedTargets();
        final String src = panelSrcLang();
        for (TextView c : langChips) {
            final String code = (String) c.getTag();
            final boolean isSrc = src != null && !"auto".equals(src) && src.equals(code);
            final boolean on = !isSrc && picked.contains(code);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(on ? COLOR_GOLD : Color.parseColor("#26FFFFFF"));
            c.setBackground(g);
            c.setTextColor(on ? Color.parseColor("#1C2541") : Color.WHITE);
            c.setAlpha(isSrc ? 0.35f : 1f);
        }
    }

    private void closeLangRow() {
        if (langRow != null && langRow.getVisibility() == View.VISIBLE) langRow.setVisibility(View.GONE);
        paintLangPill(false);
    }

    private void toggleLangRow() {
        if (langRow == null) return;
        boolean show = langRow.getVisibility() != View.VISIBLE;
        langRow.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            if (opacityRow != null) opacityRow.setVisibility(View.GONE);
            if (speedRow != null) speedRow.setVisibility(View.GONE);
            if (fontRow != null) fontRow.setVisibility(View.GONE);
            updateFontButton();
            paintLangChips();
        }
        paintLangPill(show);
        refreshLayout();
    }

    private final Runnable clearHint = this::clearStatus;

    private void langHint(String m) {
        showNotice(m);
        main.removeCallbacks(clearHint);
        main.postDelayed(clearHint, 2200);
    }

    private void onPickLang(String code) {
        final String src = panelSrcLang();
        if (src != null && !"auto".equals(src) && src.equals(code)) {
            langHint(msg("این زبانِ خودِ گفتار/ویدیوست؛ ترجمه ندارد", "That's the spoken language — nothing to translate"));
            return;
        }
        final ArrayList<String> list = pickedTargets();
        if (list.contains(code)) {
            list.remove(code);
            boolean anyActive = false;
            for (String t : list) if (!t.equals(src)) { anyActive = true; break; }
            if (!anyActive) {
                langHint(msg("حداقل یک زبان باید روشن بماند", "Keep at least one language on"));
                return;
            }
        } else {
            list.add(code);
        }
        StringBuilder csv = new StringBuilder();
        for (String t : list) { if (csv.length() > 0) csv.append(','); csv.append(t); }
        // پرچمِ dirty: اپ (حتی اگر الان بسته باشد) دفعه‌ی بعد این انتخاب را برمی‌دارد، نه برعکس
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("targets", csv.toString())
                .putBoolean("targetsDirty", true)
                .putLong("targetsDirtyAt", System.currentTimeMillis())
                .apply();
        BubblePlugin.notifyTargetsChanged();
        settingsChanged();                        // مثلِ وقتی که از اپ عوض می‌شد: ترجمه‌ها/هدر/یوتیوب تازه می‌شوند
        translateHistoryFor(code);                // زبانِ تازه برای جمله‌های همین حالا روی صفحه هم ترجمه شود
    }

    /** ترجمه‌ی زنده: جمله‌های تاریخچه که برای زبانِ تازه ترجمه ندارند (یوتیوب خودش pump می‌کند). */
    private void translateHistoryFor(final String lang) {
        if (yt != null && yt.isActive()) return;
        if (!activeTargets().contains(lang) || !hasInternet()) return;
        final String srcLang = effectiveSource();
        for (Entry e : new ArrayList<>(history)) {
            if (e == null || e.src == null || e.src.trim().isEmpty()) continue;
            String v = e.tr.get(lang);
            if (v != null && !v.isEmpty()) continue;
            e.tr.put(lang, "…");
            submitTranslate(e, e.src, srcLang, lang, "");
        }
    }

    private void computePanelPos() {
        panelLp.width = panelWidthPx();
        if (panelFree) {                       // جای دلخواهِ کاربر؛ دستگیره‌ی تغییر اندازه پایین است
            panelLp.gravity = Gravity.TOP | Gravity.START;
            panelLp.x = clamp(panelFreeX, 0, Math.max(0, screenW() - panelLp.width));
            panelLp.y = clamp(panelFreeY, 0, Math.max(0, screenH() - dp(120)));
            if (gripBottom != null) gripBottom.setVisibility(View.VISIBLE);
            if (gripTop != null) gripTop.setVisibility(View.GONE);
            return;
        }
        panelLp.x = (screenW() - panelLp.width) / 2;
        int sh = screenH();
        boolean below = bubbleLp.y + bubbleSize / 2 < sh / 2;
        // دستگیره‌ی تغییر اندازه همیشه سمتِ دورتر از حباب است (کشیدن به‌سمتِ بیرون = بزرگ‌تر)
        if (gripBottom != null) gripBottom.setVisibility(below ? View.VISIBLE : View.GONE);
        if (gripTop != null) gripTop.setVisibility(below ? View.GONE : View.VISIBLE);
        if (below) {
            panelLp.gravity = Gravity.TOP | Gravity.START;
            panelLp.y = bubbleLp.y + bubbleSize + dp(8);
        } else {
            panelLp.gravity = Gravity.BOTTOM | Gravity.START;
            panelLp.y = sh - bubbleLp.y + dp(8);
        }
    }

    private void movePanel() {
        if (!panelShown || panel == null) return;
        computePanelPos();
        try { wm.updateViewLayout(panel, panelLp); } catch (Exception ignored) {}
    }

    private void refreshLayout() {
        if (!panelShown || panel == null || wm == null) return;
        updateFontButton();
        computePanelPos();
        try { wm.updateViewLayout(panel, panelLp); } catch (Exception ignored) {}
    }

    private void showPanel() {
        if (wm == null || bubble == null) return;
        if (fadingOut) cancelPanelFade();
        ensurePanel();
        refreshHeader();
        computePanelPos();
        try {
            if (!panelShown) {
                lastPanelTouchMs = SystemClock.elapsedRealtime();
                if (chromeHidden) { chromeHidden = false; applyChrome(); }
                panel.animate().cancel();
                panel.setAlpha(0f);
                wm.addView(panel, panelLp);
                panelShown = true;
                panel.animate().alpha(1f).setDuration(PANEL_FADE_IN_MS).start();
            }
            else wm.updateViewLayout(panel, panelLp);
        } catch (Exception e) { Log.w(TAG, "panel show failed", e); }
        // history stays on screen while recording / while there is history; a lone notice fades out
        main.removeCallbacks(hidePanel);
        if (!recording && history.isEmpty()) main.postDelayed(hidePanel, PANEL_HIDE_MS);
    }

    private void removePanel() {
        stopPanelSpeech();
        main.removeCallbacks(hidePanel);
        if (fadingOut) { fadingOut = false; fadeGen++; if (panel != null) panel.animate().cancel(); }
        if (panel != null) { panel.setAlpha(1f); panel.setScaleX(1f); panel.setScaleY(1f); }
        panelDragging = false;
        idlePinned = false;
        if (panelShown && panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        panelShown = false;
        panelFree = false;
        chromeHidden = false;
        if (tvStatus != null) { tvStatus.setText(""); tvStatus.setVisibility(View.GONE); }
    }

    private void clearStatus() {
        if (tvStatus != null) { tvStatus.setText(""); tvStatus.setVisibility(View.GONE); }
    }

    /** Short status line under the history (listening…, errors, hints). */
    private void showNotice(String m) {
        if (wm == null || bubble == null) return;
        ensurePanel();
        boolean has = m != null && !m.isEmpty();
        if (idleHidden && has && m.startsWith("⚠")) { idleHidden = false; userHidden = false; }
        tvStatus.setText(has ? m : "");
        applyStyle(tvStatus);
        tvStatus.setVisibility(has ? View.VISIBLE : View.GONE);
        if (!userHidden) showPanel();
    }

    private void afterChange() {
        if (!userHidden) showPanel();
        else refreshLayout();
    }

    private void clearHistory() {
        stopPanelSpeech();
        stopStoredReplay();
        closeWordCard();
        history.clear();
        typing.clear();
        main.removeCallbacks(typeRunnable);
        typeScheduled = false;
        liveKey = null;
        live = null;
        consumedWords = 0;
        if (listBox != null) listBox.removeAllViews();
        lastFinalText = "";
        prevFinalText = "";
        lastPartialSrc = "";
        cancelLivePending();
        refreshLayout();
    }


    // ════════════════════════════════════════════════════════════════════════════
    //  🔊 خواندنِ جمله  +  👆 انتخابِ لغت/محدوده → کادرِ «افزودن به داستان / گرامر / لایتنر»
    // ════════════════════════════════════════════════════════════════════════════

    /** Supplier ساده (java.util.function روی API 23 نیست). */
    private interface Txt { String get(); }

    private TextView speakingBtn;                 // دکمه‌ای که الان در حالِ خواندن است
    private int speakToken = 0;
    private volatile boolean panelSpeaking = false;
    private volatile long panelQuietUntil = 0;

    /** وقتی خودِ پنل دارد می‌خواند، صدای آن نباید دوباره به متنِ زنده تبدیل شود. */
    private boolean asrMuted() {
        return panelSpeaking || SystemClock.uptimeMillis() < panelQuietUntil;
    }

    private String currentSrcLang() {
        if (yt != null && yt.isActive()) {
            String t = yt.trackLang();
            if (t != null && !t.isEmpty()) return t;
        }
        String s = effectiveSource();
        return (s == null || "auto".equals(s)) ? "en" : s;
    }

    private TextView speakerButton(final Txt text, final Txt lang) {
        return speakerButton(text, lang, null, null, null);
    }

    /** hl: متنی که هنگامِ خواندن جمله‌به‌جمله هایلایت می‌شود (null = بدونِ هایلایت). */
    private TextView speakerButton(final Txt text, final Txt lang, final TextView hl,
                                   final Entry ent, final String kind) {
        final TextView b = new IconText(this);
        b.setText("\uD83D\uDD0A");
        style(b, 18, false);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setMinWidth(dp(44));
        b.setMinHeight(dp(40));
        b.setPadding(dp(6), dp(4), dp(6), dp(4));
        b.setOnClickListener(v -> toggleSpeak(b, text.get(), lang.get(), hl, ent, kind));
        return b;
    }

    private void setSpeaking(TextView b) {
        TextView old = speakingBtn;
        speakingBtn = b;
        if (old != null && old != b) { old.setText("\uD83D\uDD0A"); old.setTextColor(Color.WHITE); }
        if (b != null) { b.setText("\u23F9"); b.setTextColor(COLOR_GOLD); }
    }

    // ───────── 🔊 خواندنِ جمله‌به‌جمله با هایلایتِ بخشِ در حالِ خواندن (هم متنِ اصلی، هم ترجمه) ─────────

    private TextView speakTv = null;      // متنی که الان بخش‌هایش هایلایت می‌شود
    private static final java.util.regex.Pattern SENT_PAT = java.util.regex.Pattern.compile(
            "[^.!?\\u061F\\u3002\\uFF01\\uFF1F\\u2026]+[.!?\\u061F\\u3002\\uFF01\\uFF1F\\u2026]*");

    /** متن را به بخش‌های [start,end) می‌شکند: جمله‌ها؛ و جمله‌های بلند (مثلاً متنِ بدونِ نقطه‌گذاریِ تشخیصِ گفتار) در مرزِ ویرگول/حرفِ ربط. */
    private static ArrayList<int[]> splitSegments(String text) {
        ArrayList<int[]> out = new ArrayList<>();
        java.util.regex.Matcher m = SENT_PAT.matcher(text);
        while (m.find()) {
            int a = m.start(), z = m.end();
            while (a < z && Character.isWhitespace(text.charAt(a))) a++;
            while (z > a && Character.isWhitespace(text.charAt(z - 1))) z--;
            if (a >= z) continue;
            boolean hasLetter = false;
            for (int i = a; i < z && !hasLetter; i++) hasLetter = Character.isLetterOrDigit(text.charAt(i));
            if (!hasLetter) continue;                                   // مثلاً «…» تنها
            // جمله‌ی بلند → تکه‌های ~۸ تا ۱۲ کلمه‌ای
            ArrayList<int[]> ws = new ArrayList<>();
            java.util.regex.Matcher wm = java.util.regex.Pattern.compile("\\S+").matcher(text.substring(a, z));
            while (wm.find()) ws.add(new int[]{a + wm.start(), a + wm.end()});
            if (ws.size() <= CHUNK_MAX_WORDS + 2) { out.add(new int[]{a, z, 1}); continue; }
            String[] w = new String[ws.size()];
            for (int i = 0; i < w.length; i++) w[i] = text.substring(ws.get(i)[0], ws.get(i)[1]);
            int from = 0;
            while (from < w.length) {
                int end = pickBreak(w, from, w.length, true);
                if (end <= from) end = w.length;
                out.add(new int[]{ws.get(from)[0], ws.get(end - 1)[1], end >= w.length ? 1 : 0});
                from = end;
            }
        }
        if (out.isEmpty() && !text.trim().isEmpty()) out.add(new int[]{0, text.length(), 1});
        return out;
    }

    private void highlightSpeak(TextView tv, String expected, int a, int b) {
        if (tv == null) return;
        String plain = tv.getText().toString();
        if (!plain.equals(expected) || a < 0 || b <= a || b > plain.length()) return;
        SpannableString ss = new SpannableString(plain);
        ss.setSpan(new BackgroundColorSpan(Color.parseColor("#88C9A227")), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv.setText(ss);
        scrollToOffset(tv, a, b);
    }

    /** بخشِ در حالِ خواندن را داخلِ دیدِ لیست نگه می‌دارد. */
    private void scrollToOffset(final TextView tv, final int a, final int b) {
        if (scroll == null) return;
        scroll.post(() -> {
            android.text.Layout lay = tv.getLayout();
            if (lay == null || scroll.getChildAt(0) == null) return;
            int n = tv.getText().length();
            int top = lay.getLineTop(lay.getLineForOffset(Math.min(a, Math.max(0, n - 1))));
            int bottom = lay.getLineBottom(lay.getLineForOffset(Math.min(Math.max(a, b - 1), Math.max(0, n - 1))));
            View v = tv;
            int off = 0;
            while (v != scroll.getChildAt(0) && v.getParent() instanceof View) { off += v.getTop(); v = (View) v.getParent(); }
            int y0 = off + top, y1 = off + bottom;
            int vis0 = scroll.getScrollY(), vis1 = vis0 + scroll.getHeight();
            if (y0 < vis0 + dp(6) || y1 > vis1 - dp(6)) scroll.smoothScrollTo(0, Math.max(0, y0 - dp(28)));
        });
    }

    private void clearSpeakHighlight() {
        TextView t = speakTv;
        speakTv = null;
        if (t != null && t != cardSrcTv) clearHighlight(t);
        updateScrollFreeze();
        refreshRecentEntries();                 // متنی که حین خواندن فریز بود، به آخرین نسخه برمی‌گردد
    }

    // ───────── 🔁 تکرارِ هر جمله (مثلِ دکمه‌ی تکرارِ خودِ اپ): خاموش ← ۲ ← ۳ ← ∞ ─────────
    // «N» یعنی کلاً N بار خوانده شود. «∞» تا وقتی جمله‌ی بعدی هست سقفِ ۴۰ بار دارد و بعد خودکار می‌رود سراغِ جمله‌ی بعد؛
    // اگر جمله‌ی بعدی‌ای نباشد (آخرین جمله) واقعاً بی‌نهایت تکرار می‌شود تا خودت ⏹ بزنی.
    private static final int REPEAT_INF = -1;
    private static final int REPEAT_INF_CAP = 40;
    private int repeatSetting = 0;                 // 0 خاموش | 2 | 3 | REPEAT_INF
    private TextView tvRepeat;
    private SpeakRun run;                          // پخشِ جاری (null = ساکت)

    private final class SpeakRun {
        Entry ent; String kind; TextView btn; TextView hl; String text; String lang;
        ArrayList<int[]> segs; int unitStart = 0; int rep = 0; int my;
    }

    private void loadRepeatPref() {
        int v = getSharedPreferences(PREFS, MODE_PRIVATE).getInt("repeatSetting", 0);
        repeatSetting = (v == 2 || v == 3 || v == REPEAT_INF) ? v : 0;
    }

    private void cycleRepeat() {
        repeatSetting = repeatSetting == 0 ? 2 : repeatSetting == 2 ? 3 : repeatSetting == 3 ? REPEAT_INF : 0;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("repeatSetting", repeatSetting).apply();
        updateRepeatButton();
        showNotice(repeatSetting == 0 ? msg("تکرار خاموش", "Repeat off")
                : repeatSetting == REPEAT_INF ? msg("تکرار ∞ — هر جمله، بعد جمله‌ی بعدی", "Repeat ∞ — each sentence, then the next")
                : msg("هر جمله " + repeatSetting + " بار، بعد جمله‌ی بعدی", "Each sentence " + repeatSetting + "×, then the next"));
    }

    /** عددِ روی دکمه‌ی ↺: ۲ / ۳ / ∞ (خاموش = فقط ↺). */
    private String replayLabel() {
        return repeatSetting == 0 ? "\u21BA" : repeatSetting == REPEAT_INF ? "\u21BA\u221E" : "\u21BA" + repeatSetting;
    }

    private void updateRepeatButton() {
        for (Entry en : ytEntries.values())
            if (en != null && en.ytReplayBtn != null) en.ytReplayBtn.setText(replayLabel());
        for (Entry en : history)
            if (en != null && en.pcm != null && en.ytReplayBtn != null) en.ytReplayBtn.setText(replayLabel());
        if (tvRepeat == null) return;
        tvRepeat.setText(replayLabel());   // ↺ / ↺2 / ↺3 / ↺∞ (هم‌شکلِ دکمه‌ی ↺ روی هر جمله)
        tvRepeat.setTextColor(repeatSetting == 0 ? Color.WHITE : COLOR_GOLD);
        tvRepeat.setAlpha(repeatSetting == 0 ? 0.6f : 1f);
    }

    private static String entryText(Entry n, String kind) {
        if ("src".equals(kind)) return n.src == null ? "" : n.src;
        TextView t = n.rowText.get(kind);
        return t == null ? "" : t.getText().toString();
    }

    /** جمله‌ی بعدیِ همان نوع (متنِ اصلی یا همان زبانِ ترجمه) که الان روی صفحه دیده می‌شود. */
    private Entry nextEntryFor(Entry ent, String kind) {
        if (ent == null) return null;
        int idx = history.indexOf(ent);
        if (idx < 0) return null;
        for (int j = idx + 1; j < history.size(); j++) {
            Entry n = history.get(j);
            if (n == live) continue;                                   // جمله‌ی نیمه‌کاره
            View vis = "src".equals(kind) ? n.srcRow : n.rowBox.get(kind);
            if (vis == null || vis.getVisibility() != View.VISIBLE) continue;
            String t = entryText(n, kind).trim();
            if (t.isEmpty() || t.equals("…")) continue;
            return n;
        }
        return null;
    }

    private void toggleSpeak(final TextView b, final String text, final String lang, final TextView hl,
                             final Entry ent, final String kind) {
        if (text == null || text.trim().isEmpty() || text.equals("…")) return;
        if (replayingEntry != null) stopStoredReplay();
        if (fullLoop) stopFullText();
        if (speakingBtn == b) { stopPanelSpeech(); return; }
        if (speakTv != null) clearSpeakHighlight();
        setSpeaking(b);
        final int my = ++speakToken;
        panelSpeaking = true;
        final SpeakRun r = new SpeakRun();
        r.ent = ent; r.kind = kind; r.btn = b; r.hl = hl; r.text = text; r.lang = lang; r.my = my;
        if (hl != null) {
            r.segs = splitSegments(text);
            speakTv = hl;
            updateScrollFreeze();
        } else {
            r.segs = new ArrayList<>();
            r.segs.add(new int[]{0, text.length(), 1});
        }
        run = r;
        speakSegment(r, 0);
    }

    private void speakSegment(final SpeakRun r, final int i) {
        if (r.my != speakToken || run != r) return;                 // پخشِ تازه‌تری شروع شده
        if (i >= r.segs.size()) { advanceOrFinish(r); return; }
        final int[] sg = r.segs.get(i);
        if (r.hl != null) highlightSpeak(r.hl, r.text, sg[0], sg[1]);
        PanelTts.speak(this, r.text.substring(sg[0], sg[1]), r.lang, 1.0f, ok -> {
            if (r.my != speakToken || run != r) return;
            if (!ok) { finishSpeak(r.btn, r.my); return; }
            boolean endOfSentence = sg.length < 3 || sg[2] == 1;
            if (!endOfSentence) { speakSegment(r, i + 1); return; }  // وسطِ یک جمله‌ی بلند: بخشِ بعدی
            // پایانِ یک «جمله»: تکرارِ همین جمله یا رفتن سراغِ بعدی
            boolean moreInRun = i + 1 < r.segs.size() || nextEntryFor(r.ent, r.kind) != null;
            int cap;
            if (repeatSetting == REPEAT_INF) cap = moreInRun ? REPEAT_INF_CAP : Integer.MAX_VALUE;
            else cap = repeatSetting == 0 ? 1 : repeatSetting;
            if (r.rep + 1 < cap) {
                r.rep++;
                final int restart = r.unitStart;
                main.postDelayed(() -> speakSegment(r, restart), repeatGapMs(r.text, sg));
            } else {
                r.rep = 0;
                r.unitStart = i + 1;
                speakSegment(r, i + 1);
            }
        });
    }

    private static long repeatGapMs(String text, int[] sg) {
        int n = words(text.substring(sg[0], sg[1])).length;
        return Math.min(1200, 350 + 30L * n);
    }

    /** بخش‌های این جمله تمام شد: اگر تکرار روشن است برو سراغِ جمله‌ی بعدیِ همان نوع، وگرنه تمام. */
    private void advanceOrFinish(final SpeakRun r) {
        Entry n = repeatSetting == 0 ? null : nextEntryFor(r.ent, r.kind);
        if (n == null) { finishSpeak(r.btn, r.my); return; }
        TextView nb = "src".equals(r.kind) ? n.srcSpeakBtn : n.rowSpeakBtn.get(r.kind);
        TextView nh = "src".equals(r.kind) ? n.tvSrc : n.rowText.get(r.kind);
        if (nb == null || nh == null) { finishSpeak(r.btn, r.my); return; }
        TextView old = r.hl;
        speakTv = null;                                             // هایلایتِ قبلی پاک و متنِ فریزشده به‌روز شود
        if (old != null && old != cardSrcTv) clearHighlight(old);
        refreshRecentEntries();
        String t = entryText(n, r.kind);
        if (t.trim().isEmpty()) { finishSpeak(r.btn, r.my); return; }
        r.ent = n; r.btn = nb; r.hl = nh; r.text = t;
        r.lang = "src".equals(r.kind) ? n.srcLang : r.kind;
        r.segs = splitSegments(t);
        r.unitStart = 0; r.rep = 0;
        speakTv = nh;
        updateScrollFreeze();
        setSpeaking(nb);
        speakSegment(r, 0);
    }

    private void finishSpeak(TextView b, int my) {
        if (my != speakToken) return;
        run = null;
        panelSpeaking = false;
        panelQuietUntil = SystemClock.uptimeMillis() + 1200;
        if (speakingBtn == b) setSpeaking(null);
        clearSpeakHighlight();
    }

    /** ↺ همان جمله را با صدای خودِ پلیر یوتیوب پخش می‌کند؛ تعداد تکرار از تنظیمِ 🔁 (۲ / ۳ / ∞) می‌آید. دوباره زدن = توقفِ تکرار. */
    private void replayInYoutube(Entry e) {
        if (e == null || e.ytIdx < 0 || yt == null || !yt.isActive()) return;
        if (yt.isLooping(e.ytIdx)) {
            yt.stopLoop();
            setReplayHold(false);
            showNotice(msg("تکرار متوقف شد", "Repeat stopped"));
            return;
        }
        stopPanelSpeech();                                   // صدای برنامه با صدای یوتیوب قاطی نشود
        stopStoredReplay(false);
        int times = repeatSetting == 0 ? 1 : repeatSetting;  // REPEAT_INF = -1 → بی‌نهایت
        if (!yt.replaySentence(e.ytIdx, times))
            showNotice(msg("پلیر یوتیوب در دسترس نیست", "YouTube player not available"));
        else holdPlayerForYtReplay(e.ytIdx, times);
        if (times != 1 && yt != null && yt.isLooping(e.ytIdx))
            showNotice(times < 0 ? msg("تکرار ∞ با صدای یوتیوب", "Repeat ∞ with YouTube audio")
                    : msg("تکرار " + times + " بار با صدای یوتیوب", "Repeat " + times + "× with YouTube audio"));
    }

    /** ⏮ کلِ ویدیوی یوتیوب را از ثانیه‌ی صفر دوباره پخش می‌کند (تکرارِ جمله، اگر فعال بود، متوقف می‌شود). */
    private void restartYoutubeFromStart() {
        if (yt == null || !yt.isActive()) return;
        stopPanelSpeech();                                   // صدای برنامه با صدای یوتیوب قاطی نشود
        if (yt.restartVideo())
            showNotice(msg("ویدیو از اول پخش شد", "Video restarted from the beginning"));
        else
            showNotice(msg("پلیر یوتیوب در دسترس نیست", "YouTube player not available"));
    }

    /** ∞ کلِ ویدیو را از ثانیه‌ی صفر پخش می‌کند و هر بار به آخر رسید دوباره از اول (تا دوباره بزنی). */
    private void toggleYoutubeVideoLoop() {
        if (yt == null || !yt.isActive()) return;
        if (yt.isVideoLooping()) {
            yt.stopVideoLoop();
            showNotice(msg("تکرارِ ویدیو متوقف شد", "Video loop stopped"));
            return;
        }
        stopPanelSpeech();                                   // صدای برنامه با صدای یوتیوب قاطی نشود
        if (yt.loopWholeVideo())
            showNotice(msg("∞ ویدیو از اول پخش شد و تا آخر، بی‌نهایت تکرار می‌شود", "∞ Playing from the start, looping forever"));
        else
            showNotice(msg("پلیر یوتیوب در دسترس نیست یا ویدیو مدتِ مشخص ندارد (مثلاً لایو)",
                    "YouTube player not available, or the video has no fixed length (e.g. live)"));
        updateYtButton();
    }

    /** ⏯ مکث/ادامه‌ی ویدیوی یوتیوب (از طریق MediaSession همان اپ یوتیوب). */
    private void toggleYoutubePause() {
        if (yt == null || !yt.isActive()) return;
        stopPanelSpeech();                                   // صدای برنامه با صدای یوتیوب قاطی نشود
        int r = yt.togglePlayPause();
        if (r == 1) { if (tvYtPause != null) tvYtPause.setText("\u23F8"); showNotice(msg("ادامه‌ی پخش", "Playing")); }
        else if (r == 0) { if (tvYtPause != null) tvYtPause.setText("\u25B6"); showNotice(msg("مکث", "Paused")); }
        else showNotice(msg("پلیر یوتیوب در دسترس نیست", "YouTube player not available"));
    }

    // ───────── 🎙 ↺ در ترجمه‌ی زنده: پخشِ صدای خودِ گوینده که موقع ضبط نگه داشته شده ─────────

    private static final int MAX_KEPT_AUDIO = 60;             // صدای حداکثر ۶۰ جمله‌ی آخر نگه داشته می‌شود
    private long lastAudioEnd = 0;                            // پایانِ صدای آخرین جمله‌ی بسته‌شده (sample)
    private long partAStart = -1, partAEnd = -1;              // بازه‌ی صدای جمله‌ای که همین الان commit می‌شود
    private Entry replayingEntry;

    private long asrLagSamples() {
        return sherpaEngine instanceof WhisperEngine ? (long) SAMPLE_RATE * 30 : (long) (SAMPLE_RATE * 1.3);
    }

    /** ↺ روی هر جمله: اگر از یوتیوب است با صدای پلیر، وگرنه با صدای ضبط‌شده‌ی خودِ گوینده. */
    private void replayEntry(Entry e) {
        if (e == null) return;
        if (e.ytIdx >= 0 && yt != null && yt.isActive()) { replayInYoutube(e); return; }
        replayStored(e);
    }

    private void replayStored(final Entry e) {
        if (e.pcm == null) return;
        if (replayingEntry == e) {
            stopStoredReplay();
            showNotice(msg("تکرار متوقف شد", "Repeat stopped"));
            return;
        }
        stopPanelSpeech();                                   // صدای TTS با صدای ضبط‌شده قاطی نشود
        stopStoredReplay(false);
        final int times = repeatSetting == 0 ? 1 : repeatSetting;   // REPEAT_INF = -1 → بی‌نهایت
        replayingEntry = e;
        setReplayActive(e, true);
        setReplayHold(true);                                 // ⏸ پلیرِ اپ تا پایانِ تکرار مکث کند
        SentenceAudio.play(e.pcm, times, () -> main.post(() -> {
            if (replayingEntry == e) { replayingEntry = null; setReplayActive(e, false); setReplayHold(false); }
        }));
    }

    private void stopStoredReplay() { stopStoredReplay(true); }

    private void stopStoredReplay(boolean release) {
        SentenceAudio.stop();
        Entry r = replayingEntry;
        replayingEntry = null;
        if (r != null) setReplayActive(r, false);
        if (release) setReplayHold(false);
    }

    // ───────── ⏸ هماهنگی با پلیرِ اپ: وقتی ↺ می‌زنی، پلیر مکث کند؛ بعد از تمام شدنِ تکرار ادامه بدهد ─────────
    private boolean replayHold = false;
    private long ytHoldUntil = 0;
    private final Runnable ytHoldWatch = new Runnable() {
        @Override public void run() {
            if (!replayHold || replayingEntry != null) return;
            YtSubtitles y = yt;
            boolean looping = y != null && y.isLooping(ytHoldIdx);
            if (y == null || (!looping && SystemClock.uptimeMillis() > ytHoldUntil)) { setReplayHold(false); return; }
            main.postDelayed(this, 300);
        }
    };
    private int ytHoldIdx = -1;

    private void setReplayHold(boolean on) {
        if (replayHold == on) return;
        replayHold = on;
        if (!on) main.removeCallbacks(ytHoldWatch);
        try { BubblePlugin.notifyPanelReplay(on); } catch (Throwable ignored) {}
    }

    private void holdPlayerForYtReplay(int sentIdx, int times) {
        long span = yt == null ? 0 : yt.loopSpanMs();
        ytHoldIdx = sentIdx;
        ytHoldUntil = SystemClock.uptimeMillis() + span + 1500;
        main.removeCallbacks(ytHoldWatch);
        setReplayHold(true);
        main.postDelayed(ytHoldWatch, 400);
    }

    private void setReplayActive(Entry e, boolean on) {
        if (e != null && e.ytReplayBtn != null) e.ytReplayBtn.setTextColor(on ? COLOR_GOLD : Color.WHITE);
    }

    /** صدای جمله‌ی بسته‌شده را از بافرِ ضبط جدا می‌کند و دکمه‌ی ↺ را برایش نشان می‌دهد. */
    private void attachAudio(Entry e, long from, long to) {
        if (e == null || e.ytIdx >= 0) return;
        if (from < 0) from = e.aStart >= 0 ? e.aStart : Math.max(lastAudioEnd, SentenceAudio.now() - 4L * SAMPLE_RATE);
        if (to < 0) to = SentenceAudio.now();
        from = Math.max(from, lastAudioEnd);                  // صدای جمله‌ی قبلی توی این یکی نیاید
        if (to > lastAudioEnd) lastAudioEnd = to;
        short[] a = SentenceAudio.extract(from, to);
        if (a == null) return;
        e.pcm = a;
        if (e.ytReplayBtn != null) {
            e.ytReplayBtn.setText(replayLabel());
            e.ytReplayBtn.setVisibility(View.VISIBLE);
        }
        trimStoredAudio();
    }

    private void trimStoredAudio() {
        int kept = 0;
        for (int i = history.size() - 1; i >= 0; i--) {
            Entry h = history.get(i);
            if (h.pcm == null) continue;
            if (++kept > MAX_KEPT_AUDIO && h != replayingEntry) {
                h.pcm = null;
                if (h.ytIdx < 0 && h.ytReplayBtn != null) h.ytReplayBtn.setVisibility(View.GONE);
            }
        }
    }

    private void stopPanelSpeech() {
        if (fullLoop) stopFullText();
        if (speakingBtn == null && !panelSpeaking && speakTv == null) return;
        speakToken++;
        run = null;
        PanelTts.stop(this);
        panelSpeaking = false;
        panelQuietUntil = SystemClock.uptimeMillis() + 800;
        TextView b = speakingBtn;
        speakingBtn = null;
        if (b != null) { b.setText("\uD83D\uDD0A"); b.setTextColor(Color.WHITE); }
        clearSpeakHighlight();
    }

    // ───────── انتخابِ لغت (تپ) یا محدوده (لانگ‌پرس + کشیدن) ─────────

    private static boolean isWordChar(char c) {
        return Character.isLetterOrDigit(c) || c == '\'' || c == '\u2019' || c == '-' || c == '\u200C';
    }

    /** [start,end) لغتی که offset داخل/کنار آن است؛ null اگر روی فاصله/نشانه‌گذاری بود. */
    private static int[] wordBounds(CharSequence t, int off) {
        int n = t.length();
        if (n == 0) return null;
        if (off >= n) off = n - 1;
        if (off < 0) off = 0;
        if (!isWordChar(t.charAt(off))) {
            if (off > 0 && isWordChar(t.charAt(off - 1))) off--;
            else return null;
        }
        int a = off, b = off + 1;
        while (a > 0 && isWordChar(t.charAt(a - 1))) a--;
        while (b < n && isWordChar(t.charAt(b))) b++;
        while (a < b && (t.charAt(a) == '\'' || t.charAt(a) == '\u2019' || t.charAt(a) == '-')) a++;
        while (b > a && (t.charAt(b - 1) == '\'' || t.charAt(b - 1) == '\u2019' || t.charAt(b - 1) == '-')) b--;
        return a < b ? new int[]{a, b} : null;
    }

    private void highlight(TextView tv, int a, int b) {
        String plain = tv.getText().toString();
        SpannableString ss = new SpannableString(plain);
        if (a >= 0 && b > a && b <= plain.length()) {
            ss.setSpan(new BackgroundColorSpan(Color.parseColor("#66C9A227")), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tv.setText(ss);
    }

    private void clearHighlight(TextView tv) {
        if (tv == null) return;
        CharSequence c = tv.getText();
        if (c instanceof Spanned) tv.setText(c.toString());
    }

    @SuppressLint("ClickableViewAccessibility")
    private void attachSelect(final TextView tv, final Txt langOf) {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        final int[] st = new int[]{0, 0, 0};          // anchorOffset, curOffset, mode(0 idle / 1 pending / 2 selecting)
        final float[] down = new float[2];
        final Runnable longPress = () -> {
            if (st[2] != 1) return;
            st[2] = 2;
            tv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            selectingTv = tv;
            updateScrollFreeze();
            if (tv.getParent() != null) tv.getParent().requestDisallowInterceptTouchEvent(true);
            int[] w = wordBounds(tv.getText(), st[0]);
            if (w != null) highlight(tv, w[0], w[1]);
        };
        tv.setOnTouchListener((v, ev) -> {
            CharSequence txt = tv.getText();
            if (txt == null || txt.length() == 0) return false;
            int off = tv.getOffsetForPosition(ev.getX(), ev.getY());
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = ev.getX(); down[1] = ev.getY();
                    st[0] = off; st[1] = off; st[2] = 1;
                    selectingTv = tv;            // تا انگشت روی متن است، ترجمه‌ی زنده بازنویسی‌اش نکند
                    updateScrollFreeze();
                    main.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (st[2] == 1 && (Math.abs(ev.getX() - down[0]) > slop || Math.abs(ev.getY() - down[1]) > slop)) {
                        st[2] = 0;                                   // کشیدنِ معمولی → اسکرولِ لیست
                        main.removeCallbacks(longPress);
                        selectingTv = null;
                        updateScrollFreeze();
                        return true;
                    }
                    if (st[2] == 2) {
                        st[1] = off;
                        int[] a = wordBounds(txt, st[0]), c = wordBounds(txt, st[1]);
                        if (a != null && c != null) highlight(tv, Math.min(a[0], c[0]), Math.max(a[1], c[1]));
                    }
                    return true;
                case MotionEvent.ACTION_UP: {
                    main.removeCallbacks(longPress);
                    int mode = st[2];
                    st[2] = 0;
                    String full = txt.toString();
                    int a0 = -1, b0 = -1;
                    if (mode == 1) {
                        int[] w = wordBounds(full, st[0]);
                        if (w != null) { a0 = w[0]; b0 = w[1]; }
                    } else if (mode == 2) {
                        int[] a = wordBounds(full, st[0]), c = wordBounds(full, st[1]);
                        if (a != null && c != null) { a0 = Math.min(a[0], c[0]); b0 = Math.max(a[1], c[1]); }
                        else if (a != null) { a0 = a[0]; b0 = a[1]; }
                    }
                    if (a0 >= 0 && b0 > a0) {
                        highlight(tv, a0, b0);
                        openWordCard(full.substring(a0, b0).trim(), langOf.get(), full, tv);
                    } else {
                        clearHighlight(tv);
                    }
                    selectingTv = null;
                    updateScrollFreeze();
                    refreshRecentEntries();
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    main.removeCallbacks(longPress);
                    if (st[2] == 2) clearHighlight(tv);
                    st[2] = 0;
                    selectingTv = null;
                    updateScrollFreeze();
                    return true;
            }
            return false;
        });
    }

    // ───────── کادرِ لغت: معنی + سه دکمه‌ی اپ ─────────

    private LinearLayout wordCard;
    private TextView cardTerm, cardMeaningTv, cardBtnStory, cardBtnGrammar, cardBtnLeitner;
    private TextView cardSrcTv;                       // متنی که هایلایت دارد
    private String cardWord, cardLang, cardSentence, cardMeaning = "", cardMeaningLang;
    private boolean cardStoryDone, cardGrammarDone, cardLeitnerDone;
    private int cardSeq = 0;

    private TextView cardAction(String label, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(label);
        style(b, 12, true);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        b.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        b.setOnClickListener(l);
        styleCardAction(b, false);
        return b;
    }

    private void styleCardAction(TextView b, boolean done) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#14FFFFFF"));
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), done ? COLOR_GOLD : Color.parseColor("#40FFFFFF"));
        b.setBackground(g);
        b.setTextColor(done ? COLOR_GOLD : Color.WHITE);
    }

    private void buildWordCard() {
        wordCard = new LinearLayout(this);
        wordCard.setOrientation(LinearLayout.VERTICAL);
        wordCard.setPadding(dp(10), dp(8), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(wordCardBgColor());
        wordCardBgDrawable = bg;
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), COLOR_GOLD);
        wordCard.setBackground(bg);
        wordCard.setVisibility(View.GONE);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wlp.topMargin = dp(6);
        wlp.bottomMargin = dp(4);
        wordCard.setLayoutParams(wlp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        top.setGravity(Gravity.CENTER_VERTICAL);
        cardTerm = new TextView(this);
        cardTerm.setTextColor(Color.WHITE);
        styleC(cardTerm, 17, true);
        cardTerm.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        cardTerm.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        top.addView(cardTerm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(speakerButton(() -> cardWord, () -> cardLang));
        // 📄 کلِ جمله را به‌جای لغت/محدوده انتخاب کن
        top.addView(headerButton("\uD83D\uDCC4", v -> {
            if (cardSentence == null || cardSrcTv == null || cardSentence.equals(cardWord)) return;
            String full = cardSrcTv.getText().toString();
            highlight(cardSrcTv, 0, full.length());
            openWordCard(cardSentence, cardLang, cardSentence, cardSrcTv);
        }));
        top.addView(headerButton("\u2715", v -> closeWordCard()));
        wordCard.addView(top);

        cardMeaningTv = new TextView(this);
        cardMeaningTv.setTextColor(Color.parseColor("#E8EAF2"));
        styleC(cardMeaningTv, 15, false);
        cardMeaningTv.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        cardMeaningTv.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        cardMeaningTv.setPadding(0, dp(2), 0, dp(6));
        wordCard.addView(cardMeaningTv);

        cardBtnStory = cardAction("", v -> onCardStory());
        cardBtnGrammar = cardAction("", v -> onCardGrammar());
        cardBtnLeitner = cardAction("", v -> onCardLeitner());
        for (TextView b : new TextView[]{cardBtnStory, cardBtnGrammar, cardBtnLeitner}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(5);
            wordCard.addView(b, lp);
        }
    }

    private void refreshCardButtons() {
        cardBtnStory.setText(cardStoryDone
                ? msg("\uD83D\uDD16 ذخیره شد برای داستان بعدی", "\uD83D\uDD16 Saved for next story")
                : msg("\uD83D\uDD16 ذخیره برای داستان بعدی", "\uD83D\uDD16 Save for next story"));
        cardBtnGrammar.setText(cardGrammarDone
                ? msg("\uD83E\uDDE9 ذخیره شد در گرامر", "\uD83E\uDDE9 Saved to grammar")
                : msg("\uD83E\uDDE9 افزودن به یادگیری گرامر", "\uD83E\uDDE9 Add to grammar learning"));
        cardBtnLeitner.setText(cardLeitnerDone
                ? msg("\uD83D\uDD01 به جعبه‌ی لایتنر اضافه شد", "\uD83D\uDD01 Added to Leitner box")
                : msg("\uD83D\uDD01 افزودن به جعبه‌ی لایتنر", "\uD83D\uDD01 Add to Leitner box"));
        styleCardAction(cardBtnStory, cardStoryDone);
        styleCardAction(cardBtnGrammar, cardGrammarDone);
        styleCardAction(cardBtnLeitner, cardLeitnerDone);
    }

    private void setScrollCompact(boolean compact) { applyScrollMax(); }

    private void closeWordCard() {
        cardSeq++;
        if (cardSrcTv != null) { clearHighlight(cardSrcTv); cardSrcTv = null; }
        refreshRecentEntries();                // متنی که تا الان فریز بود، به آخرین نسخه برمی‌گردد
        if (wordCard == null || wordCard.getVisibility() == View.GONE) { updateScrollFreeze(); return; }
        wordCard.setVisibility(View.GONE);
        updateScrollFreeze();
        setScrollCompact(false);
        refreshLayout();
    }

    private void openWordCard(final String word, final String lang, final String sentence, final TextView srcTv) {
        if (word == null || word.isEmpty() || wm == null || bubble == null) return;
        ensurePanel();
        if (cardSrcTv != null && cardSrcTv != srcTv) {
            clearHighlight(cardSrcTv);
            cardSrcTv = srcTv;
            refreshRecentEntries();
        }
        cardSrcTv = srcTv;
        final int my = ++cardSeq;
        cardWord = word;
        cardLang = (lang == null || lang.isEmpty() || "auto".equals(lang)) ? "en" : lang;
        cardSentence = sentence == null ? word : sentence;
        cardMeaning = "";
        cardStoryDone = cardGrammarDone = cardLeitnerDone = false;
        // 🌐 معنیِ لغت به *همه‌ی زبان‌های انتخابیِ کاربر* (نه فقط زبانِ رابطِ اپ)، جز خودِ زبانِ لغت
        final ArrayList<String> meaningLangs = new ArrayList<>();
        for (String t : activeTargets()) if (!t.equals(cardLang) && !meaningLangs.contains(t)) meaningLangs.add(t);
        if (meaningLangs.isEmpty()) {          // کاربر زبانی انتخاب نکرده / فقط همان زبانِ لغت: مثلِ قبل
            final String nativeL = targetLang();
            String other = currentSrcLang();
            meaningLangs.add(cardLang.equals(nativeL) ? (other.equals(cardLang) ? "en" : other) : nativeL);
        }
        cardMeaningLang = meaningLangs.get(0);

        cardTerm.setText(word);
        cardMeaningTv.setText("…");
        applyStyle(cardTerm);
        applyStyle(cardMeaningTv);
        refreshCardButtons();
        wordCard.setVisibility(View.VISIBLE);
        updateScrollFreeze();
        setScrollCompact(true);
        if (!userHidden) showPanel(); else refreshLayout();

        final String from = cardLang;
        if (hasInternet()) {
            try {
                netTr.execute(() -> {
                    final ArrayList<String> outs = new ArrayList<>();
                    for (String to : meaningLangs) {
                        String out;
                        try { out = LiveTranslator.translate(this, HTTP_FAST, word, from, to, aiBackend); }
                        catch (Exception ex) { out = ""; }
                        outs.add(out == null ? "" : out.trim());
                    }
                    main.post(() -> onCardMeanings(my, meaningLangs, outs));
                });
            } catch (Exception ex) { onCardMeanings(my, meaningLangs, new ArrayList<String>()); }
        } else {
            final Translator tr = localTr;
            final String first = meaningLangs.get(0);
            if (localReady && tr != null && from.equals(effectiveSource()) && first.equals(primaryTarget())) {
                tr.translate(word)
                        .addOnSuccessListener(o -> onCardMeanings(my, meaningLangs, singleMeaning(o)))
                        .addOnFailureListener(x -> onCardMeanings(my, meaningLangs, new ArrayList<String>()));
            } else {
                onCardMeanings(my, meaningLangs, new ArrayList<String>());
            }
        }
    }

    private static ArrayList<String> singleMeaning(String o) {
        ArrayList<String> l = new ArrayList<>();
        l.add(o == null ? "" : o.trim());
        return l;
    }

    /** معنی‌ها (به ترتیبِ زبان‌های انتخابی) در کادرِ لغت؛ اولین معنیِ موجود برای ذخیره (لایتنر/داستان) استفاده می‌شود. */
    private void onCardMeanings(int token, List<String> langs, List<String> outs) {
        if (token != cardSeq || cardMeaningTv == null) return;
        StringBuilder sb = new StringBuilder();
        String firstText = null, firstLang = null;
        boolean multi = langs.size() > 1;
        for (int i = 0; i < langs.size(); i++) {
            String m = i < outs.size() ? outs.get(i) : "";
            if (m == null || m.isEmpty()) continue;
            if (firstText == null) { firstText = m; firstLang = langs.get(i); }
            if (sb.length() > 0) sb.append('\n');
            if (multi) sb.append(langs.get(i).toUpperCase(Locale.ROOT)).append("  ·  ");
            sb.append(m);
        }
        if (firstText == null) {
            cardMeaningTv.setText(msg("ترجمه در دسترس نیست — ذخیره بدون معنی هم کار می‌کند",
                    "No translation — saving still works"));
            applyStyle(cardMeaningTv);
            return;
        }
        cardMeaning = firstText;
        cardMeaningLang = firstLang;
        cardMeaningTv.setText(sb.toString());
        applyStyle(cardMeaningTv);
        // اگر قبل از رسیدنِ معنی دکمه‌ای زده شده بود، همان ردیف با معنی به‌روز می‌شود (گرامر یک‌بار ثبت می‌شود)
        if (cardStoryDone) queueWord("story");
        if (cardLeitnerDone) queueWord("leitner");
        refreshLayout();
    }

    private void queueWord(String action) {
        if (cardWord == null || cardWord.isEmpty()) return;
        try {
            String lc = cardLang == null ? "en" : cardLang;
            JSONObject o = new JSONObject()
                    .put("key", action + "|" + lc + "|" + cardWord.toLowerCase(Locale.ROOT))
                    .put("action", action)
                    .put("word", cardWord)
                    .put("lang", lc)
                    .put("meaning", cardMeaning == null ? "" : cardMeaning)
                    .put("meaningLang", cardMeaningLang == null ? "fa" : cardMeaningLang)
                    .put("sentence", cardSentence == null ? cardWord : cardSentence)
                    .put("rev", System.currentTimeMillis());
            WordQueue.add(this, o);
            BubblePlugin.notifyWordQueued();
        } catch (Throwable t) {
            showNotice(msg("ذخیره نشد", "Save failed"));
        }
    }

    private void onCardStory()   { if (cardStoryDone) return;   cardStoryDone = true;   queueWord("story");   refreshCardButtons(); }
    private void onCardGrammar() { if (cardGrammarDone) return; cardGrammarDone = true; queueWord("grammar"); refreshCardButtons(); }
    private void onCardLeitner() { if (cardLeitnerDone) return; cardLeitnerDone = true; queueWord("leitner"); refreshCardButtons(); }


    // ════════════════════════════════════════════════════════════════════════════
    //  🔎 اندازه‌ی کادر و فونت: دستگیره‌ی کرکره‌ای (یک انگشت) = ارتفاع ، A−/A+ = اندازه‌ی متن ، Aa = نوع فونت
    // ════════════════════════════════════════════════════════════════════════════

    private static final float FONT_MIN = 0.7f, FONT_MAX = 2.4f;

    /** یک گزینه‌ی فونت. keys == null → فونتِ سیستم (sys؛ null = پیش‌فرض).
     *  وگرنه فایلِ فونت از assets/fonts پیدا می‌شود؛ نامِ دقیقِ فایل مهم نیست، وجودِ کلیدواژه در نام کافی است
     *  (مثلاً BNazanin.ttf ، B Nazanin.ttf ، BNazaninBd.ttf). فونت‌های optional فقط وقتی فایلشان باشد در لیست می‌آیند. */
    private static final class FontOpt {
        final String id, faLabel, enLabel, sys;
        final String[] keys;
        final boolean noBold, tall, optional;
        final float sizeMul;
        boolean resolved;
        Typeface reg, bold;
        String[] sysKeys;                       // اگر فایلِ assets/fonts نبود: فونتِ عربی/فارسیِ خودِ گوشی (/system/fonts) با این کلیدواژه‌ها
        FontOpt sys(String... k) { this.sysKeys = k; return this; }

        FontOpt(String id, String faLabel, String enLabel, String sys, String[] keys,
                boolean noBold, boolean tall, float sizeMul, boolean optional) {
            this.id = id; this.faLabel = faLabel; this.enLabel = enLabel; this.sys = sys; this.keys = keys;
            this.noBold = noBold; this.tall = tall; this.sizeMul = sizeMul; this.optional = optional;
        }
    }

    private static final FontOpt[] FA_FONTS = {
            new FontOpt("fa_default", "پیش‌فرض", "Default", null, null, false, false, 1f, false),
            new FontOpt("fa_bzar", "بی‌زر", "B Zar", null, new String[]{"bzar"}, false, false, 1.08f, false),
            new FontOpt("fa_bnazanin", "بی‌نازنین", "B Nazanin", null, new String[]{"bnazanin", "nazanin"}, false, false, 1.12f, false),
            new FontOpt("fa_btitr", "بی‌تیتر", "B Titr", null, new String[]{"btitr", "titr"}, true, false, 1f, false),
            new FontOpt("fa_nastaliq", "نستعلیق", "Nastaliq", null, new String[]{"nastaliq", "nastaleeq"}, true, true, 1.1f, false),
            new FontOpt("fa_vazir", "وزیرمتن", "Vazirmatn", null, new String[]{"vazir"}, false, false, 1f, true),
            new FontOpt("fa_serif", "سریف", "Serif", "serif", null, false, false, 1f, false),
            new FontOpt("fa_medium", "متوسط", "Medium", "sans-serif-medium", null, false, false, 1f, false),
            // فونت‌های فارسیِ خودِ گوشی؛ «serif/medium» اندروید روی حروفِ فارسی اثری ندارد و همه با یک فونتِ fallback رسم می‌شوند
            new FontOpt("fa_sysnaskh", "نسخ", "Naskh", null, new String[]{"notonaskh"}, false, false, 1.05f, false).sys("notonaskharabic", "droidnaskh", "naskh"),
            new FontOpt("fa_syssans", "ساده", "Sans", null, null, false, false, 1f, false).sys("notosansarabic", "droidsansarabic", "sansarabic"),
            new FontOpt("fa_aref", "عارف رقعه", "Aref Ruqaa", null, new String[]{"aref"}, true, true, 1.1f, true),
            new FontOpt("fa_syskufi", "کوفی", "Kufi", null, null, false, false, 1f, false).sys("kufi"),
            new FontOpt("fa_sysnastaliq", "نستعلیق", "Nastaliq", null, null, true, true, 1.1f, false).sys("nastaliq", "nastaleeq"),
    };

    private static final FontOpt[] EN_FONTS = {
            new FontOpt("en_default", "پیش‌فرض", "Default", null, null, false, false, 1f, false),
            new FontOpt("en_medium", "متوسط", "Medium", "sans-serif-medium", null, false, false, 1f, false),
            new FontOpt("en_light", "نازک", "Light", "sans-serif-light", null, false, false, 1f, false),
            new FontOpt("en_serif", "سریف", "Serif", "serif", null, false, false, 1f, false),
            new FontOpt("en_cond", "فشرده", "Condensed", "sans-serif-condensed", null, false, false, 1f, false),
            new FontOpt("en_mono", "تک‌فاصله", "Mono", "monospace", null, false, false, 1f, false),
            new FontOpt("en_inter", "Inter", "Inter", null, new String[]{"inter"}, false, false, 1f, true),
            new FontOpt("en_lora", "Lora", "Lora", null, new String[]{"lora"}, false, false, 1f, true),
            // خانواده‌های داخلیِ اندروید (بدونِ نیاز به فایل): تا هر شش گزینه‌ی «نوع فونت» روی متنِ لاتین هم واقعاً فرق کند
            new FontOpt("en_cursive", "دست‌نویس", "Cursive", "cursive", null, false, false, 1.1f, false),
            new FontOpt("en_casual", "غیررسمی", "Casual", "casual", null, false, false, 1f, false),
            // فونت‌های لاتینِ داخلِ برنامه (assets/fonts): روی همه‌ی گوشی‌ها یکسان و واقعاً متفاوت‌اند
            new FontOpt("en_vazir", "Vazirmatn", "Vazirmatn", null, new String[]{"vazir"}, false, false, 1f, true),
            new FontOpt("en_caladea", "Caladea", "Caladea", null, new String[]{"caladea"}, false, false, 1.04f, true),
            new FontOpt("en_aref", "Aref Ruqaa", "Aref Ruqaa", null, new String[]{"aref"}, true, true, 1.05f, true),
            new FontOpt("en_carlito", "Carlito", "Carlito", null, new String[]{"carlito"}, false, false, 1.06f, true),
            new FontOpt("en_dvcond", "DejaVu Condensed", "DejaVu Condensed", null, new String[]{"dejavusanscondensed"}, false, false, 0.98f, true),
    };

    /** «نوع فونت» تنظیماتِ اپ (default/modern/classic/elegant/rounded/warm) → نزدیک‌ترین فونتِ قابل‌استفاده در کادر.
     *  فونتِ وبِ دقیق (Vazirmatn/Lora/…) فقط اگر فایلش در assets/fonts باشد استفاده می‌شود؛ وگرنه معادلِ سیستمی. */
    private String[] mapAppFont(String id) {
        switch (id == null ? "default" : id) {
            case "modern":  return new String[]{pickFa("fa_vazir", "fa_syssans", "fa_default"), pickEn("en_vazir", "en_light")};
            case "classic": return new String[]{pickFa("fa_sysnaskh", "fa_serif"), pickEn("en_caladea", "en_serif")};
            case "elegant": return new String[]{pickFa("fa_aref", "fa_sysnastaliq", "fa_sysnaskh", "fa_serif"), pickEn("en_aref", "en_cursive")};
            case "rounded": return new String[]{pickFa("fa_syskufi", "fa_medium"), pickEn("en_carlito", "en_casual")};
            case "warm":    return new String[]{pickFa("fa_vazir", "fa_sysnaskh", "fa_default"), pickEn("en_dvcond", "en_cond")};
            default:        return new String[]{pickFa("fa_vazir", "fa_default"), pickEn("en_lora", "en_default")};
        }
    }

    /** اولین فونتِ لاتین از لیست که واقعاً موجود است (آخری = پشتیبانِ سیستمی). */
    private String pickEn(String... ids) {
        for (String i : ids) if (fontAvailable(fontById(EN_FONTS, i))) return i;
        return ids[ids.length - 1];
    }

    /** اولین فونتِ فارسی از لیست که واقعاً روی این گوشی/برنامه موجود است (آخری = پشتیبان). */
    private String pickFa(String... ids) {
        for (String i : ids) if (fontAvailable(fontById(FA_FONTS, i))) return i;
        return ids[ids.length - 1];
    }

    private String currentAppFont() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("appFont", "default");
    }

    private void applyAppFont() {
        String[] m = mapAppFont(currentAppFont());
        boolean changed = !(m[0].equals(fontFaId) && m[1].equals(fontEnId));
        fontFaId = m[0]; fontEnId = m[1];
        if (panel != null) {
            refreshFontChips();
            if (changed) relayoutAfterStyle();
        }
    }

    /** از اپ (Settings → نوع فونت): فقط وقتی انتخابِ اپ عوض شده اعمال می‌شود تا انتخابِ داخلِ کادر با هر بازشدنِ اپ پاک نشود. */
    public static void pushAppFont(Context ctx, String font) {
        if (font == null) return;
        String f = font.trim().toLowerCase(java.util.Locale.ROOT);
        if (!f.matches("default|modern|classic|elegant|rounded|warm")) return;
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        if (f.equals(sp.getString("appFontLast", ""))) return;
        sp.edit().putString("appFontLast", f).putString("appFont", f).apply();
    }

    public static void saveAppFont(Context ctx, String font) {
        if (font == null) return;
        String f = font.trim().toLowerCase(java.util.Locale.ROOT);
        if (!f.matches("default|modern|classic|elegant|rounded|warm")) return;
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("appFont", f).apply();
    }

    private float fontScale = 1f;
    private String fontFaId = "fa_default";    // فونتِ متنِ فارسی/عربی
    private String fontEnId = "en_default";    // فونتِ متنِ انگلیسی/لاتین
    private float panelHFrac = 0.42f;
    private float panelWFrac = -1f;            // -1 = تمام‌عرض
    private float panelAlpha = 1f;             // شفافیتِ پس‌زمینه‌ی کادر: ۱ = کاملاً مات (solid)، ۰ = کاملاً شفاف
    private LinearLayout opacityRow;
    private LinearLayout speedRow;
    private TextView tvSpeedVal;
    private float speedWanted = 1f;
    private int speedGen = 0;
    private LinearLayout fontRow;
    private final ArrayList<TextView> faChips = new ArrayList<>();
    private final ArrayList<TextView> enChips = new ArrayList<>();
    private SeekBar opacityBar;
    private GradientDrawable panelBgDrawable;
    private View gripTop, gripBottom;

    private void loadViewPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        fontScale = Math.max(FONT_MIN, Math.min(FONT_MAX, sp.getFloat("fontScale", 1f)));
        applyAppFont();                                   // فونتِ کادر = «نوع فونت» در تنظیماتِ اپ
        panelHFrac = Math.max(0.12f, Math.min(0.85f, sp.getFloat("panelHFrac", 0.42f)));
        panelWFrac = sp.getFloat("panelWFrac", -1f);
        panelAlpha = Math.max(0f, Math.min(1f, sp.getFloat("panelAlphaV2", 1f)));
    }

    private void saveViewPrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("fontScale", fontScale)
                .putString("fontFa", fontFaId).putString("fontEn", fontEnId)
                .putFloat("panelHFrac", panelHFrac).putFloat("panelWFrac", panelWFrac)
                .putFloat("panelAlphaV2", panelAlpha).apply();
    }

    private void applyPanelAlpha() {
        if (panelBgDrawable == null) return;
        int a = Math.round(Math.max(0f, Math.min(1f, panelAlpha)) * 255f);
        panelBgDrawable.setColor((a << 24) | panelRgb());
        panel.invalidate();
    }

    private int panelRgb() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getInt("panelColor", 0x1C2541) & 0xFFFFFF;
    }

    /** رنگِ کادرِ لغتِ داخلِ پنل: پیش‌فرض همان #26335F؛ برای رنگ‌های دیگر کمی روشن‌تر از رنگِ پنل. */
    private int wordCardBgColor() {
        int c = panelRgb();
        if (c == 0x1C2541) return Color.parseColor("#26335F");
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        r += Math.round((255 - r) * 0.10f); g += Math.round((255 - g) * 0.10f); b += Math.round((255 - b) * 0.10f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private GradientDrawable wordCardBgDrawable;

    private void applyPanelColor() {
        applyPanelAlpha();
        if (wordCardBgDrawable != null) wordCardBgDrawable.setColor(wordCardBgColor());
    }

    /** 🌓 نوارِ تنظیمِ شفافیت (۰ تا ۱۰۰٪) را باز/بسته می‌کند. */
    private void toggleOpacityRow() {
        if (opacityRow == null) return;
        boolean show = opacityRow.getVisibility() != View.VISIBLE;
        opacityRow.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) closeLangRow();
        if (show && fontRow != null) fontRow.setVisibility(View.GONE);
        if (show && speedRow != null) speedRow.setVisibility(View.GONE);
        refreshLayout();
    }

    /** Aa → انتخابِ فونتِ فارسی و فونتِ انگلیسی (جدا از هم). */
    private void toggleFontRow() {
        if (fontRow == null) return;
        boolean show = fontRow.getVisibility() != View.VISIBLE;
        fontRow.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) closeLangRow();
        if (show && opacityRow != null) opacityRow.setVisibility(View.GONE);
        if (show && speedRow != null) speedRow.setVisibility(View.GONE);
        refreshLayout();
    }

    // ───────── ⏩ سرعتِ پخش (ویدیو/صدای هر برنامه: یوتیوب، اینستاگرام، پلیر گوشی …) ─────────

    private static final float[] SPEED_PRESETS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};

    private View buildSpeedRow() {
        speedRow = new LinearLayout(this);
        speedRow.setOrientation(LinearLayout.VERTICAL);
        speedRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        speedRow.setVisibility(View.GONE);

        LinearLayout ctl = new LinearLayout(this);
        ctl.setOrientation(LinearLayout.HORIZONTAL);
        ctl.setGravity(Gravity.CENTER);
        ctl.addView(speedChip("\u2212", v -> bumpSpeed(-0.1f)));
        tvSpeedVal = new TextView(this);
        tvSpeedVal.setTextColor(COLOR_GOLD);
        tvSpeedVal.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvSpeedVal.setTypeface(Typeface.DEFAULT_BOLD);
        tvSpeedVal.setGravity(Gravity.CENTER);
        tvSpeedVal.setMinWidth(dp(80));
        tvSpeedVal.setText("1.0\u00D7");
        ctl.addView(tvSpeedVal);
        ctl.addView(speedChip("+", v -> bumpSpeed(0.1f)));
        speedRow.addView(ctl, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.setGravity(Gravity.CENTER);
        for (final float sp : SPEED_PRESETS) {
            TextView c = speedChip(fmtSpeed(sp), v -> applySpeed(sp));
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            c.setPadding(dp(7), dp(5), dp(7), dp(5));
            presets.addView(c, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        speedRow.addView(presets, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return speedRow;
    }

    private TextView speedChip(String label, View.OnClickListener l) {
        TextView t = headerButton(label, l);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static String fmtSpeed(float sp) {
        String t = String.format(Locale.US, "%.2f", sp);
        if (t.endsWith("0")) t = t.substring(0, t.length() - 1);
        return t + "\u00D7";
    }

    private void toggleSpeedRow() {
        if (speedRow == null) return;
        boolean show = speedRow.getVisibility() != View.VISIBLE;
        speedRow.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            closeLangRow();
            if (opacityRow != null) opacityRow.setVisibility(View.GONE);
            if (fontRow != null) fontRow.setVisibility(View.GONE);
            float cur = YtMedia.currentSpeed(this);
            if (cur > 0f) speedWanted = cur;
            if (tvSpeedVal != null) tvSpeedVal.setText(fmtSpeed(speedWanted));
        }
        refreshLayout();
    }

    private void bumpSpeed(float delta) {
        float base = speedWanted;
        float cur = YtMedia.currentSpeed(this);
        if (cur > 0f) base = cur;
        applySpeed(Math.round((base + delta) * 100f) / 100f);
    }

    private void applySpeed(float sp) {
        sp = Math.max(0.25f, Math.min(3f, sp));
        speedWanted = sp;
        if (tvSpeedVal != null) tvSpeedVal.setText(fmtSpeed(sp));
        int r = YtMedia.setSpeed(this, sp);
        if (r < 0) {
            showNotice(msg("برای تغییر سرعت، «دسترسی به اعلان‌ها» رو برای این برنامه روشن کن.",
                    "Turn on Notification access for this app to change playback speed."));
            YtMedia.openAccessSettings(this);
            return;
        }
        if (r == 0) {
            showNotice(msg("هیچ ویدیو یا صدایی در حال پخش پیدا نشد.", "No playing video or audio found."));
            return;
        }
        // چند لحظه بعد چک می‌کنیم برنامه واقعاً سرعت رو عوض کرد یا نه
        final int gen = ++speedGen;
        final float want = sp;
        main.postDelayed(() -> {
            if (gen != speedGen) return;
            float got = YtMedia.currentSpeed(this);
            if (got > 0f && Math.abs(got - want) > 0.03f) {
                if (YtMedia.YT_PKG.equals(YtMedia.playerPackage(this))) { speedViaAccessibility(want); return; }
                if (tvSpeedVal != null) tvSpeedVal.setText(fmtSpeed(got));
                speedWanted = got;
                showNotice(msg("این برنامه اجازه‌ی تغییر سرعت از بیرون رو نمی‌ده.",
                        "This app doesn't allow changing speed from outside."));
                main.postDelayed(() -> { if (gen == speedGen) clearStatus(); }, 3500);
            }
        }, 800);
    }

    /** یوتیوب سرعت رو از MediaSession قبول نکرد → از منوی خودِ یوتیوب (سرویسِ دسترسی‌پذیری). */
    private void speedViaAccessibility(final float want) {
        if (!SpeedAccessibilityService.isAvailable(this)) {      // نسخه‌ی store: سرویسِ دسترسی‌پذیری وجود ندارد
            showNotice(msg("این ویدیو اجازه‌ی تغییر سرعت از بیرون رو نمی‌ده؛ از خودِ پلیرِ یوتیوب عوضش کن.",
                    "This player doesn't allow speed changes from outside; use the YouTube player's own speed menu."));
            return;
        }
        if (!SpeedAccessibilityService.isEnabled(this)) {
            showNotice(msg("برای تغییرِ سرعتِ یوتیوب، سرویسِ «دسترسی‌پذیری» این برنامه رو روشن کن.",
                    "To change YouTube speed, turn on this app's Accessibility service."));
            SpeedAccessibilityService.openSettings(this);
            return;
        }
        showNotice(msg("در حال تنظیمِ سرعتِ یوتیوب…", "Setting YouTube speed…"));
        boolean sent = SpeedAccessibilityService.request(want, (ok, applied) -> {
            if (ok) {
                speedWanted = applied;
                if (tvSpeedVal != null) tvSpeedVal.setText(fmtSpeed(applied));
                clearStatus();
            } else {
                showNotice(msg("نشد؛ ویدیوی یوتیوب باید روی صفحه باز باشه.",
                        "Failed; the YouTube video must be on screen."));
            }
        });
        if (!sent) showNotice(msg("سرویسِ دسترسی‌پذیری هنوز وصل نشده؛ یک بار خاموش/روشنش کن.",
                "Accessibility service isn't connected yet; toggle it off/on once."));
    }

    private int panelMaxH() { return Math.max(dp(60), (int) (screenH() * panelHFrac)); }

    private int panelWidthPx() {
        int full = screenW() - dp(24);
        if (panelWFrac < 0) return full;
        return clamp(Math.round(screenW() * panelWFrac), dp(220), full);
    }

    private void applyScrollMax() {
        if (scroll == null) return;
        boolean compact = wordCard != null && wordCard.getVisibility() == View.VISIBLE;
        scroll.maxHeightPx = compact ? Math.max(dp(90), (int) (panelMaxH() * 0.55f)) : panelMaxH();
        scroll.requestLayout();
    }

    // ── فونت: فارسی و انگلیسی جدا؛ نوعِ فونتِ هر متن از خودِ حروفش تشخیص داده می‌شود ──

    private String[] fontAssets;

    private String[] fontAssetList() {
        if (fontAssets == null) {
            try { fontAssets = getAssets().list("fonts"); } catch (IOException ex) { fontAssets = null; }
            if (fontAssets == null) fontAssets = new String[0];
        }
        return fontAssets;
    }

    private static String normName(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("\\.(ttf|otf)$", "").replaceAll("[^a-z0-9]", "");
    }

    private static final String[] SYS_FONT_DIRS = {"/system/fonts", "/system/product/fonts", "/product/fonts", "/system_ext/fonts", "/vendor/fonts"};

    private static boolean isBoldName(String n) { return n.endsWith("bd") || n.contains("bold"); }

    /** فایلِ فونتِ فارسی/عربیِ خودِ گوشی؛ regular و bold جدا. نسخه‌ی «UI» فقط وقتی استفاده می‌شود که غیرِ UI نباشد. */
    private void resolveSystemFont(FontOpt o) {
        java.io.File reg = null, bold = null, regUi = null, boldUi = null;
        for (String d : SYS_FONT_DIRS) {
            java.io.File[] fs = new java.io.File(d).listFiles();
            if (fs == null) continue;
            Arrays.sort(fs);
            for (java.io.File f : fs) {
                String lf = f.getName().toLowerCase(Locale.ROOT);
                if (!lf.endsWith(".ttf") && !lf.endsWith(".otf")) continue;
                String n = normName(f.getName());
                boolean hit = false;
                for (String k : o.sysKeys) if (n.contains(k)) { hit = true; break; }
                if (!hit) continue;
                if (n.contains("italic") || n.contains("light") || n.contains("thin") || n.contains("black")
                        || n.contains("medium") || n.contains("semi") || n.contains("extra")) continue;
                boolean ui = n.contains("ui");
                if (isBoldName(n)) { if (!ui) { if (bold == null) bold = f; } else if (boldUi == null) boldUi = f; }
                else if (ui) { if (regUi == null) regUi = f; }
                else if (reg == null) reg = f;
            }
        }
        if (reg == null) reg = regUi;
        if (bold == null) bold = boldUi;
        if (reg == null) reg = bold;
        if (reg == null) { Log.w(TAG, "no system font for " + o.id); return; }
        try {
            o.reg = Typeface.createFromFile(reg);
            o.bold = bold != null && !bold.equals(reg) ? Typeface.createFromFile(bold)
                    : (o.noBold ? o.reg : Typeface.create(o.reg, Typeface.BOLD));
            Log.i(TAG, "font " + o.id + " <- " + reg.getAbsolutePath());
        } catch (Throwable t) {
            Log.w(TAG, "system font load failed: " + reg, t);
            o.reg = null; o.bold = null;
        }
    }

    private void resolveFont(FontOpt o) {
        if (o.resolved) return;
        o.resolved = true;
        if (o.keys == null && o.sysKeys == null) return;
        String regFile = null, boldFile = null;
        if (o.keys != null) for (String f : fontAssetList()) {
            String lf = f.toLowerCase(Locale.ROOT);
            if (!lf.endsWith(".ttf") && !lf.endsWith(".otf")) continue;
            String n = normName(f);
            boolean hit = false;
            for (String k : o.keys) if (n.contains(k)) { hit = true; break; }
            if (!hit) continue;
            boolean isBold = n.endsWith("bd") || n.contains("bold");
            if (isBold) { if (boldFile == null) boldFile = f; }
            else if (regFile == null) regFile = f;
        }
        if (regFile == null) regFile = boldFile;            // مثلاً BTitrBd.ttf تنها فایلِ موجود است
        if (regFile == null) {
            if (o.sysKeys != null) resolveSystemFont(o);
            else Log.w(TAG, "font file not found in assets/fonts for " + o.id);
            return;
        }
        try {
            o.reg = Typeface.createFromAsset(getAssets(), "fonts/" + regFile);
            if (boldFile != null && !boldFile.equals(regFile)) o.bold = Typeface.createFromAsset(getAssets(), "fonts/" + boldFile);
            else o.bold = o.noBold ? o.reg : Typeface.create(o.reg, Typeface.BOLD);
        } catch (Throwable t) {
            Log.w(TAG, "font load failed: " + regFile, t);
            o.reg = null; o.bold = null;
        }
    }

    private boolean fontAvailable(FontOpt o) {
        if (o.keys == null && o.sysKeys == null) return true;   // فونتِ سیستم
        resolveFont(o);
        return o.reg != null;
    }

    private Typeface typefaceOf(FontOpt o, boolean bold) {
        if (o.keys != null || o.sysKeys != null) {
            resolveFont(o);
            if (o.reg != null) return bold && o.bold != null ? o.bold : o.reg;
        }
        return Typeface.create(o.sys, bold ? Typeface.BOLD : Typeface.NORMAL);
    }

    private static FontOpt fontById(FontOpt[] arr, String id) {
        for (FontOpt o : arr) if (o.id.equals(id)) return o;
        return arr[0];
    }

    private static boolean hasArabicScript(CharSequence s) {
        if (s == null) return false;
        for (int i = 0, n = s.length(); i < n; i++) {
            char c = s.charAt(i);
            if ((c >= 0x0600 && c <= 0x06FF) || (c >= 0x0750 && c <= 0x077F)
                    || (c >= 0xFB50 && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF)) return true;
        }
        return false;
    }

    /** اندازه + نوعِ فونتِ یک TextView را ثبت و اعمال می‌کند (برای تغییرِ بعدیِ یک‌جا). */
    private void style(TextView t, float baseSp, boolean bold) {
        t.setTag(new float[]{baseSp, bold ? 1f : 0f, 0f});
        applyStyle(t);
    }

    /** مثلِ style، ولی برای «متنِ محتوا» (جمله، ترجمه، لغت، معنی): فونتِ انتخابی‌ی فارسی/انگلیسی روی آن اعمال می‌شود. */
    private void styleC(TextView t, float baseSp, boolean bold) {
        t.setTag(new float[]{baseSp, bold ? 1f : 0f, 1f});
        applyStyle(t);
    }

    private void applyStyle(TextView t) {
        Object tag = t.getTag();
        if (!(tag instanceof float[])) return;
        float[] st = (float[]) tag;
        boolean bold = st[1] > 0;
        FontOpt o = null;
        if (st.length > 2 && st[2] > 0) {
            o = hasArabicScript(t.getText()) ? fontById(FA_FONTS, fontFaId) : fontById(EN_FONTS, fontEnId);
        }
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, st[0] * fontScale * (o != null ? o.sizeMul : 1f));
        if (o == null) {
            t.setTypeface(Typeface.create((String) null, bold ? Typeface.BOLD : Typeface.NORMAL));
            return;
        }
        t.setTypeface(typefaceOf(o, bold && !o.noBold));
        t.setLineSpacing(0f, o.tall ? 1.3f : 1f);           // نستعلیق بلند است؛ بدونِ این، بالا/پایینِ حروف بریده می‌شود
    }

    private void restyle(View v) {
        if (v instanceof TextView) applyStyle((TextView) v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) restyle(g.getChildAt(i));
        }
    }

    private void relayoutAfterStyle() {
        if (panel == null) return;
        restyle(panel);
        panel.requestLayout();
        refreshLayout();
    }

    private void setFontScale(float v, boolean persist) {
        float q = Math.round(Math.max(FONT_MIN, Math.min(FONT_MAX, v)) * 20f) / 20f;   // قدم‌های ۰٫۰۵ تا لرزش/کندی نداشته باشد
        if (Math.abs(q - fontScale) < 0.001f) { if (persist) saveViewPrefs(); return; }
        fontScale = q;
        relayoutAfterStyle();
        if (persist) saveViewPrefs();
    }

    // ── ردیفِ انتخابِ فونت (زیرِ هدرِ پنل) ──

    private static final String[] APP_FONT_IDS = {"default", "modern", "classic", "elegant", "rounded", "warm"};
    private static final String[] APP_FONT_FA = {"پیش‌فرض", "مدرن", "کلاسیک", "شیک", "گرد", "گرم"};
    private static final String[] APP_FONT_EN = {"Default", "Modern", "Classic", "Elegant", "Rounded", "Warm"};
    private final ArrayList<TextView> appFontChips = new ArrayList<>();

    /** span برای نمایشِ یک تکه‌متن با یک Typeface مشخص (پیش‌نمایشِ فونت روی کلیدها). */
    private static final class FontSpan extends android.text.style.MetricAffectingSpan {
        private final Typeface tf;
        FontSpan(Typeface t) { tf = t; }
        @Override public void updateDrawState(android.text.TextPaint p) { p.setTypeface(tf); }
        @Override public void updateMeasureState(android.text.TextPaint p) { p.setTypeface(tf); }
    }

    /** متنِ کلید: خطِ اول «Aa آب» (نمونه‌ی لاتین و فارسیِ همین فونت)، خطِ دوم نامِ فونت به زبانِ رابط. */
    private CharSequence presetChipText(String id, String name) {
        String[] m = mapAppFont(id);
        FontOpt eo = fontById(EN_FONTS, m[1]);
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
        sb.append("Aa");
        sb.setSpan(new FontSpan(typefaceOf(eo, false)), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new android.text.style.RelativeSizeSpan(1.15f * eo.sizeMul), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private View buildFontRow() {
        fontRow = new LinearLayout(this);
        fontRow.setOrientation(LinearLayout.VERTICAL);
        fontRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        fontRow.setVisibility(View.GONE);
        fontRow.setPadding(0, dp(2), 0, dp(6));
        appFontChips.clear();

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        line.setPadding(0, dp(2), 0, dp(2));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        final boolean fa = isFa();
        for (int i = 0; i < APP_FONT_IDS.length; i++) {
            final String id = APP_FONT_IDS[i];
            TextView c = new TextView(this);
            c.setTag(id);
            c.setText(presetChipText(id, fa ? APP_FONT_FA[i] : APP_FONT_EN[i]));
            c.setContentDescription(fa ? APP_FONT_FA[i] : APP_FONT_EN[i]);
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            c.setGravity(Gravity.CENTER);
            c.setMaxLines(1);
            c.setMinWidth(dp(48));
            c.setLineSpacing(0f, 1.05f);
            c.setTextDirection(View.TEXT_DIRECTION_LTR);
            c.setPadding(dp(12), dp(6), dp(12), dp(6));
            c.setOnClickListener(v -> pickAppFont(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(6));
            chips.addView(c, lp);
            appFontChips.add(c);
        }
        hs.addView(chips, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        line.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        fontRow.addView(line);
        refreshFontChips();
        return fontRow;
    }

    private void pickAppFont(String id) {
        saveAppFont(this, id);
        applyAppFont();
        refreshFontChips();
        saveViewPrefs();
    }

    private View fontLine(String label, FontOpt[] opts, boolean fa) {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        line.setPadding(0, dp(2), 0, dp(2));

        TextView lb = new TextView(this);
        lb.setText(label);
        lb.setTextColor(COLOR_GOLD);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        lb.setTypeface(Typeface.DEFAULT_BOLD);
        lb.setMinWidth(dp(50));
        line.addView(lb, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        for (FontOpt o : opts) {
            if (o.optional && !fontAvailable(o)) continue;
            TextView c = fontChip(o, fa);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(6));
            chips.addView(c, lp);
            (fa ? faChips : enChips).add(c);
        }
        hs.addView(chips, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        line.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return line;
    }

    private TextView fontChip(final FontOpt o, final boolean fa) {
        TextView c = new TextView(this);
        c.setTag(o);
        c.setText(fa ? o.faLabel : o.enLabel);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13 * (fa ? o.sizeMul : 1f));
        c.setGravity(Gravity.CENTER);
        c.setSingleLine(true);
        c.setPadding(dp(12), dp(o.tall ? 8 : 5), dp(12), dp(o.tall ? 8 : 5));
        c.setLineSpacing(0f, o.tall ? 1.25f : 1f);
        c.setTypeface(typefaceOf(o, false));                 // پیش‌نمایش: نامِ هر فونت با خودِ همان فونت
        c.setOnClickListener(v -> pickFont(o, fa));
        return c;
    }

    private void refreshFontChips() {
        String sel = currentAppFont();
        for (TextView c : appFontChips) {
            boolean on = sel.equals(c.getTag());
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(on ? COLOR_GOLD : Color.parseColor("#26FFFFFF"));
            c.setBackground(g);
            c.setTextColor(on ? Color.parseColor("#1C2541") : Color.WHITE);
        }
    }

    private void paintChips(ArrayList<TextView> chips, String sel) {
        for (TextView c : chips) {
            FontOpt o = (FontOpt) c.getTag();
            boolean on = o.id.equals(sel);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(on ? COLOR_GOLD : Color.parseColor("#26FFFFFF"));
            c.setBackground(g);
            c.setTextColor(on ? Color.parseColor("#1C2541") : Color.WHITE);
            c.setAlpha(fontAvailable(o) ? 1f : 0.4f);
        }
    }

    private void pickFont(FontOpt o, boolean fa) {
        if (!fontAvailable(o)) {
            showNotice(msg("فایلِ فونتِ «" + o.faLabel + "» داخل assets/fonts پیدا نشد",
                    "Font file for " + o.enLabel + " not found in assets/fonts"));
            return;
        }
        if (fa) fontFaId = o.id; else fontEnId = o.id;
        refreshFontChips();
        relayoutAfterStyle();
        saveViewPrefs();
    }

    private void resetView() {
        fontScale = 1f;
        SharedPreferences rsp = getSharedPreferences(PREFS, MODE_PRIVATE);
        rsp.edit().putString("appFont", rsp.getString("appFontLast", "default")).apply();
        applyAppFont();
        panelHFrac = 0.42f; panelWFrac = -1f; panelAlpha = 1f;
        if (opacityBar != null) opacityBar.setProgress(100);
        applyPanelAlpha();
        applyScrollMax();
        refreshFontChips();
        relayoutAfterStyle();
        saveViewPrefs();
        showNotice(msg("اندازه، شفافیت و فونت به حالت اولیه برگشت", "Size, opacity and font reset"));
    }

    /** دستگیره‌ی «کرکره‌ای»: یک خطِ باریک؛ با یک انگشت به‌سمتِ بیرون بکش = کادر باز می‌شود، به‌سمتِ داخل = جمع می‌شود.
     *  سمتِ راستِ همان نوار یک کپسولِ کوچکِ A− | A+ برای اندازه‌ی متن است. */
    @SuppressLint("ClickableViewAccessibility")
    private boolean panelDragging = false;     // کاربر کادر را گرفته (کشیدن/نگه‌داشتن) → کادر خودکار بسته نشود

    /**
     * جابه‌جایی و بستنِ کادر (مثلِ XRecorder): با انگشت بکش تا کادر هرجا خواستی برود؛
     * یا نگه دار تا کادر «برداشته» شود و دایره‌ی ✕ پایینِ صفحه بیاید؛ کادر را روی ✕ رها کنی کاملاً بسته می‌شود.
     */
    private final class PanelMover implements View.OnTouchListener {
        private final int slop = ViewConfiguration.get(BubbleService.this).getScaledTouchSlop();
        private final long longMs = ViewConfiguration.getLongPressTimeout();
        private float downX, downY;
        private int startX, startY;
        private boolean moved, picked, hot;
        private final Runnable longRun = () -> {
            if (moved || panel == null || !panelShown) return;
            picked = true;
            panelDragging = true;
            panel.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            panel.animate().scaleX(1.02f).scaleY(1.02f).setDuration(120).start();
            showCloseTarget();
        };

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            if (panel == null || !panelShown) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    int[] loc = new int[2];
                    panel.getLocationOnScreen(loc);
                    startX = loc[0]; startY = loc[1];
                    downX = e.getRawX(); downY = e.getRawY();
                    moved = false; picked = false; hot = false;
                    main.removeCallbacks(hidePanel);
                    main.removeCallbacks(longRun);
                    main.postDelayed(longRun, longMs);
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        moved = true;
                        panelDragging = true;
                        if (!picked) main.removeCallbacks(longRun);
                        showCloseTarget();     // مثلِ ذره‌بین: به‌محضِ شروعِ کشیدن، دایره‌ی ✕ پایینِ صفحه ظاهر می‌شود
                    }
                    if (moved) {
                        panelFree = true;
                        panelFreeX = Math.round(startX + dx);
                        panelFreeY = Math.round(startY + dy);
                        refreshLayout();
                    }
                    if (picked || moved) updateHot(e.getRawX(), e.getRawY());
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    main.removeCallbacks(longRun);
                    boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                    boolean wasPicked = picked, wasHot = hot, wasMoved = moved;
                    picked = false; hot = false; moved = false;
                    panelDragging = false;
                    lastActiveMs = SystemClock.elapsedRealtime();
                    if (wasPicked || wasMoved) {
                        if (up && wasHot) { closePanelAnimated(); }
                        else {
                            panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();
                            hideCloseTarget();
                        }
                    }
                    return true;
                }
            }
            return true;
        }

        private void updateHot(float rx, float ry) {
            boolean h = closeView != null && Math.hypot(rx - tgtCx, ry - tgtCy) < dp(90);
            if (h == hot) return;
            hot = h;
            overTarget = h;
            if (closeView != null) closeView.setHot(h);
            if (h) panel.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            panel.animate().scaleX(h ? 0.55f : 1.02f).scaleY(h ? 0.55f : 1.02f).alpha(h ? 0.6f : 1f).setDuration(140).start();
        }
    }

    private boolean gripHot = false;

    /** کشیدنِ کادر با نوارِ هاشور: مثلِ ذره‌بین، ✕ نشان داده می‌شود و رها کردن روی آن سرویس را کاملاً می‌بندد. */
    private void gripDragHot(float rx, float ry) {
        if (panel == null) return;
        showCloseTarget();
        boolean h = closeView != null && Math.hypot(rx - tgtCx, ry - tgtCy) < dp(90);
        if (h == gripHot) return;
        gripHot = h;
        overTarget = h;
        if (closeView != null) closeView.setHot(h);
        if (h) panel.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        panel.animate().scaleX(h ? 0.55f : 1f).scaleY(h ? 0.55f : 1f).alpha(h ? 0.6f : 1f).setDuration(140).start();
    }

    /** کادر روی ✕ رها شد: کوچک و محو می‌شود و سرویس کاملاً بسته می‌شود. */
    private void closePanelAnimated() {
        hideCloseTarget();
        if (panel == null) { shutdown(); return; }
        panel.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(150)
                .withEndAction(this::shutdown).start();
    }

    private View makeGrip(final boolean atBottom) {
        final HatchBar f = new HatchBar(this);
        f.setContentDescription(msg("بکش: تغییرِ اندازه یا جابه‌جایی · بزن: نمایش/پنهانِ کنترل‌ها",
                "Drag: resize or move · Tap: show/hide controls"));

        // کپسولِ اندازه‌ی متن
        LinearLayout cap = new LinearLayout(this);
        cap.setOrientation(LinearLayout.HORIZONTAL);
        cap.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        cap.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable capBg = new GradientDrawable();
        capBg.setColor(Color.parseColor("#59000000"));
        capBg.setCornerRadius(dp(10));
        cap.setBackground(capBg);
        cap.addView(fontStep("A\u2212", 11, -0.1f));
        View div = new View(this);
        div.setBackgroundColor(Color.parseColor("#33FFFFFF"));
        cap.addView(div, new LinearLayout.LayoutParams(dp(1), dp(12)));
        cap.addView(fontStep("A+", 14, +0.1f));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(22),
                (atBottom ? Gravity.START : Gravity.END) | Gravity.CENTER_VERTICAL);
        if (atBottom) clp.setMarginStart(dp(2)); else clp.setMarginEnd(dp(2));
        f.addView(cap, clp);
        gripExtras.add(cap);

        // 🎙 دکمه‌ی ضبطِ shadowing (پایین-راستِ کادر)
        if (atBottom) {
            LinearLayout sh = new LinearLayout(this);
            sh.setOrientation(LinearLayout.HORIZONTAL);
            sh.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            sh.setGravity(Gravity.CENTER_VERTICAL);
            tvShadowPlay = new IconText(this);
            tvShadowPlay.setText("\u25B6");
            tvShadowPlay.setTextColor(Color.WHITE);
            tvShadowPlay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvShadowPlay.setGravity(Gravity.CENTER);
            tvShadowPlay.setPadding(dp(10), 0, dp(10), 0);
            tvShadowPlay.setVisibility(View.GONE);
            ((IconText) tvShadowPlay).setIconDp(16f);
            tvShadowPlay.setOnClickListener(v -> shadowPlay());
            sh.addView(tvShadowPlay, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
            tvShadowRec = new IconText(this);
            tvShadowRec.setTextColor(Color.WHITE);
            tvShadowRec.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvShadowRec.setGravity(Gravity.CENTER);
            tvShadowRec.setPadding(dp(10), 0, dp(10), 0);
            ((IconText) tvShadowRec).setIconDp(16f);
            tvShadowRec.setOnClickListener(v -> shadowToggle());
            sh.addView(tvShadowRec, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
            updateShadowUi();
            FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(22), Gravity.END | Gravity.CENTER_VERTICAL);
            slp.setMarginEnd(dp(2));
            f.addView(sh, slp);
            gripExtras.add(sh);
        }

        // کشیدن: عمودی = تغییرِ ارتفاع (↕)، افقی = جابه‌جاییِ کادر؛ بدونِ حرکت (بزن) = نمایش/پنهانِ کنترل‌ها
        final float[] d = new float[6];      // 0 downY, 1 startH(frac), 2 downX, 3 mode(0 نامعلوم/1 اندازه/2 جابه‌جایی), 4 panelX, 5 panelY
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        f.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    d[0] = ev.getRawY(); d[1] = panelHFrac; d[2] = ev.getRawX(); d[3] = 0;
                    int[] loc = new int[2];
                    if (panel != null) panel.getLocationOnScreen(loc);
                    d[4] = loc[0]; d[5] = loc[1];
                    f.setActive(true);
                    panelDragging = true;
                    main.removeCallbacks(hidePanel);
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    float rdx = ev.getRawX() - d[2], rdy = ev.getRawY() - d[0];
                    if (d[3] == 0 && Math.max(Math.abs(rdx), Math.abs(rdy)) > slop) {
                        d[3] = Math.abs(rdy) >= Math.abs(rdx) ? 1 : 2;
                    }
                    if (d[3] == 1) {
                        float dy = rdy * (atBottom ? 1f : -1f);
                        panelHFrac = Math.max(0.12f, Math.min(0.85f, d[1] + dy / screenH()));
                        if (scroll != null) scroll.atBottom = false;
                        applyScrollMax();
                        refreshLayout();
                    } else if (d[3] == 2) {
                        panelFree = true;
                        panelFreeX = Math.round(d[4] + rdx);
                        panelFreeY = Math.round(d[5] + rdy);
                        refreshLayout();
                        gripDragHot(ev.getRawX(), ev.getRawY());
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    f.setActive(false);
                    panelDragging = false;
                    lastActiveMs = SystemClock.elapsedRealtime();
                    if (d[3] == 2) {
                        boolean onX = gripHot;
                        gripHot = false;
                        if (onX && ev.getActionMasked() == MotionEvent.ACTION_UP) { closePanelAnimated(); return true; }
                        if (panel != null) panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();
                        hideCloseTarget();
                    }
                    if (d[3] == 0 && ev.getActionMasked() == MotionEvent.ACTION_UP) toggleChrome();
                    else saveViewPrefs();
                    return true;
            }
            return true;
        });
        return f;
    }

    /** 🟦 نوارِ هاشورخوردهٔ پایین (و بالا) کادر با آیکنِ ↕؛ برای تغییرِ اندازه/جابه‌جاییِ آسان. */
    private final class HatchBar extends FrameLayout {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrows = new Path();
        private boolean active;

        HatchBar(Context c) {
            super(c);
            setWillNotDraw(false);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(1.4f));
            ic.setStyle(Paint.Style.STROKE);
            ic.setStrokeWidth(dp(2));
            ic.setStrokeCap(Paint.Cap.ROUND);
            ic.setStrokeJoin(Paint.Join.ROUND);
            icBg.setColor(Color.parseColor("#80000000"));
        }

        void setActive(boolean a) { active = a; invalidate(); }

        @Override protected void dispatchDraw(Canvas cv) {
            final int w = getWidth(), h = getHeight();
            fill.setColor(active ? Color.parseColor("#40F2C14E") : Color.parseColor("#59000000"));   // پس‌زمینه‌ی ساده و تیره‌تر (بدون هاشور)
            cv.drawRect(0, 0, w, h, fill);
            final float cx = w / 2f, cy = h / 2f;
            cv.drawRoundRect(cx - dp(18), cy - dp(11), cx + dp(18), cy + dp(11), dp(11), dp(11), icBg);
            ic.setColor(active ? COLOR_GOLD : Color.WHITE);
            final float a = dp(5.5f), c = dp(3.5f);
            arrows.reset();
            arrows.moveTo(cx, cy - a); arrows.lineTo(cx, cy + a);
            arrows.moveTo(cx - c, cy - a + c); arrows.lineTo(cx, cy - a); arrows.lineTo(cx + c, cy - a + c);
            arrows.moveTo(cx - c, cy + a - c); arrows.lineTo(cx, cy + a); arrows.lineTo(cx + c, cy + a - c);
            cv.drawPath(arrows, ic);
            super.dispatchDraw(cv);
        }
    }

    private TextView fontStep(String label, int sp, final float delta) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.parseColor("#B3FFFFFF"));
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(34));
        t.setPadding(dp(4), 0, dp(4), 0);
        t.setOnClickListener(v -> setFontScale(fontScale + delta, true));
        return t;
    }

    private Entry newEntry() {
        ensurePanel();
        final Entry e = new Entry();
        e.box = new LinearLayout(this);
        e.box.setOrientation(LinearLayout.VERTICAL);
        e.box.setPadding(0, dp(4), 0, dp(8));

        e.tvSrc = new TextView(this);
        e.tvSrc.setTextColor(Color.parseColor("#C8CCD8"));
        styleC(e.tvSrc, 16, false);
        e.tvSrc.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        e.tvSrc.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);

        e.rowsBox = new LinearLayout(this);
        e.rowsBox.setOrientation(LinearLayout.VERTICAL);

        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#33FFFFFF"));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        dlp.topMargin = dp(8);

        e.srcLang = currentSrcLang();
        attachSelect(e.tvSrc, () -> e.srcLang);
        TextView srcSpeak = speakerButton(() -> e.src, () -> e.srcLang, e.tvSrc, e, "src");
        e.srcSpeakBtn = srcSpeak;
        e.srcRow = new LinearLayout(this);
        e.srcRow.setOrientation(LinearLayout.HORIZONTAL);
        e.srcRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        e.srcRow.setBaselineAligned(false);     // ← علتِ بریده‌شدنِ خطِ آخر: هم‌ترازیِ baseline متن را چند dp پایین می‌برد
        LinearLayout.LayoutParams srcLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        srcLp.setMarginStart(dp(2));
        e.srcRow.addView(e.tvSrc, srcLp);
        e.srcRow.addView(srcSpeak, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView replay = new IconText(this);
        replay.setText(replayLabel());
        style(replay, 20, true);
        replay.setTextColor(Color.WHITE);
        replay.setGravity(Gravity.CENTER);
        replay.setMinWidth(dp(40));
        replay.setMinHeight(dp(40));
        replay.setPadding(dp(4), dp(4), dp(4), dp(4));
        replay.setVisibility(View.GONE);                    // فقط در لیستِ زیرنویسِ یوتیوب دیده می‌شود
        replay.setOnClickListener(v -> replayEntry(e));
        e.ytReplayBtn = replay;
        e.srcRow.addView(replay, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        e.box.addView(e.srcRow);
        e.box.addView(e.rowsBox);
        e.box.addView(divider, dlp);
        listBox.addView(e.box, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        history.add(e);
        while (!ytListMode && history.size() > MAX_HISTORY) {
            Entry old = history.get(0);
            if (old == live) break;
            history.remove(0);
            listBox.removeView(old.box);
            ytEntries.values().remove(old);
        }
        return e;
    }

    /** بعد از seek به عقب، خطِ تازه سرِ جای درستِ خودش (به ترتیبِ زمانِ زیرنویس) می‌نشیند. */
    private void placeByCueIndex(Entry e) {
        int pos = 0;
        for (int i = 0; i < history.size(); i++) {
            Entry h = history.get(i);
            if (h == e) continue;
            if (h.ytIdx < 0 || h.ytIdx < e.ytIdx) pos = i + 1;
        }
        int cur = history.indexOf(e);
        if (cur == pos || (cur == history.size() - 1 && pos >= history.size() - 1)) return;
        history.remove(e);
        listBox.removeView(e.box);
        if (pos > history.size()) pos = history.size();
        history.add(pos, e);
        listBox.addView(e.box, pos, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void scrollToEntry(final Entry e) {
        if (scroll == null || e == null || e.box == null) return;
        scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, e.box.getTop() - dp(4))));
    }

    private void makeRow(Entry e, String lang) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);   // language tag always on the left
        row.setPadding(0, dp(3), 0, 0);
        row.setVisibility(View.GONE);

        TextView tag = new TextView(this);
        tag.setText(lang.toUpperCase(Locale.ROOT));
        tag.setTextColor(COLOR_GOLD);
        style(tag, 10, true);
        tag.setMinWidth(dp(26));
        tag.setPadding(dp(4), dp(5), 0, 0);

        TextView tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        styleC(tv, 16, true);
        tv.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        tv.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);

        attachSelect(tv, () -> lang);
        TextView rowSpeak = speakerButton(() -> tv.getText().toString(), () -> lang, tv, e, lang);
        e.rowSpeakBtn.put(lang, rowSpeak);
        row.setBaselineAligned(false);
        row.addView(tag, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tvLp.setMarginStart(dp(2));
        row.addView(tv, tvLp);
        row.addView(rowSpeak, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        e.rowsBox.addView(row);
        e.rowBox.put(lang, row);
        e.rowText.put(lang, tv);
    }

    /** Draws one sentence according to the display mode (both / original / translation). */
    private void renderEntry(Entry e) {
        if (e == null || e.box == null) return;
        String mode = displayMode();
        List<String> ts = activeTargets();
        boolean anyTr = false;
        for (String t : ts) {
            String v = e.tr.get(t);
            if (v != null && !v.isEmpty() && !v.equals("…")) { anyTr = true; break; }
        }
        boolean showSrc, showTr;
        if ("original".equals(mode)) { showSrc = true; showTr = false; }
        else if ("translation".equals(mode)) { showTr = !ts.isEmpty(); showSrc = ts.isEmpty() || !anyTr; }
        else { showSrc = true; showTr = !ts.isEmpty(); }

        {
            String shown = typedSrc(e);
            if (e.src != null && shown.length() < e.src.length()) setTextTyping(e.tvSrc, shown);   // وسطِ تایپ: سبک (بدون استایل/لی‌اوتِ سنگین)
            else setTextIfChanged(e.tvSrc, shown);
        }
        e.srcRow.setVisibility(showSrc && !e.src.isEmpty() ? View.VISIBLE : View.GONE);

        for (String t : ts) {
            if (!e.rowBox.containsKey(t)) makeRow(e, t);   // created in target order -> stable order on screen
            LinearLayout row = e.rowBox.get(t);
            String v = e.tr.get(t);
            boolean has = v != null && !v.isEmpty();
            row.setVisibility(showTr && has ? View.VISIBLE : View.GONE);
            if (has) setTextIfChanged(e.rowText.get(t), v);
        }
        for (Map.Entry<String, LinearLayout> r : e.rowBox.entrySet()) {
            if (!ts.contains(r.getKey())) r.getValue().setVisibility(View.GONE);
        }
    }

    /** متنِ بدونِ تغییر دوباره ست نمی‌شود، و متنی که کاربر دارد انتخابش می‌کند (یا کادرِ لغتش باز است) دست‌نخورده می‌ماند. */
    private void setTextTyping(TextView tv, String v) {
        if (tv == null || v == null) return;
        if (tv == cardSrcTv || tv == selectingTv || tv == speakTv) return;
        boolean first = tv.length() == 0;
        tv.setText(v);
        if (first) applyStyle(tv);          // استایلِ کامل فقط برای حرفِ اول و موقعِ تمام شدنِ تایپ (setTextIfChanged)
    }

    private void setTextIfChanged(TextView tv, String v) {
        if (tv == null || v == null) return;
        if (tv == cardSrcTv || tv == selectingTv || tv == speakTv) return;
        CharSequence cur = tv.getText();
        if (!(cur instanceof Spanned) && cur.toString().equals(v)) return;
        tv.setText(v);
        applyStyle(tv);
    }

    private void updateScrollFreeze() {
        if (scroll == null) return;
        scroll.frozen = selectingTv != null || speakTv != null
                || (wordCard != null && wordCard.getVisibility() == View.VISIBLE);
    }

    private void refreshRecentEntries() {
        for (int i = Math.max(0, history.size() - 6); i < history.size(); i++) renderEntry(history.get(i));
    }

    private void setTranslation(Entry e, String lang, String text, String fromSrc) {
        final String before = e.tr.get(lang);
        e.tr.put(lang, text == null ? "" : text);
        e.trSrc.put(lang, fromSrc == null ? "" : fromSrc);
        renderEntry(e);
        afterChange();
        softSwap(e, lang, before, text);
    }

    private static String stripDots(String v) {
        if (v == null) return "";
        v = v.trim();
        return v.endsWith("…") ? v.substring(0, v.length() - 1).trim() : v;
    }

    /** وقتی ترجمه‌ی نمایش‌داده‌شده واقعاً «بازنویسی» می‌شود (نه فقط ادامه‌دار)، نرم محو/ظاهر می‌شود تا ناگهان نپرد. */
    private void softSwap(Entry e, String lang, String before, String after) {
        try {
            final String b = stripDots(before), a = stripDots(after);
            if (b.isEmpty() || a.isEmpty() || a.equals(b) || a.startsWith(b) || b.startsWith(a)) return;
            final TextView tv = e.rowText.get(lang);
            if (tv == null || tv.getVisibility() != View.VISIBLE || tv == selectingTv || tv == cardSrcTv) return;
            tv.setAlpha(0.2f);
            tv.animate().alpha(1f).setDuration(280).start();
        } catch (Throwable ignored) {}
    }

    private void setTranslationSeq(Entry e, String lang, String text, String fromSrc, int id) {
        Integer a = e.applied.get(lang);
        if (a != null && id < a) return;     // an older answer must never overwrite a newer one
        e.applied.put(lang, id);
        setTranslation(e, lang, text, fromSrc);
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Live recognition -> translation into ALL target languages
    // ════════════════════════════════════════════════════════════════════════════

    private static String[] words(String s) {
        String t = s == null ? "" : s.trim();
        return t.isEmpty() ? new String[0] : t.split("\\s+");
    }

    private static String joinWords(String[] w, int from, int to) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < to; i++) { if (i > from) sb.append(' '); sb.append(w[i]); }
        return sb.toString();
    }

    // ───────── ✍️ تایپِ حرف‌به‌حرفِ متنِ زنده ─────────
    private final java.util.LinkedHashSet<Entry> typing = new java.util.LinkedHashSet<>();
    private boolean typeScheduled = false;
    private final Runnable typeRunnable = () -> {
        typeScheduled = false;
        for (Entry e : new ArrayList<>(typing)) {
            int len = e.src == null ? 0 : e.src.length();
            if (e.box == null || e.shownChars >= len) { typing.remove(e); continue; }
            int back = len - e.shownChars;
            e.shownChars += Math.max(1, (back + 2) / 3);   // عقب‌افتادگی خیلی سریع جبران می‌شه (~۰٫۱ ثانیه)
            renderEntry(e);                       // اگه هنوز عقبه، typedSrc دوباره اضافه‌اش می‌کنه
        }
        if (!typing.isEmpty()) scheduleType();
        queueYtRefresh();
    };

    private void scheduleType() {
        if (typeScheduled) return;
        typeScheduled = true;
        main.postDelayed(typeRunnable, 16);
    }

    /** متنِ اصلیِ خطِ زنده: فقط تا حرفِ «رسیده» نشون داده می‌شه و بقیه یکی‌یکی ظاهر می‌شن. */
    private String typedSrc(Entry e) {
        String full = e.src == null ? "" : e.src;
        if (e.shownChars == Integer.MAX_VALUE) return full;
        if (full.isEmpty()) return full;
        if (e.shownChars >= full.length()) { e.shownChars = full.length(); return full; }
        if (e.shownChars < 1) e.shownChars = 1;
        int cut = e.shownChars;
        if (cut < full.length() && Character.isHighSurrogate(full.charAt(cut - 1))) cut++;
        typing.add(e);
        scheduleType();
        return full.substring(0, cut);
    }

    private void cancelLivePending() {
        main.removeCallbacks(srcRenderRunnable);
        srcRenderScheduled = false;
        main.removeCallbacks(pauseCommitRunnable);
        pendingHyp = "";
    }

    /** هر تکانِ تشخیصِ گفتار فقط «آخرین فرضیه» را ذخیره می‌کند؛ نمایش با ریتمِ ثابت و نرم به‌روز می‌شود. */
    private void onPartialText(final String raw) {
        if (wm == null || bubble == null || raw == null || raw.isEmpty()) return;
        if (asrMuted()) return;
        wakeFromIdle();
        noteDetected(raw);                                // 🌐 زبان را پیش از ساختنِ خطِ زنده تشخیص بده
        trackSpeechRate(raw);
        final String text = stripConsumed(raw);          // بخشِ قبلاً‌بسته‌شده (خط‌های جدا) دوباره نمایش داده نشود
        if (text.isEmpty()) return;
        pendingHyp = text;
        if (live == null) live = newLiveEntry();
        clearStatus();
        long wait = lastSrcRenderAt + SRC_RENDER_MS - SystemClock.uptimeMillis();
        if (wait <= 0) {
            main.removeCallbacks(srcRenderRunnable);
            srcRenderScheduled = false;
            flushPartial(false);
        } else if (!srcRenderScheduled) {
            srcRenderScheduled = true;
            main.postDelayed(srcRenderRunnable, wait);
        }
        main.removeCallbacks(pauseCommitRunnable);
        main.postDelayed(pauseCommitRunnable, pauseMs());
    }

    private long pauseMs() {
        if (sherpaEngine instanceof WhisperEngine) return PAUSE_COMMIT_SONG_MS;
        if (!micEngine) return SRV_PAUSE_COMMIT_MS;       // حالت سرور: پیش‌نمایش‌ها فاصله دارند
        syncSentenceLang();
        long base = looksIncomplete(pendingHyp) ? SENT_PAUSE_INCOMPLETE_MS : SENT_PAUSE_MS;
        return Math.round(base * paceFactor());
    }

    // ── مکثِ تطبیقی: گوینده‌ی کند مکثِ بلندتری بین جمله‌ها دارد، گوینده‌ی تند مکثِ کوتاه‌تری ──
    private double speechWps = 2.5;                      // میانگینِ سرعتِ گفتار (کلمه در ثانیه)؛ ~۲٫۵ = گفتگوی معمولی
    private long rateStartAt = 0, rateLastAt = 0;
    private int rateStartWords = 0, rateLastWords = 0;

    private void trackSpeechRate(String raw) {
        if (!cumulativeAsr() || raw == null) return;
        long now = SystemClock.uptimeMillis();
        int n = words(raw).length;
        if (rateStartAt == 0 || n < rateLastWords || now - rateLastAt > 1200) {   // شروعِ تازه یا مکث/ریست شدنِ متن
            rateStartAt = now; rateStartWords = n; rateLastWords = n; rateLastAt = now;
            return;
        }
        rateLastWords = n; rateLastAt = now;
        long dt = now - rateStartAt;
        int dw = n - rateStartWords;
        if (dt >= 1500 && dw >= 4) {
            double sample = dw * 1000.0 / dt;
            if (sample > 0.8 && sample < 6.0) speechWps = 0.75 * speechWps + 0.25 * sample;
            rateStartAt = now; rateStartWords = n;
        }
    }

    /** ۰٫۷ (گوینده‌ی تند) … ۱٫۶ (گوینده‌ی کند): ضریبِ مکثِ پایانِ جمله. */
    private double paceFactor() { return Math.max(0.7, Math.min(1.6, 2.5 / speechWps)); }

    /** تشخیصِ گفتارِ زنده (Sherpa/Google) متنِ «کلِ گفتارِ جاری» را می‌دهد؛ حالتِ آهنگ (Whisper) پنجره‌ای است و تجمعی نیست. */
    private boolean cumulativeAsr() {
        return !(sherpaEngine instanceof WhisperEngine);
    }

    private String stripConsumed(String raw) {
        if (consumedWords <= 0 || !cumulativeAsr()) return raw;
        String[] w = words(raw);
        if (w.length <= consumedWords) return "";
        return joinWords(w, consumedWords, w.length);
    }

    private Entry newLiveEntry() {
        Entry e = newEntry();
        e.aStart = Math.max(lastAudioEnd, SentenceAudio.now() - asrLagSamples());   // 🎙 آغازِ صدای این جمله (با کسرِ تأخیرِ تشخیص)
        e.shownChars = 0;                 // متنِ زنده حرف‌به‌حرف تایپ می‌شود
        try {
            YtMedia.Now n = YtMedia.nowPlaying(this);
            if (n != null && n.posMs >= 0) e.mediaPosMs = Math.max(0, n.posMs - 800);   // ~تأخیرِ تشخیصِ گفتار
        } catch (Throwable ignored) {}
        return e;
    }

    // ───────── جمله‌به‌جمله ─────────

    private static boolean endsSentence(String word) {
        if (word == null || word.isEmpty()) return false;
        int n = word.length();
        while (n > 0 && "\"'\u201D\u2019)\u00BB]".indexOf(word.charAt(n - 1)) >= 0) n--;
        if (n == 0) return false;
        char c = word.charAt(n - 1);
        if (c == '!' || c == '?' || c == '\u061F' || c == '\u2026') return true;
        if (c != '.') return false;
        String low = word.substring(0, n).toLowerCase(Locale.ROOT);
        if (ABBREVIATIONS.contains(low)) return false;
        if (n == 2 && Character.isUpperCase(word.charAt(0))) return false;        // initials: J.
        return true;
    }

    /** اولین پایانِ جمله در w[from, limit): اندیسِ «بعد از» کلمه‌ی پایانی، یا -1. */
    private static int sentenceEnd(String[] w, int from, int limit) {
        for (int i = from; i < limit && i < w.length; i++) if (endsSentence(w[i])) return i + 1;
        return -1;
    }

    /** برای جمله‌ی بلندِ بدونِ نقطه: نزدیک‌ترین ویرگول/نقطه، بعد حرفِ ربط، در بازه‌ی [from+6, from+maxLen]. */
    private static int pickLineBreak(String[] w, int from, int maxLen) {
        int hi = Math.min(w.length, from + maxLen);
        int lo = Math.min(hi, from + 6);
        for (int i = hi; i >= lo; i--) {
            String x = w[i - 1];
            char c = x.isEmpty() ? ' ' : x.charAt(x.length() - 1);
            if (",;:\u060C".indexOf(c) >= 0 || endsSentence(x)) return i;
        }
        for (int i = hi - 1; i >= lo; i--) {
            if (activeBreak.contains(w[i].toLowerCase(Locale.ROOT))) return i;
        }
        for (int i = hi; i >= lo; i--) {                               // برشِ اجباری: هرگز بعد از «the/of/to/and…» نه
            if (!endsDangling(w[i - 1])) return i;
        }
        return hi;
    }

    /** کلماتی که یک جمله با آن‌ها «تمام نمی‌شود»؛ اگر آخرِ متن بودند یعنی گوینده هنوز ادامه می‌دهد. */
    private static final java.util.Set<String> DANGLING = new HashSet<>(Arrays.asList(
            "a", "an", "the", "and", "but", "or", "so", "because", "that's", "which", "who", "whom", "whose",
            "when", "where", "while", "if", "though", "although", "until", "unless", "as", "than", "of", "to",
            "in", "on", "at", "by", "for", "with", "from", "into", "about", "over", "under", "between",
            "through", "during", "before", "after", "is", "are", "was", "were", "am", "be", "been", "being",
            "have", "has", "had", "do", "does", "did", "will", "would", "can", "could", "should", "shall",
            "may", "might", "must", "not", "my", "your", "his", "our", "their", "its", "some", "any", "very",
            "i", "we", "they", "he", "she", "i'm", "i've", "i'll", "i'd", "we're", "they're", "you're",
            "he's", "she's", "it's", "there's", "what", "how", "why", "also", "just", "even", "then"));

    // ── کلمه‌های «آویزان» و حرف‌ربط‌ها برای زبان‌های دیگر (فقط واژه‌هایی که تقریباً هرگز آخرِ جمله نمی‌آیند) ──
    private static java.util.Set<String> wset(String csv) {
        return new HashSet<>(Arrays.asList(csv.trim().split("\\s+")));
    }

    private static final java.util.Map<String, java.util.Set<String>> DANGLING_BY_LANG = new HashMap<>();
    private static final java.util.Map<String, java.util.Set<String>> BREAK_BY_LANG = new HashMap<>();
    static {
        DANGLING_BY_LANG.put("es", wset("el la los las un una unos unas y e o u pero que porque si como cuando donde mientras aunque de del a al en con por para sin sobre entre hasta desde mi tu su mis tus sus muy"));
        BREAK_BY_LANG.put("es", wset("y pero que porque cuando donde mientras aunque si como"));
        DANGLING_BY_LANG.put("fr", wset("le la les un une des du de et ou mais que qui dont si comme quand parce car à au aux en dans avec pour sans sur sous par mon ma mes ton ta tes son sa ses notre votre leur je tu il elle ne très"));
        BREAK_BY_LANG.put("fr", wset("et mais que qui dont quand parce car comme si"));
        DANGLING_BY_LANG.put("de", wset("der die das den dem des ein eine einen einem einer und oder aber dass weil wenn als ob von zu zum zur in im mit für auf an bei nach aus über unter durch gegen ohne um mein dein sein ihr unser ich du er wir sehr"));
        BREAK_BY_LANG.put("de", wset("und aber oder dass weil wenn als ob während obwohl damit"));
        DANGLING_BY_LANG.put("it", wset("il lo la i gli le un uno una e ed o ma che perché se come quando mentre di del della dei delle a al alla ai in nel nella con per su sul tra fra da mio tuo suo mia tua sua io tu lui lei noi voi non molto"));
        BREAK_BY_LANG.put("it", wset("e ed ma che perché quando mentre se come"));
        DANGLING_BY_LANG.put("pt", wset("o a os as um uma uns umas e ou mas que porque se como quando onde enquanto embora de do da dos das em no na nos nas com por para sem sobre entre até desde meu minha seu sua eu tu ele ela muito"));
        BREAK_BY_LANG.put("pt", wset("e mas que porque quando onde enquanto embora se como"));
        DANGLING_BY_LANG.put("nl", wset("de het een en of maar dat omdat als wanneer waar terwijl van in op met voor naar aan bij uit over door zonder mijn jouw zijn haar ik jij je hij zij wij zeer"));
        BREAK_BY_LANG.put("nl", wset("en maar of dat omdat als wanneer terwijl"));
        DANGLING_BY_LANG.put("ru", wset("и а но или что чтобы как если когда где пока хотя потому в на с со по к у о об от до из за для без при про над под между через мой твой его её их наш ваш я ты он она мы они не очень"));
        BREAK_BY_LANG.put("ru", wset("и а но или что чтобы как если когда где пока хотя потому"));
        DANGLING_BY_LANG.put("tr", wset("ve ile ama fakat ancak çünkü eğer veya bir bu şu ki"));
        BREAK_BY_LANG.put("tr", wset("ve ama fakat ancak çünkü eğer veya ki"));
        DANGLING_BY_LANG.put("ar", wset("في من على إلى الى عن مع أن إن لكن لأن أو ثم حتى كما لقد"));
        BREAK_BY_LANG.put("ar", wset("لكن لأن ثم حتى أو"));
        DANGLING_BY_LANG.put("fa", wset("و که از به در با را برای تا اگر اما ولی یا چون این آن یک بر بی"));
        BREAK_BY_LANG.put("fa", wset("و که اما ولی یا چون اگر تا"));
    }
    private static volatile java.util.Set<String> activeDangling = DANGLING;
    private static volatile java.util.Set<String> activeBreak = BREAK_BEFORE;
    private static volatile String sentenceLang = "en";

    /** قوانینِ «جمله ناتمام است» را با زبانِ گفتار هماهنگ می‌کند؛ زبانِ بدونِ فهرست (ژاپنی، چینی، …) فقط با نقطه‌گذاری/مکث/طولِ خط می‌شکند. */
    private void syncSentenceLang() {
        String l;
        try { l = (yt != null && yt.isActive()) ? yt.trackLang() : effectiveSource(); } catch (Throwable t) { l = "en"; }
        if (l == null) l = "";
        l = l.toLowerCase(Locale.ROOT);
        if (l.length() > 2) l = l.substring(0, 2);
        if (l.equals(sentenceLang)) return;
        sentenceLang = l;
        if (l.isEmpty() || l.equals("au") || l.equals("en")) {         // «auto» و انگلیسی: همان قوانینِ قبلی
            activeDangling = DANGLING; activeBreak = BREAK_BEFORE;
        } else {
            java.util.Set<String> d = DANGLING_BY_LANG.get(l), b = BREAK_BY_LANG.get(l);
            activeDangling = d != null ? d : new HashSet<String>();
            activeBreak = b != null ? b : new HashSet<String>();
        }
    }

    private static boolean endsDangling(String word) {
        if (word == null || word.isEmpty()) return false;
        char last = word.charAt(word.length() - 1);
        if (",.;:!?\u061F\u060C\u2026".indexOf(last) >= 0) return false;       // علامتِ پایان/ویرگول دارد
        String low = word.toLowerCase(Locale.ROOT).replace('\u2019', '\'');
        low = low.replaceAll("^[\"'(\\[]+|[\"')\\]]+$", "");
        return activeDangling.contains(low);
    }

    /** آیا متنِ زنده هنوز ناتمام به‌نظر می‌رسد؟ (خیلی کوتاه یا آخرش کلمه‌ی «آویزان») */
    private static boolean looksIncomplete(String text) {
        String[] w = words(text);
        if (w.length == 0) return false;
        return w.length < 4 || endsDangling(w[w.length - 1]);
    }

    /** متنِ چندجمله‌ای/بلند را به خط‌هایی (هر کدام یک جمله) می‌شکند. */
    private static List<String> splitSentences(String text) {
        final ArrayList<String> out = new ArrayList<>();
        final String[] w = words(text);
        int from = 0;
        while (from < w.length) {
            int end = sentenceEnd(w, from, w.length);
            if (end < 0) break;
            out.add(joinWords(w, from, end));
            from = end;
        }
        while (w.length - from > MAX_LINE_WORDS + 4) {
            int end = pickLineBreak(w, from, MAX_LINE_WORDS);
            if (end <= from) break;
            out.add(joinWords(w, from, end));
            from = end;
        }
        if (from < w.length) out.add(joinWords(w, from, w.length));
        if (out.isEmpty()) out.add(text == null ? "" : text.trim());
        return out;
    }

    private void commitSentences(String text) { commitSentences(text, -1f); }

    /**
     * liveFrac در (0,1): گوینده هنوز ادامه می‌دهد و فقط این کسر از گفتارِ تشخیص‌داده‌شده بسته می‌شود؛
     * وگرنه همه‌ی صدا تا همین لحظه مالِ این متن است. صدا بینِ جمله‌ها به نسبتِ تعدادِ کلمه‌ها تقسیم می‌شود.
     */
    private void commitSentences(String text, float liveFrac) {
        final List<String> parts = new ArrayList<>();
        int totalWords = 0;
        for (String part : splitSentences(text)) {
            if (part.trim().isEmpty()) continue;
            parts.add(part);
            totalWords += Math.max(1, words(part).length);
        }
        if (parts.isEmpty()) return;
        final long now = SentenceAudio.now();
        final Entry cur = live;
        final long s = (cur != null && cur.aStart >= 0) ? cur.aStart
                : Math.max(lastAudioEnd, now - 4L * SAMPLE_RATE);
        long en = now;
        if (liveFrac > 0f && liveFrac < 1f)
            en = s + (long) (Math.max(0, now - asrLagSamples() - s) * (double) liveFrac);
        int before = 0;
        for (String part : parts) {
            int w = Math.max(1, words(part).length);
            partAStart = s + (long) ((en - s) * (before / (double) totalWords));
            partAEnd = s + (long) ((en - s) * ((before + w) / (double) totalWords));
            before += w;
            commitSentence(part);
            partAStart = partAEnd = -1;
        }
    }

    /** مکثِ بلند: جمله‌ی جاری همین‌جا بسته می‌شود و گفتارِ بعدی در خطِ تازه می‌آید. */
    private void endSentenceByPause() {
        syncSentenceLang();
        rateStartAt = 0;                                    // جمله بسته شد؛ اندازه‌گیریِ سرعت از جمله‌ی بعد
        final String hyp = pendingHyp;
        if (hyp == null || hyp.isEmpty()) return;
        final int n = words(hyp).length;
        consumedWords += n;
        commitSentences(hyp);
    }

    /** وسطِ گفتار: اگر نقطه/علامتِ پایانی در متنِ زنده آمد یا خط خیلی بلند شد، بخشِ اول به خطِ جدا بسته می‌شود. */
    private boolean splitLiveIfNeeded(String next) {
        final String[] w = words(next);
        final int n = w.length;
        int end = sentenceEnd(w, 0, n - 2);                   // علامتِ پایان در دو کلمه‌ی آخر هنوز ممکن است عوض شود
        if (end < 0 && n >= MAX_LINE_WORDS + TAIL_GUARD_WORDS) end = pickLineBreak(w, 0, MAX_LINE_WORDS);
        if (end <= 0 || end >= n) return false;
        final String head = joinWords(w, 0, end);
        final String tail = joinWords(w, end, n);
        consumedWords += end;
        commitSentences(head, end / (float) n);                                // live = null؛ تایمرها هم پاک می‌شوند
        live = newLiveEntry();
        live.src = tail;
        pendingHyp = tail;
        lastSrcRenderAt = SystemClock.uptimeMillis();
        renderEntry(live);
        afterChange();
        main.postDelayed(pauseCommitRunnable, pauseMs());
        if (!activeTargets().isEmpty()) commitChunks(live, false);
        flushPartial(false);                                  // ممکن است باقیِ متن هم جمله‌ی کامل داشته باشد
        return true;
    }

    private void flushPartial(boolean pause) {
        syncSentenceLang();
        final Entry e = live;
        if (e == null || pendingHyp.isEmpty()) return;
        final String next = smoothHyp(e.src, pendingHyp);
        lastSrcRenderAt = SystemClock.uptimeMillis();
        if (cumulativeAsr() && splitLiveIfNeeded(next)) return;
        if (!next.equals(e.src)) {
            e.src = next;
            renderEntry(e);
            afterChange();
        }
        if (!activeTargets().isEmpty()) { commitChunks(e, pause); requestTail(e); }
    }

    /** اصلاحِ کوچکِ انتهای جمله (مثلاً beings↔being) متنِ روی صفحه را عقب‌وجلو نمی‌کند. */
    private static String smoothHyp(String shown, String hyp) {
        if (shown == null || shown.isEmpty() || hyp.startsWith(shown)) return hyp;
        String[] a = words(shown), b = words(hyp);
        int common = 0;
        while (common < a.length && common < b.length && a[common].equals(b[common])) common++;
        if (b.length <= a.length && a.length - common <= 2 && b.length - common <= 2) return shown;
        return hyp;
    }

    // ───────── تکه‌تکه کردنِ جمله‌ی زنده ─────────
    // کلمه‌های پایدار (همه به‌جز ۳ کلمه‌ی آخر) در تکه‌های ۷ تا ۱۲ کلمه‌ای «قفل» و هر تکه فقط یک‌بار ترجمه می‌شود.
    // ترجمه‌ی قبلی هیچ‌وقت عوض نمی‌شود؛ فقط ترجمه‌ی تکه‌ی بعدی به انتهایش اضافه می‌شود → دیگر نمی‌پرد.

    private void reconcileChunks(Entry e, String[] w) {
        int keep = 0, kept = 0;
        for (int i = 0; i < e.chunkSrc.size(); i++) {
            String[] cw = words(e.chunkSrc.get(i));
            if (kept + cw.length > w.length) break;
            boolean same = true;
            for (int j = 0; j < cw.length; j++) {
                if (!cw[j].equals(w[kept + j])) { same = false; break; }
            }
            if (!same) break;
            kept += cw.length;
            keep = i + 1;
        }
        while (e.chunkSrc.size() > keep) removeChunk(e, e.chunkSrc.size() - 1);
        e.committedWords = kept;
    }

    private void removeChunk(Entry e, int idx) {
        e.chunkSrc.remove(idx);
        for (ArrayList<String> l : e.chunkTr.values()) if (idx < l.size()) l.remove(idx);
    }

    private static int pickBreak(String[] w, int from, int limit, boolean flushAll) {
        if (flushAll && limit - from <= CHUNK_MAX_WORDS + 2) return limit;
        int maxEnd = Math.min(limit, from + CHUNK_MAX_WORDS);
        for (int i = maxEnd; i >= from + 3; i--) {                     // اولویت: آخرین نقطه/ویرگول
            String x = w[i - 1];
            char c = x.isEmpty() ? ' ' : x.charAt(x.length() - 1);
            if (",.;:?!\u061F\u060C".indexOf(c) >= 0) return i;
        }
        for (int i = maxEnd - 1; i >= from + 4; i--) {                 // بعد: قبل از حرفِ ربط
            if (activeBreak.contains(w[i].toLowerCase(Locale.ROOT))) return i;
        }
        for (int i = maxEnd; i >= from + CHUNK_MIN_WORDS; i--) {       // تکه را به «the/of/to/and…» ختم نکن
            if (!endsDangling(w[i - 1])) return i;
        }
        return maxEnd;
    }

    private void commitChunks(Entry e, boolean flushAll) {
        final String[] w = words(e.src);
        reconcileChunks(e, w);
        int limit = flushAll ? w.length : w.length - TAIL_GUARD_WORDS;
        if (flushAll) {                                           // مکثِ کوتاه وسطِ جمله: کلماتِ آویزانِ آخر قفل/ترجمه نشوند
            while (limit > e.committedWords + 1 && endsDangling(w[limit - 1])) limit--;
        }
        while (true) {
            int from = e.committedWords;
            if (limit - from < (flushAll ? 1 : CHUNK_MIN_WORDS)) break;
            int end = pickBreak(w, from, limit, flushAll);
            if (end <= from) break;
            addChunk(e, joinWords(w, from, end));
            e.committedWords = end;
        }
    }

    private void addChunk(Entry e, String text) {
        final int idx = e.chunkSrc.size();
        e.chunkSrc.add(text);
        for (String lang : activeTargets()) {
            ArrayList<String> l = e.chunkTr.get(lang);
            if (l == null) { l = new ArrayList<>(); e.chunkTr.put(lang, l); }
            int have = l.size();
            while (l.size() <= idx) l.add("");
            for (int i = have; i <= idx; i++) requestChunk(e, i, e.chunkSrc.get(i), lang);
        }
    }

    /** کش → سرویس‌های رایگان (+ بررسیِ مشکوک بودن/AI) → در آخر مترجمِ آفلاین. */
    private void requestChunk(final Entry e, final int idx, final String text, final String lang) {
        final String srcLang = effectiveSource();
        final boolean first = lang.equals(primaryTarget());
        String hit = TransCache.get(this).get(srcLang, lang, text);
        if (hit != null && !LiveTranslator.looksLikelyMistranslated(text, hit, lang, srcLang)) {
            applyChunk(e, idx, text, lang, hit);
            return;
        }
        if (!hasInternet()) { localChunk(e, idx, text, lang, first); return; }
        try {
            netPartial.execute(() -> {
                String out = null;
                try { out = LiveTranslator.translate(this, HTTP_FAST, text, srcLang, lang, aiBackend); }
                catch (Exception ex) { Log.d(TAG, "chunk translate failed: " + ex); }
                final String res = out;
                main.post(() -> {
                    if (res != null) applyChunk(e, idx, text, lang, res);
                    else localChunk(e, idx, text, lang, first);
                });
            });
        } catch (Exception ex) { localChunk(e, idx, text, lang, first); }
    }

    private void localChunk(final Entry e, final int idx, final String text, final String lang, boolean first) {
        final Translator tr = localTr;
        if (first && localReady && tr != null) {
            tr.translate(text)
                    .addOnSuccessListener(o -> applyChunk(e, idx, text, lang, o))
                    .addOnFailureListener(x -> applyChunk(e, idx, text, lang, null));
        } else {
            applyChunk(e, idx, text, lang, null);
        }
    }

    private void applyChunk(Entry e, int idx, String text, String lang, String out) {
        if (idx >= e.chunkSrc.size() || !e.chunkSrc.get(idx).equals(text)) return;     // تکه در این بین عوض/حذف شده
        ArrayList<String> l = e.chunkTr.get(lang);
        if (l == null || idx >= l.size()) return;
        l.set(idx, (out == null || out.trim().isEmpty()) ? CHUNK_FAIL : out.trim());
        refreshLiveTr(e, lang);
        if (e == live) requestTail(e);
    }

    /** ترجمه‌ی نمایش‌داده‌شده = تکه‌های قفل‌شده + ترجمه‌ی زنده‌ی دنباله‌ی جمله. */
    private void refreshLiveTr(Entry e, String lang) {
        String ts = e.trSrc.get(lang);
        if (ts != null && !ts.isEmpty()) return;          // ترجمه‌ی کاملِ جمله قبلاً نشسته؛ تکه‌ها بازنویسی‌اش نکنند
        ArrayList<String> l = e.chunkTr.get(lang);
        StringBuilder sb = new StringBuilder();
        boolean pending = false;
        if (l != null) {
            for (String v : l) {
                if (v.isEmpty()) { pending = true; break; }
                if (v.equals(CHUNK_FAIL)) continue;
                if (sb.length() > 0) sb.append(' ');
                sb.append(v);
            }
        }
        String shown = e.tr.get(lang);
        boolean hasShown = shown != null && !shown.isEmpty() && !shown.equals("…");
        if (pending && hasShown) return;                  // تکه‌ی بعدی در راه است؛ ترجمه‌ی روی صفحه کوتاه نشود
        if (!pending) {
            String tt = e.tailTr.get(lang);
            Integer tf = e.tailTrFrom.get(lang);
            if (e == live && tt != null && !tt.isEmpty() && tf != null && tf == e.committedWords) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(tt);
            }
        }
        if (sb.length() == 0) return;
        String out = e == live ? sb + " …" : sb.toString();
        if (out.equals(shown)) return;
        e.tr.put(lang, out);
        e.trSrc.put(lang, "");
        renderEntry(e);
        afterChange();
    }

    /** ترجمه‌ی فوریِ «دنباله‌ی» جمله‌ی زنده (بدونِ منتظر ماندن برای تکمیلِ تکه‌ها). */
    private void requestTail(final Entry e) {
        if (e == null || e != live) return;
        final List<String> ts = activeTargets();
        if (ts.isEmpty()) return;
        final String[] w = words(e.src);
        final int from = e.committedWords;
        if (from >= w.length) { e.tailTr.clear(); e.tailAsked.clear(); return; }
        final String tail = joinWords(w, from, w.length);
        final long now = SystemClock.uptimeMillis();
        if (now - e.tailLastAt < TAIL_MIN_MS) {
            if (!e.tailScheduled) {
                e.tailScheduled = true;
                main.postDelayed(() -> { e.tailScheduled = false; if (e == live) requestTail(e); },
                        TAIL_MIN_MS - (now - e.tailLastAt) + 10);
            }
            return;
        }
        final String srcLang = effectiveSource();
        for (final String lang : ts) {
            Integer askedFrom = e.tailTrFrom.get(lang);
            if (tail.equals(e.tailAsked.get(lang)) && askedFrom != null && askedFrom == from) continue;
            if (Boolean.TRUE.equals(e.tailBusy.get(lang))) continue;     // وقتی جوابِ قبلی رسید، دوباره بررسی می‌شود
            e.tailLastAt = now;
            e.tailAsked.put(lang, tail);
            final boolean first = lang.equals(primaryTarget());
            String hit = TransCache.get(this).get(srcLang, lang, tail);
            if (hit != null && !LiveTranslator.looksLikelyMistranslated(tail, hit, lang, srcLang)) {
                applyTail(e, lang, from, hit);
                continue;
            }
            e.tailBusy.put(lang, true);
            if (!hasInternet()) {
                final Translator tr = localTr;
                if (first && localReady && tr != null) {
                    tr.translate(tail)
                            .addOnSuccessListener(o -> { e.tailBusy.put(lang, false); applyTail(e, lang, from, o); })
                            .addOnFailureListener(x -> e.tailBusy.put(lang, false));
                } else e.tailBusy.put(lang, false);
                continue;
            }
            try {
                netPartial.execute(() -> {
                    String out = null;
                    try { out = LiveTranslator.translate(this, HTTP_FAST, tail, srcLang, lang, aiBackend); }
                    catch (Exception ex) { Log.d(TAG, "tail translate failed: " + ex); }
                    final String res = out;
                    main.post(() -> {
                        e.tailBusy.put(lang, false);
                        if (res != null) applyTail(e, lang, from, res);
                        if (e == live) requestTail(e);
                    });
                });
            } catch (Exception ex) { e.tailBusy.put(lang, false); }
        }
    }

    private void applyTail(Entry e, String lang, int from, String out) {
        if (out == null || out.trim().isEmpty()) return;
        e.tailTr.put(lang, out.trim());
        e.tailTrFrom.put(lang, from);
        refreshLiveTr(e, lang);
    }

    /** ترجمه‌ی تکه‌های آماده‌ی پشتِ‌سرهم. completeOnly=true: اگر حتی یک تکه آماده/موفق نباشد null. */
    private static String joinChunks(Entry e, String lang, boolean completeOnly) {
        ArrayList<String> l = e.chunkTr.get(lang);
        if (l == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            String v = l.get(i);
            if (v.isEmpty()) { if (completeOnly) return null; break; }
            if (v.equals(CHUNK_FAIL)) { if (completeOnly) return null; continue; }
            if (sb.length() > 0) sb.append(' ');
            sb.append(v);
        }
        return sb.toString();
    }

    private final LiveTranslator.Ai aiBackend = new LiveTranslator.Ai() {
        @Override public String translate(String text, String tgt) throws Exception {
            return BubbleService.this.translate(text, "", tgt);
        }

        @Override public String verify(String text, String tgt, String draft) throws Exception {
            String name = LANG_NAMES.containsKey(tgt) ? LANG_NAMES.get(tgt) : tgt;
            String prompt = "Source text: \"" + text + "\"\n"
                    + "Draft translation into " + name + ": \"" + draft + "\"\n\n"
                    + "Is the draft an accurate, complete translation? If yes, reply with EXACTLY: OK\n"
                    + "If no, reply with ONLY the corrected translation \u2014 no quotes, no explanation, nothing else.";
            JSONObject body = new JSONObject();
            body.put(GENERATE_PROMPT_KEY, prompt);
            String resp = postBytes(HTTP_FAST, 1, WORKER_BASE + GENERATE_PATH,
                    "application/json; charset=utf-8", body.toString().getBytes(StandardCharsets.UTF_8));
            return extractText(resp);
        }
    };

    private void onFinalText(final String raw) {
        if (wm == null || bubble == null || raw == null || raw.trim().isEmpty()) return;
        if (asrMuted()) return;
        wakeFromIdle();
        // the server sometimes returns the same final text several times - show it once
        if (raw.equals(lastFinalText)) {
            Log.d(TAG, "skipping duplicate final text");
            return;
        }
        lastFinalText = raw;
        noteDetected(raw);                                // 🌐 پیش از ترجمه
        final String text = stripConsumed(raw);           // قسمت‌هایی که با مکث قبلاً خطِ جدا شده‌اند تکرار نشود
        consumedWords = 0;                                // گفتارِ جاری تمام شد
        if (text.trim().isEmpty()) {
            final Entry le = live;
            cancelLivePending();
            if (le != null && le.src != null && !le.src.trim().isEmpty()) commitSentences(le.src);
            return;
        }
        commitSentences(text);
    }

    /** یک جمله‌ی کامل: خطِ زنده بسته و ترجمه‌ی نهایی‌اش گرفته می‌شود. */
    private void commitSentence(final String text) {
        if (wm == null || bubble == null || text == null || text.trim().isEmpty()) return;

        cancelLivePending();
        lastPartialSrc = "";
        final String ctxPrev = prevFinalText;
        prevFinalText = text;
        clearStatus();

        final Entry e = live != null ? live : newLiveEntry();
        live = null;                      // this sentence is finished; the next partial starts a new line
        e.src = text;
        attachAudio(e, partAStart, partAEnd);             // 🎙 صدای خودِ گوینده برای ↺

        final List<String> ts = activeTargets();
        if (ts.isEmpty()) { renderEntry(e); afterChange(); return; }

        final String srcLang = effectiveSource();
        final boolean online = hasInternet();
        final String offlineMsg = msg("ترجمه در دسترس نیست (آفلاین)", "No translation (offline)");
        final String[] fw = words(text);
        reconcileChunks(e, fw);
        for (int i = 0; i < ts.size(); i++) {
            final String lang = ts.get(i);
            // اگر تکه‌های زنده کلِ جمله را پوشانده‌اند و ترجمه‌شان مشکوک نیست، همان‌ها نهایی می‌شوند → هیچ پرشی در پایانِ جمله نیست
            if (fw.length > 0 && e.committedWords == fw.length) {
                String joined = joinChunks(e, lang, true);
                if (joined != null && !joined.isEmpty()
                        && !LiveTranslator.looksLikelyMistranslated(text, joined, lang, srcLang)) {
                    setTranslation(e, lang, joined, text);
                    continue;
                }
            }
            String have = e.tr.get(lang);
            boolean haveGood = have != null && !have.isEmpty() && !have.equals("…");
            if (haveGood && text.equals(e.trSrc.get(lang))) continue;   // live translation already matches the final text
            if (haveGood) {
                // ترجمه‌ی تکه‌ایِ فعلی را نگه دار (علامتِ «…»ی انتها را بردار) تا ترجمه‌ی کاملِ جمله برسد
                String cur = have.endsWith(" …") ? have.substring(0, have.length() - 2) : have;
                if (!cur.equals(have)) e.tr.put(lang, cur);
            }
            if (!haveGood) e.tr.put(lang, "…");
            if (!online) {
                final Translator tr = localTr;
                if (i == 0 && localReady && tr != null) {
                    tr.translate(text)
                            .addOnSuccessListener(out -> setTranslation(e, lang, out, text))
                            .addOnFailureListener(x -> setTranslation(e, lang, offlineMsg, text));
                } else {
                    e.tr.put(lang, offlineMsg);
                }
                continue;
            }
            submitTranslate(e, text, srcLang, lang, ctxPrev);
        }
        renderEntry(e);
        afterChange();
    }

    private void submitTranslate(final Entry e, final String text, final String srcLang,
                                 final String lang, final String ctxPrev) {
        if (textPending.get() >= MAX_TEXT_PENDING) {
            Log.w(TAG, "dropping translation (backlog)");
            e.tr.put(lang, "");
            return;
        }
        final int id = ++reqCounter;
        textPending.incrementAndGet();
        try {
            netTr.execute(() -> {
                String out;
                try { out = translateOne(text, srcLang, lang, ctxPrev); }
                catch (Exception ex) { Log.w(TAG, "translate failed", ex); out = netErrText(ex); }
                final String shown = out;
                textPending.decrementAndGet();
                main.post(() -> setTranslationSeq(e, lang, shown, text, id));
            });
        } catch (Exception ex) { textPending.decrementAndGet(); }
    }

    /** Free services first (Google -> MyMemory -> Lingva -> Libre); the app's AI worker is the last resort. */
    private String translateOne(String text, String srcLang, String tgt, String ctxPrev) throws Exception {
        // کش → سرویس‌های رایگان → (اگر مشکوک بود) بازبینی/ترجمه با AI → کشِ نتیجه‌ی تأییدشده
        return LiveTranslator.translate(this, HTTP_FAST, text, srcLang, tgt, aiBackend);
    }

    // ───────── 📺 حالت یوتیوب: روشن/خاموش و اتصال به پنل ─────────

    private void toggleYoutube() {
        if (yt != null && yt.isActive()) stopYoutube(true);
        else startYoutube(true);
    }

    private void updateYtButton() {
        boolean on = yt != null && yt.isActive();
        updateModeSwitch();
        if (tvYtRestart != null) tvYtRestart.setVisibility(on && !ytFullMode ? View.VISIBLE : View.GONE);
        if (tvYtPause != null) {
            tvYtPause.setVisibility(on && !ytFullMode ? View.VISIBLE : View.GONE);
            tvYtPause.setText(on && yt != null && !yt.isPlaying() ? "\u25B6" : "\u23F8");
            tvYtPause.setContentDescription(msg("مکث / ادامه‌ی پخش", "Pause / resume"));
        }
        if (tvYtLoop != null) {
            boolean looping = on && yt != null && yt.isVideoLooping();
            tvYtLoop.setVisibility(on && !ytFullMode ? View.VISIBLE : View.GONE);
            tvYtLoop.setTextColor(looping ? COLOR_GOLD : Color.WHITE);
            tvYtLoop.setAlpha(looping ? 1f : 0.75f);
        }
        if (tvYtAll != null) {
            tvYtAll.setVisibility(on && ytFullMode ? View.VISIBLE : View.GONE);
            tvYtAll.setText(fullLoop ? "\u23F9" : "\uD83D\uDD02");
            tvYtAll.setTextColor(fullLoop ? COLOR_GOLD : Color.WHITE);
        }
        if (tvSave != null) tvSave.setVisibility(View.VISIBLE);
    }

    private void saveCurrent() {
        if (yt != null && yt.isActive()) saveYoutube();
        else saveLive();
    }

    /**
     * 💾 ترجمه‌ی زنده (صوتِ پخش‌شده از هر پلیر/برنامه): همه‌ی جمله‌های تاریخچه + ترجمه‌ها → «داستان‌های ذخیره‌شده».
     * اگر دسترسیِ اعلان‌ها روشن باشد، منبعِ صدا (برنامه، عنوانِ فایل، لینک) و «موقعیتِ زمانیِ» هر جمله در همان فایل هم
     * ذخیره می‌شود (مثل زیرنویسِ ذخیره‌شده‌ی یوتیوب)، و ذخیره‌ی دوباره‌ی همان فایل خط‌ها را ادغام می‌کند.
     */
    private void saveLive() {
        try {
            final String offFa = "ترجمه در دسترس نیست (آفلاین)", offEn = "No translation (offline)";
            final List<String> ts = activeTargets();
            if (history.isEmpty()) { showNotice(msg("هنوز چیزی برای ذخیره نیست", "Nothing to save yet")); return; }
            if (liveKey == null) {
                liveStartMs = history.get(0).createdAt;
                liveKey = "live-" + liveStartMs;
            }
            final ArrayList<Entry> snap = new ArrayList<>(history);
            int counted = 0, withPos = 0;
            for (Entry e : snap) {
                if (e == live || e.src == null || e.src.trim().isEmpty()) continue;
                counted++;
                if (e.mediaPosMs >= 0) withPos++;
            }
            YtMedia.Now np = null;
            try { np = YtMedia.nowPlaying(this); } catch (Throwable ignored) {}
            // برنامه‌هایی مثلِ اینستاگرام/تیک‌تاک/تلگرام معمولاً MediaSession (عنوان) نمی‌دهند؛ اگر چیزی «در حالِ پخش»
            // نبود، برنامه‌ی مبدأ را از روی آخرین برنامه‌ی جلوی صفحه می‌گیریم (فقط نامِ برنامه، نه محتوا).
            if (np != null && (np.title == null || np.title.isEmpty())) np.title = (np.app == null || np.app.isEmpty()) ? np.pkg : np.app;
            final boolean hasSource = np != null && np.title != null && !np.title.isEmpty();
            final boolean useMedia = hasSource && counted > 0 && withPos * 5 >= counted * 4;   // ≥۸۰٪ جمله‌ها موقعیتِ پلیر دارند

            // 🔒 کپی‌رایت: متنِ صدا/ویدیو (و ترجمه‌اش) ذخیره نمی‌شود؛ فقط منبع (برنامه + عنوان + لینک) تا
            //    کاربر بعداً همان برنامه/لینک را دوباره باز کند.
            JSONArray lines = new JSONArray();
            if (!hasSource) {
                // اینستاگرام/تیک‌تاک/… اطلاعاتِ پخش نمی‌دهند → لینکِ کپی‌شده‌ی پست را (Share ← Copy link) از کلیپ‌بورد می‌خوانیم.
                // 1) همین الان یک ردیفِ «بدونِ لینک» ذخیره می‌شود (زمان + چند کلمه‌ی اولِ گفتار فقط برای شناختنِ آن)، تا چیزی گم نشود.
                // 2) اگر لینکِ پست کپی شده باشد (Share ← Copy link)، همان ردیف با لینک کامل می‌شود. کلیپ‌بورد فقط از یک
                //    Activityِ دارای فوکوس خوانده می‌شود؛ ShareReceiverActivity آن را یک لحظه باز می‌کند و برمی‌گردد.
                String snippet = "";
                for (Entry e : snap) {
                    if (e == live || e.src == null || e.src.trim().isEmpty()) continue;
                    String[] ws = words(e.src);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < ws.length && i < 6; i++) { if (i > 0) sb.append(' '); sb.append(ws[i]); }
                    snippet = sb.toString() + (ws.length > 6 ? "…" : "");
                    break;
                }
                java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("MM/dd HH:mm", Locale.US);
                String ptitle = msg("ویدیوی ذخیره‌شده", "Saved video") + " · " + tf.format(new java.util.Date())
                        + (snippet.isEmpty() ? "" : " — " + snippet);
                long pnow = System.currentTimeMillis();
                java.text.SimpleDateFormat pfmt = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
                pfmt.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                String psrc = effectiveSource();
                JSONObject pitem = new JSONObject()
                        .put("key", liveKey)
                        .put("live", true)
                        .put("title", ptitle)
                        .put("channel", msg("منبعِ نامشخص (بدونِ لینک)", "Unknown source (no link)"))
                        .put("lang", psrc == null || "auto".equals(psrc) ? "en" : psrc)
                        .put("targets", new JSONArray(ts))
                        .put("rev", pnow)
                        .put("savedAt", pfmt.format(new java.util.Date(pnow)))
                        .put("lines", new JSONArray());
                boolean pok = YtSaved.add(this, pitem);
                try {
                    Intent ci = new Intent(this, ShareReceiverActivity.class)
                            .putExtra(ShareReceiverActivity.EXTRA_FROM_CLIP, true)
                            .putExtra(ShareReceiverActivity.EXTRA_REPLACE_KEY, liveKey)
                            .putExtra(ShareReceiverActivity.EXTRA_TITLE, ptitle)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(ci);
                } catch (Throwable ignored) {}
                showNotice(pok
                        ? msg("ذخیره شد ✓ (بدونِ لینک). برای لینک: در همان برنامه Share ← Copy link بزن و دوباره دکمه‌ی ذخیره",
                              "Saved ✓ (no link). For the link: Share → Copy link in that app, then tap Save again")
                        : msg("ذخیره نشد", "Save failed"));
                return;
            }
            long now = System.currentTimeMillis();
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            fmt.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            String src = effectiveSource();
            JSONObject item = new JSONObject()
                    .put("key", liveKey)
                    .put("live", true)
                    .put("title", msg("ترجمه‌ی زنده", "Live translation"))
                    .put("lang", src == null || "auto".equals(src) ? "en" : src)
                    .put("targets", new JSONArray(ts))
                    .put("rev", now)
                    .put("savedAt", fmt.format(new java.util.Date(now)))
                    .put("lines", lines);
            if (hasSource) {
                JSONObject so = new JSONObject()
                        .put("app", np.app == null ? "" : np.app)
                        .put("pkg", np.pkg == null ? "" : np.pkg)
                        .put("title", np.title)
                        .put("artist", np.artist == null ? "" : np.artist)
                        .put("url", np.url == null ? "" : np.url)
                        .put("inApp", np.inApp)
                        .put("timed", useMedia);
                item.put("source", so);
                item.put("title", np.title);
                item.put("channel", (np.artist != null && !np.artist.isEmpty()) ? np.artist : (np.app == null ? "" : np.app));
                if (np.url != null && !np.url.isEmpty()) item.put("url", np.url);
                if (useMedia) {   // همان فایل = همان ردیف (مثل videoId در یوتیوب) تا ذخیره‌ی دوباره خط‌ها را ادغام کند
                    item.put("key", "live-" + Integer.toHexString((np.pkg + "|" + np.title + "|" + np.artist).hashCode()));
                }
            }
            boolean ok = YtSaved.add(this, item);
            showNotice(ok
                    ? msg("منبع ذخیره شد ✓ — در «داستان‌های ذخیره‌شده» اپ", "Source saved ✓ — see Saved stories in the app")
                    : msg("ذخیره نشد", "Save failed"));
        } catch (Throwable t) {
            showNotice(msg("ذخیره نشد", "Save failed"));
        }
    }

    /** 💾 زیرنویس + ترجمه‌ی نمایش‌داده‌شده + لینکِ ویدیو → «داستان‌های ذخیره‌شده»ی اپ. */
    private void saveYoutube() {
        YtSubtitles engine = yt;
        if (engine == null || !engine.isActive()) return;
        try {
            JSONObject snap = engine.snapshot();
            if (snap == null) {
                showNotice(msg("هنوز زیرنویسی برای ذخیره نیست", "Nothing to save yet"));
                return;
            }
            boolean ok = YtSaved.add(this, snap);
            showNotice(ok
                    ? msg("لینکِ ویدیو ذخیره شد ✓ — در «داستان‌های ذخیره‌شده» اپ", "Video link saved ✓ — see Saved stories in the app")
                    : msg("ذخیره نشد", "Save failed"));
        } catch (Throwable t) {
            showNotice(msg("ذخیره نشد", "Save failed"));
        }
    }

    private void startYoutube(boolean openSettingsIfNeeded) {
        if (wm == null || bubble == null) return;
        if (yt != null && yt.isActive()) return;
        userHidden = false;
        if (!YtMedia.hasAccess(this)) {
            showNotice(msg("برای زیرنویسِ همگام، «دسترسی به اعلان‌ها» لازم است؛ یا «فقط متنِ کامل» را انتخاب کن",
                    "Synced subtitles need “Notification access”; or choose “Full text only”"));
            if (openSettingsIfNeeded) askYoutubeAccessChoice();
            return;
        }
        if (recording) stopRecording();     // دو منبعِ هم‌زمان روی یک پنل نباشه
        YtSubtitles engine = new YtSubtitles(this, ytHost, WORKER_BASE, HTTP_FAST);
        engine.setOffsetMs(getSharedPreferences(PREFS, MODE_PRIVATE).getLong("ytOffsetMs", 0L));
        if (!engine.start()) {
            engine.stop();
            showNotice(msg("دسترسی به اعلان‌ها هنوز فعال نیست", "Notification access is not enabled yet"));
            if (openSettingsIfNeeded) askYoutubeAccessChoice();
            return;
        }
        yt = engine;
        ytFullMode = false;
        ytEntries.clear();
        refreshHeader();
        updateYtButton();
    }

    /** ▶ بدونِ دسترسیِ اعلان / نگه‌داشتنِ ▶: توضیحِ شفاف و انتخابِ «همگام با پخش» یا «فقط متنِ کامل». */
    private void askYoutubeAccessChoice() {
        try {
            startActivity(new Intent(this, ShareReceiverActivity.class)
                    .putExtra(ShareReceiverActivity.EXTRA_YT_CHOOSE, true)
                    .putExtra(ShareReceiverActivity.EXTRA_FA, isFa())
                    .putExtra(ShareReceiverActivity.EXTRA_LANG, NativeI18n.lang(this))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        } catch (Throwable t) {
            YtMedia.openAccessSettings(this);
        }
    }

    /** از ShareReceiverActivity (لینکِ کلیپ‌بورد): کلِ زیرنویسِ ویدیو را یک‌جا و بدونِ همگام‌سازی می‌آورد. */
    static void startYoutubeFull(Context ctx, final String videoId) {
        final BubbleService s = instance;
        if (s == null) return;
        s.main.post(() -> s.beginYoutubeFull(videoId));
    }

    private void beginYoutubeFull(String videoId) {
        if (wm == null || bubble == null || !YtMedia.isValidYouTubeVideoId(videoId)) return;
        if (yt != null) stopYoutube(false);
        userHidden = false;
        if (recording) stopRecording();
        YtSubtitles engine = new YtSubtitles(this, ytHost, WORKER_BASE, HTTP_FAST);
        yt = engine;
        ytFullMode = true;
        ytEntries.clear();
        engine.startFullText(videoId, "");
        refreshHeader();
        updateYtButton();
        showNotice(msg("در حال گرفتنِ زیرنویسِ کامل…", "Fetching the full subtitles…"));
    }

    // ─── 🔂 «متنِ کامل»: خواندنِ کلِ متن از اول؛ بعد از آخرین جمله دوباره از اول، تا دوباره بزنی ───

    private void toggleFullText() {
        if (fullLoop) { stopFullText(); return; }
        if (history.isEmpty()) return;
        stopPanelSpeech();
        fullLoop = true;
        fullIdx = 0;
        fullToken++;
        updateYtButton();
        speakFull(fullToken, 0);
    }

    private void speakFull(final int my, final int empties) {
        if (!fullLoop || my != fullToken) return;
        if (history.isEmpty() || empties > history.size()) { stopFullText(); return; }
        if (fullIdx >= history.size()) {
            fullIdx = 0;                                           // تمام شد → از اولِ متن
            main.postDelayed(() -> speakFull(my, 0), 700);
            return;
        }
        final Entry e = history.get(fullIdx);
        String t = e.src == null ? "" : e.src.trim();
        if (t.isEmpty()) { fullIdx++; speakFull(my, empties + 1); return; }
        scrollToEntry(e);
        panelSpeaking = true;
        PanelTts.speak(this, t, e.srcLang, 1.0f, ok -> {
            if (!fullLoop || my != fullToken) return;
            if (!ok) { stopFullText(); return; }
            fullIdx++;
            speakFull(my, 0);
        });
    }

    private void stopFullText() {
        boolean was = fullLoop;
        fullLoop = false;
        fullToken++;
        if (was) {
            PanelTts.stop(this);
            panelSpeaking = false;
            panelQuietUntil = SystemClock.uptimeMillis() + 800;
        }
        updateYtButton();
    }

    private void stopYoutube(boolean notify) {
        YtSubtitles engine = yt;
        yt = null;
        ytAutoStarted = false;
        if (notify && engine != null) ytAutoOffKey = ytWatchKey;   // کاربر خودش خاموش کرد → برای همین ویدیو دوباره خودکار روشن نشود
        ytFullMode = false;
        stopFullText();
        ytEntries.clear();
        ytListMode = false; ytListGen++; ytCur = -1;
        if (scroll != null) scroll.ytMode = false;
        if (engine != null) { try { engine.stop(); } catch (Throwable ignored) {} }
        if (engine == null) return;
        refreshHeader();
        updateYtButton();
        if (!recording) {          // خروج از حالتِ ویدیو → کادر هم همان لحظه بسته بشه و متنِ ویدیو پاک بشه
            clearHistory();
            removePanel();
            userHidden = false;
        } else if (notify) {
            showNotice(msg("زیرنویس یوتیوب خاموش شد", "YouTube subtitles off"));
        }
    }

    private final YtSubtitles.Host ytHost = new YtSubtitles.Host() {
        @Override public List<String> targets() { return activeTargets(); }
        @Override public LiveTranslator.Ai ai() { return aiBackend; }       // 🔎 بازبینیِ ترجمه‌ی مشکوکِ یوتیوب با همان AIِ ترجمه‌ی زنده
        @Override public String requestedSource() { return effectiveSource(); }
        @Override public String tone() { return BubbleService.this.tone(); }
        @Override public String langName(String code) {
            String n = LANG_NAMES.get(code);
            return n != null ? n : code;
        }
        @Override public boolean fa() { return isFa(); }
        @Override public String lang() { return NativeI18n.lang(BubbleService.this); }
        @Override public void onVideoLoopChanged(boolean on) { main.post(BubbleService.this::updateYtButton); }

        @Override public void notice(String m) {
            if (m == null || m.isEmpty()) { clearStatus(); return; }
            showNotice(m);
        }

        @Override public void loadAll(final List<String> sentences, final Map<String, String[]> tr, final int cur) {
            if (wm == null || bubble == null) return;
            clearStatus();
            refreshHeader();     // زبانِ زیرنویسِ ویدیو معلوم شد → فهرستِ زبان‌های مقصدِ هدر را تازه کن
            final int g = ++ytListGen;
            clearHistory();
            ytEntries.clear();
            ytCur = -1;
            ytWanted = cur;
            ytWantedForce = true;
            ytListMode = true;
            ensurePanel();
            scroll.ytMode = true;
            scroll.atBottom = false;
            buildYtBatch(sentences, tr, 0, g);
        }

        @Override public void setCurrent(int sentIdx, boolean force) {
            ytWanted = sentIdx;
            ytWantedForce = ytWantedForce || force;
            applyYtCurrent(false);
        }

        @Override public void updateSentence(int sentIdx, String lang, String text) {
            Entry e = ytEntries.get(sentIdx);
            if (e == null || text == null || text.isEmpty()) return;
            e.tr.put(lang, text);
            e.trSrc.put(lang, e.src);
            renderEntry(e);
            queueYtRefresh();
        }

        @Override public void noCaptions() {
            if (!ytAutoStarted) return;          // با دکمه روشن شده بود: پیامِ «زیرنویس ندارد» نشان داده شود
            ytAutoOffKey = ytWatchKey;           // همین ویدیو دوباره امتحان نشود
            final boolean resume = ytAutoWasRecording;
            ytAutoWasRecording = false;
            stopYoutube(false);                  // خودکار بود → خاموش
            main.postDelayed(() -> showNotice(msg(                 // قبلاً بی‌صدا بسته می‌شد و کاربر نمی‌فهمید چرا زیرنویس نیامده
                    "زیرنویسِ یوتیوب برای این ویدیو پیدا نشد",
                    "No YouTube captions found for this video")), 1500);
            if (resume && !recording) {          // ترجمه‌ی زنده‌ی صدا که قبل از روشن‌شدنِ خودکار در جریان بود، برگردد
                main.post(() -> { try { toggleRecording(); } catch (Throwable ignored) {} });
            }
        }

        @Override public void videoChanged() {
            if (wm == null || bubble == null) return;
            ytListGen++;
            clearHistory();
            ytEntries.clear();
            ytCur = -1;
        }
    };

    // ─── 📜 لیستِ کاملِ زیرنویس: همه کم‌رنگ، جمله‌ی در حالِ پخش پررنگ ───

    /** ردیف‌ها را دسته‌دسته (۴۰ تا در هر فریم) می‌سازد تا گوشی برای ویدیوهای بلند هنگ نکند. */
    private void buildYtBatch(final List<String> sents, final Map<String, String[]> tr, final int from, final int g) {
        if (g != ytListGen || wm == null || bubble == null) return;
        int end = Math.min(sents.size(), from + 40);
        for (int i = from; i < end; i++) {
            Entry e = newEntry();
            e.ytIdx = i;
            if (e.ytReplayBtn != null && !ytFullMode) e.ytReplayBtn.setVisibility(View.VISIBLE);
            e.src = sents.get(i);
            e.srcLang = currentSrcLang();
            for (Map.Entry<String, String[]> x : tr.entrySet()) {
                String[] a = x.getValue();
                if (a != null && i < a.length && a[i] != null && !a[i].isEmpty()) {
                    e.tr.put(x.getKey(), a[i]);
                    e.trSrc.put(x.getKey(), e.src);
                }
            }
            styleYtEntry(e, false);
            ytEntries.put(i, e);
            renderEntry(e);
        }
        afterChange();
        if (end < sents.size()) {
            final int nxt = end;
            main.post(() -> buildYtBatch(sents, tr, nxt, g));
        } else {
            applyYtCurrent(true);
        }
    }

    private void styleYtEntry(Entry e, boolean current) {
        if (e == null || e.box == null) return;
        if (ytFullMode) current = false;                    // 📄 متنِ کامل: همه‌ی جمله‌ها یکسان، بدونِ کم‌رنگ/پررنگ
        e.box.setAlpha(current || ytFullMode ? 1f : YT_DIM);
        e.tvSrc.setTextColor(current ? Color.WHITE : Color.parseColor("#C8CCD8"));
        e.tvSrc.setTag(new float[]{16f, current ? 1f : 0f, 1f});   // ۱ = «متنِ محتوا»؛ بدونِ آن فونتِ انتخابیِ کادر روی متنِ اصلیِ یوتیوب اعمال نمی‌شد
        applyStyle(e.tvSrc);
    }

    private void applyYtCurrent(boolean listJustBuilt) {
        int idx = ytWanted;
        if (idx < 0) return;
        Entry n = ytEntries.get(idx);
        if (n == null) return;                 // هنوز در حالِ ساختنِ لیست؛ آخرِ ساخت دوباره صدا زده می‌شود
        boolean changed = ytCur != idx;
        if (changed) {
            Entry o = ytEntries.get(ytCur);
            if (o != null) styleYtEntry(o, false);
            ytCur = idx;
        }
        for (String t : activeTargets()) {
            String v = n.tr.get(t);
            if (v == null || v.isEmpty()) n.tr.put(t, "…");
        }
        styleYtEntry(n, true);
        renderEntry(n);
        boolean force = ytWantedForce || listJustBuilt;
        ytWantedForce = false;
        if (scroll != null && (changed || force)) {
            boolean userBusy = SystemClock.uptimeMillis() - scroll.lastUserTouch < 4000;
            if (force || !userBusy) scrollToYtEntry(n);
        }
        queueYtRefresh();
    }

    private void scrollToYtEntry(final Entry e) {
        if (scroll == null || e == null || e.box == null) return;
        scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, e.box.getTop() - scroll.getHeight() / 3)));
    }

    /** چند به‌روزرسانیِ پشتِ‌سرهم (ترجمه‌ی یک chunk) فقط یک بار layout پنل را تازه می‌کنند. */
    private void queueYtRefresh() {
        if (ytRefreshQueued) return;
        ytRefreshQueued = true;
        main.postDelayed(() -> { ytRefreshQueued = false; afterChange(); }, 120);
    }

    private void setRecordingUi(boolean rec) {
        if (bubble == null) return;
        bubble.setRecording(rec);
        updateModeSwitch();
        if (rec) {
            lastVoiceMs = lastTextMs = lastActiveMs = SystemClock.elapsedRealtime();
            idleHidden = false;
        }
        main.removeCallbacks(idleRunnable);
        main.postDelayed(idleRunnable, 700);
        // شروعِ ضبط → حباب جمع می‌شود و می‌رود گوشه؛ توقف → کامل به لبه می‌چسبد و بعد از چند ثانیه دوباره جمع می‌شود
        main.postDelayed(() -> dockBubble(rec), rec ? 350 : 0);
        if (!rec) scheduleIdleDock();
    }

    private String msg(String fa, String en) { return NativeI18n.tr(NativeI18n.lang(this), fa, en); }

    // ───────── 📦 ترجمه‌ی زنده فقط با تشخیص گفتارِ آفلاین (بدونِ سرور و بدونِ تشخیص‌دهنده‌ی آنلاین) ─────────

    /** بسته‌ای که برای زبانِ مبدأ لازم است ولی روی گوشی نیست: {نوع، شناسه}؛ null = بسته آماده است. */
    private String[] missingOfflinePack(String src) {
        if (whisperModelPref() != null) return null;                       // «حالت آهنگ»ِ انتخابیِ کاربر
        boolean sherpaLang = src != null && !"auto".equals(src) && SherpaModelManager.isAvailable(src);
        if (sherpaLang) {
            if (SherpaModelManager.getModelDir(this, src) != null) return null;
            String n = SherpaModelManager.normalize(src);
            return new String[]{"sherpa", n != null ? n : src};
        }
        if (anyWhisperModel() != null) return null;                        // زبان‌های بدونِ بسته‌ی اختصاصی + «خودکار»
        return new String[]{"whisper", "base"};
    }

    private String anyWhisperModel() {
        for (String m : new String[]{"small", "base", "tiny"}) {      // مدلِ بزرگ‌تر = تشخیصِ زبانِ دقیق‌تر
            if (WhisperModelManager.getModelDir(this, m) != null) return m;
        }
        return null;
    }

    /** true = می‌شود شروع کرد؛ false = یا دانلود در جریان است یا پیامِ تأییدِ دانلود نشان داده شد. */
    private boolean offlinePackReady() {
        if (SherpaModelManager.isDownloading() || WhisperModelManager.isDownloading()) {
            showNotice(msg("دانلودِ بسته‌ی آفلاین در حال انجام است؛ کمی صبر کنید",
                    "The offline pack is still downloading — please wait"));
            return false;
        }
        String[] need = missingOfflinePack(engineSource());
        if (need == null) return true;
        askOfflinePack(need[0], need[1]);
        return false;
    }

    private void askOfflinePack(String kind, String id) {
        try {
            String name = LANG_NAMES.containsKey(id) ? LANG_NAMES.get(id) : id;
            startActivity(new Intent(this, ShareReceiverActivity.class)
                    .putExtra(ShareReceiverActivity.EXTRA_ASR_PACK, true)
                    .putExtra(ShareReceiverActivity.EXTRA_PACK_KIND, kind)
                    .putExtra(ShareReceiverActivity.EXTRA_PACK_ID, id)
                    .putExtra(ShareReceiverActivity.EXTRA_PACK_NAME, name)
                    .putExtra(ShareReceiverActivity.EXTRA_PACK_MB, "whisper".equals(kind) ? WhisperModelManager.approxMb(id) : 0)
                    .putExtra(ShareReceiverActivity.EXTRA_FA, isFa())
                    .putExtra(ShareReceiverActivity.EXTRA_LANG, NativeI18n.lang(this))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION));
        } catch (Throwable t) {
            showNotice(msg("برای ترجمه‌ی زنده، بسته‌ی آفلاین را از تنظیماتِ اپ دانلود کنید",
                    "For live translation, download the offline pack from the app settings"));
        }
    }

    /** از ShareReceiverActivity، بعد از «دانلود» زدنِ کاربر. */
    static void startAsrPackDownload(Context ctx, final String kind, final String id) {
        final BubbleService s = instance;
        if (s == null) return;
        s.main.post(() -> s.downloadAsrPack(kind, id));
    }

    private void downloadAsrPack(final String kind, final String id) {
        if (SherpaModelManager.isDownloading() || WhisperModelManager.isDownloading()) {
            showNotice(msg("یک دانلود دیگر در حال انجام است", "Another download is already running"));
            return;
        }
        if (!hasInternet()) {
            showNotice(msg("برای دانلودِ بسته به اینترنت نیاز است", "An internet connection is needed to download the pack"));
            return;
        }
        showNotice(msg("دانلودِ بسته‌ی آفلاین شروع شد…", "Offline pack download started…"));
        final long[] last = {0};
        if ("whisper".equals(kind)) {
            WhisperModelManager.download(this, id, new WhisperModelManager.Callback() {
                @Override public void onProgress(String m, long done, long total) { packProgress(done, total, last); }
                @Override public void onDone(String m) { packDone(); }
                @Override public void onError(String m, Exception e) { packFailed(e); }
            });
        } else {
            SherpaModelManager.downloadModel(this, id, new SherpaModelManager.ProgressCallback() {
                @Override public void onProgress(String l, long done, long total) { packProgress(done, total, last); }
                @Override public void onDone(String l) { packDone(); }
                @Override public void onError(String l, Exception e) { packFailed(e); }
            });
        }
    }

    private void packProgress(long done, long total, long[] last) {
        long now = SystemClock.elapsedRealtime();
        if (now - last[0] < 1500) return;
        last[0] = now;
        final String p = total > 0 ? (int) (done * 100 / total) + "٪" : (done / (1024 * 1024)) + " MB";
        main.post(() -> showNotice(msg("دانلودِ بسته‌ی آفلاین… ", "Downloading offline pack… ") + p));
    }

    private void packDone() {
        main.post(() -> showNotice(msg("بسته‌ی آفلاین آماده شد ✓ — دوباره دکمه‌ی میکروفون را بزنید",
                "Offline pack ready ✓ — tap the mic again")));
    }

    private void packFailed(final Exception e) {
        final boolean cancelled = e instanceof java.io.IOException && String.valueOf(e.getMessage()).contains("cancelled");
        main.post(() -> showNotice(cancelled
                ? msg("دانلود لغو شد", "Download cancelled")
                : msg("دانلود ناموفق بود؛ اتصال را بررسی کنید و دوباره امتحان کنید (ادامه از همان‌جا)",
                        "Download failed — check your connection and try again (it resumes)")));
    }

    private void toggleRecording() {
        if (recording) { stopRecording(); return; }
        userHidden = false;
        if (!offlinePackReady()) return;                      // پیش از درخواستِ مجوزِ ضبطِ صفحه
        if (mediaProjection == null) {
            // 🔑 اگر ذره‌بین (یا قبلاً همین ترجمه‌ی زنده) مجوزِ ضبط را گرفته، همان را استفاده کن؛ پنجره‌ی اندروید نیاید
            if (ProjectionHolder.canReuse()
                    && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                try {
                    startForegroundService(new Intent(this, BubbleService.class)
                            .setAction(ACTION_PROJECTION_RESULT).putExtra(EXTRA_REUSE, true));
                    return;
                } catch (Exception e) { Log.w(TAG, "reuse projection failed, asking", e); }
            }
            launchProjectionDialog();
            return;
        }
        startCapture();
    }

    private void launchProjectionDialog() {
        Intent i = new Intent(this, ProjectionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); }
        catch (Exception e) { Log.e(TAG, "cannot launch ProjectionActivity", e); showNotice("⚠ " + briefErr(e)); }
    }

    @SuppressWarnings("deprecation")
    private void handleProjectionResult(Intent intent) {
        try {
            int rc = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent data = intent.getBooleanExtra(EXTRA_REUSE, false) ? null
                    : (Build.VERSION.SDK_INT >= 33
                        ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                        : (Intent) intent.getParcelableExtra(EXTRA_DATA));
            // مجوزِ مشترک با ذره‌بین: اگر زنده است همان؛ وگرنه از نتیجه‌ی پنجره‌ی اندروید ساخته می‌شود
            final MediaProjection mp = ProjectionHolder.obtain(this, rc, data);
            if (mp == null) {
                if (data == null) launchProjectionDialog();      // مجوزِ قبلی منقضی شده → یک بار دوباره بپرس
                else showNotice(msg("مجوز ضبط صدا گرفته نشد", "Could not get the capture permission"));
                return;
            }
            if (!projectionRetained) { ProjectionHolder.retain(); projectionRetained = true; }
            ProjectionHolder.addStopListener(projectionStopListener);
            mediaProjection = mp;
            startCapture();
        } catch (Exception e) {
            Log.e(TAG, "projection failed", e);
            showNotice("⚠ " + briefErr(e));
        }
    }

    // ───────── 🌐 انتخابِ موتورِ تشخیص گفتار: «offline» (پیش‌فرض) یا «google» ─────────
    /** بعد از شکستِ Google در همین نشست، تا تغییرِ تنظیمات یا ری‌استارتِ سرویس، دیگر امتحان نمی‌شود. */
    private static volatile boolean googleSkipped = false;

    static void resetGoogleSkip() { googleSkipped = false; }

    private String speechProvider() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString("speechProvider", "offline");
    }

    /** Google با ورودیِ صدای سیستم فقط روی اندروید ۱۳+ (EXTRA_AUDIO_SOURCE) و با زبانِ مشخص کار می‌کند. */
    private boolean googleUsable(String src) {
        if (Build.VERSION.SDK_INT < 33) return false;
        if (src == null || src.isEmpty() || "auto".equals(src)) return false;
        try { return SpeechRecognizer.isRecognitionAvailable(this); } catch (Throwable t) { return false; }
    }

    /** Google کار نکرد (آفلاین/زبانِ ناپشتیبان/نبودنِ سرویس): ضبط را می‌بندد و با موتورِ آفلاین دوباره شروع می‌کند. */
    private void fallbackToOffline(String notice) {
        if (!micEngine) return;
        final boolean canRestart = mediaProjection != null;
        googleSkipped = true;
        stopRecording();
        if (notice != null) showNotice(notice);
        if (canRestart) main.postDelayed(() -> { if (!recording) startCapture(); }, 500);
    }

    private static String localeTag(String lang) {
        String t = LOCALE_TAGS.get(lang);
        return t != null ? t : lang;
    }

    private void startCapture() {
        if (mediaProjection == null || recording) return;
        prepareLocalTranslator();
        prevFinalText = "";
        // ✅ تغییر ۲: ریست کردن lastFinalText
        lastFinalText = "";
        partialBusy = false;
        shownPartialSeq = partialSeq;
        lastPartialSrc = ""; live = null; consumedWords = 0;
        SentenceAudio.reset();
        lastAudioEnd = SentenceAudio.now();
        cancelLivePending();
        speechHostRestarts = 0;
        gotAsrText = false; voicedSinceText = 0;
        resetDetected();                                      // هر شروعِ تازه: تشخیصِ زبان از اول
        final String src = engineSource();
        // 🌐 موتورِ «Google» (SpeechRecognizerِ خودِ اندروید) اگر کاربر در تنظیمات انتخاب کرده باشد
        if ("google".equals(speechProvider()) && !googleSkipped) {
            if (googleUsable(src) && startMicEngine(src)) return;
            showNotice(msg("تشخیص گفتارِ گوگل در دسترس نیست؛ موتورِ آفلاین استفاده شد",
                    "Google speech unavailable — using the offline engine"));
        }
        // 📦 موتورِ آفلاین (Sherpa یا Whisper). بدونِ بسته: پیامِ تأییدِ دانلود، نه سرور و نه تشخیص‌دهنده‌ی آنلاین.
        String[] need = missingOfflinePack(src);
        if (need != null) { askOfflinePack(need[0], need[1]); return; }
        String wModel = whisperModelPref();
        final boolean sherpaLang = src != null && !"auto".equals(src) && SherpaModelManager.isAvailable(src);
        if (wModel == null && !sherpaLang) wModel = anyWhisperModel();
        if (startSherpaEngine(src, wModel)) return;           // wModel == null ← بسته‌ی Sherpa
        showNotice(msg("راه‌اندازیِ موتورِ آفلاین ممکن نشد", "Could not start the offline engine"));
    }

    /**
     * Recognizer engine: captures the phone's PLAYBACK audio (not the microphone), converts it to
     * 16 kHz mono PCM16 and streams it to SpeechRecognizer through PcmFeed / EXTRA_AUDIO_SOURCE.
     */
    private boolean startMicEngine(String src) {
        AudioRecord rec = null;
        try {
            rec = buildPlaybackRecord();
            if (rec == null) return false;
            record = rec;
            micEngine = true;
            recording = true;
            setRecordingUi(true);
            rec.startRecording();
            final AudioRecord fr = rec;
            new Thread(() -> feedLoop(fr), "bubble-feed").start();
            launchGoogleHost(src);
            showNotice(msg("در حال اجرا…", "Running…"));
            return true;
        } catch (Exception e) {
            Log.w(TAG, "cannot start recognizer engine", e);
            micEngine = false; recording = false; setRecordingUi(false);
            PcmFeed.close();
            if (rec != null) { record = null; try { rec.stop(); } catch (Exception ignored) {} try { rec.release(); } catch (Exception ignored) {} }
            return false;
        }
    }

    // ── میزبانِ موتورِ گوگل: ترجیحاً داخلِ همین سرویس (هیچ صفحه‌ای باز نمی‌شود → ویدیو/اپِ زیرش دست‌نخورده)،
    //    و فقط اگر اندروید/گوشی اجازه نداد، همان صفحه‌ی نامرئیِ شفاف و بدونِ فوکوس (SpeechHostActivity). ──
    private GoogleAsr googleAsr;

    private boolean googleNeedsActivityHost() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("googleHostActivity", false);
    }

    private void launchGoogleHost(String src) {
        stopGoogleAsr();
        if (googleNeedsActivityHost()) { launchGoogleActivity(src); return; }
        final String lang = localeTag(src);
        final GoogleAsr[] ref = new GoogleAsr[1];
        ref[0] = new GoogleAsr(this, lang, new GoogleAsr.Host() {
            @Override public void onFatal() { if (googleAsr == ref[0]) asrFallback(); }
            @Override public void onNeedsPermission() { if (googleAsr == ref[0]) asrNeedsPermission(); }
            @Override public void onHostUnsupported() {
                if (googleAsr != ref[0]) return;
                // گوگل از داخلِ سرویس صدا نمی‌گیرد → از این به بعد با صفحه‌ی نامرئی
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("googleHostActivity", true).apply();
                stopGoogleAsr();
                if (recording && micEngine) launchGoogleActivity(lang);
            }
        });
        googleAsr = ref[0];
        googleAsr.start();
    }

    private void launchGoogleActivity(String langTag) {
        try {
            Intent i = new Intent(this, SpeechHostActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra(SpeechHostActivity.EXTRA_LANG_TAG, langTag);
            startActivity(i);
        } catch (Exception e) {
            Log.w(TAG, "cannot start speech host activity", e);
            asrFallback();
        }
    }

    private void stopGoogleAsr() {
        GoogleAsr a = googleAsr;
        googleAsr = null;
        if (a != null) { try { a.stop(); } catch (Throwable ignored) {} }
    }

    /**
     * Sherpa engine: same playback capture + feedLoop as the recognizer engine, but the 16 kHz PCM
     * goes to SherpaEngine instead of PcmFeed. Returns false (-> Google/server path) if the model
     * is not downloaded or the capture cannot start.
     */
    private boolean startSherpaEngine(final String src, final String whisperModel) {
        if (whisperModel != null) {
            if (WhisperModelManager.getModelDir(this, whisperModel) == null) return false;   // not downloaded yet
        } else if (SherpaModelManager.getModelDir(this, src) == null) return false;           // not downloaded yet
        AudioRecord rec = null;
        try {
            rec = buildPlaybackRecord();
            if (rec == null) return false;
            record = rec;
            micEngine = true;          // so feedLoop runs and asr* callbacks are accepted
            recording = true;
            setRecordingUi(true);
            rec.startRecording();
            final AudioRecord fr = rec;
            new Thread(() -> runSherpa(fr, src, whisperModel), "bubble-feed").start();
            showNotice(msg("در حال اجرا…", "Running…"));
            return true;
        } catch (Exception e) {
            Log.w(TAG, "cannot start sherpa engine", e);
            micEngine = false; recording = false; setRecordingUi(false);
            if (rec != null) { record = null; try { rec.stop(); } catch (Exception ignored) {} try { rec.release(); } catch (Exception ignored) {} }
            return false;
        }
    }

    /** Feed-thread entry for Sherpa: loads the model off the main thread, then runs feedLoop. */
    private void runSherpa(final AudioRecord rec, final String src, final String whisperModel) {
        PcmSink eng = (whisperModel != null)
                ? WhisperEngine.create(getApplicationContext(), whisperModel, src)
                : SherpaEngine.create(getApplicationContext(), src);
        boolean stillActive = recording && micEngine && record == rec;
        if (eng != null && stillActive) {
            sherpaEngine = eng;
            // stop/cleanup may have run between the check and the assignment
            if (!(recording && micEngine && record == rec)) { releaseSherpa(); stillActive = false; }
        } else {
            if (eng != null) eng.release();
            if (stillActive) {
                main.post(() -> fallbackToServer(msg("بسته‌ی آفلاین بارگذاری نشد؛ دوباره دانلودش کنید",
                        "The offline pack failed to load — please download it again")));
            }
            stillActive = false;
        }
        if (stillActive) {
            feedLoop(rec);   // releases rec in its finally
        } else {
            try { rec.stop(); } catch (Exception ignored) {}
            try { rec.release(); } catch (Exception ignored) {}
        }
    }

    /** Selected Whisper ("song mode") model id if the user enabled it and it is downloaded, else null. */
    private String whisperModelPref() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!"whisper".equals(sp.getString("sttEngine", "sherpa"))) return null;
        String m = sp.getString("whisperModel", "base");
        return WhisperModelManager.getModelDir(this, m) != null ? m : null;
    }

    private void releaseSherpa() {
        PcmSink e = sherpaEngine;
        sherpaEngine = null;
        if (e != null) e.release();
    }

    /** Playback-capture AudioRecord at the best native rate (48 kHz, then 44.1 kHz, then 16 kHz). */
    private AudioRecord buildPlaybackRecord() {
        if (mediaProjection == null) return null;
        AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .excludeUid(android.os.Process.myUid())
                .build();
        int[] rates = {48000, 44100, SAMPLE_RATE};
        for (int rate : rates) {
            AudioRecord r = null;
            try {
                int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                r = new AudioRecord.Builder()
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(rate)
                                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(min, rate / 5 * 2))
                        .setAudioPlaybackCaptureConfig(cfg)
                        .build();
                if (r.getState() == AudioRecord.STATE_INITIALIZED) return r;
                r.release();
            } catch (Exception e) {
                Log.w(TAG, "playback record @" + rate + " failed", e);
                if (r != null) { try { r.release(); } catch (Exception ignored) {} }
            }
        }
        return null;
    }

    private void feedLoop(final AudioRecord rec) {
        final int rate = rec.getSampleRate() > 0 ? rec.getSampleRate() : SAMPLE_RATE;
        final int frame = Math.max(1, rate / 50);                   // 20 ms of input
        final short[] in = new short[frame];
        final byte[] out = new byte[(frame * SAMPLE_RATE / rate + 4) * 2];
        try {
            while (recording && micEngine && record == rec) {
                int n = rec.read(in, 0, frame);
                if (n < 0) break;
                if (n == 0) continue;
                int outBytes = toPcm16k(in, n, rate, out);
                SentenceAudio.write(out, outBytes);                 // 🎙 برای ↺ (صدای خودِ گوینده)
                final PcmSink se = sherpaEngine;
                if (se != null) {
                    se.accept(out, outBytes);
                } else {
                    PcmFeed.write(out, outBytes);
                }
                final boolean loud = rms16(in, n) > SILENCE_RMS;
                if (loud) lastVoiceMs = SystemClock.elapsedRealtime();
                if (!gotAsrText) {
                    if (loud) voicedSinceText += 20;
                    // Whisper answers in ~10-30 s windows, so give it a much longer leash than the streaming engine
                    final int wd = (se instanceof WhisperEngine) ? ASR_WATCHDOG_VOICED_MS * 4 : ASR_WATCHDOG_VOICED_MS;
                    if (voicedSinceText >= wd) {
                        voicedSinceText = 0;
                        main.post(() -> fallbackToServer(
                                msg("گفتاری تشخیص داده نشد؛ زبانِ مبدأ را بررسی کنید",
                                        "No speech recognized — check the source language")));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "feed loop", e);
        } finally {
            try { rec.stop(); } catch (Exception ignored) {}
            try { rec.release(); } catch (Exception ignored) {}
            if (recording && micEngine && record == rec) {
                record = null; recording = false;
                main.post(() -> setRecordingUi(false));
            }
        }
    }

    /** Box-filter downsample of mono PCM16 to 16 kHz little-endian bytes. Returns byte count. */
    private static int toPcm16k(short[] in, int n, int rate, byte[] out) {
        int outN;
        if (rate == SAMPLE_RATE) {
            outN = Math.min(n, out.length / 2);
            for (int j = 0; j < outN; j++) {
                out[2 * j] = (byte) (in[j] & 0xff);
                out[2 * j + 1] = (byte) ((in[j] >> 8) & 0xff);
            }
            return outN * 2;
        }
        outN = Math.min((int) ((long) n * SAMPLE_RATE / rate), out.length / 2);
        for (int j = 0; j < outN; j++) {
            int a = (int) ((long) j * rate / SAMPLE_RATE);
            int b = Math.min(n, (int) ((long) (j + 1) * rate / SAMPLE_RATE));
            if (b <= a) b = Math.min(n, a + 1);
            int sum = 0;
            for (int k = a; k < b; k++) sum += in[k];
            short s = (short) (sum / (b - a));
            out[2 * j] = (byte) (s & 0xff);
            out[2 * j + 1] = (byte) ((s >> 8) & 0xff);
        }
        return outN * 2;
    }

    private static double rms16(short[] s, int n) {
        if (n <= 0) return 0;
        long sum = 0;
        for (int i = 0; i < n; i++) sum += (long) s[i] * s[i];
        return Math.sqrt(sum / (double) n);
    }

    /** Leaves the recognizer engine and uses the server (chunked transcribe) path instead. */
    /** ☁ حالتِ سرور حذف شده؛ اگر موتورِ آفلاین نتوانست کار کند، ضبط متوقف می‌شود و دلیلش نشان داده می‌شود. */
    private void fallbackToServer(String notice) {
        if (!micEngine) return;
        stopRecording();
        if (notice != null) showNotice(notice);
    }

    private void restartSpeechHost() {
        if (!recording || !micEngine) return;
        if (speechHostRestarts >= MAX_SPEECH_HOST_RESTARTS) {
            fallbackToOffline(null); return;
        }
        final String src = effectiveSource();
        if (src == null || src.isEmpty() || "auto".equals(src)) {
            fallbackToOffline(null); return;
        }
        speechHostRestarts++;
        main.postDelayed(() -> {
            if (!recording || !micEngine) return;
            try {
                launchGoogleHost(src);
            } catch (Exception e) {
                Log.w(TAG, "restart speech host failed", e);
                fallbackToOffline(null);
            }
        }, 200);
    }

    private void beginCapture() {
        if (mediaProjection == null || recording) return;
        try {
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .excludeUid(android.os.Process.myUid())
                    .build();
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();
            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            final AudioRecord rec = new AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min, SAMPLE_RATE * 2))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                throw new IllegalStateException("AudioRecord not initialized");
            }
            rec.startRecording();
            record = rec;
            recording = true;
            setRecordingUi(true);
            showNotice(msg("در حال اجرا…", "Running…"));
            new Thread(() -> captureLoop(rec), "bubble-capture").start();
        } catch (Exception e) {
            Log.e(TAG, "startCapture failed", e);
            recording = false; setRecordingUi(false);
            showNotice("⚠ " + briefErr(e));
        }
    }

    private void stopRecording() {
        if (!recording) return;
        recording = false;
        if (micEngine) { micEngine = false; stopGoogleAsr(); SpeechHostActivity.finishIfRunning(); PcmFeed.close(); }
        releaseSherpa();
        resetDetected();
        AudioRecord r = record; record = null;
        if (r != null) { try { r.stop(); } catch (Exception ignored) {} }
        setRecordingUi(false);
        showNotice(msg("ضبط متوقف شد", "Stopped"));
        lastActiveMs = SystemClock.elapsedRealtime() - IDLE_HIDE_MS + 1800;   // پیامِ توقف ~۲ ثانیه دیده می‌شه، بعد کادر خودش جمع می‌شه
    }

    private void captureLoop(AudioRecord rec) {
        byte[] buf = new byte[CHUNK_BYTES];
        ByteArrayOutputStream seg = new ByteArrayOutputStream();
        int segMs = 0, voicedMs = 0, silentMs = 0, sincePartialMs = 0;
        try {
            while (recording) {
                int n = rec.read(buf, 0, buf.length);
                if (n < 0) break;
                if (n == 0) continue;
                seg.write(buf, 0, n);
                int chunkMs = n * 1000 / (SAMPLE_RATE * 2);
                segMs += chunkMs;
                sincePartialMs += chunkMs;
                if (rms(buf, n) > SILENCE_RMS) { voicedMs += chunkMs; silentMs = 0; lastVoiceMs = SystemClock.elapsedRealtime(); }
                else silentMs += chunkMs;
                boolean cut = segMs >= MAX_SEG_MS || (segMs >= MIN_SEG_MS && silentMs >= SILENCE_CUT_MS);
                if (cut) {
                    srvSegId++;                                   // پیش‌نمایش‌های دیرِ این قطعه دور ریخته شوند
                    if (voicedMs >= MIN_VOICED_MS) submit(seg.toByteArray());
                    seg.reset(); segMs = voicedMs = silentMs = 0; sincePartialMs = 0;
                } else if (voicedMs == 0 && segMs >= 1000) {
                    seg.reset(); segMs = silentMs = 0; sincePartialMs = 0;
                } else if (voicedMs >= SRV_PARTIAL_MIN_VOICED_MS && sincePartialMs >= SRV_PARTIAL_EVERY_MS
                        && silentMs < SILENCE_CUT_MS) {
                    sincePartialMs = 0;
                    submitServerPartial(seg.toByteArray(), srvSegId);
                }
            }
            if (voicedMs >= MIN_VOICED_MS) submit(seg.toByteArray());
        } catch (Exception e) { Log.e(TAG, "capture loop", e); }
        finally {
            try { rec.stop(); } catch (Exception ignored) {}
            rec.release();
            if (recording) { recording = false; main.post(() -> setRecordingUi(false)); }
        }
    }

    private static double rms(byte[] b, int len) {
        long sum = 0;
        int n = len / 2;
        for (int i = 0; i + 1 < len; i += 2) {
            short s = (short) ((b[i] & 0xff) | (b[i + 1] << 8));
            sum += (long) s * s;
        }
        return n == 0 ? 0 : Math.sqrt(sum / (double) n);
    }

    static void asrPartial(String text) {
        BubbleService s = instance;
        if (s != null && s.micEngine) { s.gotAsrText = true; s.onPartialText(text); }
    }

    static void asrFinal(String text) {
        BubbleService s = instance;
        if (s != null && s.micEngine) { s.gotAsrText = true; s.onFinalText(text); }
    }

    /** نسخه‌ی نهایی چیزِ جدیدی نداشت: خطِ زنده همون‌طور که هست بسته می‌شه (و ترجمه‌ی بقیه‌اش شروع می‌شه). */
    static void asrCommit() {
        BubbleService s = instance;
        if (s == null || !s.micEngine || s.live == null) return;
        s.flushPartial(true);
        s.cancelLivePending();
        s.attachAudio(s.live, -1, -1);
        s.live = null;
        s.consumedWords = 0;
    }

    static void asrFallback() {
        BubbleService s = instance;
        if (s == null || !s.micEngine) return;
        s.fallbackToOffline(s.msg("تشخیص گفتار گوگل در دسترس نیست؛ موتورِ آفلاین فعال شد",
                "Google speech unavailable; switching to the offline engine"));
    }

    static void asrNeedsPermission() {
        BubbleService s = instance;
        if (s == null || !s.micEngine) return;
        s.stopRecording();
        s.showNotice(s.msg("مجوز میکروفون لازم است", "Microphone permission required"));
    }

    static void asrClosed() {
        BubbleService s = instance;
        if (s == null || !s.micEngine) return;
        s.restartSpeechHost();
    }

    private void prepareLocalTranslator() {
        String src = TranslateLanguage.fromLanguageTag(effectiveSource());
        String primary = primaryTarget();
        String tgt = primary == null ? null : TranslateLanguage.fromLanguageTag(primary);
        final boolean wasReady = localReady;
        if (src == null || tgt == null || src.equals(tgt)) { closeLocalTranslator(); return; }
        String key = src + ">" + tgt;
        if (key.equals(localTrKey) && localTr != null && wasReady) return;
        localReady = false;
        if (!key.equals(localTrKey) || localTr == null) {
            closeLocalTranslator();
            localTr = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(src).setTargetLanguage(tgt).build());
            localTrKey = key;
        }
        final Translator tr = localTr;
        tr.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> {
                    if (tr == localTr) localReady = true;
                })
                .addOnFailureListener(e -> {
                    Log.w(TAG, "translation model download failed", e);
                    if (tr == localTr) {
                        main.postDelayed(() -> { if (tr == localTr && !localReady) prepareLocalTranslator(); }, 8000);
                    }
                });
    }

    private void closeLocalTranslator() {
        Translator t = localTr; localTr = null; localTrKey = ""; localReady = false;
        if (t != null) { try { t.close(); } catch (Exception ignored) {} }
    }






    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return true; }
    }

    private boolean isOfflineError(Exception e) {
        return e instanceof UnknownHostException || e instanceof ConnectException
                || e instanceof SocketTimeoutException || !hasInternet();
    }

    private String netErrText(Exception e) {
        if (isOfflineError(e)) return msg("ترجمه در دسترس نیست (آفلاین)", "No translation (offline)");
        return "⚠ " + briefErr(e);
    }

    private void submit(final byte[] pcm) {
        if (pending.get() >= MAX_PENDING) { Log.w(TAG, "dropping segment (backlog)"); return; }
        pending.incrementAndGet();
        try {
            net.execute(() -> { try { processSegment(pcm); } finally { pending.decrementAndGet(); } });
        } catch (Exception e) { pending.decrementAndGet(); }
    }


    /** حالت سرور: متنِ نیمه‌کاره‌ی قطعه‌ی جاری را هر چند صد میلی‌ثانیه نشان بده (بدونِ منتظر ماندن برای پایانِ جمله). */
    private void submitServerPartial(final byte[] pcm, final int id) {
        if (!srvPartialBusy.compareAndSet(false, true)) return;
        try {
            sttPartialEx.execute(() -> {
                String t = "";
                try { t = transcribe(pcm); } catch (Exception ex) { Log.d(TAG, "partial transcribe failed: " + ex); }
                srvPartialBusy.set(false);
                final String text = t;
                if (text.isEmpty()) return;
                main.post(() -> {
                    if (id == srvSegId && recording && !micEngine) onPartialText(text);
                });
            });
        } catch (Exception ex) { srvPartialBusy.set(false); }
    }

    private void processSegment(byte[] pcm) {
        try {
            final String text = transcribe(pcm);
            if (text.isEmpty()) return;
            main.post(() -> onFinalText(text));
        } catch (Exception e) {
            Log.w(TAG, "transcribe failed", e);
            final String m = netErrText(e);
            main.post(() -> showNotice(m));
        }
    }


    private String transcribe(byte[] pcm) throws Exception {
        String src = sourceLang();
        String url = WORKER_BASE + TRANSCRIBE_PATH;
        if (src != null && !src.isEmpty() && !"auto".equals(src)) {
            url += "?lang=" + URLEncoder.encode(src, "UTF-8");
        }
        String resp = postBytes(url, "audio/wav", toWav(pcm));
        JSONObject j = new JSONObject(resp);
        return j.optString("text", "").trim();
    }


    private String translate(String text, String prevContext, String target) throws Exception {
        String name = LANG_NAMES.containsKey(target) ? LANG_NAMES.get(target) : target;
        String prompt = "Translate the following text to " + name
                + ". Reply with ONLY the translation, no quotes, no explanations.";
        String tone = tone();
        if ("formal".equals(tone)) {
            prompt += " Use a formal, polite register.";
        } else if ("casual".equals(tone)) {
            prompt += " Use a casual, spoken, everyday register.";
        }
        if (prevContext != null && !prevContext.isEmpty()) {
            prompt += "\n\nPrevious sentence (context only, do NOT translate it): " + prevContext;
        }
        prompt += "\n\nText: " + text;
        JSONObject body = new JSONObject();
        body.put(GENERATE_PROMPT_KEY, prompt);
        String resp = postBytes(HTTP_FAST, 2, WORKER_BASE + GENERATE_PATH,
                "application/json; charset=utf-8",
                body.toString().getBytes(StandardCharsets.UTF_8));
        return extractText(resp);
    }

    private static String extractText(String raw) {
        try {
            String r = dig(new JSONTokener(raw).nextValue());
            if (r != null && !r.trim().isEmpty()) return stripThink(r);
        } catch (Exception ignored) {}
        return stripThink(raw);
    }

    /** بلوکِ <think>…</think> (فکرِ سرویس) را حذف می‌کند و فقط پاسخ را نگه می‌دارد. */
    private static String stripThink(String s) {
        if (s == null) return "";
        return s.replaceAll("(?is)<think(ing)?>.*?</think(ing)?>", "")
                .replaceAll("(?is)<think(ing)?>.*$", "").trim();
    }

    private static String dig(Object o) {
        if (o instanceof String) return (String) o;
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            String[] keys = {"text", "result", "response", "output", "translation", "reply",
                    "content", "message", "choices", "candidates", "parts"};
            for (String k : keys) {
                if (j.has(k)) { String s = dig(j.opt(k)); if (s != null) return s; }
            }
        } else if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            if (a.length() > 0) return dig(a.opt(0));
        }
        return null;
    }

    private static byte[] toWav(byte[] pcm) {
        int len = pcm.length;
        ByteBuffer b = ByteBuffer.allocate(44 + len).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes(StandardCharsets.US_ASCII));
        b.putInt(36 + len);
        b.put("WAVE".getBytes(StandardCharsets.US_ASCII));
        b.put("fmt ".getBytes(StandardCharsets.US_ASCII));
        b.putInt(16);
        b.putShort((short) 1);
        b.putShort((short) 1);
        b.putInt(SAMPLE_RATE);
        b.putInt(SAMPLE_RATE * 2);
        b.putShort((short) 2);
        b.putShort((short) 16);
        b.put("data".getBytes(StandardCharsets.US_ASCII));
        b.putInt(len);
        b.put(pcm);
        return b.array();
    }

    private static class HttpStatusException extends IOException {
        final int code;
        HttpStatusException(int code, String body) { super("HTTP " + code + " " + body); this.code = code; }
    }

    private static String postBytes(String url, String contentType, byte[] body) throws IOException {
        return postBytes(HTTP, NET_ATTEMPTS, url, contentType, body);
    }

    private static String postBytes(OkHttpClient client, int attempts, String url, String contentType,
                                    byte[] body) throws IOException {
        IOException last = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try { return postOnce(client, url, contentType, body); }
            catch (IOException e) {
                last = e;
                if (e instanceof UnknownHostException) throw e;
                if (e instanceof HttpStatusException) {
                    int code = ((HttpStatusException) e).code;
                    if (code < 500 && code != 429) throw e;
                }
                Log.w(TAG, "request attempt " + attempt + " failed: " + e);
                if (attempt == attempts) break;
                try { Thread.sleep(300L * attempt); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw e; }
            }
        }
        throw last;
    }

    private static String postOnce(OkHttpClient client, String url, String contentType, byte[] body)
            throws IOException {
        Request req = new Request.Builder()
                .url(url)
                .post(RequestBody.create(body, MediaType.get(contentType)))
                .build();
        try (Response r = client.newCall(req).execute()) {
            ResponseBody rb = r.body();
            String resp = rb == null ? "" : rb.string();
            if (!r.isSuccessful()) throw new HttpStatusException(r.code(), resp);
        return resp;
        }
    }

    /** پیامِ کوتاه و قابل‌فهم از یک خطا برای نمایش در کادر. */
    private static String briefErr(Throwable e) {
        if (e == null) return "error";
        if (e instanceof HttpStatusException) return "HTTP " + ((HttpStatusException) e).code;
        if (e instanceof UnknownHostException) return "no internet";
        if (e instanceof SocketTimeoutException) return "timeout";
        String m = e.getMessage();
        if (m == null || m.isEmpty()) m = e.getClass().getSimpleName();
        m = m.replace('\n', ' ').trim();
        return m.length() > 80 ? m.substring(0, 80) + "…" : m;
    }

    /** بستنِ کاملِ سرویس (✕ روی حباب / ACTION_HIDE). */
    private void shutdown() {
        running = false;
        main.removeCallbacks(idleRunnable);
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    /** آزاد کردنِ همه‌ی منابع؛ از onDestroy صدا زده می‌شود. */
    private void cleanup() {
        running = false;
        if (instance == this) instance = null;
        main.removeCallbacksAndMessages(null);
        setReplayHold(false);                                // پلیرِ اپ اگر بخاطرِ ↺ مکث شده بود ادامه دهد

        try { stopYoutube(false); } catch (Throwable ignored) {}
        if (ytWatch != null) { try { ytWatch.stop(); } catch (Throwable ignored) {} ytWatch = null; }
        ytWatchOn = false;

        recording = false;
        try { SentenceAudio.stop(); } catch (Throwable ignored) {}
        if (micEngine) {
            micEngine = false;
            try { stopGoogleAsr(); } catch (Throwable ignored) {}
            try { SpeechHostActivity.finishIfRunning(); } catch (Throwable ignored) {}
            try { PcmFeed.close(); } catch (Throwable ignored) {}
        }
        releaseSherpa();
        AudioRecord r = record; record = null;
        if (r != null) { try { r.stop(); } catch (Exception ignored) {} }
        // مجوزِ ضبط مشترک است: فقط سهمِ خودمان را برمی‌گردانیم؛ اگر ذره‌بین هنوز بازه، مجوز زنده می‌ماند
        mediaProjection = null;
        ProjectionHolder.removeStopListener(projectionStopListener);
        if (projectionRetained) { projectionRetained = false; ProjectionHolder.release(); }

        try { PanelTts.stop(this); } catch (Throwable ignored) {}
        if (pulse != null) { try { pulse.cancel(); } catch (Exception ignored) {} pulse = null; }

        removePanel();
        removeCloseTargetNow();
        if (bubble != null && wm != null) { try { wm.removeView(bubble); } catch (Exception ignored) {} }
        bubble = null;

        closeLocalTranslator();
        net.shutdownNow();
        netTr.shutdownNow();
        netPartial.shutdownNow();
        sttPartialEx.shutdownNow();
    }
}
