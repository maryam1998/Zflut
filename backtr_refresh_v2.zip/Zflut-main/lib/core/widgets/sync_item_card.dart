import '../../features/shell/widgets/spotlight_tour.dart' show TourTarget;
import '../translate/known_translations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app.dart';
import '../ai/word_examples.dart' show wordExamplesStoreProvider;
import '../constants/level_colors.dart';
import '../constants/supported_languages.dart';
import '../player_sync/sync_widgets.dart';
import '../providers/ai_settings_provider.dart';
import '../models/text_prefs.dart';
import '../providers/favorites_provider.dart';
import '../providers/text_prefs_provider.dart';
import '../providers/translation_provider.dart';
import '../theme/app_theme_colors.dart';
import '../translate/translation_service.dart';
import '../translate/ai_first_translator.dart';
import '../storage/translation_cache_db.dart';

import '../../features/reader/widgets/neural_path_dialog.dart';
import 'selection_card.dart';
import 'translation_alt_row.dart';
import 'roman_line.dart';
import 'back_translation_line.dart';
import 'feature_coach.dart';
import '../storage/local_storage.dart' show sharedPrefsProvider;
import 'word_examples_panel.dart';
import '../providers/language_selection_provider.dart';

/// عرضِ ستونِ کناریِ ⭐ و ○ (خوانده‌شده) در کارت‌های دارای «مثال (با هوش مصنوعی)».
/// همه‌ی ردیف‌های کارت لبه‌ی راستشان را با این ستون هم‌تراز می‌کنند.
const double kCardSideGutter = 48;

// ═══════════════════════════════════════════════════════════════════
// SyncItemCard — «کارتِ مشترک» برای همه‌ی تب‌ها
// ═══════════════════════════════════════════════════════════════════
class SyncItemCard extends ConsumerStatefulWidget {
  final String id;
  final String en;
  final String level;
  final String? pos;
  final bool isPersonal;
  final List<String> langsToShow;
  final Map<String, String> knownTranslations;
  final bool compact;
  final bool showActions;

  /// اگر null نباشد، دکمه‌ی ✕ گوشه‌ی پایین‌راستِ کارت نشان داده می‌شود
  /// (برای لغات شخصیِ «دیکشنری من» — فقط از همان تب پنهان می‌کند).
  final VoidCallback? onRemove;

  /// وضعیتِ «خوانده‌شده» (فقط وقتی onToggleRead داده شود دکمه‌اش دیده می‌شود).
  final bool isRead;
  final VoidCallback? onToggleRead;

  /// زبانِ متنِ اصلیِ کارت (پیش‌فرض انگلیسی؛ لغاتِ شخصیِ زبان‌های دیگر هم می‌توانند باشند).
  final String lang;

  /// 🤖 ترجمه‌ی «اول AI» (فعلاً فقط تب مکالمه): کشِ گوشی ← کشِ مشترکِ سرور ← AI؛
  /// تا رسیدنِ AI ترجمه‌ی موقتِ ML Kit/آنلاین و بعد جایگزینیِ بی‌صدا.
  final bool aiFirst;

  /// 🎭 لغتِ اصطلاح/عامیانه (pos از دیتابیس): ترجمه‌ی رایگانش مشکوک حساب می‌شود و برای بازبینی (دسته‌ای) به AI می‌رود.
  final bool isExpression;

  const SyncItemCard({
    super.key,
    required this.id,
    required this.en,
    required this.level,
    required this.langsToShow,
    this.pos,
    this.isPersonal = false,
    this.knownTranslations = const <String, String>{},
    this.compact = false,
    this.showActions = false,
    this.onRemove,
    this.isRead = false,
    this.onToggleRead,
    this.lang = 'en',
    this.aiFirst = false,
    this.isExpression = false,
  });

  @override
  ConsumerState<SyncItemCard> createState() => _SyncItemCardState();
}

class _SyncItemCardState extends ConsumerState<SyncItemCard> {
  bool _showAiExamples = false;
  final GlobalKey _personalKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    // مثال‌های ذخیره‌شده نباید با بازسازیِ کارت (اسکرول/تغییر تب) «ناپدید» شوند:
    // اگر برای این لغت مثالی ذخیره است، پنل از ابتدا باز است.
    if (widget.showActions) {
      try {
        _showAiExamples = ref
            .read(wordExamplesStoreProvider)
            .load(widget.en, widget.lang)
            .isNotEmpty;
      } catch (_) {}
    }
    // 🏷️ اولین باری که یک لغتِ «شخصی» دیده می‌شود (فقط بعد از تورِ اصلی)
    if (widget.isPersonal) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await Future<void>.delayed(const Duration(milliseconds: 700));
        if (!mounted) return;
        try {
          if (!(ref.read(sharedPrefsProvider).getBool('zflut-tour-seen-v1') ??
              false)) {
            return;
          }
        } catch (_) {
          return;
        }
        await showFeatureCoach(context, ref,
            id: CoachId.personalWord, target: _personalKey);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final tp = ref.watch(textPrefsProvider);
    final compact = widget.compact;
    final pos = widget.pos;
    final isFavorite = widget.showActions &&
        ref.watch(wordFavoritesProvider.select((s) => s.contains(widget.id)));

    final removable = widget.onRemove != null;

    // اگر زبانِ مبدأ و مقصد یکی باشد (مثلاً هر دو عربی) هر زبان فقط یک‌بار نشان داده می‌شود
    final langs = <String>[];
    for (final l in widget.langsToShow) {
      if (!langs.contains(l)) langs.add(l);
    }

    final gutter = widget.showActions ? kCardSideGutter : 0.0;
    // ⭐ + ○ : بدونِ مثال کنارِ اولین ردیفِ ترجمه؛ با مثال، کنارِ جعبه‌ی مثال
    final Widget? side = widget.showActions
        ? _SideActions(
            isFavorite: isFavorite,
            onToggleFavorite: () =>
                ref.read(wordFavoritesProvider.notifier).toggle(widget.id),
            isRead: widget.isRead,
            onToggleRead: widget.onToggleRead,
          )
        : null;
    // ⭐ِ لغت (+ ○) همیشه بالا سمت راست، پشتِ 🔊 است؛ ⭐ِ مثال‌ها دقیقاً زیرِ آن
    final sideInHeader = side != null;

    return SyncAnchor(
      code: widget.lang,
      id: widget.id,
      child: Padding(
        padding: EdgeInsets.only(bottom: tp.sentenceGap.toDouble()),
        child: Stack(
          children: [
      Container(
        padding: compact
            ? const EdgeInsets.fromLTRB(10, 8, 10, 8)
            // کارتِ شخصی جای ✕ی پایین‌راست را دارد (مثل Hope: paddingBottom 30)
            : EdgeInsets.fromLTRB(14, 12, 14, removable ? 30 : 10),
        decoration: BoxDecoration(
          color: widget.isRead ? c.surfaceRead : c.surface,
          borderRadius: BorderRadius.circular(compact ? 10 : 14),
          border: Border.all(
              color: widget.isRead ? const Color(0xFFE3D2A2) : c.cardBorder,
              width: compact ? 0.6 : 1),
          boxShadow: compact
              ? null
              : [
                  BoxShadow(
                    color: c.ink.withOpacity(0.04),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ═══ ردیف اصلی: [سطح] متن … [نوع] [🔊] ═══
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(
                children: [
                  if (widget.level.isNotEmpty) ...[
                    _Badge(
                      text: widget.level,
                      fg: levelColor(widget.level),
                      bg: levelBgColor(widget.level),
                      size: compact ? 10 : 11,
                    ),
                    const SizedBox(width: 8),
                  ],
                  
                  // ═══ متن اصلی: لمسِ لغت / انتخابِ محدوده → کارتِ مشترک ═══
                  Expanded(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: SelectableSyncText(
                        code: widget.lang,
                        id: widget.id,
                        text: widget.en,
                        sentence: widget.en,
                        style: TextStyle(
                          color: c.ink,
                          fontSize: (compact ? 15 : 19) * tp.scaleFactor,
                          fontWeight: (tp.bold == TargetBoldMode.both ||
                                  tp.bold == TargetBoldMode.text)
                              ? FontWeight.w700
                              : FontWeight.w400,
                          height: 1.25,
                        ),
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ),

                  if (pos != null && pos.isNotEmpty) ...[
                    const SizedBox(width: 6),
                    _Badge(
                      text: pos,
                      fg: c.inkSoft,
                      bg: c.paperDark,
                      size: 10,
                    ),
                  ],
                  if (widget.isPersonal) ...[
                    const SizedBox(width: 6),
                    KeyedSubtree(
                      key: _personalKey,
                      child: _Badge(
                        text: context.l10n.words_personal_badge,
                        fg: Color(0xFFA34960),
                        bg: Color(0x1FA34960),
                        size: 10,
                      ),
                    ),
                  ],
                  // از راست به چپ: 🔊 ← 🧬
                  // 🧬 مسیر عصبیِ متنِ اصلی (تکرارهای پلیر خودکار ثبت می‌شود)
                  NeuralPathButton(
                    onTap: () => showNeuralPath(
                      context,
                      word: widget.en,
                      langCode: widget.lang,
                      baseText: widget.en,
                    ),
                  ),
                  SyncSpeakButton(
                    code: widget.lang,
                    id: widget.id,
                    text: widget.en,
                    color: c.gold,
                    size: 20,
                    padding: const EdgeInsets.all(4),
                  ),
                  if (gutter > 0)
                    SizedBox(
                      width: gutter,
                      child: sideInHeader
                          ? Align(
                              alignment: Alignment.centerLeft, child: side)
                          : null,
                    ),
                ],
              ),
            ),

            // فاصله‌ی بین زبان‌ها را خودِ هر ردیفِ ترجمه با tp.langGap می‌دهد

            // ═══ ردیف‌های ترجمه ═══
            for (var li = 0; li < langs.length; li++)
              SyncTranslationRow(
                key: ValueKey('${widget.id}::${langs[li]}'),
                itemId: widget.id,
                en: widget.en,
                langCode: langs[li],
                knownText: widget.knownTranslations[langs[li]] ?? '',
                compact: compact,
                gutter: gutter,
                sourceLang: widget.lang,
                aiFirst: widget.aiFirst,
                isExpression: widget.isExpression,
              ),

            if (widget.showActions) ...[
              const SizedBox(height: 6),
              // دکمه‌ی «مثال (با هوش مصنوعی)» با لبه‌ی راستِ ستونِ 🔊/🧬 هم‌راستا است
              Directionality(
                textDirection: TextDirection.ltr,
                child: Row(
                  children: [
                    const Spacer(),
                    Padding(
                      padding: EdgeInsets.only(right: gutter),
                      child: AiExamplesButton(
                        onTap: () =>
                            setState(() => _showAiExamples = !_showAiExamples),
                        expanded: _showAiExamples,
                      ),
                    ),
                  ],
                ),
              ),
              if (_showAiExamples) ...[
                const SizedBox(height: 8),
                WordExamplesPanel(
                  word: widget.en,
                  langCode: widget.lang,
                  nativeCode: ref.read(languageSelectionProvider).native,
                  meaningNative: widget.knownTranslations[
                          ref.read(languageSelectionProvider).native] ??
                      '',
                  targetLangs: langs,
                  gutter: gutter,
                ),
              ],
            ],
          ],
        ),
      ),
            // ✕ فقط برای لغات/عبارات شخصی: از تبِ «دیکشنری من» پنهان می‌شود،
            // ولی از «لغات ذخیره‌شده» پاک نمی‌شود.
            if (removable)
              Positioned(
                right: 8,
                bottom: 6,
                child: Tooltip(
                  message: context.l10n.words_remove_from_dictionary_hint,
                  child: InkWell(
                    onTap: widget.onRemove,
                    customBorder: const CircleBorder(),
                    child: Container(
                      width: 22,
                      height: 22,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: c.surface,
                        border: Border.all(color: c.cardBorder),
                      ),
                      child: Icon(Icons.close, size: 12, color: c.inkSoft),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ReadToggle extends StatelessWidget {
  final bool isRead;
  final VoidCallback onTap;
  const _ReadToggle({required this.isRead, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: context.l10n.grammar_mark_as_read,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 22,
          height: 22,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isRead ? const Color(0xFF3F9B72) : Colors.transparent,
            border: Border.all(
              color: isRead ? const Color(0xFF276E4F) : const Color(0xFFC8BE95),
              width: 1.6,
            ),
          ),
          child: isRead
              ? const Icon(Icons.check, size: 13, color: Colors.white)
              : null,
        ),
      ),
    );
  }
}

/// ستونِ کناریِ کارت: ⭐ (علاقه‌مندی) + ○ (خوانده‌شد)
class _SideActions extends StatelessWidget {
  final bool isFavorite;
  final VoidCallback onToggleFavorite;
  final bool isRead;
  final VoidCallback? onToggleRead;
  const _SideActions({
    required this.isFavorite,
    required this.onToggleFavorite,
    required this.isRead,
    required this.onToggleRead,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkResponse(
            onTap: onToggleFavorite,
            radius: 16,
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: Icon(
                isFavorite ? Icons.star : Icons.star_border,
                size: 20,
                color: isFavorite
                    ? const Color(0xFFF5C518)
                    : c.inkSoft.withOpacity(0.4),
              ),
            ),
          ),
          if (onToggleRead != null) ...[
            const SizedBox(width: 2),
            _ReadToggle(isRead: isRead, onTap: onToggleRead!),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// SyncTranslationRow — ردیفِ ترجمه‌ی برنامه
// ═══════════════════════════════════════════════════════════════════
class SyncTranslationRow extends ConsumerStatefulWidget {
  final String itemId;
  final String en;
  final String langCode;
  final String knownText;
  final bool compact;

  /// عرضِ ستونِ کناری که انتهای ردیف رزرو می‌شود (۰ = بدون ستون)
  final double gutter;

  /// ⭐ + ○ ؛ فقط در اولین ردیف و وقتی مثال باز نیست داده می‌شود
  final Widget? sideActions;

  /// زبانِ متنِ مبدأ (پیش‌فرض انگلیسی)
  final String sourceLang;

  /// 🤖 ترجمه‌ی «اول AI» (به SyncItemCard.aiFirst نگاه کن)
  final bool aiFirst;

  /// 🎭 اصطلاح/عامیانه (به SyncItemCard.isExpression نگاه کن)
  final bool isExpression;

  const SyncTranslationRow({
    super.key,
    required this.itemId,
    required this.en,
    required this.langCode,
    this.knownText = '',
    this.compact = false,
    this.gutter = 0,
    this.sideActions,
    this.sourceLang = 'en',
    this.aiFirst = false,
    this.isExpression = false,
  });

  @override
  ConsumerState<SyncTranslationRow> createState() => _SyncTranslationRowState();
}

class _SyncTranslationRowState extends ConsumerState<SyncTranslationRow> {
  static const int _maxAttempts = 2;

  String? _text;
  bool _failed = false;
  bool _retrying = false;
  bool _retryFailed = false;
  final GlobalKey _refreshKey = GlobalKey();
  int _gen = 0;
  bool _fromKnown = false; // متنِ فعلی از فایلِ داده آمده و هنوز AI جایگزینش نکرده
  void Function()? _aiStop; // 🤖 لغوِ ترجمه‌ی «اول AI»

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant SyncTranslationRow old) {
    super.didUpdateWidget(old);
    if (old.en != widget.en ||
        old.sourceLang != widget.sourceLang ||
        old.langCode != widget.langCode ||
        old.knownText != widget.knownText) {
      _aiStop?.call();
      _aiStop = null;
      _text = null;
      _failed = false;
      _retryFailed = false;
      _retrying = false;
      _resolve();
    }
  }

  @override
  void dispose() {
    _gen++;
    _aiStop?.call();
    _aiStop = null;
    super.dispose();
  }

  /// معنیِ از‌پیش‌معلوم فقط وقتی معتبر است که به رسم‌الخطِ همین زبان باشد
  /// (مثلاً معنیِ اسپانیاییِ یک لغتِ شخصی نباید در ردیفِ FA بنشیند).
  bool get _hasKnown =>
      widget.knownText.isNotEmpty &&
      textMatchesScript(widget.knownText, widget.langCode);

  bool _usable(String t) {
    final s = t.trim();
    if (s.isEmpty) return false;
    return !looksLikelyMistranslated(widget.en, s, widget.langCode,
        sourceLang: widget.sourceLang);
  }

  void _resolve() {
    final gen = ++_gen;
    _fromKnown = false;

    // 🤖 تب Talk: ترجمه‌ی آماده‌ی داخلِ فایل (known) فقط موقتی است؛ AI/کشِ مشترک جایگزینش می‌کند
    final aiRow = widget.aiFirst &&
        widget.sourceLang.isNotEmpty &&
        widget.sourceLang != widget.langCode;
    if (aiRow) {
      _resolveAiFirst(gen);
      return;
    }

    if (_hasKnown) {
      _text = widget.knownText;
      KnownTranslations.put(
          widget.en, widget.sourceLang, widget.langCode, widget.knownText);
      // اگر کاربر با دکمه‌ی رفرش دوباره ترجمه‌اش کرده، نسخه‌ی ذخیره‌شده نشان داده شود
      // (برای همه‌ی زبان‌ها، نه فقط فارسی)
      final saved = ref
          .read(translationServiceProvider)
          .peekCached(widget.en, widget.sourceLang, widget.langCode);
      if (saved != null && _usable(saved)) _text = saved;
      if (!TranslationCacheDb.instance.isReady) {
        // کش هنوز لود نشده بود → بعد از آماده شدن، ترجمه‌ی رفرش‌شده را جایگزین کن
        TranslationCacheDb.instance.ready.then((_) {
          if (!mounted || gen != _gen) return;
          final s2 = ref
              .read(translationServiceProvider)
              .peekCached(widget.en, widget.sourceLang, widget.langCode);
          if (s2 != null && _usable(s2) && s2.trim() != _text) {
            setState(() => _text = s2.trim());
          }
        });
      }
      return;
    }

    if (widget.aiFirst &&
        widget.sourceLang.isNotEmpty &&
        widget.sourceLang != widget.langCode) {
      _resolveAiFirst(gen);
      return;
    }

    final service = ref.read(translationServiceProvider);
    final hit = service.peekCached(widget.en, widget.sourceLang, widget.langCode);
    if (hit != null && _usable(hit)) {
      _text = hit;
      return;
    }

    Future.delayed(const Duration(milliseconds: 200), () {
      if (!mounted || gen != _gen) return;
      _fetch(gen, 0);
    });
  }

  /// 🤖 «اول AI»: نمایشِ فوریِ آنچه روی گوشی هست، بعد AI/کشِ مشترک؛ موقتی‌ها بی‌صدا جایگزین می‌شوند.
  void _resolveAiFirst(int gen) {
    final service = ref.read(translationServiceProvider);
    final peek =
        AiFirstTranslator.peek(service, widget.en, widget.sourceLang, widget.langCode);
    if (_hasKnown) {
      KnownTranslations.put(
          widget.en, widget.sourceLang, widget.langCode, widget.knownText);
    }
    if (peek != null && peek.isFinal && _usable(peek.text)) {
      _text = peek.text; // نهایی (قفل‌شده/AI/آماده‌ی اپ)؛ همگام چون از initState می‌آید
    } else if (_hasKnown && _usable(widget.knownText)) {
      _text = widget.knownText; // موقتی تا رسیدنِ AI
      _fromKnown = true;
    } else if (peek != null && _usable(peek.text)) {
      _text = peek.text;
    }
    _aiStop?.call();
    _aiStop = AiFirstTranslator.watch(
      svc: service,
      ai: ref.read(aiSettingsProvider),
      text: widget.en,
      from: widget.sourceLang,
      to: widget.langCode,
      onValue: (t, isFinal) {
        if (!mounted || gen != _gen) return;
        final s = t.trim();
        if (s.isEmpty || !_usable(s)) return;
        // ترجمه‌ی موقتیِ ماشینی روی متنِ آماده‌ی فایل نمی‌نشیند؛ فقط نتیجه‌ی نهایی (AI)
        if (_fromKnown && !isFinal) return;
        if (s == _text && !_failed) return;
        if (isFinal) {
          _fromKnown = false;
          KnownTranslations.put(widget.en, widget.sourceLang, widget.langCode, s);
        }
        setState(() {
          _text = s;
          _failed = false;
        });
      },
      onGiveUp: () {
        if (!mounted || gen != _gen) return;
        if (_text == null) setState(() => _failed = true);
      },
    );
  }

  Future<void> _fetch(int gen, int attempt) async {
    final service = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);
    final en = widget.en;
    final code = widget.langCode;

    String? result;
    try {
      result = await service.translate(
        text: en,
        targetLang: code,
        sourceLang: widget.sourceLang,
        aiSettings: ai,
        treatAsIdiom: widget.isExpression,
      );
    } catch (_) {
      result = null;
    }
    if (!mounted || gen != _gen) return;

    final r = result;
    if (r != null && _usable(r)) {
      setState(() {
        _text = r.trim();
        _failed = false;
      });
      return;
    }

    if (attempt + 1 < _maxAttempts) {
      await Future.delayed(Duration(milliseconds: 1500 * (attempt + 1)));
      if (!mounted || gen != _gen) return;
      await _fetch(gen, attempt + 1);
      return;
    }

    setState(() => _failed = true);
  }

  /// اولین بار که کاربر دکمه‌ی رفرش را می‌زند، همان دکمه روشن و توضیح داده می‌شود.
  Future<void> _retryWithCoach() async {
    if (_retrying) return;
    final go = await showFeatureCoach(context, ref,
        id: CoachId.refreshTranslation, target: _refreshKey);
    if (!go || !mounted) return;
    await _retry();
  }

  Future<void> _retry() async {
    if (_retrying) return;
    final service = ref.read(translationServiceProvider);
    final ai = ref.read(aiSettingsProvider);
    final en = widget.en;
    final code = widget.langCode;
    final gen = ++_gen;

    setState(() {
      _retrying = true;
      _retryFailed = false;
    });

    String? result;
    try {
      result = await service.retranslate(
        text: en,
        targetLang: code,
        sourceLang: widget.sourceLang,
        aiSettings: ai,
        previous: _text,
        keepPrevious: true,
      );
    } catch (_) {
      result = null;
    }
    if (!mounted || gen != _gen) return;

    final r = result;
    if (r != null && _usable(r)) {
      await service.cachePut(en, widget.sourceLang, code, r.trim());
      if (!mounted || gen != _gen) return;
      setState(() {
        _text = r.trim();
        _failed = false;
        _retrying = false;
      });
    } else {
      setState(() {
        _retrying = false;
        if (_text == null) {
          _failed = true;
        } else {
          _retryFailed = true;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final tp = ref.watch(textPrefsProvider);
    final text = _text;
    final loading = text == null && !_failed;
    final rtl = dirFor(widget.langCode) == TextDirection.rtl;

    if (text != null) {
      syncReportTranslation(context, ref, widget.langCode, widget.itemId, text);
    }

    final canRetry = !loading;

    // 🗂️ ↻ ترجمه‌ی قبلی را نگه داشته و جدید «گزینه‌ی دوم» شده
    Widget? altRow;
    if (text != null) {
      final svc = ref.read(translationServiceProvider);
      final alt = svc.alternative(widget.en, widget.langCode);
      if (alt != null && alt.trim() != text.trim()) {
        altRow = Padding(
          padding: const EdgeInsets.only(left: 36),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              TranslationAltRow(
            alt: alt,
            textDirection: dirFor(widget.langCode),
            onChoose: () async {
              final v = await svc.chooseAlternative(
                  widget.en, widget.sourceLang, widget.langCode);
              if (v == null || !mounted) return;
              await svc.cachePut(
                  widget.en, widget.sourceLang, widget.langCode, v.trim());
              if (!mounted) return;
              setState(() => _text = v.trim());
            },
            onDismiss: () async {
              await svc.dismissAlternative(widget.en, widget.langCode);
              if (mounted) setState(() {});
            },
              ),
              // ↩ ترجمه‌ی برگشتیِ «گزینه‌ی دوم»: کاربر قبل از انتخاب بفهمد درست است یا نه
              if (widget.aiFirst && widget.sourceLang != widget.langCode)
                BackTranslationLine(
                  langCode: widget.langCode,
                  text: alt,
                  alwaysShow: true,
                  compact: widget.compact,
                  leftInset: 0,
                ),
            ],
          ),
        );
      }
    }

    return SyncAnchor(
      code: widget.langCode,
      id: widget.itemId,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Padding(
          padding: EdgeInsets.only(top: tp.langGap.toDouble()),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: c.paperDark,
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(color: c.cardBorder, width: 0.6),
                ),
                child: Text(
                  widget.langCode.toUpperCase(),
                  style: TextStyle(
                    color: c.gold,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              
              // ═══ متن ترجمه: لمسِ لغت / انتخابِ محدوده → کارتِ مشترک ═══
              Expanded(
                child: text != null
                    ? Align(
                        alignment:
                            rtl ? Alignment.centerRight : Alignment.centerLeft,
                        child: SelectableSyncText(
                          code: widget.langCode,
                          id: widget.itemId,
                          text: text,
                          sentence: text,
                          style: TextStyle(
                            color: c.translationText,
                            fontSize: (widget.compact ? 13 : 14) * tp.scaleFactor,
                            fontWeight: (tp.bold == TargetBoldMode.both ||
                                    tp.bold == TargetBoldMode.translation)
                                ? FontWeight.w600
                                : FontWeight.w400,
                            height: 1.3,
                          ),
                          textDirection: dirFor(widget.langCode),
                          textAlign: rtl ? TextAlign.right : TextAlign.left,
                        ),
                      )
                    : Text(
                        _failed
                            ? context.l10n.reader_not_translated_retry
                            : context.l10n.grammar_translating,
                        style: TextStyle(
                          color: _failed ? c.rose : c.inkSoft,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
              
              if (_retryFailed)
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Text(
                    context.l10n.translation_no_better,
                    style: TextStyle(color: c.rose, fontSize: 10),
                  ),
                ),
              if (canRetry)
                TourTarget(
                  id: 'tr_refresh',
                  child: KeyedSubtree(
                  key: _refreshKey,
                  child: _IconBtn(
                    onTap: _retrying ? null : _retryWithCoach,
                    size: 16,
                    color: c.inkSoft.withOpacity(0.7),
                    child: _retrying
                        ? SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                                strokeWidth: 1.6, color: c.inkSoft),
                          )
                        : null,
                    icon: Icons.refresh,
                  ),
                ),
                ),
              // 🧬 مسیر عصبیِ همین زبان؛ تقویمش با بقیه‌ی زبان‌های همین آیتم مشترک است
              if (text != null)
                NeuralPathButton(
                  onTap: () => showNeuralPath(
                    context,
                    word: text,
                    langCode: widget.langCode,
                    baseText: widget.en,
                  ),
                ),
              if (text != null)
                SyncSpeakButton(
                  code: widget.langCode,
                  id: widget.itemId,
                  text: text,
                  color: c.gold,
                  size: widget.compact ? 17 : 16,
                  padding: const EdgeInsets.all(5),
                ),
              if (widget.gutter > 0)
                SizedBox(
                  width: widget.gutter,
                  child: widget.sideActions == null
                      ? null
                      : Align(
                          alignment: Alignment.centerLeft,
                          child: widget.sideActions),
                ),
            ],
          ),
            // 🔤 خوانشِ لاتین (هندی/چینی/ژاپنی/کره‌ای/روسی) زیرِ متنِ ترجمه
            if (text != null)
              RomanLine(
                langCode: widget.langCode,
                text: text,
                compact: widget.compact,
              ),
            // ↩ ترجمه‌ی برگشتی به زبانِ مادری (فقط تب Talk) تا کاربر بفهمد ترجمه درست رفته یا نه
            if (text != null &&
                widget.aiFirst &&
                widget.sourceLang != widget.langCode)
              BackTranslationLine(
                langCode: widget.langCode,
                text: text,
                en: widget.en,
                sourceLang: widget.sourceLang,
                compact: widget.compact,
              ),
            if (altRow != null) altRow,
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// اجزای کوچکِ مشترک (بدون تغییر)
// ═══════════════════════════════════════════════════════════════════
class _Badge extends StatelessWidget {
  final String text;
  final Color fg;
  final Color bg;
  final double size;

  const _Badge({
    required this.text,
    required this.fg,
    required this.bg,
    this.size = 11,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: fg,
          fontSize: size,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final double size;
  final Widget? child;

  const _IconBtn({
    required this.icon,
    required this.color,
    required this.onTap,
    this.size = 18,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: child ?? Icon(icon, size: size, color: color),
        ),
      ),
    );
  }
}

class NeuralPathButton extends StatelessWidget {
  final VoidCallback onTap;
  const NeuralPathButton({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: 'مسیر عصبی',
      child: InkResponse(
        onTap: onTap,
        radius: 18,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          child: Icon(Icons.hub_outlined,
              size: 16, color: context.appColors.inkSoft.withOpacity(0.4)),
        ),
      ),
    );
  }
}

class AiExamplesButton extends StatelessWidget {
  final VoidCallback onTap;
  final bool expanded;

  const AiExamplesButton({
    super.key,
    required this.onTap,
    required this.expanded,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: c.gold.withOpacity(0.08),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: c.gold.withOpacity(0.35), width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 13, color: c.gold),
            const SizedBox(width: 5),
            Text(
              expanded
                  ? context.l10n.word_examples_btn_close
                  : context.l10n.word_examples_btn_generate,
              style: TextStyle(
                color: c.gold,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
