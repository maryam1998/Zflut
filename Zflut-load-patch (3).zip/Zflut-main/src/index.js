// ---------------------------------------------------------------------------
// LingoLearn — Cloudflare Worker backend
// مسیر این فایل باید دقیقاً src/index.js باشه (طبق wrangler.toml).
// ---------------------------------------------------------------------------

import { handleTranscribe } from "./transcribe.js";
import { handleWordExample } from "./examples.js";
import { authGate, handleSession, verifySessionToken, handleDevices, handleDevicesLogoutAll } from "./auth.js";
import { handleUsage, featureOf, aiMissGate } from "./usage.js";
import { handleContent } from "./content.js";
import { recordUsage, handleAdminReport } from "./metrics.js";
import { beginAi } from "./load.js";
import { handleTrShare } from "./trshare.js";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-App-Token, Authorization, X-Feature, X-Use-Id, X-Device-Id, X-Device-Type, X-Device-Model",
};

export default {
  // 🧹 پاک‌سازیِ هفتگیِ کش (cron در wrangler.toml): فقط ردیف‌های قدیمی‌تر از ۳ سال؛ ترجمه‌های اصلاح‌شده‌ی کاربرها (provider='user') هیچ‌وقت پاک نمی‌شوند.
  async scheduled(event, env, ctx) {
    if (!env.TR_DB) return;
    ctx.waitUntil(
      (async () => {
        try {
          await genCacheInit(env);
          await env.TR_DB.prepare("DELETE FROM gen_cache WHERE created < ?1 AND (provider IS NULL OR provider != 'user')")
            .bind(Date.now() - GEN_CACHE_PURGE_MS)
            .run();
        } catch (e) {
          console.error("[gen_cache purge]", e && e.message);
        }
      })()
    );
  },

  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (url.pathname === "/" && request.method === "GET") {
      return json({ ok: true, message: "Phrasebook backend is running" });
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return json({
        ok: true,
        providers: getProviderChain(env),
        hfTts: {
          fa: hfTtsConfigStatus(env, "fa"),
          ar: hfTtsConfigStatus(env, "ar"),
        },
      });
    }

    // 📊 پنلِ گزارشِ مصرفِ AI (با ADMIN_KEY؛ جدا از /api/*)
    if (url.pathname === "/admin/usage-report" && request.method === "GET") {
      return handleAdminReport(request, env, url);
    }

    // 🔐 ورود: توکنِ Supabase → توکنِ نشستِ امضاشده (فقط همین مسیر بدونِ X-App-Token است)
    if (url.pathname === "/api/session" && request.method === "POST") {
      return handleSession(request, env, CORS_HEADERS);
    }

    // 🔒 دستگاه‌های متصل (لیست) و «خروج از همه‌ی دستگاه‌ها» (با کدِ ایمیل)
    if (url.pathname === "/api/devices" && request.method === "GET") {
      return handleDevices(request, env, CORS_HEADERS);
    }
    if (url.pathname === "/api/devices/logout-all" && request.method === "POST") {
      return handleDevicesLogoutAll(request, env, CORS_HEADERS);
    }

    // 💎 وضعیتِ سهمیه‌ی رایگان / شروعِ یک استفاده (بدونِ شمارشِ سهمیه‌ی روزانه)
    if ((url.pathname === "/api/use" && request.method === "POST") ||
        (url.pathname === "/api/usage" && request.method === "GET")) {
      const sess = await verifySessionToken(env, request.headers.get("X-App-Token"));
      if (!sess) return new Response(JSON.stringify({ error: "login required" }), {
        status: 401, headers: { "Content-Type": "application/json", ...CORS_HEADERS } });
      return handleUsage(request, env, url, CORS_HEADERS, sess);
    }

    // 💎 محتوای پولی (فقط Pro) — توکنِ نشست + چکِ پلن داخلِ handleContent
    if (url.pathname.startsWith("/api/content/")) {
      const sess = await verifySessionToken(env, request.headers.get("X-App-Token"));
      if (!sess) return new Response(JSON.stringify({ error: "login required" }), {
        status: 401, headers: { "Content-Type": "application/json", ...CORS_HEADERS } });
      return handleContent(request, env, url, CORS_HEADERS, sess);
    }

    // 🔐 همه‌ی بقیه‌ی /api/* نیاز به توکنِ نشست + سهمیه‌ی روزانه‌ی هر کاربر دارند
    if (url.pathname.startsWith("/api/")) {
      const denied = await authGate(request, env, url, CORS_HEADERS);
      if (denied) return denied;
    }

    // 📊 ثبتِ مصرف (فقط شمارش؛ تبدیلِ گفتار و ترجمه‌ی زیرنویس)
    if (request.method === "POST" &&
        (url.pathname === "/api/transcribe" || url.pathname === "/api/translate-subtitles")) {
      ctx.waitUntil(recordUsage(env, request, {
        feature: url.pathname === "/api/transcribe" ? "stt" : "ytsub", provider: "n/a" }));
    }

    // 🧩 مثال‌سازِ مشترکِ Pro (کشِ سراسریِ مثال‌ها در D1؛ AI فقط وقتی مثالِ تازه لازم است)
    if (url.pathname === "/api/word-example") {
      const sess = await verifySessionToken(env, request.headers.get("X-App-Token"));
      if (!sess) return json({ error: "login required" }, 401);
      return handleWordExample(request, env, ctx, CORS_HEADERS, sess, {
        buildPrompt: buildExamplePrompt,
        getProviderChain, callProvider, withTimeout, sanitizeAiText, badAiOutputReason, recordUsage,
        beginAi: (kind, opts) => beginAi(request, env, kind, CORS_HEADERS, opts),
      });
    }

    // ⭐ NEW: تبدیل صدا به متن با Whisper (Cloudflare Workers AI)
    if (url.pathname === "/api/transcribe" && request.method === "POST") {
      // ⚖️ همزمانیِ Pro + سقفِ سراسریِ روزانه‌ی Whisper
      const gate = await beginAi(request, env, "whisper", CORS_HEADERS);
      if (gate.deny) return gate.deny;
      try {
        return await handleTranscribe(request, env);
      } finally {
        await gate.release();
      }
    }

    // 🔇 TTS آنلاین حذف شد (هزینه + مجوز). صدا فقط آفلاین: بسته‌ی صوتی اپ یا TTS خودِ گوشی.
    if (url.pathname === "/api/tts" || url.pathname === "/api/tts-gemini") {
      return json({ error: "online TTS removed; use offline voice", code: "tts_removed" }, 410);
    }

    if (url.pathname === "/api/youtube-captions" && request.method === "GET") {
      const videoId = (url.searchParams.get("videoId") || "").trim();
      const lang = (url.searchParams.get("lang") || "en").trim();
      if (!videoId) return json({ error: "videoId is required" }, 400);
      if (!/^[A-Za-z0-9_-]{5,32}$/.test(videoId) || !/^[A-Za-z0-9_-]{1,16}$/.test(lang)) {
        return json({ error: "invalid videoId or lang" }, 400);
      }
      try {
        const result = await fetchYoutubeCaptions(videoId, lang, env);
        return json(result);
      } catch (e) {
        return json({ ok: false, error: e.message || "Could not fetch captions", noCaptions: !!e.noCaptions }, 502);
      }
    }

    // 📺 ترجمه‌ی زیرنویس یوتیوب به‌صورت chunk (چند خط + جمله‌های همسایه به‌عنوان زمینه)
    if (url.pathname === "/api/translate-subtitles" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Invalid JSON body" }, 400);
      }
      try {
        return json(await translateSubtitleChunk(body, env, ctx,
          () => beginAi(request, env, "ai", CORS_HEADERS, { queue: false })));
      } catch (e) {
        if (e && e.gateResponse) return e.gateResponse; // سقفِ سراسریِ روزانه
        return json({ error: e.message || "subtitle translation failed" }, 502);
      }
    }

    // 📺 وقتی MediaSession آی‌دی ویدیو نمی‌ده، از روی عنوان (+مدت و کانال) آی‌دی رو پیدا می‌کنه
    if (url.pathname === "/api/youtube-resolve" && request.method === "GET") {
      const title = (url.searchParams.get("title") || "").trim().slice(0, 200);
      const channel = (url.searchParams.get("channel") || "").trim().slice(0, 100);
      const durationSec = Number(url.searchParams.get("durationSec") || 0) || 0;
      if (!title) return json({ error: "title is required" }, 400);
      try {
        return json(await resolveYoutubeVideoId(title, channel, durationSec));
      } catch (e) {
        return json({ error: e.message || "could not resolve video" }, 502);
      }
    }

    // 🗄️ ترجمه‌ی متنِ کوتاه با کشِ مشترکِ همه‌ی کاربرها (اپ اول همین را صدا می‌زند)
    if (url.pathname === "/api/translate-text" && request.method === "POST") {
      return handleTranslateText(request, env, ctx);
    }

    // 🗄️ کشِ مشترکِ ترجمه‌های اصلاح‌شده (↻ کاربرها) — بدونِ AI، فقط D1
    if (url.pathname === "/api/tr-share" && request.method === "POST") {
      return handleTrShare(request, env, ctx, CORS_HEADERS, { genCacheKey, genCacheGet, genCachePut, trCacheKey });
    }

    if (url.pathname === "/api/generate" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Invalid JSON body" }, 400);
      }
      const { prompt, maxTokens } = body || {};
      if (!prompt || typeof prompt !== "string") {
        return json({ error: "prompt (string) is required" }, 400);
      }
      const capped = Math.min(Math.max(Number(maxTokens) || 1000, 1), 8192);
      // 🔒 سقفِ طولِ پرامپت (هزینه‌ی توکنِ ورودی). env.MAX_PROMPT_CHARS قابلِ تنظیم؛ پیش‌فرض ۳۰٬۰۰۰ نویسه.
      const maxPrompt = Number(env.MAX_PROMPT_CHARS) > 0 ? Number(env.MAX_PROMPT_CHARS) : 30000;
      if (prompt.length > maxPrompt) return json({ error: "prompt too long", code: "prompt_too_long", max: maxPrompt }, 413);

      // کشِ مشترکِ D1: همان پرامپت (با همان سقفِ توکن) دوباره به هوش مصنوعی نمی‌رود.
      // برای «مثالِ جدید/بازتولید» کلاینت می‌تواند { "noCache": true } بفرستد.
      const useCache = !body.noCache;
      const cacheKey = useCache ? await genCacheKey(prompt, capped) : null;
      if (cacheKey) {
        const hit = await genCacheGet(env, cacheKey);
        if (hit) {
          ctx.waitUntil(recordUsage(env, request, { feature: "other", provider: "cache", cached: true }));
          return json({ text: hit, provider: "cache", cached: true });
        }
      }

      // 🌐 درخواستِ بدونِ X-Feature معتبر (ترجمه/تأیید/کلاینتِ دست‌ساز) فقط وقتی که کش جواب نداشت سقفِ روزانه‌ی خودش را مصرف می‌کند
      if (!featureOf(request, url)) {
        const over = await missGate(request, env);
        if (over) return over;
      }

      // ⚖️ همزمانیِ Pro (حداکثر ۲ هم‌زمان، بقیه در صفِ FIFO) + سقفِ سراسریِ روزانه — فقط وقتی کش جواب نداشت
      const gate = await beginAi(request, env, "ai", CORS_HEADERS);
      if (gate.deny) return gate.deny;
      try {
        // 🎚️ زنجیره‌ی ارزان برای کارهای ساده (چت/تصحیح/گرامر/ترجمه/...) و زنجیره‌ی
        // قوی فقط برای داستان؛ اگر AI_PROVIDER_LIGHT / AI_PROVIDER_STRONG ست نشده
        // باشد همان AI_PROVIDER قبلی استفاده می‌شود (رفتارِ فعلی بدونِ تغییر).
        const chain = getProviderChainFor(env, featureOf(request, url));
        const errors = [];
        // سقفِ زمانِ هر پرووایدر: یکی که کند/بی‌صدا شد، کلِ درخواست را معطل نکند و
        // زنجیره سریع برود سراغِ بعدی. متنِ کوتاه ≈ ۵ ثانیه؛ متنِ بلند (داستان) بیشتر.
        const perProviderMs = Math.min(45000, 4000 + capped * 10);
        for (const provider of chain) {
          try {
            const raw = await withTimeout(callProvider(provider, prompt, capped, env), perProviderMs, provider);
            // خروجیِ «فکرکردن»/«گارد (User Safety: safe)»/پرامپتِ برگشتی جواب نیست؛
            // به‌جای فرستادنش به اپ، همین‌جا رد می‌شود و پرووایدرِ بعدی امتحان می‌شود.
            const text = sanitizeAiText(raw);
            const bad = badAiOutputReason(text, prompt);
            if (bad) throw new Error(`unusable output (${bad})`);
            if (cacheKey) ctx.waitUntil(genCachePut(env, cacheKey, text, provider));
            ctx.waitUntil(recordUsage(env, request, { feature: "other", provider, cached: false, prompt, text }));
            return json({ text, provider });
          } catch (e) {
            errors.push(`${provider}: ${e.message}`);
          }
        }
        console.error("[AI-FAIL] /api/generate همه‌ی پرووایدرها خطا دادند:", errors.join(" | ").slice(0, 900));
        return json({ error: errors.join(" | ") }, 502);
      } finally {
        await gate.release();
      }
    }

    return json({ error: "Not found" }, 404);
  },
};

// پرامپتِ مثال‌ساز (همان متنِ پرامپتِ اپ در word_examples.dart)
function buildExamplePrompt({ word, lang, meaning, nativeLabel, used }) {
  const langNames = { en: "English", fa: "Persian", ar: "Arabic", de: "German", fr: "French", es: "Spanish", it: "Italian", tr: "Turkish", ru: "Russian" };
  const langLabel = langNames[lang.split("-")[0]] || lang;
  const avoid = used.length
    ? "Do NOT reuse or closely paraphrase any of these already-used examples for this same word:\n" +
      used.slice(0, 20).map((u, i) => `${i + 1}. ${String(u).slice(0, 300)}`).join("\n") + "\n\n"
    : "";
  const mean = meaning ? ` (its ${nativeLabel || "native-language"} meaning is: "${meaning}")` : "";
  return (
    `Write exactly ONE natural example sentence in ${langLabel} that uses the word/expression "${word}"${mean} ` +
    "in a way that reflects REAL, current, everyday usage — the kind of sentence a native speaker might actually say or write today. " +
    "Avoid textbook-sounding, generic sentences. " +
    "Keep it natural length (roughly 8-20 words), grammatically correct, and appropriate for a language learner to study.\n\n" +
    `${avoid}Respond with ONLY the example sentence itself in ${langLabel} — no quotes, no translation, no numbering, no explanation, nothing else.`
  );
}

// سقفِ روزانه‌ی درخواست‌های کش‌نشده‌ی بدونِ بخش (ترجمه). فقط در AUTH_MODE=on اعمال می‌شود.
async function missGate(request, env) {
  if (String(env.AUTH_MODE || "on").toLowerCase() !== "on") return null;
  const sess = await verifySessionToken(env, request.headers.get("X-App-Token"));
  return sess ? aiMissGate(env, sess.sub, CORS_HEADERS, sess.em) : null;
}

// --- /api/translate-text -----------------------------------------------------
// ورودی: { text, source_lang_code ("auto" هم می‌شود), target_lang_code } → خروجی: { text, provider, cached }
// کش: همان جدولِ gen_cache (کلیدِ جدا از پرامپت‌های generate). مسیر/زنجیره‌ی پرووایدرها مثلِ generate است.
const TT_LANGS = {
  fa: "Persian", en: "English", it: "Italian", hi: "Hindi", tr: "Turkish", ar: "Arabic",
  es: "Spanish", de: "German", fr: "French", zh: "Chinese", ko: "Korean", ru: "Russian", ja: "Japanese",
};

// 🔌 قطع‌کننده‌ی مدار (per-isolate): پرووایدری که پشتِ‌هم خطا بدهد چند ثانیه کنار گذاشته می‌شود تا صف پشتِ یک سرویسِ خراب نماند.
//   CB_FAILS (پیش‌فرض ۳) خطای پشتِ‌هم → CB_COOL_MS (پیش‌فرض ۶۰ ثانیه) کنار.
const CB_STATE = new Map();
function numVar(env, key, dflt) {
  const raw = env && env[key];
  if (raw === undefined || raw === null || String(raw).trim() === "") return dflt;
  const v = Number(raw);
  return Number.isFinite(v) && v >= 0 ? v : dflt;
}
function cbOpen(p) {
  const s = CB_STATE.get(p);
  return !!(s && s.until > Date.now());
}
function cbOk(p) {
  CB_STATE.delete(p);
}
function cbFail(env, p) {
  const s = CB_STATE.get(p) || { fails: 0, until: 0 };
  s.fails++;
  if (s.fails >= numVar(env, "CB_FAILS", 3)) {
    s.until = Date.now() + numVar(env, "CB_COOL_MS", 60000);
    s.fails = 0;
    console.warn(`[CB] provider=${p} کنار گذاشته شد`);
  }
  CB_STATE.set(p, s);
}

// 🤝 ادغامِ درخواست‌های هم‌زمانِ یک متن (per-isolate): ۵۰ نفر همزمان یک جمله → فقط «یک» تماسِ AI؛ بقیه منتظرِ همان نتیجه می‌مانند.
const TT_INFLIGHT = new Map();

async function handleTranslateText(request, env, ctx) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }
  const text = String(body?.text ?? "").trim();
  const target = String(body?.target_lang_code ?? "").toLowerCase();
  const source = String(body?.source_lang_code ?? "auto").toLowerCase() || "auto";
  if (!text) return json({ error: "text is required" }, 400);
  if (text.length > 300) return json({ error: "text too long" }, 400);
  if (!TT_LANGS[target]) return json({ error: "unsupported target language" }, 400);
  if (source !== "auto" && !TT_LANGS[source]) return json({ error: "unsupported source language" }, 400);

  const cacheKey = await trCacheKey(env, source, target, text);
  const hit = await genCacheGet(env, cacheKey);
  if (hit) {
    ctx.waitUntil(recordUsage(env, request, { feature: "translate", provider: "cache", cached: true }));
    return json({ text: hit, provider: "cache", cached: true });
  }

  // 🤝 اگر همین متن همین الان در همین isolate در حالِ ترجمه است، منتظرِ همان بمان (بدونِ مصرفِ سهمیه/AI)
  const pending = TT_INFLIGHT.get(cacheKey);
  if (pending) {
    try {
      const r = await pending;
      ctx.waitUntil(recordUsage(env, request, { feature: "translate", provider: "cache", cached: true }));
      return json({ text: r.text, provider: r.provider, cached: true, coalesced: true });
    } catch {
      // رهبر شکست خورد/رد شد → خودمان امتحان می‌کنیم (سهمیه‌ی خودمان را هم می‌دهیم)
    }
  }
  let settle, fail;
  const flight = new Promise((res, rej) => { settle = res; fail = rej; });
  flight.catch(() => {});
  TT_INFLIGHT.set(cacheKey, flight);
  try {
    const { resp, result } = await translateLeader(request, env, ctx, { text, target, source, cacheKey });
    if (result) settle(result); else fail(new Error("leader-failed"));
    return resp;
  } catch (e) {
    fail(e);
    throw e;
  } finally {
    TT_INFLIGHT.delete(cacheKey);
  }
}

async function translateLeader(request, env, ctx, { text, target, source, cacheKey }) {
  const none = (resp) => ({ resp, result: null });

  // 🌐 فقط ترجمه‌ی کش‌نشده (واقعاً AI) از سقفِ روزانه‌ی DAILY_TRANSLATE مصرف می‌کند
  const over = await missGate(request, env);
  if (over) return none(over);
  // ⚖️ سقفِ سراسریِ روزانه (فقط کش‌نشده‌ها؛ بدونِ صف چون ترجمه‌های کوتاه موازی می‌آیند)
  //    افتِ تدریجی: سهمِ رزروِ Pro، و pct برای خاموش‌کردنِ بازبینی در بار بالا
  const capGate = await beginAi(request, env, "ai", CORS_HEADERS, { queue: false });
  if (capGate.deny) return none(capGate.deny);

  const label = TT_LANGS[target];
  const prompt =
    `Translate the following text into ${label} by meaning, the way a native speaker would naturally say it. ` +
    `Idioms, slang, rhyming or fixed expressions and greeting/farewell formulas must be rendered with their real meaning or a natural ${label} equivalent, never word for word ` +
    `(e.g. "See you later, alligator!" is just a playful goodbye: drop the animal and the rhyme). ` +
    trStyle(target) +
    "Respond with ONLY the translation itself — no quotes, no explanation, no original text, nothing else.\n\n" +
    `Text: ${text}`;
  const maxTokens = Math.min(Math.max(Math.floor(text.length / 2) + 96, 128), 600);
  // 🧠 ترجمه با مدل‌های قوی‌تر (فقط وقتی AI_PROVIDER_TRANSLATE / *_MODEL_TRANSLATE ست شده)؛ نتیجه در D1 برای همه می‌ماند
  const { chain: trChain, env: trEnv, strong } = translateSetup(env);
  const perProviderMs = Math.min(30000, (strong ? 12000 : 4000) + maxTokens * 10);
  // ⏱️ سقفِ کلِ زمانِ زنجیره (به‌جای جمعِ تایم‌اوتِ همه‌ی پرووایدرها) — زیرِ بارِ زیاد درخواست بی‌نهایت معلق نمی‌ماند
  const budgetMs = numVar(env, "TR_TOTAL_BUDGET_MS", 22000);
  const deadline = Date.now() + budgetMs;
  const errors = [];
  for (const provider of trChain) {
    const left = deadline - Date.now();
    if (left < 1500) { errors.push("budget exhausted"); break; }
    if (cbOpen(provider)) { errors.push(`${provider}: circuit-open`); continue; }
    try {
      // Gemini 2.5 Pro «فکر» می‌کند و فکر از سقفِ توکن کم می‌شود → سقفِ بیشتر تا خروجی خالی نشود
      const mt = strong && provider === "gemini" ? maxTokens + 2000 : maxTokens;
      const raw = await withTimeout(callProvider(provider, prompt, mt, trEnv), Math.min(perProviderMs, left), provider);
      let out = sanitizeAiText(raw).trim();
      // گیومه‌ی دورِ خروجی را بردار
      out = out.replace(/^["“”«»]+|["“”«»]+$/g, "").trim();
      const bad = badAiOutputReason(out, prompt);
      if (bad) throw new Error(`unusable output (${bad})`);
      // 🛡️ قبل از ورود به کشِ مشترکِ همه‌ی کاربرها: خروجی باید واقعاً به زبانِ مقصد باشد
      if (!trScriptOk(target, text, out)) throw new Error("unusable output (wrong-script)");
      cbOk(provider);
      // 🔎 بازبینیِ دوم (TR_REVIEW="1") — با «مدل‌های رایگان/ارزان» (AI_PROVIDER_REVIEW)، نه همان مدلِ ترجمه:
      //   • وقتی مصرفِ سراسری ≥ REVIEW_OFF_PCT (پیش‌فرض ۷۰٪) خاموش است (افتِ تدریجی؛ اول بازبینی قطع می‌شود)
      //   • بودجه‌ی زمانیِ محدود (TR_REVIEW_TIMEOUT_MS)؛ هر خطا/تایم‌اوت/خروجیِ مشکوک = همان ترجمه‌ی اول
      const loadHigh = typeof capGate.pct === "number" && capGate.pct >= numVar(env, "REVIEW_OFF_PCT", 70);
      if (String(env.TR_REVIEW || "") === "1" && !loadHigh) {
        const rleft = deadline - Date.now();
        if (rleft > 1500) out = await trReviewFree(env, text, out, label, target, maxTokens, rleft);
      }
      ctx.waitUntil(genCachePut(env, cacheKey, out, provider));
      ctx.waitUntil(recordUsage(env, request, { feature: "translate", provider, cached: false, prompt, text: out }));
      return { resp: json({ text: out, provider }), result: { text: out, provider } };
    } catch (e) {
      cbFail(env, provider);
      errors.push(`${provider}: ${e.message}`);
    }
  }
  console.error("[AI-FAIL] /api/translate-text همه‌ی پرووایدرها خطا دادند:", errors.join(" | ").slice(0, 900));
  return none(json({ error: errors.join(" | ") }, 502));
}

// 🛡️ آیا خروجی خطِ زبانِ مقصد را دارد؟ (فقط برای متن‌های ≥ ۲ کلمه؛ اسمِ تکی مثل Netflix می‌تواند بدونِ تغییر بماند)
const TR_SCRIPTS = {
  fa: /[؀-ۿ]/, ar: /[؀-ۿ]/, hi: /[ऀ-ॿ]/, zh: /[一-鿿]/,
  ja: /[぀-ヿ一-鿿]/, ko: /[가-힯]/, ru: /[Ѐ-ӿ]/,
};
function trScriptOk(target, text, out) {
  const re = TR_SCRIPTS[target];
  if (!re) return true;
  if (String(text).trim().split(/\s+/).length < 2) return true;
  if (!/\p{L}/u.test(text)) return true;
  return re.test(out);
}

// 🎨 سبکِ ترجمه به فارسی: یک‌دست، محاوره‌ای‌ملایم و محترمانه؛ نه کلمه‌به‌کلمه، نه رسمی/کتابی در یک جمله و محاوره‌ای در جمله‌ی بعد.
function trStyle(target) {
  if (target !== "fa") return "";
  return (
    "Style for Persian: natural, fluent, everyday spoken Persian of Iran (polite colloquial, e.g. «چطوری؟»، «خوبه»، «می‌کنم»), " +
    "used consistently in every sentence — do not mix stiff bookish forms with colloquial ones, and never translate word for word. " +
    "Pay attention to the exact meaning of every word (e.g. \"together\" = «با هم», \"a little\" = «یه کم / کمی»). "
  );
}

// 🔎 بازبینیِ ترجمه با مدل‌های رایگان/ارزان: «درست و طبیعی است؟ همان را برگردان؛ وگرنه اصلاحش کن».
//   AI_PROVIDER_REVIEW (پیش‌فرض groq,cerebras,llm7,kilocode) و <NAME>_MODEL_REVIEW برای مدلِ بازبین.
//   حداکثر دو بازبین امتحان می‌شود؛ هر مشکلی (خطا، تایم‌اوت، خروجیِ مشکوک) = ترجمه‌ی اول بدونِ تغییر.
const REVIEW_DEFAULT_CHAIN = "groq,cerebras,llm7,kilocode";
function reviewSetup(env) {
  const raw = String(env.AI_PROVIDER_REVIEW || REVIEW_DEFAULT_CHAIN).toLowerCase();
  const chain = raw.split(",").map((p) => p.trim()).filter((p) => VALID_PROVIDERS.includes(p));
  const e = { ...env };
  for (const v of TR_MODEL_VARS) {
    if (env[v + "_REVIEW"]) e[v] = env[v + "_REVIEW"];
  }
  return { chain, env: e };
}

async function trReviewFree(env, text, out, label, target, maxTokens, leftMs) {
  const { chain, env: rEnv } = reviewSetup(env);
  const timeoutMs = Math.min(numVar(env, "TR_REVIEW_TIMEOUT_MS", 3500), leftMs);
  let tried = 0;
  for (const provider of chain) {
    if (tried >= 2) break;
    if (cbOpen(provider)) continue;
    tried++;
    try {
      const rev = await trReviewOnce(provider, rEnv, text, out, label, target, timeoutMs, maxTokens);
      cbOk(provider);
      return rev;
    } catch {
      cbFail(env, provider);
    }
  }
  return out;
}

// خطای پرووایدر (تایم‌اوت، بدونِ کلید، …) را پرتاب می‌کند؛ خروجیِ مشکوک = همان out.
async function trReviewOnce(provider, rEnv, text, out, label, target, timeoutMs, maxTokens) {
  const rp =
    `You are a strict ${label} translation reviewer.\n` +
    `Source text: ${text}\n` +
    `Proposed ${label} translation: ${out}\n` +
    `If the translation is accurate, complete and sounds natural to a native ${label} speaker, output it exactly unchanged. ` +
    `Otherwise output a corrected ${label} translation (by meaning; idioms and slang rendered naturally, never word for word). ` +
    trStyle(target) +
    `Output ONLY the final ${label} text — no quotes, no explanation, nothing else.`;
  const raw = await withTimeout(callProvider(provider, rp, maxTokens, rEnv), timeoutMs, provider);
  const rev = sanitizeAiText(raw).trim().replace(/^["“”«»]+|["“”«»]+$/g, "").trim();
  if (!rev || badAiOutputReason(rev, rp)) return out;
  if (!trScriptOk(target, text, rev)) return out;
  if (rev.length > out.length * 3 + 60) return out;
  if (rev.length < out.length * 0.4) return out; // بازبین نباید ترجمه را به‌شدت کوتاه کند (حذفِ محتوا)
  return rev;
}

// 🧠 زنجیره و مدل‌های «قوی‌تر» برای /api/translate-text.
//   AI_PROVIDER_TRANSLATE = ترتیبِ پرووایدرها (ست‌نشده = همان AI_PROVIDER قبلی)
//   <NAME>_MODEL_TRANSLATE = مدلِ قوی‌ترِ همان پرووایدر فقط برای ترجمه (مثلاً GEMINI_MODEL_TRANSLATE)
// هر پرووایدری که خطا بدهد/کلید نداشته باشد رد می‌شود و بعدی امتحان می‌شود (همان رفتارِ قبلی).
const TR_MODEL_VARS = [
  "GEMINI_MODEL", "MISTRAL_MODEL", "GROQ_MODEL", "NVIDIA_MODEL", "OPENAI_MODEL", "DEEPSEEK_MODEL",
  "OPENROUTER_MODEL", "GROK_MODEL", "CEREBRAS_MODEL", "COHERE_MODEL", "ZAI_MODEL", "CF_AI_MODEL",
];
function translateSetup(env) {
  let chain = null;
  if (env.AI_PROVIDER_TRANSLATE) {
    const c = String(env.AI_PROVIDER_TRANSLATE).toLowerCase().split(",").map((p) => p.trim()).filter((p) => VALID_PROVIDERS.includes(p));
    if (c.length) chain = c;
  }
  const e = { ...env };
  let overridden = false;
  for (const v of TR_MODEL_VARS) {
    if (env[v + "_TRANSLATE"]) { e[v] = env[v + "_TRANSLATE"]; overridden = true; }
  }
  return { chain: chain || getProviderChain(env), env: e, strong: !!chain || overridden };
}

// --- کشِ مشترکِ D1 برای /api/generate (مثال‌ساز و ...) ---------------------
// اگر binding با نام TR_DB تنظیم نشده باشد، همه‌ی این توابع بی‌صدا هیچ‌کاری نمی‌کنند.
// ⏳ دیگر TTLِ زمانی روی «خواندن» نیست: ترجمه تا وقتی متن همان است (کلیدِ هشِ متن) معتبر می‌ماند.
// این عدد فقط برای پاک‌سازیِ ردیف‌های یتیم (cron هفتگی، scheduled پایین) است.
const GEN_CACHE_PURGE_MS = 3 * 365 * 24 * 60 * 60 * 1000; // ۳ سال

// 🔖 نسخه‌ی مدل/پرامپتِ ترجمه (env.TR_MODEL_VERSION). "1" = کلیدِ قدیمی (ردیف‌های فعلیِ D1 معتبر می‌مانند)؛
// هر مقدارِ دیگر (مثلاً "2") کلیدِ همه‌ی ترجمه‌ها را عوض می‌کند → همه دوباره از AI گرفته می‌شوند.
async function trCacheKey(env, source, target, text) {
  const mv = String((env && env.TR_MODEL_VERSION) || "1").trim() || "1";
  const base = `translate-text|${source}|${target}|${text}`;
  return genCacheKey(mv === "1" ? base : `mv${mv}|${base}`, 0);
}
let genCacheReady = false;

async function genCacheKey(prompt, capped) {
  const data = new TextEncoder().encode(JSON.stringify([prompt, capped]));
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function genCacheInit(env) {
  if (genCacheReady) return;
  await env.TR_DB.prepare(
    "CREATE TABLE IF NOT EXISTS gen_cache (k TEXT PRIMARY KEY, v TEXT NOT NULL, provider TEXT, created INTEGER NOT NULL)"
  ).run();
  genCacheReady = true;
}

async function genCacheGet(env, key) {
  if (!env.TR_DB) return null;
  try {
    await genCacheInit(env);
    const row = await env.TR_DB.prepare("SELECT v, created, provider FROM gen_cache WHERE k = ?1").bind(key).first();
    // ✅ بدونِ انقضای زمانی: کلید = هشِ متن (+ نسخه‌ی مدل)، پس متنِ عوض‌شده خودبه‌خود miss می‌شود
    if (!row) return null;
    return row.v;
  } catch {
    return null;
  }
}

async function genCachePut(env, key, text, provider) {
  if (!env.TR_DB || !text) return;
  try {
    await genCacheInit(env);
    await env.TR_DB.prepare(
      "INSERT OR REPLACE INTO gen_cache (k, v, provider, created) VALUES (?1, ?2, ?3, ?4)"
    ).bind(key, text, provider, Date.now()).run();
  } catch {
    // خطای کش نباید جواب را خراب کند
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS },
  });
}

// --- زیرنویسِ واقعیِ یوتیوب -----------------------------------------------
// چند کلاینتِ innertube (ANDROID / ANDROID_VR / IOS / TV-embed) + صفحه‌ی watch هم‌زمان امتحان می‌شن؛
// اولین کسی که زیرنویسِ واقعی بده برنده‌ست. اگه همه شکست بخورن، دلیلِ واقعیِ هر کدوم تو پیام میاد.
const YT_CLIENTS = {
  ANDROID: {
    id: "3", version: "20.10.38",
    ua: "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
    client: { clientName: "ANDROID", clientVersion: "20.10.38", androidSdkVersion: 30, osName: "Android", osVersion: "11" },
  },
  ANDROID_VR: {
    id: "28", version: "1.62.27",
    ua: "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
    client: { clientName: "ANDROID_VR", clientVersion: "1.62.27", deviceMake: "Oculus", deviceModel: "Quest 3", androidSdkVersion: 32, osName: "Android", osVersion: "12L" },
  },
  IOS: {
    id: "5", version: "20.10.4",
    ua: "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
    client: { clientName: "IOS", clientVersion: "20.10.4", deviceMake: "Apple", deviceModel: "iPhone16,2", osName: "iPhone", osVersion: "18.3.2.22D82" },
  },
  TV: {
    id: "85", version: "2.0",
    ua: "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    client: { clientName: "TVHTML5_SIMPLY_EMBEDDED_PLAYER", clientVersion: "2.0" },
  },
};

function ytErr(msg, noCaptions) {
  const e = new Error(msg);
  e.noCaptions = !!noCaptions;
  return e;
}

async function fetchYoutubeCaptions(videoId, wantLang, env) {
  // 🗄️ اول D1 (ماندگار و مشترک بین همه‌ی کاربرها)؛ اگر TR_DB نبود/نیافت، همان Cache API قبلی
  const d1Key = env && env.TR_DB ? await genCacheKey(`yt-captions|${videoId}|${wantLang}`, 0) : null;
  if (d1Key) {
    const raw = await genCacheGet(env, d1Key);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {}
    }
  }
  const cache = typeof caches !== "undefined" ? caches.default : null;
  const cacheKey = new Request(`https://cache.phrasebook.local/yt-captions/${encodeURIComponent(videoId)}/${encodeURIComponent(wantLang)}`);
  if (cache) {
    const hit = await cache.match(cacheKey).catch(() => null);
    if (hit) return await hit.json();
  }

  const attempts = [
    captionsViaClient("ANDROID", videoId, wantLang, 0),
    captionsViaClient("ANDROID_VR", videoId, wantLang, 0),
    captionsViaClient("IOS", videoId, wantLang, 300),
    captionsViaClient("TV", videoId, wantLang, 600),
    captionsViaWatchPage(videoId, wantLang, 900),
  ];
  let result;
  try {
    result = await Promise.any(attempts);
  } catch (agg) {
    const errs = (agg && agg.errors) || [agg];
    const noCaptions = errs.filter((e) => e && e.noCaptions).length >= 2;
    const msg = errs.map((e) => (e && e.message) || String(e)).join(" · ").slice(0, 400);
    throw ytErr(noCaptions ? "این ویدیو زیرنویس ندارد" : msg, noCaptions);
  }

  const resultJson = JSON.stringify(result);
  if (d1Key && resultJson.length < 1500000) await genCachePut(env, d1Key, resultJson, "yt");
  if (cache) {
    await cache
      .put(cacheKey, new Response(resultJson, { headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=21600" } }))
      .catch(() => {});
  }
  return result;
}

async function captionsViaClient(name, videoId, wantLang, delayMs) {
  if (delayMs) await new Promise((r) => setTimeout(r, delayMs));
  const c = YT_CLIENTS[name];
  const label = name.toLowerCase();
  const body = {
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
    context: { client: { hl: "en", gl: "US", ...c.client } },
  };
  if (name === "TV") body.context.thirdParty = { embedUrl: `https://www.youtube.com/watch?v=${videoId}` };
  const res = await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": c.ua,
      "X-YouTube-Client-Name": c.id,
      "X-YouTube-Client-Version": c.version,
      Origin: "https://www.youtube.com",
      "Accept-Language": "en-US,en;q=0.9",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw ytErr(`${label}: player HTTP ${res.status}`);
  const data = await res.json();
  return await captionsFromPlayerResponse(data, label, c.ua, wantLang, videoId);
}

async function captionsViaWatchPage(videoId, wantLang, delayMs) {
  if (delayMs) await new Promise((r) => setTimeout(r, delayMs));
  const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
  const res = await fetch(`https://www.youtube.com/watch?v=${videoId}&hl=en&has_verified=1&bpctr=9999999999`, {
    headers: { "User-Agent": ua, "Accept-Language": "en-US,en;q=0.9", Cookie: "CONSENT=YES+1; SOCS=CAI" },
  });
  if (!res.ok) throw ytErr(`watch: HTTP ${res.status}`);
  const html = await res.text();
  const jsonStr = extractJsonAfter(html, "ytInitialPlayerResponse");
  if (!jsonStr) throw ytErr("watch: player response not found");
  return await captionsFromPlayerResponse(JSON.parse(jsonStr), "watch", ua, wantLang, videoId);
}

async function captionsFromPlayerResponse(data, label, ua, wantLang, videoId) {
  const status = data?.playabilityStatus?.status || "";
  if (status !== "OK") {
    const reason = String(data?.playabilityStatus?.reason || "").slice(0, 70);
    throw ytErr(`${label}: ${status || "no playability"}${reason ? ` (${reason})` : ""}`);
  }
  const tracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  if (!tracks || !tracks.length) throw ytErr(`${label}: no caption tracks`, true);

  const track = pickCaptionTrack(tracks, wantLang);
  const clean = track.baseUrl.replace(/[&?]fmt=[^&]*/g, "");
  let cues = [];
  let why = "";
  for (const url of [`${clean}&fmt=json3`, clean]) {
    const capRes = await fetch(url, { headers: { "User-Agent": ua, "Accept-Language": "en-US,en;q=0.9" } });
    if (!capRes.ok) { why = `timedtext HTTP ${capRes.status}`; continue; }
    const text = await capRes.text();
    if (!text.trim()) { why = "timedtext empty (needs PO token?)"; continue; }
    cues = parseCaptionBody(text);
    if (cues.length) break;
    why = "timedtext unparsable";
  }
  if (!cues.length) throw ytErr(`${label}: ${why}`);

  return {
    ok: true,
    videoId,
    lang: track.languageCode,
    isAuto: track.kind === "asr",
    availableLangs: tracks.map((t) => ({
      code: t.languageCode,
      name: (t.name && t.name.simpleText) || t.languageCode,
      auto: t.kind === "asr",
    })),
    cues,
  };
}

function decodeXmlEntities(s) {
  let out = s;
  for (let i = 0; i < 2 && out.includes("&"); i++) {
    out = out
      .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
      .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");
  }
  return out;
}

// json3 یا XML (srv1: <text start dur>، srv3: <p t d>)
function parseCaptionBody(text) {
  const t = text.trim();
  if (t.startsWith("{")) {
    try {
      const j = JSON.parse(t);
      return (j.events || [])
        .filter((e) => e.segs && e.segs.length)
        .map((e) => ({
          start: Math.round(e.tStartMs || 0) / 1000,
          end: Math.round((e.tStartMs || 0) + (e.dDurationMs || 0)) / 1000,
          text: e.segs.map((s) => s.utf8 || "").join("").replace(/\n/g, " ").trim(),
        }))
        .filter((c) => c.text);
    } catch {
      /* می‌افتیم رو XML */
    }
  }
  const out = [];
  const clean = (raw) => decodeXmlEntities(raw.replace(/<[^>]+>/g, "")).replace(/\n/g, " ").trim();
  let m;
  const v3 = /<p\s+t="(\d+)"(?:\s+d="(\d+)")?[^>]*>([\s\S]*?)<\/p>/g;
  while ((m = v3.exec(t))) {
    const st = parseInt(m[1], 10), du = m[2] ? parseInt(m[2], 10) : 0, tx = clean(m[3]);
    if (tx) out.push({ start: st / 1000, end: (st + du) / 1000, text: tx });
  }
  if (out.length) return out;
  const v1 = /<text\s+start="([\d.]+)"(?:\s+dur="([\d.]+)")?[^>]*>([\s\S]*?)<\/text>/g;
  while ((m = v1.exec(t))) {
    const st = parseFloat(m[1]), du = m[2] ? parseFloat(m[2]) : 0, tx = clean(m[3]);
    if (tx) out.push({ start: st, end: st + du, text: tx });
  }
  return out;
}

function extractJsonAfter(html, marker) {
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  const start = html.indexOf("{", idx);
  if (start === -1) return null;
  let depth = 0;
  let inStr = false;
  let strCh = "";
  let esc = false;
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === strCh) inStr = false;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inStr = true;
      strCh = ch;
      continue;
    }
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return html.slice(start, i + 1);
    }
  }
  return null;
}

function pickCaptionTrack(tracks, wantLang) {
  const norm = (s) => (s || "").toLowerCase().split("-")[0];
  const want = norm(wantLang);
  // 🌍 "auto": زبانِ اصلیِ ویدیو. ترکِ خودکار (asr) همیشه به زبانِ گفتارِ ویدیو ساخته می‌شه؛
  // اگه ترکِ دستی هم به همون زبان بود اون، وگرنه خودِ asr؛ اگه asr نبود، اولین ترکِ دستی.
  if (want === "auto") {
    const asr = tracks.find((t) => t.kind === "asr");
    if (asr) {
      const spoken = norm(asr.languageCode);
      return tracks.find((t) => t.kind !== "asr" && norm(t.languageCode) === spoken) || asr;
    }
    return tracks.find((t) => t.kind !== "asr") || tracks[0];
  }
  return (
    tracks.find((t) => norm(t.languageCode) === want && t.kind !== "asr") ||
    tracks.find((t) => norm(t.languageCode) === want) ||
    tracks.find((t) => t.kind !== "asr") ||
    tracks[0]
  );
}

// --- ترجمه‌ی chunk به chunk‌ِ زیرنویس (برای حالت یوتیوبِ حباب) --------------
// ورودی: { subtitles: [متنِ هر خط], context_before: [...], context_after: [...],
//          content_title, source_language, target_language, translation_tone }
// خروجی: { ok: true, translations: [...] } — دقیقاً به تعدادِ subtitles.
// جمله‌های همسایه فقط برای فهمیدنِ معنی داده می‌شن و ترجمه نمی‌شن؛ همین باعث
// می‌شه ترجمه‌ی خط‌های نیمه‌کاره (که یوتیوب وسطِ جمله می‌بره) دقیق‌تر بشه.
async function translateSubtitleChunk(body, env, ctx, gateFn) {
  const subs = Array.isArray(body?.subtitles)
    ? body.subtitles.map((s) => (typeof s === "string" ? s : String(s?.text ?? "")).slice(0, 500))
    : [];
  if (!subs.length) throw new Error("subtitles (array) is required");
  if (subs.length > 30) throw new Error("too many subtitles in one chunk");

  const cleanList = (a) =>
    (Array.isArray(a) ? a : []).map((s) => String(s ?? "").slice(0, 300)).filter(Boolean).slice(0, 6);
  const before = cleanList(body.context_before);
  const after = cleanList(body.context_after);
  const srcName = String(body.source_language || "the source language").slice(0, 40);
  const tgtName = String(body.target_language || "").slice(0, 40);
  if (!tgtName) throw new Error("target_language is required");
  const title = String(body.content_title || "").slice(0, 160);
  const tone = String(body.translation_tone || "neutral").toLowerCase();

  let toneRule = "Use natural, neutral spoken language.";
  if (tone === "formal") toneRule = "Use a formal, polite register.";
  else if (tone === "casual") toneRule = "Use a casual, everyday spoken register.";

  const prompt =
    `You are a professional subtitle translator. Translate every subtitle line from ${srcName} to ${tgtName}.\n` +
    `Rules:\n` +
    `- Output ONLY a JSON array of exactly ${subs.length} strings, in the same order as the input. No markdown, no commentary.\n` +
    `- Item N of the output is the translation of item N of the input. Never merge or split lines, even if a sentence continues on the next line.\n` +
    `- ${toneRule}\n` +
    `- The context lines are ONLY for understanding the meaning; do NOT translate or output them.\n` +
    (title ? `\nVideo title: ${title}\n` : "\n") +
    (before.length ? `Context before (do not translate): ${JSON.stringify(before)}\n` : "") +
    `Subtitle lines to translate: ${JSON.stringify(subs)}\n` +
    (after.length ? `Context after (do not translate): ${JSON.stringify(after)}\n` : "");

  const maxTokens = Math.min(Math.max(600, subs.join("").length * 4 + 300), 4000);

  // ⚡ کشِ سمتِ سرور: همین جمله‌ها + همین زبان‌ها + همین لحن = همان ترجمه (بین همه‌ی کاربرها مشترک).
  // زمینه (جمله‌های قبل/بعد) عمداً در کلید نیست تا شانسِ hit بیشتر شود.
  // 🗄️ اول D1 (ماندگار)؛ اگر TR_DB نبود/نیافت، همان Cache API قبلی
  const cache = typeof caches !== "undefined" ? caches.default : null;
  let cacheReq = null;
  let d1Key = null;
  if (env.TR_DB) {
    try {
      d1Key = await genCacheKey(`sub-tr|${String(env.TR_MODEL_VERSION || "1") === "1" ? "" : "mv" + env.TR_MODEL_VERSION + "|"}${JSON.stringify([srcName, tgtName, tone, subs])}`, 0);
      const raw = await genCacheGet(env, d1Key);
      if (raw) {
        const arr0 = JSON.parse(raw);
        if (Array.isArray(arr0) && arr0.length === subs.length) {
          return { ok: true, provider: "cache", cached: true, translations: arr0 };
        }
      }
    } catch {}
  }
  if (cache) {
    try {
      const keyStr = JSON.stringify([srcName, tgtName, tone, subs]);
      const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyStr));
      const hex = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
      cacheReq = new Request(`https://cache.phrasebook.local/sub-tr/${hex}`);
      const hit = await cache.match(cacheReq).catch(() => null);
      if (hit) {
        const j = await hit.json();
        if (Array.isArray(j.translations) && j.translations.length === subs.length) {
          return { ok: true, provider: "cache", cached: true, translations: j.translations };
        }
      }
    } catch {
      cacheReq = null;
    }
  }

  // ⚖️ کش جواب نداشت و واقعاً به AI می‌رود → سقفِ سراسریِ روزانه
  if (gateFn) {
    const g = await gateFn();
    if (g && g.deny) {
      const err = new Error("global daily cap");
      err.gateResponse = g.deny;
      throw err;
    }
  }

  // ⚡ به‌جای امتحانِ ترتیبیِ ~۲۰ پرووایدر (هر خرابی = چند ثانیه تأخیر)، «hedged»: اولی شروع می‌شود؛
  // اگر خطا داد، فوراً بعدی؛ اگر تا hedgeMs جواب نداد، بعدی هم‌زمان (حداکثر ۳ تا هم‌زمان). اولین جوابِ معتبر برنده است.
  const chain = getProviderChain(env);
  const { provider, value: arr } = await hedgedProviders(chain, prompt, maxTokens, env, (raw) => {
    const a = parseJsonStringArray(raw);
    if (!a || a.length !== subs.length) throw new Error(`bad shape (${a ? a.length : "no array"} vs ${subs.length})`);
    return a;
  });

  if (d1Key) {
    const d1put = genCachePut(env, d1Key, JSON.stringify(arr), provider);
    if (ctx && typeof ctx.waitUntil === "function") ctx.waitUntil(d1put);
    else await d1put;
  }
  if (cache && cacheReq) {
    const put = cache
      .put(
        cacheReq,
        new Response(JSON.stringify({ translations: arr }), {
          headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=2592000" },
        })
      )
      .catch(() => {});
    if (ctx && typeof ctx.waitUntil === "function") ctx.waitUntil(put);
  }
  return { ok: true, provider, translations: arr };
}

// اولین پرووایدرِ موفق برنده است؛ بقیه‌ی درخواست‌های در حالِ اجرا نادیده گرفته می‌شوند.
function hedgedProviders(chain, prompt, maxTokens, env, validate, hedgeMs = 2500, maxInflight = 3) {
  return new Promise((resolve, reject) => {
    const errors = [];
    let next = 0;
    let inflight = 0;
    let settled = false;
    let timer = null;

    const finishFail = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error(errors.join(" | ") || "no provider available"));
    };

    const arm = () => {
      clearTimeout(timer);
      if (settled || next >= chain.length) return;
      timer = setTimeout(() => {
        if (!settled && inflight < maxInflight && next < chain.length) launch();
      }, hedgeMs);
    };

    const launch = () => {
      if (settled) return;
      if (next >= chain.length) {
        if (inflight === 0) finishFail();
        return;
      }
      const provider = chain[next++];
      inflight++;
      Promise.resolve()
        .then(() => callProvider(provider, prompt, maxTokens, env))
        .then((raw) => validate(raw))
        .then((value) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve({ provider, value });
        })
        .catch((e) => {
          errors.push(`${provider}: ${(e && e.message) || e}`);
        })
        .finally(() => {
          inflight--;
          if (settled) return;
          if (next < chain.length) launch();
          else if (inflight === 0) finishFail();
        });
      arm();
    };

    launch();
  });
}

function parseJsonStringArray(raw) {
  if (typeof raw !== "string") return null;
  const a = raw.indexOf("[");
  const b = raw.lastIndexOf("]");
  if (a === -1 || b <= a) return null;
  try {
    const arr = JSON.parse(raw.slice(a, b + 1));
    if (!Array.isArray(arr)) return null;
    return arr.map((x) => (typeof x === "string" ? x.trim() : String(x ?? "").trim()));
  } catch {
    return null;
  }
}

// --- پیدا کردنِ آی‌دیِ ویدیو از روی عنوان (جست‌وجوی innertube) -----------------
async function resolveYoutubeVideoId(title, channel, durationSec) {
  const INNERTUBE_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
  const res = await fetch(`https://www.youtube.com/youtubei/v1/search?key=${INNERTUBE_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: channel ? `${title} ${channel}` : title,
      context: { client: { clientName: "WEB", clientVersion: "2.20240401.01.00", hl: "en", gl: "US" } },
    }),
  });
  if (!res.ok) throw new Error(`search status ${res.status}`);
  const data = await res.json();

  const found = [];
  const walk = (node, depth) => {
    if (!node || depth > 14 || found.length > 40) return;
    if (Array.isArray(node)) {
      for (const n of node) walk(n, depth + 1);
      return;
    }
    if (typeof node !== "object") return;
    if (node.videoRenderer && node.videoRenderer.videoId) found.push(node.videoRenderer);
    for (const k of Object.keys(node)) walk(node[k], depth + 1);
  };
  walk(data, 0);
  if (!found.length) throw new Error("no search results");

  const norm = (s) => String(s || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  const wantTitle = norm(title);
  const wantChannel = norm(channel);
  const toSec = (t) => {
    const parts = String(t || "").split(":").map((x) => parseInt(x, 10));
    if (!parts.length || parts.some((n) => Number.isNaN(n))) return 0;
    return parts.reduce((acc, n) => acc * 60 + n, 0);
  };

  let best = null;
  let bestScore = -1;
  for (const v of found) {
    const vTitle = norm((v.title?.runs || []).map((r) => r.text).join("") || v.title?.simpleText);
    const vChannel = norm((v.ownerText?.runs || []).map((r) => r.text).join(""));
    const vSec = toSec(v.lengthText?.simpleText);
    let score = 0;
    if (vTitle === wantTitle) score += 6;
    else if (vTitle && (vTitle.includes(wantTitle) || wantTitle.includes(vTitle))) score += 3;
    if (wantChannel && vChannel && (vChannel === wantChannel || vChannel.includes(wantChannel) || wantChannel.includes(vChannel))) score += 2;
    if (durationSec > 0 && vSec > 0) {
      const diff = Math.abs(vSec - durationSec);
      if (diff <= 2) score += 5;
      else if (diff <= 6) score += 2;
      else score -= 3;
    }
    if (score > bestScore) {
      bestScore = score;
      best = v;
    }
  }
  // بدونِ هیچ نشانه‌ی قابل‌اعتمادی (عنوان یا مدت) حدس نمی‌زنیم؛ زیرنویسِ ویدیوی اشتباه بدتر از بی‌زیرنویسیه.
  if (!best || bestScore < 3) throw new Error("could not confidently match the video");
  return {
    ok: true,
    videoId: best.videoId,
    title: (best.title?.runs || []).map((r) => r.text).join("") || best.title?.simpleText || "",
    score: bestScore,
  };
}

// --- Hugging Face TTS (فارسی/عربی) -------------------------------------------
function hfTtsModelFor(lang, env) {
  if (lang === "fa") return env.HF_TTS_MODEL_FA || "facebook/mms-tts-fas";
  if (lang === "ar") return env.HF_TTS_MODEL_AR || "facebook/mms-tts-ara";
  return null;
}

function hfTtsSpaceUrlFor(lang, env) {
  if (lang === "fa") return env.HF_TTS_SPACE_FA_URL || "";
  if (lang === "ar") return env.HF_TTS_SPACE_AR_URL || "";
  return "";
}

function hfTtsConfigStatus(env, lang) {
  const spaceUrl = hfTtsSpaceUrlFor(lang, env);
  if (spaceUrl) return { mode: "custom-space", url: spaceUrl };
  if (env.HF_API_KEY) return { mode: "hf-inference", model: hfTtsModelFor(lang, env) };
  return { mode: "none (HF_API_KEY not set)" };
}

async function fetchHuggingFaceTtsAudio(text, lang, env) {
  const sanitized = String(text).slice(0, 600);
  const spaceUrl = hfTtsSpaceUrlFor(lang, env);

  if (spaceUrl) {
    const headers = { "Content-Type": "application/json" };
    if (env.HF_TTS_SPACE_TOKEN) headers.Authorization = `Bearer ${env.HF_TTS_SPACE_TOKEN}`;
    const r = await fetch(spaceUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({ text: sanitized, lang }),
    });
    if (!r.ok) {
      const snippet = (await r.text().catch(() => "")).slice(0, 160);
      throw new Error(`custom TTS service HTTP ${r.status}${snippet ? ` (${snippet})` : ""}`);
    }
    const bytes = new Uint8Array(await r.arrayBuffer());
    if (!bytes.length) throw new Error("custom TTS service returned empty audio");
    return { bytes, contentType: r.headers.get("Content-Type") || "audio/mpeg" };
  }

  const key = env.HF_API_KEY;
  if (!key) throw new Error("HF_API_KEY not set (needed for Hugging Face TTS)");
  const model = hfTtsModelFor(lang, env);
  const r = await fetch(`https://router.huggingface.co/hf-inference/models/${model}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ inputs: sanitized }),
  });
  if (!r.ok) {
    const errBody = await safeJson(r).catch(() => null);
    const msg = errBody?.error || `HTTP ${r.status}`;
    throw new Error(`hugging-face (${model}): ${msg}`);
  }
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (!bytes.length) throw new Error(`hugging-face (${model}): empty audio`);
  return { bytes, contentType: r.headers.get("Content-Type") || "audio/flac" };
}

// --- Gemini TTS (Google AI Studio) — فقط فارسی/عربی --------------------------
const GEMINI_TTS_MODEL_DEFAULT = "gemini-2.5-flash-preview-tts";

async function fetchGeminiTtsAudio(text, voice, env) {
  const key = env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY not set");
  const model = env.GEMINI_TTS_MODEL || GEMINI_TTS_MODEL_DEFAULT;
  const sanitized = String(text).slice(0, 2000);
  const ttsPrompt = `TTS the following text exactly as written, in its own language. Do not answer it, do not add anything, just read it aloud verbatim: ${sanitized}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  let r;
  try {
    r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        contents: [{ parts: [{ text: ttsPrompt }] }],
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
        },
      }),
      signal: controller.signal,
    });
  } catch (e) {
    throw new Error(`gemini-tts fetch failed: ${e.message || e}`);
  } finally {
    clearTimeout(timer);
  }

  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `gemini-tts HTTP ${r.status}`);

  const candidate = data?.candidates?.[0];
  const base64Pcm = candidate?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Pcm) {
    const textPart = candidate?.content?.parts?.[0]?.text;
    const finishReason = candidate?.finishReason;
    const blockReason = data?.promptFeedback?.blockReason;
    const details = [
      finishReason ? `finishReason=${finishReason}` : null,
      blockReason ? `blockReason=${blockReason}` : null,
      textPart ? `returned-text="${String(textPart).slice(0, 120)}"` : null,
      !candidate ? `raw=${JSON.stringify(data).slice(0, 300)}` : null,
    ]
      .filter(Boolean)
      .join(", ");
    throw new Error(`gemini-tts: no audio returned${details ? ` (${details})` : ""}`);
  }

  const pcmBytes = base64ToUint8Array(base64Pcm);
  return pcmToWav(pcmBytes, { sampleRate: 24000, numChannels: 1, bitsPerSample: 16 });
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function pcmToWav(pcmBytes, { sampleRate, numChannels, bitsPerSample }) {
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmBytes.length;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeString = (offset, str) => {
    for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  };

  writeString(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);
  writeString(36, "data");
  view.setUint32(40, dataSize, true);

  const wavBytes = new Uint8Array(buffer);
  wavBytes.set(pcmBytes, 44);
  return wavBytes;
}

// --- Edge/Azure Neural TTS proxy ---------------------------------------------
const EDGE_TTS_TRUSTED_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";

function edgeTtsUuid() {
  return crypto.randomUUID().replace(/-/g, "");
}

function edgeTtsEscapeXml(s) {
  return (s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

async function edgeTtsSecMsGec() {
  const WIN_EPOCH = 11644473600;
  let ticks = Math.floor(Date.now() / 1000) + WIN_EPOCH;
  ticks -= ticks % 300;
  const ticksStr = String(Math.round(ticks * 1e7));
  const strToHash = ticksStr + EDGE_TTS_TRUSTED_TOKEN;
  const enc = new TextEncoder().encode(strToHash);
  const hashBuf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(hashBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

// ⛔ غیرفعال: این مسیر غیررسمی است و در حجمِ بالا خطرِ بن‌شدنِ IP دارد. برای فعال‌کردنِ دوباره false را true کن.
const EDGE_TTS_ENABLED = false;

async function fetchEdgeTtsAudio(text, voice) {
  if (!EDGE_TTS_ENABLED) throw new Error("edge-tts disabled");
  const sanitized = String(text).slice(0, 600);
  const gec = await edgeTtsSecMsGec();
  const connId = edgeTtsUuid();
  const wsUrl =
    "https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
    `?TrustedClientToken=${EDGE_TTS_TRUSTED_TOKEN}` +
    `&Sec-MS-GEC=${gec}` +
    `&Sec-MS-GEC-Version=1-131.0.2903.99` +
    `&ConnectionId=${connId}`;

  const resp = await fetch(wsUrl, {
    headers: {
      Upgrade: "websocket",
      Origin: "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
    },
  });
  const ws = resp.webSocket;
  if (!ws) throw new Error("edge-tts: upstream didn't upgrade to websocket");
  ws.accept();

  return new Promise((resolve, reject) => {
    const audioParts = [];
    let settled = false;

    const finishOk = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      try {
        ws.close();
      } catch (e) {}
      if (!audioParts.length) {
        reject(new Error("edge-tts: no audio returned"));
        return;
      }
      let total = 0;
      for (const p of audioParts) total += p.length;
      const merged = new Uint8Array(total);
      let offset = 0;
      for (const p of audioParts) {
        merged.set(p, offset);
        offset += p.length;
      }
      resolve(merged);
    };
    const finishFail = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      try {
        ws.close();
      } catch (e) {}
      reject(err || new Error("edge-tts: failed"));
    };
    const timeoutId = setTimeout(() => finishFail(new Error("edge-tts: timeout")), 15000);

    ws.addEventListener("message", (evt) => {
      if (typeof evt.data === "string") {
        if (evt.data.indexOf("Path:turn.end") !== -1) finishOk();
        return;
      }
      try {
        const buf = new Uint8Array(evt.data);
        if (buf.length < 2) return;
        const headerLen = (buf[0] << 8) | buf[1];
        const headerStr = new TextDecoder("utf-8").decode(buf.slice(2, 2 + headerLen));
        if (headerStr.indexOf("Path:audio") !== -1) {
          const audioData = buf.slice(2 + headerLen);
          if (audioData.length) audioParts.push(audioData);
        }
      } catch (e) {}
    });
    ws.addEventListener("close", () => finishOk());
    ws.addEventListener("error", () => finishFail(new Error("edge-tts: websocket error")));

    try {
      const now = new Date().toISOString();
      ws.send(
        `X-Timestamp:${now}\r\n` +
          "Content-Type:application/json; charset=utf-8\r\n" +
          "Path:speech.config\r\n\r\n" +
          JSON.stringify({
            context: {
              synthesis: {
                audio: {
                  metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false },
                  outputFormat: "audio-24khz-48kbitrate-mono-mp3",
                },
              },
            },
          })
      );
      const ssml =
        `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>` +
        `<voice name='${voice}'><prosody rate='+0%'>${edgeTtsEscapeXml(sanitized)}</prosody></voice>` +
        `</speak>`;
      ws.send(
        `X-RequestId:${edgeTtsUuid()}\r\n` +
          "Content-Type:application/ssml+xml\r\n" +
          `X-Timestamp:${now}\r\n` +
          "Path:ssml\r\n\r\n" +
          ssml
      );
    } catch (e) {
      finishFail(e);
    }
  });
}

async function safeJson(r) {
  const raw = await r.text();
  try {
    return JSON.parse(raw);
  } catch {
    const snippet = raw.trim().slice(0, 120) || `HTTP ${r.status}`;
    throw new Error(`non-JSON response (${snippet})`);
  }
}

function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`timeout after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

// <think>…</think> و برچسب‌های مشابه را برمی‌دارد.
function sanitizeAiText(text) {
  return String(text || "")
    .replace(/<think(ing)?>[\s\S]*?<\/think(ing)?>/gi, "")
    .replace(/<think(ing)?>[\s\S]*$/gi, "")
    .trim();
}

// دلیلِ «این جواب نیست» — یا null اگر سالم است.
function badAiOutputReason(text, prompt) {
  const t = String(text || "").trim();
  if (!t) return "empty";
  if (/^\s*(user\s+|assistant\s+)?safety\s*:/im.test(t) || /^\s*(safe|unsafe)\s*$/im.test(t)) return "guard";
  if (/(thinking process|here'?s a thinking|analy[sz]e the (request|text|input|user)|\*\*\s*analy[sz]e|the user (wants|asks|is asking) |let me (read|think|analy[sz]e|re-?read)|<\/?think(ing)?>|^\s*(we need to|we should|we must|let'?s (craft|produce|compose|draft)))/im.test(t)) return "reasoning";
  // خودِ پرامپت برگشته؟ (۶۰ کاراکترِ اولِ پرامپت عیناً در جواب)
  const head = String(prompt || "").trim().slice(0, 60);
  if (head.length >= 40 && t.includes(head)) return "prompt-echo";
  return null;
}

const VALID_PROVIDERS = [
  "huggingface", "groq", "gemini", "deepseek", "openai", "avalai", "grok", "openrouter", "mistral", "cerebras",
  "aionlabs", "cohere", "zai", "cloudflareai", "kilocode", "llm7", "modelscope", "nvidianim", "ollamacloud", "ovhcloud", "siliconflow",
];
function getProviderChain(env) {
  const raw = (
    env.AI_PROVIDER ||
    "deepseek,kilocode,llm7,ovhcloud,groq,nvidianim,ollamacloud,cloudflareai,mistral,cohere,zai,aionlabs,modelscope,siliconflow,openrouter,cerebras,grok,gemini,huggingface"
  ).toLowerCase();
  const chain = raw
    .split(",")
    .map((p) => p.trim())
    .filter((p) => VALID_PROVIDERS.includes(p));
  return chain.length ? chain : ["openrouter"];
}

// 🎚️ زنجیره بر اساسِ نوعِ کار: story → AI_PROVIDER_STRONG، بقیه → AI_PROVIDER_LIGHT.
// متغیرِ ست‌نشده/نامعتبر = همان getProviderChain (بدونِ تغییرِ رفتار).
function getProviderChainFor(env, feature) {
  // ⚡ ویدیو کال: زنجیره‌ی جدا با مدل‌های کوچک و سریع (AI_PROVIDER_CALL)؛ ست‌نشده/نامعتبر
  // = همان زنجیره‌ی سبکِ قبلی (بدونِ تغییرِ رفتار).
  if (feature === "videocall" && env.AI_PROVIDER_CALL) {
    const chain = String(env.AI_PROVIDER_CALL)
      .toLowerCase()
      .split(",")
      .map((p) => p.trim())
      .filter((p) => VALID_PROVIDERS.includes(p));
    if (chain.length) return chain;
  }
  const raw = feature === "story" ? env.AI_PROVIDER_STRONG : env.AI_PROVIDER_LIGHT;
  if (raw) {
    const chain = String(raw)
      .toLowerCase()
      .split(",")
      .map((p) => p.trim())
      .filter((p) => VALID_PROVIDERS.includes(p));
    if (chain.length) return chain;
  }
  return getProviderChain(env);
}

async function callProvider(provider, prompt, maxTokens, env) {
  if (provider === "huggingface") return callHuggingFace(prompt, maxTokens, env);
  if (provider === "groq") return callGroq(prompt, maxTokens, env);
  if (provider === "gemini") return callGemini(prompt, maxTokens, env);
  if (provider === "deepseek") return callDeepSeek(prompt, maxTokens, env);
  if (provider === "openai") return callOpenAI(prompt, maxTokens, env);
  if (provider === "avalai") return callAvalAI(prompt, maxTokens, env);
  if (provider === "grok") return callGrok(prompt, maxTokens, env);
  if (provider === "openrouter") return callOpenRouter(prompt, maxTokens, env);
  if (provider === "mistral") return callMistral(prompt, maxTokens, env);
  if (provider === "cerebras") return callCerebras(prompt, maxTokens, env);
  if (provider === "aionlabs") return callAionLabs(prompt, maxTokens, env);
  if (provider === "cohere") return callCohere(prompt, maxTokens, env);
  if (provider === "zai") return callZai(prompt, maxTokens, env);
  if (provider === "cloudflareai") return callCloudflareAI(prompt, maxTokens, env);
  if (provider === "kilocode") return callKiloCode(prompt, maxTokens, env);
  if (provider === "llm7") return callLLM7(prompt, maxTokens, env);
  if (provider === "modelscope") return callModelScope(prompt, maxTokens, env);
  if (provider === "nvidianim") return callNvidiaNim(prompt, maxTokens, env);
  if (provider === "ollamacloud") return callOllamaCloud(prompt, maxTokens, env);
  if (provider === "ovhcloud") return callOvhCloud(prompt, maxTokens, env);
  if (provider === "siliconflow") return callSiliconFlow(prompt, maxTokens, env);
  throw new Error(`Unknown provider "${provider}"`);
}

async function callAionLabs(prompt, maxTokens, env) {
  const key = env.AIONLABS_API_KEY;
  if (!key) throw new Error("AIONLABS_API_KEY not set");
  const r = await fetch("https://api.aionlabs.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.AIONLABS_MODEL || "aion-labs/aion-3.0-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Aion Labs HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Aion Labs returned empty response");
  return text;
}

async function callCohere(prompt, maxTokens, env) {
  const key = env.COHERE_API_KEY;
  if (!key) throw new Error("COHERE_API_KEY not set");
  const r = await fetch("https://api.cohere.com/v2/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.COHERE_MODEL || "command-r7b-12-2024",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.message || `Cohere HTTP ${r.status}`);
  const parts = data?.message?.content || [];
  const text = parts.map((p) => p.text || "").join("").trim();
  if (!text) throw new Error("Cohere returned empty response");
  return text;
}

async function callZai(prompt, maxTokens, env) {
  const key = env.ZAI_API_KEY;
  if (!key) throw new Error("ZAI_API_KEY not set");
  const r = await fetch("https://api.z.ai/api/paas/v4/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.ZAI_MODEL || "glm-4.7-flash",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Z AI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Z AI returned empty response");
  return text;
}

async function callCloudflareAI(prompt, maxTokens, env) {
  const token = env.CF_API_TOKEN;
  const accountId = env.CF_ACCOUNT_ID;
  if (!token || !accountId) throw new Error("CF_API_TOKEN/CF_ACCOUNT_ID not set");
  const model = env.CF_AI_MODEL || "@cf/openai/gpt-oss-120b";
  const r = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/${model}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens,
      }),
    }
  );
  const data = await safeJson(r);
  if (!r.ok || data?.success === false) {
    const errMsg = (data?.errors || []).map((e) => e.message).join("; ");
    throw new Error(errMsg || `Cloudflare Workers AI HTTP ${r.status}`);
  }
  const text = data?.result?.response || "";
  if (!text) throw new Error("Cloudflare Workers AI returned empty response");
  return text;
}

async function callKiloCode(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.KILOCODE_API_KEY) headers.Authorization = `Bearer ${env.KILOCODE_API_KEY}`;
  const r = await fetch("https://api.kilo.ai/api/gateway/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.KILOCODE_MODEL || "openrouter/free",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Kilo Code HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Kilo Code returned empty response");
  return text;
}

async function callLLM7(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.LLM7_API_KEY) headers.Authorization = `Bearer ${env.LLM7_API_KEY}`;
  const r = await fetch("https://api.llm7.io/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.LLM7_MODEL || "gpt-oss:20b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `LLM7.io HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("LLM7.io returned empty response");
  return text;
}

async function callModelScope(prompt, maxTokens, env) {
  const key = env.MODELSCOPE_API_KEY;
  if (!key) throw new Error("MODELSCOPE_API_KEY not set");
  const r = await fetch("https://api-inference.modelscope.cn/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.MODELSCOPE_MODEL || "Qwen/Qwen3.5-35B-A3B",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `ModelScope HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("ModelScope returned empty response");
  return text;
}

async function callNvidiaNim(prompt, maxTokens, env) {
  const key = env.NVIDIA_API_KEY;
  if (!key) throw new Error("NVIDIA_API_KEY not set");
  const r = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.NVIDIA_MODEL || "meta/llama-3.3-70b-instruct",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `NVIDIA NIM HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("NVIDIA NIM returned empty response");
  return text;
}

async function callOllamaCloud(prompt, maxTokens, env) {
  const key = env.OLLAMA_API_KEY;
  if (!key) throw new Error("OLLAMA_API_KEY not set");
  const r = await fetch("https://ollama.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.OLLAMA_MODEL || "gpt-oss:120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Ollama Cloud HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Ollama Cloud returned empty response");
  return text;
}

async function callOvhCloud(prompt, maxTokens, env) {
  const headers = { "Content-Type": "application/json" };
  if (env.OVHCLOUD_API_KEY) headers.Authorization = `Bearer ${env.OVHCLOUD_API_KEY}`;
  const r = await fetch("https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: env.OVHCLOUD_MODEL || "gpt-oss-120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `OVHcloud HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OVHcloud returned empty response");
  return text;
}

async function callSiliconFlow(prompt, maxTokens, env) {
  const key = env.SILICONFLOW_API_KEY;
  if (!key) throw new Error("SILICONFLOW_API_KEY not set");
  const r = await fetch("https://api.siliconflow.cn/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.SILICONFLOW_MODEL || "Qwen/Qwen3-8B",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `SiliconFlow HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("SiliconFlow returned empty response");
  return text;
}

async function callHuggingFace(prompt, maxTokens, env) {
  const key = env.HF_API_KEY;
  if (!key) throw new Error("HF_API_KEY not set");
  const model = env.HF_MODEL || "openai/gpt-oss-120b";
  const r = await fetch("https://router.huggingface.co/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Hugging Face HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Hugging Face returned empty response");
  return text.trim();
}

async function callGroq(prompt, maxTokens, env) {
  const key = env.GROQ_API_KEY;
  if (!key) throw new Error("GROQ_API_KEY not set");
  const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.GROQ_MODEL || "openai/gpt-oss-120b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
      // gpt-oss «فکر» می‌کند و فکرش از سقفِ توکن و زمان کم می‌کند → حداقل
      ...((env.GROQ_MODEL || "openai/gpt-oss-120b").includes("gpt-oss")
        ? { reasoning_effort: "low", include_reasoning: false }
        : {}),
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Groq HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Groq returned empty response");
  return text;
}

async function callGemini(prompt, maxTokens, env) {
  const key = env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY not set");
  const model = env.GEMINI_MODEL || "gemini-3.6-flash";
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: maxTokens },
      }),
    }
  );
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Gemini HTTP ${r.status}`);
  const text = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
  if (!text) throw new Error("Gemini returned empty response");
  return text;
}

async function callDeepSeek(prompt, maxTokens, env) {
  const key = env.DEEPSEEK_API_KEY;
  if (!key) throw new Error("DEEPSEEK_API_KEY not set");
  const baseUrl = env.DEEPSEEK_BASE_URL || "https://api.deepseek.com";
  const r = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.DEEPSEEK_MODEL || "deepseek-v4.1-flash",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `DeepSeek HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("DeepSeek returned empty response");
  return text;
}

async function callOpenAI(prompt, maxTokens, env) {
  const key = env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY not set");
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `OpenAI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OpenAI returned empty response");
  return text;
}

async function callGrok(prompt, maxTokens, env) {
  const key = env.GROK_API_KEY || env.XAI_API_KEY;
  if (!key) throw new Error("GROK_API_KEY not set");
  const r = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.GROK_MODEL || "grok-3-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || data?.error || `Grok HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Grok returned empty response");
  return text;
}

async function callOpenRouter(prompt, maxTokens, env) {
  const key = env.OPENROUTER_API_KEY;
  if (!key) throw new Error("OPENROUTER_API_KEY not set");
  const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
      ...(env.OPENROUTER_SITE_URL ? { "HTTP-Referer": env.OPENROUTER_SITE_URL } : {}),
      "X-Title": "LingoLearn",
    },
    body: JSON.stringify({
      model: env.OPENROUTER_MODEL || "deepseek/deepseek-chat",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `OpenRouter HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("OpenRouter returned empty response");
  return text;
}

async function callMistral(prompt, maxTokens, env) {
  const key = env.MISTRAL_API_KEY;
  if (!key) throw new Error("MISTRAL_API_KEY not set");
  const r = await fetch("https://api.mistral.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.MISTRAL_MODEL || "mistral-small-latest",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Mistral HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Mistral returned empty response");
  return text;
}

async function callCerebras(prompt, maxTokens, env) {
  const key = env.CEREBRAS_API_KEY;
  if (!key) throw new Error("CEREBRAS_API_KEY not set");
  const r = await fetch("https://api.cerebras.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.CEREBRAS_MODEL || "llama3.1-8b",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `Cerebras HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Cerebras returned empty response");
  return text;
}

async function callAvalAI(prompt, maxTokens, env) {
  const key = env.AVALAI_API_KEY;
  if (!key) throw new Error("AVALAI_API_KEY not set");
  const r = await fetch("https://api.avalai.ir/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: env.AVALAI_MODEL || "deepseek-chat",
      messages: [{ role: "user", content: prompt }],
      max_tokens: maxTokens,
    }),
  });
  const data = await safeJson(r);
  if (!r.ok) throw new Error(data?.error?.message || `AvalAI HTTP ${r.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("AvalAI returned empty response");
  return text;
}
